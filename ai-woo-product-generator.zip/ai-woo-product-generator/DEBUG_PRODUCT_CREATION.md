# تشخيص مشكلة فشل إنشاء المنتج
## Debugging Product Creation Failure

---

## المشكلة الحالية / Current Problem

عند محاولة إنشاء منتج، تحصل على الخطأ التالي:

```json
{
  "success": false, 
  "data": {
    "message": "Failed to create product"
  }
}
```

---

## أسباب محتملة / Possible Causes

### 1. **مشكلة في الأسعار** / Price Issues
- السعر العادي (`regular_price`) غير موجود أو غير صحيح للمنتجات البسيطة
- السعر ليس رقماً أو سالباً
- سعر التخفيض أكبر من أو يساوي السعر العادي

### 2. **مشكلة في المنتجات المتغيرة** / Variable Product Issues
- منتج متغير بدون أي تنويعات (`variations`)
- تنويع بدون سعر
- خصائص (`attributes`) غير صحيحة

### 3. **مشكلة في البيانات المطلوبة** / Required Data Issues
- اسم المنتج (`name` أو `title`) مفقود
- SKU مكرر في قاعدة البيانات

### 4. **مشكلة في قاعدة البيانات** / Database Issues
- مشكلة في الاتصال بقاعدة البيانات
- صلاحيات غير كافية للكتابة

---

## كيفية تشخيص المشكلة / How to Diagnose

### الخطوة 1: تحقق من ملفات السجل / Check Log Files

#### السجل المخصص للإضافة:
```
wp-content/uploads/aiwpg-logs/aiwpg-YYYY-MM-DD.log
```

#### سجل WordPress للأخطاء:
```
wp-content/debug.log
```
(تأكد من تفعيل WP_DEBUG في `wp-config.php`)

#### سجل PHP للأخطاء:
تحقق من سجل أخطاء PHP في الخادم (موقعه يختلف حسب الإعداد)

---

### الخطوة 2: تفعيل تسجيل الأخطاء / Enable Error Logging

أضف هذه الأسطر إلى ملف `wp-config.php`:

```php
define('WP_DEBUG', true);
define('WP_DEBUG_LOG', true);
define('WP_DEBUG_DISPLAY', false);
```

---

### الخطوة 3: فحص البيانات المرسلة / Check Sent Data

افتح Developer Tools في المتصفح (F12) ثم:

1. انتقل إلى تبويب **Network**
2. حاول إنشاء منتج جديد
3. ابحث عن الطلب `aiwpg_create_product`
4. افحص البيانات المرسلة في تبويب **Payload** أو **Request**

تأكد من وجود:
```json
{
  "name": "اسم المنتج",
  "type": "simple",
  "regular_price": "99.99",
  "stock_quantity": "10"
}
```

---

### الخطوة 4: التحديثات الجديدة / New Updates

قمت بإضافة تسجيل مفصل للأخطاء في:

#### في `models/class-aiwpg-product-model.php`:
- تسجيل بيانات المنتج قبل الحفظ
- تسجيل حالة المنتج عند الفشل
- تسجيل أخطاء WooCommerce إن وجدت

#### في `controllers/class-aiwpg-products-controller.php`:
- تسجيل محاولة إنشاء المنتج
- تسجيل رمز الخطأ ورسالته
- تسجيل جميع البيانات المُرسلة

---

## الحل المقترح / Suggested Solution

### 1. حاول إنشاء منتج مرة أخرى
بعد التحديثات، حاول إنشاء منتج جديد

### 2. افحص السجلات
```powershell
# في PowerShell
Get-Content "d:\server\htdocs\Domain_project\ai-wo\wp-content\uploads\aiwpg-logs\aiwpg-$(Get-Date -Format 'yyyy-MM-dd').log" -Tail 50
```

### 3. ابحث عن رسائل الأخطاء
ابحث عن سطور تحتوي على:
- `AIWPG: Product save failed`
- `AIWPG: Product creation failed`
- `[ERROR]`

---

## مثال على رسالة خطأ مفيدة / Example Error Message

بعد التحديثات، ستحصل على معلومات مثل:

```
[2025-11-23 23:58:00] [ERROR] [products_controller] [admin] [ID:1] Product creation failed: Regular price must be a positive number | Data: {"error_code":"invalid_price","error_message":"Regular price must be a positive number","product_data":{...}}
```

---

## التحقق من صحة البيانات / Data Validation

### للمنتجات البسيطة (Simple Products):
```json
{
  "name": "اسم المنتج",             // مطلوب
  "type": "simple",                // مطلوب
  "regular_price": "99.99",        // مطلوب، رقم موجب
  "sale_price": "79.99",           // اختياري، يجب أن يكون أقل من regular_price
  "stock_quantity": "10",          // مطلوب
  "sku": "PRODUCT-001",            // اختياري، يجب أن يكون فريداً
  "description": "الوصف",          // اختياري
  "short_description": "وصف قصير" // اختياري
}
```

### للمنتجات المتغيرة (Variable Products):
```json
{
  "name": "اسم المنتج",
  "type": "variable",
  "attributes": [
    {
      "name": "Color",
      "values": ["Red", "Blue"]
    }
  ],
  "variations": [
    {
      "attributes": {"Color": "Red"},
      "regular_price": "99.99",    // مطلوب لكل تنويع
      "stock_quantity": "10",
      "sku": "PRODUCT-RED"
    }
  ]
}
```

---

## معلومات إضافية / Additional Information

### موقع ملفات السجل:
```
D:\server\htdocs\Domain_project\ai-wo\wp-content\uploads\aiwpg-logs\
```

### تحقق من وجود إضافة WooCommerce:
تأكد من أن WooCommerce مثبت ومفعل

### صلاحيات المستخدم:
تأكد من أن المستخدم الحالي لديه صلاحية `manage_woocommerce`

---

## الخطوات التالية / Next Steps

1. ✅ قم بمحاولة إنشاء منتج جديد
2. ✅ افحص ملف السجل الجديد
3. ✅ أرسل لي محتوى السجل إذا استمرت المشكلة
4. ✅ تحقق من Developer Console في المتصفح

---

## مساعدة إضافية / Additional Help

إذا استمرت المشكلة، أرسل لي:
1. محتوى ملف `aiwpg-YYYY-MM-DD.log`
2. صورة من Developer Console (F12 > Console)
3. البيانات المُرسلة (من Network tab)


