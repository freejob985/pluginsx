# 🚀 دليل الإصلاح السريع

## 🔍 Linked Products لا تظهر؟

### ✅ الحل السريع في 3 خطوات

#### الخطوة 1: افتح Console
```
اضغط F12 في المتصفح
↓
انتقل إلى تبويب Console
```

#### الخطوة 2: افتح Edit Product
```
Products List → اختر منتج → Edit
↓
انتقل إلى تبويب Linked
```

#### الخطوة 3: اقرأ الرسائل

**🟢 إذا رأيت:**
```javascript
Total products available: 15
Linked products loaded successfully
```
✅ **كل شيء يعمل!** المنتجات ستظهر في القوائم

**🟡 إذا رأيت:**
```javascript
Total products available: 0
```
⚠️ **لا توجد منتجات أخرى** - أضف منتجات في WooCommerce

**🔴 إذا رأيت:**
```javascript
AJAX error loading linked products
```
❌ **خطأ في التحميل** - راجع [دليل استكشاف الأخطاء](TROUBLESHOOTING.md)

---

## 🆕 Add Product Modal مشكلة؟

### ✅ الحل السريع في 3 خطوات

#### الخطوة 1: افتح Console
```
F12 → Console
```

#### الخطوة 2: افتح Add Product Modal
```
انقر بزر الماوس الأيمن → Add Product
أو
من قائمة السياق
```

#### الخطوة 3: أكمل النموذج واضغط Create Product

**🟢 إذا رأيت:**
```javascript
Product created with ID: 123
```
✅ **تم إنشاء المنتج بنجاح!**

**🔴 إذا رأيت:**
```javascript
AJAX error creating product
```
❌ **خطأ في الإنشاء** - تحقق من الخطوات أدناه

---

## 🔧 الإصلاحات الفورية

### 1️⃣ تحديث الصفحة
```
Ctrl + F5
```
✅ يحل 70% من المشاكل

### 2️⃣ مسح Cache
```
Ctrl + Shift + Delete → Clear Cache
```
✅ يحل مشاكل JavaScript القديم

### 3️⃣ تسجيل خروج ودخول
```
Logout → Login
```
✅ يحل مشاكل Session و Nonce

### 4️⃣ تحقق من الصلاحيات
```
يجب أن تكون Admin أو Shop Manager
```

### 5️⃣ تحقق من المنتجات
```
WooCommerce → Products
تأكد من وجود منتجات بحالة "Published"
```

---

## 📋 قائمة التحقق السريعة

قبل أي شيء، تحقق من:

- [ ] Console المتصفح مفتوح (F12)
- [ ] أنت مسجل دخول كـ Admin
- [ ] WooCommerce مفعّل
- [ ] توجد منتجات منشورة (للLinked Products)
- [ ] الصفحة محدّثة (Ctrl + F5)

---

## 🎯 أين أجد Logs؟

### Console Logs (JavaScript)
```
F12 → Console
```

### PHP Logs
```
wp-content/uploads/aiwpg-logs/aiwpg-2025-11-23.log
```

### Network Logs
```
F12 → Network → XHR
```

---

## 💡 نصيحة مهمة

**دائماً افتح Console قبل اختبار أي ميزة!**

```
F12 → Console → جرب الميزة → اقرأ الرسائل
```

الـ Logs الآن واضحة ومفصلة بالعربي والإنجليزي 🎉

---

## 🆘 لا تزال المشكلة موجودة؟

راجع [دليل استكشاف الأخطاء الكامل](TROUBLESHOOTING.md)

أو

أرسل Screenshot من Console مع وصف المشكلة 📸

---

**تم إضافة Logging شامل لسهولة التشخيص! ✨**

