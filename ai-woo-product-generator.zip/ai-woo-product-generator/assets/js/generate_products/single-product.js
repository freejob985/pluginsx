/**
 * Single Product Generation
 * Handles single product form and generation
 */

(function($) {
    'use strict';
    
    window.AIWPG = window.AIWPG || {};
    window.AIWPG.SingleProduct = {};
    
    /**
     * Initialize single product form
     */
    window.AIWPG.SingleProduct.init = function() {
        $('#single-product-form').on('submit', function(e) {
            e.preventDefault();
            
            const prompt = $('#single-prompt').val().trim();
            if (!prompt) {
                toastr.error('Please enter a product description');
                return;
            }
            
            window.AIWPG.SingleProduct.generate(prompt);
        });

        $('#single-example').on('click', function() {
            const type = window.AIWPG.GenerateProducts.selectedProductType.single;
            let example = '';
            
            if (type === 'simple') {
                example = 'سماعة بلوتوث لاسلكية فاخرة مع تقنية إلغاء الضوضاء النشطة، عمر بطارية يصل إلى 40 ساعة، جودة صوت عالية الدقة مع باس عميق، مريحة للاستخدام الطويل، متوافقة مع جميع الأجهزة';
            } else if (type === 'variable') {
                example = 'تيشيرت قطن 100% عالي الجودة، متوفر بألوان متعددة (أسود، أبيض، أزرق، رمادي، أحمر) ومقاسات مختلفة (S, M, L, XL, XXL)، تصميم عصري مريح، مناسب للاستخدام اليومي';
            } else {
                example = 'A premium wireless Bluetooth headphone with noise cancellation, 40-hour battery life, and premium sound quality.';
            }
            
            $('#single-prompt').val(example);
        });

        $('#save-single-product').on('click', function() {
            if (window.AIWPG.GenerateProducts.generatedProducts.length > 0) {
                window.AIWPG.SingleProduct.save(window.AIWPG.GenerateProducts.generatedProducts[0]);
            }
        });

        $('#cancel-single').on('click', function() {
            $('#single-preview').hide();
            $('#single-product-form')[0].reset();
            window.AIWPG.GenerateProducts.generatedProducts = [];
        });
    };
    
    /**
     * Generate single product
     */
    window.AIWPG.SingleProduct.generate = function(prompt) {
        const $button = $('#single-product-form button[type="submit"]');
        const originalText = $button.html();
        
        $button.prop('disabled', true).html('<span class="spinner is-active"></span> Generating...');
        
        $.ajax({
            url: aiwpgData.ajaxUrl,
            type: 'POST',
            data: {
                action: 'aiwpg_generate_single',
                nonce: aiwpgData.nonce,
                prompt: prompt,
                product_type: window.AIWPG.GenerateProducts.selectedProductType.single
            },
            success: function(response) {
                if (response.success) {
                    window.AIWPG.GenerateProducts.generatedProducts = [response.data.product];
                    window.AIWPG.SingleProduct.displayPreview(response.data.product);
                    toastr.success(response.data.message || 'Product generated successfully');
                } else {
                    toastr.error(response.data.message || 'Failed to generate product');
                }
            },
            error: function(xhr, status, error) {
                window.AIWPG.Common.handleAjaxError(xhr, status, error);
            },
            complete: function() {
                $button.prop('disabled', false).html(originalText);
            }
        });
    };
    
    /**
     * Display single product preview
     */
    window.AIWPG.SingleProduct.displayPreview = function(product) {
        const escapeHtml = window.AIWPG.Common.escapeHtml;
        const formatPrice = window.AIWPG.Common.formatPrice;
        const getProductTypeBadge = window.AIWPG.Common.getProductTypeBadge;
        
        const regularPrice = product.regular_price || product.price || 'N/A';
        const salePrice = product.sale_price || '';
        const priceDisplay = formatPrice(regularPrice, salePrice);
        const productTypeBadge = getProductTypeBadge(product.product_type);
        
        const html = `
            <div class="product-preview-card" style="position: relative;">
                ${productTypeBadge}
                <div class="preview-field">
                    <strong>Title:</strong>
                    <p>${escapeHtml(product.title)}</p>
                </div>
                <div class="preview-field">
                    <strong>Short Description:</strong>
                    <p>${escapeHtml(product.short_description)}</p>
                </div>
                <div class="preview-field">
                    <strong>Long Description:</strong>
                    <p>${escapeHtml(product.long_description)}</p>
                </div>
                <div class="preview-row">
                    <div class="preview-field">
                        <strong>SKU:</strong>
                        <p>${escapeHtml(product.sku)}</p>
                    </div>
                    <div class="preview-field">
                        <strong>Price:</strong>
                        <p>${priceDisplay}</p>
                    </div>
                    <div class="preview-field">
                        <strong>Stock Quantity:</strong>
                        <p>${product.stock_quantity}</p>
                    </div>
                </div>
                <div class="preview-field">
                    <strong>Categories:</strong>
                    <p>${(product.categories || []).join(', ')}</p>
                </div>
                <div class="preview-field">
                    <strong>Tags:</strong>
                    <p>${(product.tags || []).join(', ')}</p>
                </div>
            </div>
        `;
        
        $('#single-preview-content').html(html);
        $('#single-preview').slideDown();
    };
    
    /**
     * Save single product
     */
    window.AIWPG.SingleProduct.save = function(product) {
        const $button = $('#save-single-product');
        const originalText = $button.html();
        
        $button.prop('disabled', true).html('<span class="spinner is-active"></span> Saving...');
        
        $.ajax({
            url: aiwpgData.ajaxUrl,
            type: 'POST',
            data: {
                action: 'aiwpg_save_product',
                nonce: aiwpgData.nonce,
                product: JSON.stringify(product)
            },
            success: function(response) {
                if (response.success) {
                    toastr.success(response.data.message || 'Product saved successfully');
                    $('#single-preview').slideUp();
                    $('#single-product-form')[0].reset();
                    window.AIWPG.GenerateProducts.generatedProducts = [];
                } else {
                    toastr.error(response.data.message || 'Failed to save product');
                }
            },
            error: function(xhr, status, error) {
                window.AIWPG.Common.handleAjaxError(xhr, status, error);
            },
            complete: function() {
                $button.prop('disabled', false).html(originalText);
            }
        });
    };
    
})(jQuery);

