/**
 * Generate Products - Initialization
 * Initializes all generate products related modules
 */

(function($) {
    'use strict';
    
    window.AIWPG = window.AIWPG || {};
    window.AIWPG.GenerateProducts = {};
    
    // Global variables for generate products
    window.AIWPG.GenerateProducts.generatedProducts = [];
    window.AIWPG.GenerateProducts.selectedProductType = { single: 'automatic', multiple: 'automatic' };
    
    /**
     * Initialize all generate products modules
     */
    window.AIWPG.GenerateProducts.init = function() {
        if (typeof window.AIWPG.ProductTypeToggle !== 'undefined') {
            window.AIWPG.ProductTypeToggle.init();
        }
        
        if (typeof window.AIWPG.SingleProduct !== 'undefined') {
            window.AIWPG.SingleProduct.init();
        }
        
        if (typeof window.AIWPG.MultipleProducts !== 'undefined') {
            window.AIWPG.MultipleProducts.init();
        }
        
        if (typeof window.AIWPG.ExcelImport !== 'undefined') {
            window.AIWPG.ExcelImport.init();
        }
        
        if (typeof window.AIWPG.VoiceInput !== 'undefined') {
            window.AIWPG.VoiceInput.init();
        }
        
        if (typeof window.AIWPG.ImprovePrompts !== 'undefined') {
            window.AIWPG.ImprovePrompts.init();
        }
        
        if (typeof window.AIWPG.PromptTemplate !== 'undefined') {
            window.AIWPG.PromptTemplate.init();
        }
    };
    
})(jQuery);

