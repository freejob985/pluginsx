/**
 * Improve Prompts
 * AI-powered prompt improvement for product descriptions
 */

(function($) {
    'use strict';
    
    window.AIWPG = window.AIWPG || {};
    window.AIWPG.ImprovePrompts = {};
    
    /**
     * Initialize improve prompts buttons
     */
    window.AIWPG.ImprovePrompts.init = function() {
        // Improve single prompt
        $('#improve-single-prompt').on('click', function() {
            window.AIWPG.ImprovePrompts.improveSingle();
        });
        
        // Improve multiple prompts
        $('#improve-multiple-prompts').on('click', function() {
            window.AIWPG.ImprovePrompts.improveMultiple();
        });
    };
    
    /**
     * Improve single prompt with AI
     */
    window.AIWPG.ImprovePrompts.improveSingle = function() {
        const prompt = $('#single-prompt').val().trim();
        if (!prompt) {
            toastr.error('Please enter a description first');
            return;
        }
        
        const $button = $('#improve-single-prompt');
        const originalText = $button.html();
        
        $button.prop('disabled', true).html('<span class="spinner is-active"></span> Improving...');
        
        $.ajax({
            url: aiwpgData.ajaxUrl,
            type: 'POST',
            data: {
                action: 'aiwpg_improve_prompt',
                nonce: aiwpgData.nonce,
                prompt: prompt
            },
            success: function(response) {
                if (response.success) {
                    // Clean markdown from improved prompt
                    const cleanedPrompt = window.AIWPG.Common.cleanMarkdown(response.data.improved_prompt);
                    $('#single-prompt').val(cleanedPrompt);
                    toastr.success('Description improved successfully');
                } else {
                    toastr.error(response.data.message || 'Failed to improve description');
                }
            },
            error: function(xhr, status, error) {
                window.AIWPG.Common.handleAjaxError(xhr, status, error);
            },
            complete: function() {
                $button.prop('disabled', false).html(originalText);
            }
        });
    };
    
    /**
     * Improve multiple prompts with AI
     */
    window.AIWPG.ImprovePrompts.improveMultiple = function() {
        const prompts = $('#multiple-prompts').val().trim();
        if (!prompts) {
            toastr.error('Please enter descriptions first');
            return;
        }
        
        const $button = $('#improve-multiple-prompts');
        const originalText = $button.html();
        
        $button.prop('disabled', true).html('<span class="spinner is-active"></span> Improving...');
        
        $.ajax({
            url: aiwpgData.ajaxUrl,
            type: 'POST',
            data: {
                action: 'aiwpg_improve_prompt',
                nonce: aiwpgData.nonce,
                prompt: prompts,
                is_multiple: true
            },
            success: function(response) {
                if (response.success) {
                    // Clean markdown from improved prompts and preserve line structure
                    let improvedText = response.data.improved_prompt;
                    
                    // Split by lines to maintain structure
                    const lines = improvedText.split('\n');
                    const cleanedLines = lines.map(line => window.AIWPG.Common.cleanMarkdown(line.trim())).filter(line => line.length > 0);
                    
                    $('#multiple-prompts').val(cleanedLines.join('\n'));
                    toastr.success('Descriptions improved successfully');
                } else {
                    toastr.error(response.data.message || 'Failed to improve descriptions');
                }
            },
            error: function(xhr, status, error) {
                window.AIWPG.Common.handleAjaxError(xhr, status, error);
            },
            complete: function() {
                $button.prop('disabled', false).html(originalText);
            }
        });
    };
    
})(jQuery);

