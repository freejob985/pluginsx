/**
 * Voice Input (Speech Recognition)
 * Handles voice input for product descriptions
 */

(function($) {
    'use strict';
    
    window.AIWPG = window.AIWPG || {};
    window.AIWPG.VoiceInput = {};
    
    // Store speech recognition instances
    let recognitions = {};
    let voiceLanguage = 'ar-SA'; // Default language (Arabic Saudi Arabia)
    
    /**
     * Initialize voice input (Speech Recognition)
     */
    window.AIWPG.VoiceInput.init = function() {
        // Check if browser supports speech recognition
        if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
            console.warn('Speech recognition not supported in this browser');
            $('.mic-button').prop('disabled', true).attr('title', 'Speech recognition not supported');
            return;
        }
        
        // Attach click handlers to mic buttons
        $('.mic-button').on('click', function() {
            const targetId = $(this).data('target');
            window.AIWPG.VoiceInput.toggleRecognition(this, targetId);
        });
    };
    
    /**
     * Toggle speech recognition
     */
    window.AIWPG.VoiceInput.toggleRecognition = function(button, targetId) {
        const $button = $(button);
        const $textarea = $('#' + targetId);
        
        if (!$textarea.length) {
            toastr.error('Target textarea not found');
            return;
        }
        
        // Initialize recognition if not exists
        if (!recognitions[targetId]) {
            const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
            recognitions[targetId] = new SpeechRecognition();
            recognitions[targetId].continuous = true;
            recognitions[targetId].interimResults = true;
            recognitions[targetId].lang = voiceLanguage;
            
            // On result
            recognitions[targetId].onresult = function(event) {
                let finalTranscript = '';
                
                for (let i = event.resultIndex; i < event.results.length; ++i) {
                    if (event.results[i].isFinal) {
                        finalTranscript += event.results[i][0].transcript + ' ';
                    }
                }
                
                if (finalTranscript) {
                    // Add space if textarea is not empty
                    const currentValue = $textarea.val();
                    if (currentValue && !currentValue.endsWith(' ') && !currentValue.endsWith('\n')) {
                        finalTranscript = ' ' + finalTranscript;
                    }
                    
                    $textarea.val(currentValue + finalTranscript);
                    $textarea.scrollTop($textarea[0].scrollHeight);
                    $textarea.focus();
                }
            };
            
            // On end
            recognitions[targetId].onend = function() {
                $button.removeClass('recording');
                toastr.info('تم إيقاف التسجيل الصوتي');
            };
            
            // On error
            recognitions[targetId].onerror = function(event) {
                $button.removeClass('recording');
                
                let errorMessage = 'حدث خطأ في التسجيل الصوتي';
                
                switch(event.error) {
                    case 'no-speech':
                        errorMessage = 'لم يتم اكتشاف صوت';
                        break;
                    case 'audio-capture':
                        errorMessage = 'لم يتم العثور على ميكروفون';
                        break;
                    case 'not-allowed':
                        errorMessage = 'تم رفض الوصول للميكروفون';
                        break;
                }
                
                toastr.error(errorMessage);
            };
        }
        
        // Toggle recording
        if ($button.hasClass('recording')) {
            // Stop recording
            recognitions[targetId].stop();
            $button.removeClass('recording');
            toastr.info('تم إيقاف التسجيل الصوتي');
        } else {
            // Start recording
            try {
                recognitions[targetId].start();
                $button.addClass('recording');
                toastr.success('بدأ التسجيل الصوتي... تحدث الآن');
            } catch (e) {
                toastr.error('فشل بدء التسجيل الصوتي');
                console.error('Speech recognition error:', e);
            }
        }
    };
    
})(jQuery);

