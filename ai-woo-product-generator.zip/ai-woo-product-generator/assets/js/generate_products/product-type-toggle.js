/**
 * Product Type Toggle
 * Handles switching between automatic, simple, and variable product types
 */

(function($) {
    'use strict';
    
    window.AIWPG = window.AIWPG || {};
    window.AIWPG.ProductTypeToggle = {};
    
    /**
     * Initialize product type toggle
     */
    window.AIWPG.ProductTypeToggle.init = function() {
        // Initialize on page load - show automatic description by default
        $('.product-type-description span[data-type="automatic"]').show();
        
        $('.type-toggle-btn').on('click', function() {
            const $btn = $(this);
            const type = $btn.data('type');
            const $form = $btn.closest('form');
            const formId = $form.attr('id');
            
            // Update active state
            $btn.siblings('.type-toggle-btn').removeClass('active');
            $btn.addClass('active');
            
            // Update description
            const $descriptions = $btn.closest('.form-group').find('.product-type-description span');
            $descriptions.hide();
            $descriptions.filter(`[data-type="${type}"]`).show();
            
            // Store selected type
            if (formId === 'single-product-form') {
                window.AIWPG.GenerateProducts.selectedProductType.single = type;
            } else if (formId === 'multiple-products-form') {
                window.AIWPG.GenerateProducts.selectedProductType.multiple = type;
            }
            
            // Update placeholder and example based on type
            window.AIWPG.ProductTypeToggle.updatePlaceholderAndExample(formId, type);
        });
    };
    
    /**
     * Update placeholder and example based on product type
     */
    window.AIWPG.ProductTypeToggle.updatePlaceholderAndExample = function(formId, type) {
        let placeholder = '';
        
        if (formId === 'single-product-form') {
            if (type === 'simple') {
                placeholder = 'مثال: سماعة بلوتوث لاسلكية بتقنية إلغاء الضوضاء، عمر بطارية 40 ساعة، جودة صوت عالية';
            } else if (type === 'variable') {
                placeholder = 'مثال: تيشيرت قطن 100% متوفر بألوان (أسود، أبيض، أزرق) ومقاسات (S, M, L, XL, XXL)';
            } else {
                placeholder = 'e.g., A premium wireless Bluetooth headphone with noise cancellation, 40-hour battery life, and premium sound quality...';
            }
            $('#single-prompt').attr('placeholder', placeholder);
        } else if (formId === 'multiple-products-form') {
            if (type === 'simple') {
                placeholder = 'Wireless mouse | 25\nUSB-C cable 2 meters | 50\nPhone case | 100';
            } else if (type === 'variable') {
                placeholder = 'T-shirt available in colors (Black, White, Blue) and sizes (S, M, L, XL) | 50\nShoes available in sizes (38, 39, 40, 41, 42) | 30';
            } else {
                placeholder = 'Wireless Bluetooth speaker | 30\nSmartphone protective case | 100\nScreen protector tempered glass';
            }
            $('#multiple-prompts').attr('placeholder', placeholder);
        }
    };
    
})(jQuery);

