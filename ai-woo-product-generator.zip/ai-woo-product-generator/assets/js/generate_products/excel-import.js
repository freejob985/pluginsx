/**
 * Excel Import
 * Handles Excel file import and product generation from Excel
 */

(function($) {
    'use strict';
    
    window.AIWPG = window.AIWPG || {};
    window.AIWPG.ExcelImport = {};
    
    /**
     * Initialize Excel form
     */
    window.AIWPG.ExcelImport.init = function() {
        $('#excel-products-form').on('submit', function(e) {
            e.preventDefault();
            
            const fileInput = $('#excel-file')[0];
            if (!fileInput.files || fileInput.files.length === 0) {
                toastr.error('Please select an Excel file');
                return;
            }
            
            window.AIWPG.ExcelImport.processFile(fileInput.files[0]);
        });

        $('#select-all-excel').on('change', function() {
            $('#excel-preview-body').find('input[type="checkbox"]').prop('checked', this.checked);
        });

        $('#save-excel-products').on('click', function() {
            window.AIWPG.ExcelImport.save();
        });

        $('#cancel-excel').on('click', function() {
            $('#excel-preview').hide();
            $('#excel-products-form')[0].reset();
            window.AIWPG.GenerateProducts.generatedProducts = [];
        });
        
        // Initialize template download
        window.AIWPG.ExcelImport.initTemplateDownload();
    };
    
    /**
     * Process Excel file
     */
    window.AIWPG.ExcelImport.processFile = function(file) {
        const $button = $('#excel-products-form button[type="submit"]');
        const originalText = $button.html();
        
        $button.prop('disabled', true).html('<span class="spinner is-active"></span> Processing...');
        
        const reader = new FileReader();
        
        reader.onload = function(e) {
            try {
                const data = new Uint8Array(e.target.result);
                const workbook = XLSX.read(data, {type: 'array'});
                const firstSheet = workbook.Sheets[workbook.SheetNames[0]];
                const jsonData = XLSX.utils.sheet_to_json(firstSheet);
                
                if (jsonData.length === 0) {
                    toastr.error('Excel file is empty');
                    $button.prop('disabled', false).html(originalText);
                    return;
                }
                
                // Parse Excel data
                const productsData = jsonData.map(row => ({
                    description: row.ProductPrompt || row.Description || '',
                    quantity: parseInt(row.Quantity) || 10
                }));
                
                window.AIWPG.ExcelImport.generateFromExcel(productsData, $button, originalText);
                
            } catch (error) {
                toastr.error('Error reading Excel file: ' + error.message);
                $button.prop('disabled', false).html(originalText);
            }
        };
        
        reader.onerror = function() {
            toastr.error('Failed to read file');
            $button.prop('disabled', false).html(originalText);
        };
        
        reader.readAsArrayBuffer(file);
    };
    
    /**
     * Generate products from Excel data
     */
    window.AIWPG.ExcelImport.generateFromExcel = function(productsData, $button, originalText) {
        $.ajax({
            url: aiwpgData.ajaxUrl,
            type: 'POST',
            data: {
                action: 'aiwpg_generate_excel',
                nonce: aiwpgData.nonce,
                products_data: JSON.stringify(productsData)
            },
            success: function(response) {
                if (response.success) {
                    window.AIWPG.GenerateProducts.generatedProducts = response.data.products;
                    window.AIWPG.ExcelImport.displayPreview(response.data.products);
                    toastr.success(response.data.message || 'Products generated from Excel');
                } else {
                    toastr.error(response.data.message || 'Failed to generate products');
                }
            },
            error: function(xhr, status, error) {
                window.AIWPG.Common.handleAjaxError(xhr, status, error);
            },
            complete: function() {
                $button.prop('disabled', false).html(originalText);
            }
        });
    };
    
    /**
     * Display Excel products preview
     */
    window.AIWPG.ExcelImport.displayPreview = function(products) {
        const escapeHtml = window.AIWPG.Common.escapeHtml;
        const formatPriceTable = window.AIWPG.Common.formatPriceTable;
        
        let html = '';
        
        products.forEach((product, index) => {
            const regularPrice = product.regular_price || product.price || 'N/A';
            const salePrice = product.sale_price || '';
            const priceDisplay = formatPriceTable(regularPrice, salePrice);
            
            html += `
                <tr>
                    <th class="check-column">
                        <input type="checkbox" value="${index}" checked>
                    </th>
                    <td>${escapeHtml(product.title)}</td>
                    <td>${escapeHtml(product.short_description.substring(0, 100))}...</td>
                    <td>${escapeHtml(product.sku)}</td>
                    <td>${priceDisplay}</td>
                    <td>${product.stock_quantity}</td>
                    <td>${(product.categories || []).join(', ')}</td>
                </tr>
            `;
        });
        
        $('#excel-preview-body').html(html);
        $('#excel-preview').slideDown();
    };
    
    /**
     * Save Excel products
     */
    window.AIWPG.ExcelImport.save = function() {
        const selectedProducts = [];
        
        $('#excel-preview-body input[type="checkbox"]:checked').each(function() {
            const index = parseInt($(this).val());
            selectedProducts.push(window.AIWPG.GenerateProducts.generatedProducts[index]);
        });
        
        if (selectedProducts.length === 0) {
            toastr.warning('Please select at least one product to save');
            return;
        }
        
        const $button = $('#save-excel-products');
        const originalText = $button.html();
        
        $button.prop('disabled', true).html('<span class="spinner is-active"></span> Saving...');
        
        $.ajax({
            url: aiwpgData.ajaxUrl,
            type: 'POST',
            data: {
                action: 'aiwpg_save_products',
                nonce: aiwpgData.nonce,
                products: JSON.stringify(selectedProducts)
            },
            success: function(response) {
                if (response.success) {
                    toastr.success(response.data.message || 'Products saved successfully');
                    if (response.data.errors && response.data.errors.length > 0) {
                        response.data.errors.forEach(err => toastr.warning(err));
                    }
                    $('#excel-preview').slideUp();
                    $('#excel-products-form')[0].reset();
                    window.AIWPG.GenerateProducts.generatedProducts = [];
                } else {
                    toastr.error(response.data.message || 'Failed to save products');
                }
            },
            error: function(xhr, status, error) {
                window.AIWPG.Common.handleAjaxError(xhr, status, error);
            },
            complete: function() {
                $button.prop('disabled', false).html(originalText);
            }
        });
    };
    
    /**
     * Initialize template download
     */
    window.AIWPG.ExcelImport.initTemplateDownload = function() {
        $('#download-template').on('click', function(e) {
            e.preventDefault();
            
            // Create a simple Excel template
            const wb = XLSX.utils.book_new();
            const wsData = [
                ['ProductPrompt', 'Quantity'],
                ['Wireless Bluetooth headphones with noise cancellation', '25'],
                ['Gaming mouse with RGB lighting and programmable buttons', '50'],
                ['USB-C fast charging cable 2 meters', '100']
            ];
            
            const ws = XLSX.utils.aoa_to_sheet(wsData);
            XLSX.utils.book_append_sheet(wb, ws, 'Products');
            
            XLSX.writeFile(wb, 'product-template.xlsx');
            toastr.success('Template downloaded successfully');
        });
    };
    
})(jQuery);

