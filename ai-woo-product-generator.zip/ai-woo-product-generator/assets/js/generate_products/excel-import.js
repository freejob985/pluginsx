/**
 * Excel Import
 * Handles Excel/CSV file import with AI-powered enrichment
 * Uses client-side parsing (SheetJS) for Excel files
 */

(function($) {
    'use strict';
    
    window.AIWPG = window.AIWPG || {};
    window.AIWPG.ExcelImport = {};
    
    // Store processed rows
    window.AIWPG.ExcelImport.processedRows = [];
    
    /**
     * Initialize Excel form
     */
    window.AIWPG.ExcelImport.init = function() {
        $('#excel-products-form').on('submit', function(e) {
            e.preventDefault();
            
            const fileInput = $('#excel-file')[0];
            if (!fileInput.files || fileInput.files.length === 0) {
                toastr.error('Please select an Excel/CSV file');
                return;
            }
            
            const file = fileInput.files[0];
            const importMode = $('#excel-import-mode').val();
            const useAI = $('#excel-use-ai').is(':checked');
            const draftAmbiguous = $('#excel-draft-ambiguous').is(':checked');
            const aiModule = $('#excel-ai-module').val() || '';
            
            window.AIWPG.ExcelImport.uploadAndProcess(file, importMode, useAI, draftAmbiguous, aiModule);
        });

        $('#select-all-excel').on('change', function() {
            $('#excel-preview-body').find('input[type="checkbox"]').prop('checked', this.checked);
        });

        // Handle both button IDs for compatibility
        $('#confirm-excel-import, #save-excel-products').on('click', function() {
            window.AIWPG.ExcelImport.confirmImport();
        });

        $('#cancel-excel').on('click', function() {
            $('#excel-preview').hide();
            $('#excel-processing').hide();
            $('#excel-products-form')[0].reset();
            window.AIWPG.ExcelImport.processedRows = [];
        });
        
        // Initialize template download
        window.AIWPG.ExcelImport.initTemplateDownload();
        
        // Show/hide AI module selector based on AI checkbox
        $('#excel-use-ai').on('change', function() {
            if ($(this).is(':checked')) {
                $('#excel-ai-module-group').slideDown();
            } else {
                $('#excel-ai-module-group').slideUp();
            }
        });
        
        // Initialize visibility
        if ($('#excel-use-ai').is(':checked')) {
            $('#excel-ai-module-group').show();
        }
    };
    
    /**
     * Upload file and process with AI enrichment
     * Uses client-side parsing (SheetJS) for Excel files, server-side for CSV
     */
    window.AIWPG.ExcelImport.uploadAndProcess = function(file, importMode, useAI, draftAmbiguous, aiModule) {
        const $form = $('#excel-products-form');
        const $button = $form.find('button[type="submit"]');
        const originalText = $button.html();
        
        // Hide preview, show processing
        $('#excel-preview').hide();
        $('#excel-processing').show();
        $('#excel-progress').css('width', '0%');
        $('#excel-processing-status').text('Reading file...');
        
        $button.prop('disabled', true).html('<span class="spinner is-active"></span> Processing...');
        
        const fileExtension = file.name.split('.').pop().toLowerCase();
        
        // Use client-side parsing for Excel files (SheetJS already loaded)
        if (fileExtension === 'xlsx' || fileExtension === 'xls') {
            if (typeof XLSX !== 'undefined') {
                window.AIWPG.ExcelImport.parseExcelClientSide(file, importMode, useAI, draftAmbiguous, aiModule);
            } else {
                toastr.error('Excel library not loaded. Please refresh the page.');
                $('#excel-processing').hide();
                $button.prop('disabled', false).html(originalText);
            }
        } else {
            // For CSV, use server-side parsing (no library needed)
            window.AIWPG.ExcelImport.parseFileServerSide(file, importMode, useAI, draftAmbiguous, aiModule);
        }
    };
    
    /**
     * Parse Excel file on client-side using SheetJS
     */
    window.AIWPG.ExcelImport.parseExcelClientSide = function(file, importMode, useAI, draftAmbiguous, aiModule) {
        $('#excel-progress').css('width', '30%');
        $('#excel-processing-status').text('Parsing Excel file...');
        
        const reader = new FileReader();
        
        reader.onload = function(e) {
            try {
                const data = new Uint8Array(e.target.result);
                const workbook = XLSX.read(data, {type: 'array'});
                const firstSheet = workbook.Sheets[workbook.SheetNames[0]];
                const jsonData = XLSX.utils.sheet_to_json(firstSheet, {defval: ''});
                
                if (jsonData.length === 0) {
                    toastr.error('Excel file is empty');
                    $('#excel-processing').hide();
                    return;
                }
                
                $('#excel-progress').css('width', '50%');
                $('#excel-processing-status').text('Sending to server...');
                
                // Send parsed data to server for normalization
                $.ajax({
                    url: aiwpgData.ajaxUrl,
                    type: 'POST',
                    data: {
                        action: 'aiwpg_parse_excel',
                        nonce: aiwpgData.nonce,
                        parsed_data: JSON.stringify(jsonData),
                        ai_module: aiModule || ''
                    },
                    success: function(response) {
                        if (response.success) {
                            $('#excel-progress').css('width', '60%');
                            $('#excel-processing-status').text('Processing data...');
                            
                            // Step 2: AI enrichment (if enabled)
                            if (useAI && response.data.rows && response.data.rows.length > 0) {
                                window.AIWPG.ExcelImport.enrichWithAI(
                                    response.data.rows,
                                    importMode,
                                    draftAmbiguous,
                                    aiModule
                                );
                            } else {
                                // Skip AI, show preview directly
                                window.AIWPG.ExcelImport.processedRows = response.data.rows || [];
                                $('#excel-processing').hide();
                                window.AIWPG.ExcelImport.displayPreview(response.data.rows || [], importMode);
                                const $button = $('#excel-products-form button[type="submit"]');
                                $button.prop('disabled', false).html('<span class="dashicons dashicons-upload"></span> Upload and Process');
                            }
                        } else {
                            toastr.error(response.data.message || 'Failed to process file');
                            $('#excel-processing').hide();
                        }
                    },
                    error: function(xhr, status, error) {
                        window.AIWPG.Common.handleAjaxError(xhr, status, error);
                        $('#excel-processing').hide();
                    }
                });
                
            } catch (error) {
                toastr.error('Error reading Excel file: ' + error.message);
                $('#excel-processing').hide();
                const $button = $('#excel-products-form button[type="submit"]');
                $button.prop('disabled', false).html('<span class="dashicons dashicons-upload"></span> Upload and Process');
            }
        };
        
        reader.onerror = function() {
            toastr.error('Failed to read file');
            $('#excel-processing').hide();
            const $button = $('#excel-products-form button[type="submit"]');
            $button.prop('disabled', false).html('<span class="dashicons dashicons-upload"></span> Upload and Process');
        };
        
        reader.readAsArrayBuffer(file);
    };
    
    /**
     * Parse file on server-side (CSV or Excel with library)
     */
    window.AIWPG.ExcelImport.parseFileServerSide = function(file, importMode, useAI, draftAmbiguous, aiModule) {
        $('#excel-progress').css('width', '10%');
        $('#excel-processing-status').text('Uploading file...');
        
        // Create FormData
        const formData = new FormData();
        formData.append('file', file);
        formData.append('action', 'aiwpg_parse_excel');
        formData.append('nonce', aiwpgData.nonce);
        formData.append('import_mode', importMode);
        formData.append('use_ai', useAI ? '1' : '0');
        formData.append('draft_ambiguous', draftAmbiguous ? '1' : '0');
        formData.append('ai_module', aiModule || '');
        
        // Step 1: Parse file on server
        $.ajax({
            url: aiwpgData.ajaxUrl,
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            xhr: function() {
                const xhr = new window.XMLHttpRequest();
                xhr.upload.addEventListener('progress', function(e) {
                    if (e.lengthComputable) {
                        const percentComplete = 10 + (e.loaded / e.total) * 40; // 10-50% for upload
                        $('#excel-progress').css('width', percentComplete + '%');
                    }
                }, false);
                return xhr;
            },
            success: function(response) {
                if (response.success) {
                    $('#excel-progress').css('width', '50%');
                    $('#excel-processing-status').text('Processing data...');
                    
                    // Check if server-side parsing failed and suggest client-side
                    if (response.data.code === 'library_missing' && (file.name.endsWith('.xlsx') || file.name.endsWith('.xls'))) {
                        toastr.warning('Server-side Excel parsing not available. Using client-side parsing...');
                        if (typeof XLSX !== 'undefined') {
                            window.AIWPG.ExcelImport.parseExcelClientSide(file, importMode, useAI, draftAmbiguous, aiModule);
                            return;
                        }
                    }
                    
                    // Step 2: AI enrichment (if enabled)
                    if (useAI && response.data.rows && response.data.rows.length > 0) {
                        window.AIWPG.ExcelImport.enrichWithAI(
                            response.data.rows,
                            importMode,
                            draftAmbiguous,
                            aiModule
                        );
                    } else {
                        // Skip AI, show preview directly
                        window.AIWPG.ExcelImport.processedRows = response.data.rows || [];
                        $('#excel-processing').hide();
                        window.AIWPG.ExcelImport.displayPreview(response.data.rows || [], importMode);
                        const $button = $('#excel-products-form button[type="submit"]');
                        $button.prop('disabled', false).html('<span class="dashicons dashicons-upload"></span> Upload and Process');
                    }
                } else {
                    toastr.error(response.data.message || 'Failed to parse file');
                    $('#excel-processing').hide();
                    const $button = $('#excel-products-form button[type="submit"]');
                    $button.prop('disabled', false).html('<span class="dashicons dashicons-upload"></span> Upload and Process');
                }
            },
            error: function(xhr, status, error) {
                window.AIWPG.Common.handleAjaxError(xhr, status, error);
                $('#excel-processing').hide();
                const $button = $('#excel-products-form button[type="submit"]');
                $button.prop('disabled', false).html('<span class="dashicons dashicons-upload"></span> Upload and Process');
            }
        });
    };
    
    /**
     * Enrich rows with AI
     */
    window.AIWPG.ExcelImport.enrichWithAI = function(rows, importMode, draftAmbiguous, aiModule) {
        $('#excel-progress').css('width', '60%');
        $('#excel-processing-status').text('AI is analyzing products...');
        
        $.ajax({
            url: aiwpgData.ajaxUrl,
            type: 'POST',
            data: {
                action: 'aiwpg_enrich_excel_rows',
                nonce: aiwpgData.nonce,
                rows: JSON.stringify(rows),
                ai_module: aiModule || ''
            },
            success: function(response) {
                if (response.success) {
                    $('#excel-progress').css('width', '100%');
                    $('#excel-processing-status').text('Processing complete!');
                    
                    window.AIWPG.ExcelImport.processedRows = response.data.enriched || rows;
                    
                    setTimeout(function() {
                        $('#excel-processing').hide();
                        window.AIWPG.ExcelImport.displayPreview(
                            window.AIWPG.ExcelImport.processedRows,
                            importMode
                        );
                    }, 500);
                } else {
                    toastr.warning(response.data.message || 'AI enrichment failed, showing basic preview');
                    window.AIWPG.ExcelImport.processedRows = rows;
                    $('#excel-processing').hide();
                    window.AIWPG.ExcelImport.displayPreview(rows, importMode);
                }
            },
            error: function(xhr, status, error) {
                toastr.warning('AI enrichment error, showing basic preview');
                window.AIWPG.ExcelImport.processedRows = rows;
                $('#excel-processing').hide();
                window.AIWPG.ExcelImport.displayPreview(rows, importMode);
            },
            complete: function() {
                const $button = $('#excel-products-form button[type="submit"]');
                $button.prop('disabled', false).html('<span class="dashicons dashicons-upload"></span> Upload and Process');
            }
        });
    };
    
    /**
     * Display preview table with enriched data
     */
    window.AIWPG.ExcelImport.displayPreview = function(rows, importMode) {
        const escapeHtml = window.AIWPG.Common.escapeHtml;
        
        if (!rows || rows.length === 0) {
            toastr.error('No products found in file');
            return;
        }
        
        // Calculate summary stats
        const total = rows.length;
        const foodCount = rows.filter(r => r.type === 'Food').length;
        const beverageCount = rows.filter(r => r.type === 'Beverage').length;
        const addonCount = rows.filter(r => {
            const isaddon = r.isaddon === true || r.isaddon === 'true' || r.isaddon === '1' || r.isaddon === 1;
            if (!isaddon) {
                const searchText = ((r.name || '') + ' ' + (r.notes || '')).toLowerCase();
                return /extra|add-on|addon|side|topping|sauce|cheese|additional/.test(searchText);
            }
            return isaddon;
        }).length;
        
        // Count successfully processed (rows without errors)
        const successCount = rows.filter(r => !r.error).length;
        const errorCount = rows.filter(r => r.error).length;
        
        // Count AI calls (if AI was used, count enriched rows)
        const aiCallsCount = rows.filter(r => r.type || r.category || r.kitchen).length;
        
        // Update statistics display
        $('#excel-total-rows').text(total);
        $('#excel-success-count').text(successCount);
        $('#excel-error-count').text(errorCount);
        $('#excel-ai-calls').text(aiCallsCount);
        
        let summaryText = `${total} products found`;
        if (foodCount > 0 || beverageCount > 0) {
            summaryText += ` (${foodCount} Food, ${beverageCount} Beverage)`;
        }
        if (addonCount > 0) {
            summaryText += `, ${addonCount} Add-ons`;
        }
        
        $('#excel-summary-text').text(summaryText);
        
        // Build table rows
        let html = '';
        
        rows.forEach((row, index) => {
            const type = row.type || 'Food';
            const category = row.category || 'Uncategorized';
            const kitchen = row.kitchen || 'Main Kitchen';
            const price = row.baseprice || row.base_price || '0.00';
            
            // Check isaddon in multiple formats (boolean, string, number)
            let isAddon = false;
            if (row.isaddon === true || row.isaddon === 'true' || row.isaddon === '1' || row.isaddon === 1) {
                isAddon = true;
            }
            
            // Check additions column - if it has value, likely an add-on
            if (!isAddon && row.additions && row.additions.trim() !== '') {
                isAddon = true;
                row.isaddon = true;
            }
            
            // Also check name/notes/description for add-on keywords (fallback)
            if (!isAddon) {
                const searchText = ((row.name || '') + ' ' + (row.notes || '') + ' ' + (row.description || '') + ' ' + (row.additions || '')).toLowerCase();
                if (/extra|add-on|addon|side|topping|sauce|cheese|additional|supplement|optional|plus|add|إضافي|إضافة|جانبي/.test(searchText)) {
                    isAddon = true;
                    // Update row data for consistency
                    row.isaddon = true;
                }
            }
            
            const isAddonDisplay = isAddon ? 'Yes' : 'No';
            let addonGroup = '-';
            if (isAddon) {
                addonGroup = row.addongroup || row.addon_group || 'Extras';
                // If no group specified, suggest one
                if (addonGroup === '-') {
                    const nameLower = (row.name || '').toLowerCase();
                    if (nameLower.includes('pizza')) {
                        addonGroup = 'Pizza Extras';
                    } else if (nameLower.includes('burger')) {
                        addonGroup = 'Burger Add-ons';
                    } else if (nameLower.includes('salad')) {
                        addonGroup = 'Salad Toppings';
                    } else if (nameLower.includes('coffee') || nameLower.includes('drink')) {
                        addonGroup = 'Drink Extras';
                    } else {
                        addonGroup = 'Extras';
                    }
                    // Update row data
                    row.addongroup = addonGroup;
                }
            }
            
            const status = 'Ready';
            const additions = row.additions || '';
            const aiModule = row.ai_module || '';
            
            html += `
                <tr>
                    <th class="check-column">
                        <input type="checkbox" value="${index}" checked data-row-index="${index}">
                    </th>
                    <td>${escapeHtml(row.name || '')}</td>
                    <td><span class="badge badge-${type === 'Beverage' ? 'info' : 'success'}">${escapeHtml(type)}</span></td>
                    <td>${escapeHtml(category)}</td>
                    <td>${escapeHtml(kitchen)}</td>
                    <td>${escapeHtml(price)}</td>
                    <td><strong>${isAddonDisplay}</strong></td>
                    <td><strong>${escapeHtml(addonGroup)}</strong></td>
                    <td>${escapeHtml(additions)}</td>
                    <td>${escapeHtml(aiModule)}</td>
                    <td><span class="status-${status.toLowerCase()}">${status}</span></td>
                </tr>
            `;
        });
        
        $('#excel-preview-body').html(html);
        $('#excel-preview').slideDown();
        
        // Reset form button
        const $button = $('#excel-products-form button[type="submit"]');
        $button.prop('disabled', false).html('<span class="dashicons dashicons-upload"></span> Upload and Process');
    };
    
    /**
     * Confirm and import products
     */
    window.AIWPG.ExcelImport.confirmImport = function() {
        const selectedIndices = [];
        
        $('#excel-preview-body input[type="checkbox"]:checked').each(function() {
            selectedIndices.push(parseInt($(this).data('row-index')));
        });
        
        if (selectedIndices.length === 0) {
            toastr.warning('Please select at least one product to import');
            return;
        }
        
        // Convert rows to product data format for backend
        const selectedProducts = selectedIndices.map(index => {
            const row = window.AIWPG.ExcelImport.processedRows[index];
            // Convert row to product data format expected by backend
            return {
                title: row.name || '',
                short_description: row.description || '',
                description: row.description || '',
                sku: row.sku || '',
                regular_price: row.baseprice || row.base_price || '0.00',
                stock_quantity: 10,
                stock_status: 'instock',
                status: 'draft',
                categories: row.category ? [row.category] : [],
                tags: row.tags || [],
                _ai_kitchen: row.kitchen || '',
                _ai_type: row.type || 'Food',
                _ai_isaddon: row.isaddon || false,
                _ai_addongroup: row.addongroup || row.addon_group || null,
            };
        });
        
        console.log('Selected products for import:', selectedProducts);
        
        // Get import mode from the form (should still be visible)
        const importMode = $('#excel-import-mode').val() || 'create-new';
        const $button = $('#confirm-excel-import, #save-excel-products');
        const originalText = $button.html();
        
        console.log('Import mode selected:', importMode);
        
        // Warn if dry-run
        if (importMode === 'dry-run') {
            const confirmImport = confirm('You are in DRY-RUN mode. No products will be created.\n\nDo you want to change to "Create only new products" mode and continue?');
            if (confirmImport) {
                $('#excel-import-mode').val('create-new');
                // Continue with create-new mode
                const newMode = 'create-new';
                window.AIWPG.ExcelImport.performImport(selectedProducts, newMode, $button, originalText);
            } else {
                toastr.info('Import cancelled. Change import mode and try again.');
            }
            return;
        }
        
        $button.prop('disabled', true).html('<span class="spinner is-active"></span> Importing...');
        
        window.AIWPG.ExcelImport.performImport(selectedProducts, importMode, $button, originalText);
    };
    
    /**
     * Perform the actual import
     */
    window.AIWPG.ExcelImport.performImport = function(selectedProducts, importMode, $button, originalText) {
        console.log('Performing import:', {
            products_count: selectedProducts.length,
            import_mode: importMode,
            first_product: selectedProducts[0]
        });
        
        $.ajax({
            url: aiwpgData.ajaxUrl,
            type: 'POST',
            data: {
                action: 'aiwpg_save_excel_products',
                nonce: aiwpgData.nonce,
                products: JSON.stringify(selectedProducts),
                import_mode: importMode
            },
            success: function(response) {
                console.log('Import response:', response);
                
                if (response.success) {
                    const created = response.data.created || 0;
                    const updated = response.data.updated || 0;
                    const skipped = response.data.skipped_details || [];
                    const errors = response.data.errors || [];
                    
                    let message = '';
                    
                    if (created > 0) {
                        message = `✓ Successfully created ${created} product(s)`;
                        if (updated > 0) {
                            message += `, updated ${updated} product(s)`;
                        }
                        toastr.success(message);
                    } else if (updated > 0) {
                        message = `✓ Successfully updated ${updated} product(s)`;
                        toastr.success(message);
                    } else {
                        message = '⚠ No products were created or updated.';
                        toastr.warning(message);
                    }
                    
                    if (skipped.length > 0) {
                        console.info(`${skipped.length} product(s) skipped`);
                        skipped.slice(0, 3).forEach(msg => toastr.info(msg));
                    }
                    
                    if (errors.length > 0) {
                        console.error('Import errors:', errors);
                        errors.slice(0, 5).forEach(function(err) {
                            toastr.warning(err);
                        });
                        if (errors.length > 5) {
                            toastr.warning(`... and ${errors.length - 5} more errors. Check console for details.`);
                        }
                    }
                    
                    // Show detailed results
                    if (created === 0 && updated === 0) {
                        let warningMsg = 'No products were created or updated. ';
                        
                        if (skipped.length > 0) {
                            warningMsg += `${skipped.length} product(s) were skipped. `;
                        }
                        
                        if (importMode === 'create-new' || importMode === 'create-only') {
                            warningMsg += 'All selected products may already exist. Try "Create & update existing" mode.';
                        } else if (errors.length > 0) {
                            warningMsg += 'Please check the errors above and your data.';
                        } else {
                            warningMsg += 'Please check your import settings and data. Check browser console (F12) for details.';
                        }
                        
                        toastr.warning(warningMsg, 'Import Result', {timeOut: 10000});
                        
                        console.warn('Import stats:', {created, updated, skipped: skipped.length, errors: errors.length});
                        console.warn('Import mode:', importMode);
                        console.warn('Selected rows sample:', selectedRows.slice(0, 3));
                    }
                    
                    // Reset form only if products were created
                    if (created > 0 || updated > 0) {
                        setTimeout(function() {
                            if (confirm('Import completed! Would you like to view the imported products?')) {
                                window.location.href = 'admin.php?page=aiwpg-products';
                            } else {
                                $('#excel-preview').slideUp();
                                $('#excel-products-form')[0].reset();
                                window.AIWPG.ExcelImport.processedRows = [];
                            }
                        }, 2000);
                    }
                } else {
                    console.error('Import failed:', response);
                    let errorMsg = response.data.message || 'Failed to import products';
                    toastr.error(errorMsg, 'Import Error', {timeOut: 8000});
                }
            },
            error: function(xhr, status, error) {
                console.error('Import AJAX error:', {
                    status: status,
                    error: error,
                    response: xhr.responseText
                });
                
                let errorMsg = 'Network error occurred during import. ';
                if (xhr.responseText) {
                    try {
                        const errorData = JSON.parse(xhr.responseText);
                        if (errorData.data && errorData.data.message) {
                            errorMsg = errorData.data.message;
                        }
                    } catch(e) {
                        errorMsg += 'Please check your connection and try again.';
                    }
                }
                
                toastr.error(errorMsg, 'Import Error', {timeOut: 8000});
                window.AIWPG.Common.handleAjaxError(xhr, status, error);
            },
            complete: function() {
                $button.prop('disabled', false).html(originalText);
            }
        });
    };
    
    /**
     * Initialize template download
     */
    window.AIWPG.ExcelImport.initTemplateDownload = function() {
        $('#download-template').on('click', function(e) {
            e.preventDefault();
            
            // Create Excel template with new column structure
            if (typeof XLSX !== 'undefined') {
                const wb = XLSX.utils.book_new();
                const wsData = [
                    ['Product Name', 'Description', 'Base Price', 'SKU', 'Raw Category', 'Raw Tags', 'Notes', 'Additions', 'AI Module'],
                    ['Latte Coffee', 'Medium hot latte with foam', '3.50', 'LATTE-001', '', '', '', '', 'beverages'],
                    ['Margherita Pizza', 'Classic Italian pizza with tomato and mozzarella', '12.00', 'PIZZA-001', '', '', '', '', 'kitchen'],
                    ['Extra Cheese', 'Additional mozzarella cheese', '1.50', 'EXTRA-001', '', '', 'extra / add-on', 'Pizza toppings', 'kitchen'],
                    ['Caesar Salad', 'Fresh romaine lettuce with caesar dressing', '8.00', 'SALAD-001', '', '', '', '', 'food'],
                    ['Extra Fries', 'Side order of crispy fries', '2.50', 'FRIES-001', '', '', 'side dish', 'Burger sides', 'food']
                ];
                
                const ws = XLSX.utils.aoa_to_sheet(wsData);
                XLSX.utils.book_append_sheet(wb, ws, 'Products');
                
                XLSX.writeFile(wb, 'product-template.xlsx');
                toastr.success('Template downloaded successfully');
            } else {
                toastr.error('Excel library not loaded. Please refresh the page.');
            }
        });
    };
    
})(jQuery);
