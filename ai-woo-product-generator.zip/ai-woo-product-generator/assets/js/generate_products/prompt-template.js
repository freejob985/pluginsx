/**
 * Prompt Template & Quality Scoring
 * Professional templates and AI-powered quality scoring for product prompts
 */

(function($) {
    'use strict';
    
    window.AIWPG = window.AIWPG || {};
    window.AIWPG.PromptTemplate = {};
    
    /**
     * Professional prompt templates for Simple and Variable products
     */
    const templates = {
        simple: `منتج [اسم المنتج] متوفر بسعر [السعر] وبكمية [الكمية] في المخزون.

المواصفات:
- النوع: منتج بسيط
- السعر: [السعر] (السعر الأساسي: [السعر الأساسي])
- الكمية المتوفرة: [الكمية]
- حالة المخزون: متوفر
- الوزن: [الوزن] كجم
- الأبعاد: [الطول] × [العرض] × [الارتفاع] سم

الميزات:
- [ميزة 1]
- [ميزة 2]
- [ميزة 3]

الوصف التفصيلي:
[اكتب وصفاً تفصيلياً للمنتج هنا]`,

        variable: `منتج [اسم المنتج] متوفر بأشكال وأحجام متعددة.

التنويعات المتاحة:
- النوع: منتج متغير
- السمات: [اللون، الحجم، المادة]
- نطاق السعر: من [السعر الأدنى] إلى [السعر الأقصى]

التنويعات:
1. [اللون: أحمر] - [الحجم: صغير] - السعر: [السعر] - الكمية: [الكمية]
2. [اللون: أزرق] - [الحجم: متوسط] - السعر: [السعر] - الكمية: [الكمية]
3. [اللون: أخضر] - [الحجم: كبير] - السعر: [السعر] - الكمية: [الكمية]

المواصفات العامة:
- الوزن: [الوزن] كجم
- الأبعاد: [الطول] × [العرض] × [الارتفاع] سم
- المادة: [المادة]

الوصف التفصيلي:
[اكتب وصفاً تفصيلياً للمنتج وتنويعاته هنا]`,

        multiline: `[اسم المنتج الأول] | [السعر] | [الكمية]
[اسم المنتج الثاني] | [السعر] | [الكمية]
[اسم المنتج الثالث] | [السعر] | [الكمية]`
    };
    
    /**
     * Initialize template and quality scoring
     */
    window.AIWPG.PromptTemplate.init = function() {
        // Insert template buttons
        $('#insert-single-template').on('click', function() {
            window.AIWPG.PromptTemplate.insertTemplate('single');
        });
        
        $('#insert-multiple-template').on('click', function() {
            window.AIWPG.PromptTemplate.insertTemplate('multiple');
        });
        
        // Score quality buttons
        $('#score-single-quality').on('click', function() {
            window.AIWPG.PromptTemplate.scoreQuality('single');
        });
        
        $('#score-multiple-quality').on('click', function() {
            window.AIWPG.PromptTemplate.scoreQuality('multiple');
        });
    };
    
    /**
     * Insert template into textarea
     */
    window.AIWPG.PromptTemplate.insertTemplate = function(type) {
        let template;
        let targetId;
        
        if (type === 'single') {
            targetId = 'single-prompt';
            // Ask user to choose between simple or variable
            const productType = $('#single-product-type .type-option.selected').data('type');
            
            if (productType === 'variable') {
                template = templates.variable;
            } else {
                template = templates.simple;
            }
        } else {
            targetId = 'multiple-prompts';
            template = templates.multiline;
        }
        
        // Insert template
        const $textarea = $('#' + targetId);
        const currentValue = $textarea.val().trim();
        
        if (currentValue) {
            // Ask if user wants to replace or append
            if (confirm('هل تريد استبدال النص الحالي بالقالب؟\n(اضغط Cancel للإلحاق بدلاً من ذلك)')) {
                $textarea.val(template);
            } else {
                $textarea.val(currentValue + '\n\n' + template);
            }
        } else {
            $textarea.val(template);
        }
        
        // Focus on textarea
        $textarea.focus();
        
        toastr.success('تم إدراج القالب بنجاح');
    };
    
    /**
     * Score quality of prompt using AI
     */
    window.AIWPG.PromptTemplate.scoreQuality = function(type) {
        const targetId = type === 'single' ? 'single-prompt' : 'multiple-prompts';
        const scoreContainerId = type === 'single' ? 'single-quality-score' : 'multiple-quality-score';
        
        const prompt = $('#' + targetId).val().trim();
        
        if (!prompt) {
            toastr.error('الرجاء إدخال نص أولاً');
            return;
        }
        
        const $button = $('#score-' + type + '-quality');
        const originalText = $button.html();
        
        $button.prop('disabled', true).html('<span class="spinner is-active"></span> جارٍ التقييم...');
        
        $.ajax({
            url: aiwpgData.ajaxUrl,
            type: 'POST',
            data: {
                action: 'aiwpg_score_prompt_quality',
                nonce: aiwpgData.nonce,
                prompt: prompt
            },
            success: function(response) {
                if (response.success) {
                    const score = response.data.score;
                    const feedback = response.data.feedback;
                    
                    // Show score container
                    const $container = $('#' + scoreContainerId);
                    $container.fadeIn();
                    
                    // Update score
                    $container.find('.quality-percentage').text(score + '%');
                    $container.find('.quality-progress-fill').css('width', score + '%');
                    $container.find('.quality-feedback').text(feedback);
                    
                    // Set color based on score
                    const $fill = $container.find('.quality-progress-fill');
                    $fill.removeClass('low medium high');
                    
                    if (score >= 80) {
                        $fill.addClass('high');
                    } else if (score >= 50) {
                        $fill.addClass('medium');
                    } else {
                        $fill.addClass('low');
                    }
                    
                    toastr.success('تم تقييم جودة البرومبت بنجاح');
                } else {
                    toastr.error(response.data.message || 'فشل في تقييم الجودة');
                }
            },
            error: function(xhr, status, error) {
                window.AIWPG.Common.handleAjaxError(xhr, status, error);
            },
            complete: function() {
                $button.prop('disabled', false).html(originalText);
            }
        });
    };
    
})(jQuery);

