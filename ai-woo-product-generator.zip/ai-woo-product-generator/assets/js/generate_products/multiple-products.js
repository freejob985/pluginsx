/**
 * Multiple Products Generation
 * Handles multiple products form and generation
 */


(function($) {
    'use strict';
    
    window.AIWPG = window.AIWPG || {};
    window.AIWPG.MultipleProducts = {};
    
    /**
     * Initialize multiple products form
     */
    window.AIWPG.MultipleProducts.init = function() {
        $('#multiple-products-form').on('submit', function(e) {
            e.preventDefault();
            
            const prompts = $('#multiple-prompts').val().trim();
            if (!prompts) {
                toastr.error('Please enter product descriptions');
                return;
            }
            
            window.AIWPG.MultipleProducts.generate(prompts);
        });

        $('#multiple-example').on('click', function() {
            const type = window.AIWPG.GenerateProducts.selectedProductType.multiple;
            let example = '';
            
            if (type === 'simple') {
                example = 'سماعة بلوتوث محمولة | 30\nكابل USB-C بطول 2 متر | 100\nماوس لاسلكي | 50\nحامل هاتف للسيارة | 75';
            } else if (type === 'variable') {
                example = 'تيشيرت قطن متوفر بألوان (أسود، أبيض، أزرق) ومقاسات (S, M, L, XL) | 50\nحذاء رياضي متوفر بمقاسات (38, 39, 40, 41, 42, 43) | 30\nجاكيت شتوي متوفر بألوان (أسود، رمادي، بني) ومقاسات (M, L, XL, XXL) | 25';
            } else {
                example = 'Wireless Bluetooth speaker | 30\nSmartphone protective case | 100\nScreen protector tempered glass';
            }
            
            $('#multiple-prompts').val(example);
        });

        $('#select-all-multiple').on('change', function() {
            $('#multiple-preview-body').find('input[type="checkbox"]').prop('checked', this.checked);
        });

        $('#save-multiple-products').on('click', function() {
            window.AIWPG.MultipleProducts.save();
        });

        $('#cancel-multiple').on('click', function() {
            $('#multiple-preview').hide();
            $('#multiple-products-form')[0].reset();
            window.AIWPG.GenerateProducts.generatedProducts = [];
        });
    };
    
    /**
     * Generate multiple products
     */
    window.AIWPG.MultipleProducts.generate = function(prompts) {
        const $button = $('#multiple-products-form button[type="submit"]');
        const originalText = $button.html();
        
        $button.prop('disabled', true).html('<span class="spinner is-active"></span> Generating...');
        
        $.ajax({
            url: aiwpgData.ajaxUrl,
            type: 'POST',
            data: {
                action: 'aiwpg_generate_multiple',
                nonce: aiwpgData.nonce,
                prompts: prompts,
                product_type: window.AIWPG.GenerateProducts.selectedProductType.multiple
            },
            success: function(response) {
                if (response.success) {
                    window.AIWPG.GenerateProducts.generatedProducts = response.data.products;
                    window.AIWPG.MultipleProducts.displayPreview(response.data.products);
                    toastr.success(response.data.message || 'Products generated successfully');
                } else {
                    toastr.error(response.data.message || 'Failed to generate products');
                }
            },
            error: function(xhr, status, error) {
                window.AIWPG.Common.handleAjaxError(xhr, status, error);
            },
            complete: function() {
                $button.prop('disabled', false).html(originalText);
            }
        });
    };
    
    /**
     * Display multiple products preview
     */
    window.AIWPG.MultipleProducts.displayPreview = function(products) {
        const escapeHtml = window.AIWPG.Common.escapeHtml;
        const formatPriceTable = window.AIWPG.Common.formatPriceTable;
        
        let html = '';
        
        products.forEach((product, index) => {
            const regularPrice = product.regular_price || product.price || 'N/A';
            const salePrice = product.sale_price || '';
            const priceDisplay = formatPriceTable(regularPrice, salePrice);
            
            html += `
                <tr>
                    <th class="check-column">
                        <input type="checkbox" value="${index}" checked>
                    </th>
                    <td>${escapeHtml(product.title)}</td>
                    <td>${escapeHtml(product.short_description.substring(0, 100))}...</td>
                    <td>${escapeHtml(product.sku)}</td>
                    <td>${priceDisplay}</td>
                    <td>${product.stock_quantity}</td>
                    <td>${(product.categories || []).join(', ')}</td>
                </tr>
            `;
        });
        
        $('#multiple-preview-body').html(html);
        $('#multiple-preview').slideDown();
    };
    
    /**
     * Save multiple products
     */
    window.AIWPG.MultipleProducts.save = function() {
        const selectedProducts = [];
        
        $('#multiple-preview-body input[type="checkbox"]:checked').each(function() {
            const index = parseInt($(this).val());
            selectedProducts.push(window.AIWPG.GenerateProducts.generatedProducts[index]);
        });
        
        if (selectedProducts.length === 0) {
            toastr.warning('Please select at least one product to save');
            return;
        }
        
        const $button = $('#save-multiple-products');
        const originalText = $button.html();
        
        $button.prop('disabled', true).html('<span class="spinner is-active"></span> Saving...');
        
        $.ajax({
            url: aiwpgData.ajaxUrl,
            type: 'POST',
            data: {
                action: 'aiwpg_save_products',
                nonce: aiwpgData.nonce,
                products: JSON.stringify(selectedProducts)
            },
            success: function(response) {
                if (response.success) {
                    toastr.success(response.data.message || 'Products saved successfully');
                    if (response.data.errors && response.data.errors.length > 0) {
                        response.data.errors.forEach(err => toastr.warning(err));
                    }
                    $('#multiple-preview').slideUp();
                    $('#multiple-products-form')[0].reset();
                    window.AIWPG.GenerateProducts.generatedProducts = [];
                } else {
                    toastr.error(response.data.message || 'Failed to save products');
                }
            },
            error: function(xhr, status, error) {
                window.AIWPG.Common.handleAjaxError(xhr, status, error);
            },
            complete: function() {
                $button.prop('disabled', false).html(originalText);
            }
        });
    };
    
})(jQuery);

