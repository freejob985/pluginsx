/**
 * AI Woo Product Generator - Main Initialization
 * Handles all AJAX operations, SweetAlert confirmations, Toastr notifications,
 * search, autocomplete, modals, and pagination
 * 
 * Dependencies:
 * - jQuery 3.x
 * - SweetAlert2 11.x
 * - Toastr 2.1.4
 * - SheetJS (XLSX) 0.20.0
 * 
 * Make sure all dependencies are loaded before this script!
 */

(function($) {
    'use strict';
    
    // Verify dependencies
    if (typeof jQuery === 'undefined') {
        console.error('AIWPG Error: jQuery is not loaded!');
        return;
    }
    
    if (typeof Swal === 'undefined') {
        console.warn('AIWPG Warning: SweetAlert2 is not loaded! Delete functions will not work.');
    }
    
    if (typeof toastr === 'undefined') {
        console.warn('AIWPG Warning: Toastr is not loaded! Notifications will not work.');
    }
    
    if (typeof XLSX === 'undefined') {
        console.warn('AIWPG Warning: XLSX is not loaded! Excel import/export will not work.');
    }
    
    console.log('✅ AIWPG: Admin JavaScript initialized successfully');
    
    /**
     * Initialize on document ready
     */
    $(document).ready(function() {
        // Initialize shared modules
        if (typeof window.AIWPG.Tabs !== 'undefined') {
            window.AIWPG.Tabs.init();
        }
        
        if (typeof window.AIWPG.Modals !== 'undefined') {
            window.AIWPG.Modals.init();
        }
        
        if (typeof window.AIWPG.ContextMenu !== 'undefined') {
            window.AIWPG.ContextMenu.init();
        }
        
        // Initialize page-specific modules
        if (typeof window.AIWPG.GenerateProducts !== 'undefined') {
            window.AIWPG.GenerateProducts.init();
        }
        
        if (typeof window.AIWPG.ProductsList !== 'undefined') {
            window.AIWPG.ProductsList.init();
        }
        
        if (typeof window.AIWPG.Settings !== 'undefined') {
            window.AIWPG.Settings.init();
        }
        
        if (typeof window.AIWPG.AddonsTab !== 'undefined') {
            window.AIWPG.AddonsTab.init();
        }
    });
    
})(jQuery);


