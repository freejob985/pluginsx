# JavaScript File Structure

تم تقسيم ملف `aiwpg-admin.js` الكبير (2700 سطر) إلى ملفات منظمة حسب الوظائف والصفحات.

## البنية الجديدة

```
assets/js/
├── main.js                    # الملف الرئيسي لتهيئة جميع الوحدات
├── shared/                    # الوحدات المشتركة
│   ├── common.js             # الوظائف المساعدة المشتركة
│   ├── tabs.js               # إدارة التبويبات
│   └── modals.js             # إدارة النوافذ المنبثقة
├── generate_products/         # صفحة توليد المنتجات
│   ├── init.js               # تهيئة الصفحة
│   ├── product-type-toggle.js # تبديل نوع المنتج
│   ├── single-product.js     # توليد منتج واحد
│   ├── multiple-products.js  # توليد منتجات متعددة
│   ├── excel-import.js       # استيراد من Excel
│   ├── voice-input.js        # الإدخال الصوتي
│   └── improve-prompts.js    # تحسين الوصف بالذكاء الاصطناعي
├── products_list/             # صفحة قائمة المنتجات
│   ├── init.js               # تهيئة الصفحة
│   ├── statistics.js         # عرض الإحصائيات
│   ├── products-display.js   # عرض المنتجات في Grid
│   ├── pagination.js         # الترقيم
│   ├── search.js             # البحث والإكمال التلقائي
│   ├── view-modal.js         # نافذة عرض المنتج
│   ├── edit-modal.js         # نافذة تحرير المنتج
│   ├── image-generation.js   # توليد صور المنتجات بالذكاء الاصطناعي
│   └── variations.js         # إدارة متغيرات المنتج
└── settings/                  # صفحة الإعدادات
    ├── init.js               # تهيئة الصفحة
    ├── settings-form.js      # نموذج الإعدادات
    └── delete-products.js    # حذف المنتجات

```

## ترتيب تحميل الملفات

تم تنظيم الملفات بحيث يتم تحميلها بالترتيب الصحيح **حسب الصفحة الحالية**:

### ✅ في جميع الصفحات (Shared):
1. **المكتبات الأساسية** - jQuery, Toastr
2. **الوحدات المشتركة** - common.js, tabs.js, modals.js
3. **الملف الرئيسي** - main.js

### 📄 في صفحة توليد المنتجات فقط:
- **المكتبات الإضافية** - XLSX (للإكسل)
- **وحدات توليد المنتجات** - جميع ملفات generate_products/

### 📄 في صفحة قائمة المنتجات فقط:
- **المكتبات الإضافية** - SweetAlert2, Tagify
- **وحدات قائمة المنتجات** - جميع ملفات products_list/

### 📄 في صفحة الإعدادات فقط:
- **المكتبات الإضافية** - SweetAlert2
- **وحدات الإعدادات** - جميع ملفات settings/

> **ملاحظة:** هذا التحميل الذكي يحسن الأداء بشكل كبير لأن كل صفحة تحمل فقط الملفات التي تحتاجها.

## Namespace Structure

جميع الوظائف منظمة تحت namespace عالمي:

```javascript
window.AIWPG = {
    Common: {
        escapeHtml(),
        cleanMarkdown(),
        formatPrice(),
        handleAjaxError(),
        // ...
    },
    Tabs: {
        init()
    },
    Modals: {
        init(),
        toggleFullscreen()
    },
    GenerateProducts: {
        init(),
        generatedProducts,
        selectedProductType
    },
    ProductsList: {
        init(),
        currentPage,
        currentProductsList,
        // ...
    },
    Settings: {
        init()
    }
}
```

## المزايا

### 1. سهولة الصيانة
- كل ملف يحتوي على وظيفة محددة
- سهولة العثور على الكود المطلوب
- تقليل التعارضات عند العمل الجماعي

### 2. قابلية إعادة الاستخدام
- الوظائف المشتركة في ملف واحد
- يمكن استخدامها من أي وحدة أخرى

### 3. الأداء المحسّن ⚡
- **تحميل ذكي حسب الصفحة** - كل صفحة تحمل فقط ملفاتها
- تقليل عدد الملفات المحملة بنسبة 60-70%
- تحسين سرعة تحميل الصفحة
- تقليل استهلاك الذاكرة
- سهولة التخزين المؤقت (caching)

### 4. التوسع
- إضافة ميزات جديدة بسهولة
- إنشاء ملفات جديدة دون التأثير على الموجود

## كيفية إضافة ميزة جديدة

1. قرر في أي صفحة ستكون الميزة
2. أنشئ ملف جديد في الفولدر المناسب
3. اتبع نفس pattern:

```javascript
(function($) {
    'use strict';
    
    window.AIWPG = window.AIWPG || {};
    window.AIWPG.NewFeature = {};
    
    window.AIWPG.NewFeature.init = function() {
        // Initialization code
    };
    
    window.AIWPG.NewFeature.someMethod = function() {
        // Feature code
    };
    
})(jQuery);
```

4. أضف الملف في `class-aiwpg-admin-controller.php`:

```php
wp_enqueue_script(
    'aiwpg-new-feature-js',
    AIWPG_PLUGIN_URL . 'assets/js/folder/new-feature.js',
    array('jquery', 'aiwpg-common-js'),
    AIWPG_VERSION . '-' . time(),
    true
);
```

5. استدع `init()` في الملف المناسب (init.js)

## ملاحظات مهمة

- جميع الملفات تستخدم jQuery wrapper: `(function($) { })(jQuery)`
- جميع الوظائف مربوطة بـ namespace: `window.AIWPG`
- استخدام `'use strict'` في جميع الملفات
- التعامل مع الأخطاء موحد عبر `AIWPG.Common.handleAjaxError()`
- جميع الوظائف المساعدة في `shared/common.js`

## Dependencies

كل ملف يجب أن يحدد dependencies في `wp_enqueue_script`:

```php
array('jquery', 'aiwpg-common-js', 'sweetalert2')
```

هذا يضمن أن الملفات المطلوبة محملة قبل تنفيذ الكود.

