/**
 * Pagination
 * Handles products pagination
 */

(function($) {
    'use strict';
    
    window.AIWPG = window.AIWPG || {};
    window.AIWPG.Pagination = {};
    
    /**
     * Display pagination
     */
    window.AIWPG.Pagination.display = function(totalPages, currentPageNum) {
        if (totalPages <= 1) {
            $('#products-pagination').html('');
            return;
        }
        
        let html = '<div class="pagination-info">';
        html += '<span class="pagination-label">Page</span> ';
        html += '<span class="pagination-current">' + currentPageNum + '</span>';
        html += ' <span class="pagination-separator">of</span> ';
        html += '<span class="pagination-total">' + totalPages + '</span>';
        html += '</div>';
        
        html += '<div class="pagination-wrapper">';
        
        // First and Previous buttons
        if (currentPageNum > 1) {
            html += `<button class="button page-btn page-btn-nav" data-page="1" title="First page">
                        <span class="dashicons dashicons-controls-skipback"></span>
                     </button>`;
            html += `<button class="button page-btn page-btn-nav" data-page="${currentPageNum - 1}" title="Previous page">
                        <span class="dashicons dashicons-arrow-left-alt2"></span>
                     </button>`;
        }
        
        // Page numbers with smart ellipsis
        let startPage = Math.max(1, currentPageNum - 2);
        let endPage = Math.min(totalPages, currentPageNum + 2);
        
        // Always show first page
        if (startPage > 1) {
            html += `<button class="button page-btn" data-page="1">1</button>`;
            if (startPage > 2) {
                html += '<span class="pagination-dots">⋯</span>';
            }
        }
        
        // Page numbers around current
        for (let i = startPage; i <= endPage; i++) {
            if (i === currentPageNum) {
                html += `<button class="button page-btn active" data-page="${i}">${i}</button>`;
            } else {
                html += `<button class="button page-btn" data-page="${i}">${i}</button>`;
            }
        }
        
        // Always show last page
        if (endPage < totalPages) {
            if (endPage < totalPages - 1) {
                html += '<span class="pagination-dots">⋯</span>';
            }
            html += `<button class="button page-btn" data-page="${totalPages}">${totalPages}</button>`;
        }
        
        // Next and Last buttons
        if (currentPageNum < totalPages) {
            html += `<button class="button page-btn page-btn-nav" data-page="${currentPageNum + 1}" title="Next page">
                        <span class="dashicons dashicons-arrow-right-alt2"></span>
                     </button>`;
            html += `<button class="button page-btn page-btn-nav" data-page="${totalPages}" title="Last page">
                        <span class="dashicons dashicons-controls-skipforward"></span>
                     </button>`;
        }
        
        html += '</div>';
        
        $('#products-pagination').html(html);
        
        // Attach event handlers
        $('.page-btn').on('click', function() {
            const page = $(this).data('page');
            window.AIWPG.ProductsList.currentPage = page;
            window.AIWPG.ProductsDisplay.load(page);
            
            // Scroll to top of products grid
            $('html, body').animate({
                scrollTop: $('#products-container').offset().top - 100
            }, 400);
        });
    };
    
})(jQuery);

