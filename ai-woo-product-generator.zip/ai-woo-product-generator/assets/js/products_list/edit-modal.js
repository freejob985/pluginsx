/**
 * Edit Product Modal
 * Handles editing product details with advanced features
 */

(function($) {
    'use strict';
    
    window.AIWPG = window.AIWPG || {};
    window.AIWPG.EditModal = {};
    
    // Media frame variables (persist across function calls)
    let productImageFrame;
    let galleryImageFrame;
    
    /**
     * Initialize edit modal
     */
    window.AIWPG.EditModal.init = function() {
        // Save product edit
        $('#save-product-edit').on('click', function() {
            window.AIWPG.EditModal.save();
        });
        
        // Improve field buttons in Edit Modal
        $(document).on('click', '.improve-field-btn', function() {
            const fieldId = $(this).data('field');
            window.AIWPG.EditModal.improveField(fieldId);
        });
        
        // Manage stock toggle
        $(document).on('change', '#edit-manage-stock', function() {
            if ($(this).is(':checked')) {
                $('.stock-quantity-group').slideDown();
            } else {
                $('.stock-quantity-group').slideUp();
            }
        });
        
        // Previous product button
        $('#prev-product-btn').on('click', function() {
            if (window.AIWPG.ProductsList.currentEditingProductIndex > 0) {
                const prevProduct = window.AIWPG.ProductsList.currentProductsList[window.AIWPG.ProductsList.currentEditingProductIndex - 1];
                if (prevProduct) {
                    window.AIWPG.EditModal.edit(prevProduct.id);
                }
            }
        });
        
        // Next product button
        $('#next-product-btn').on('click', function() {
            if (window.AIWPG.ProductsList.currentEditingProductIndex < window.AIWPG.ProductsList.currentProductsList.length - 1) {
                const nextProduct = window.AIWPG.ProductsList.currentProductsList[window.AIWPG.ProductsList.currentEditingProductIndex + 1];
                if (nextProduct) {
                    window.AIWPG.EditModal.edit(nextProduct.id);
                }
            }
        });
        
        // Arrow keys for Previous/Next navigation in Edit Product modal
        $(document).on('keydown', function(e) {
            // Only work if Edit Product modal is active
            if (!$('#edit-product-modal').hasClass('active')) {
                return;
            }
            
            // Don't trigger if user is typing in an input/textarea
            if ($(e.target).is('input, textarea, select')) {
                return;
            }
            
            // Left Arrow - Previous Product
            if (e.key === 'ArrowLeft' || e.keyCode === 37) {
                e.preventDefault();
                if (!$('#prev-product-btn').prop('disabled')) {
                    $('#prev-product-btn').click();
                } else {
                    toastr.info('لا يوجد منتج سابق');
                }
            }
            
            // Right Arrow - Next Product
            if (e.key === 'ArrowRight' || e.keyCode === 39) {
                e.preventDefault();
                if (!$('#next-product-btn').prop('disabled')) {
                    $('#next-product-btn').click();
                } else {
                    toastr.info('لا يوجد منتج تالي');
                }
            }
        });
        
        // Context menu for Edit Product modal
        window.AIWPG.EditModal.initContextMenu();
        
        // Media upload buttons
        window.AIWPG.EditModal.initMediaUpload();
    };
    
    /**
     * Edit product (modal)
     */
    window.AIWPG.EditModal.edit = function(productId) {
        console.log('🎯 Opening edit modal for product ID:', productId);
        
        // Find product index in current list
        window.AIWPG.ProductsList.currentEditingProductIndex = window.AIWPG.ProductsList.currentProductsList.findIndex(p => p.id == productId);
        
        $.ajax({
            url: aiwpgData.ajaxUrl,
            type: 'POST',
            data: {
                action: 'aiwpg_get_product',
                nonce: aiwpgData.nonce,
                product_id: productId
            },
            success: function(response) {
                if (response.success) {
                    const product = response.data.product;
                    console.log('✅ Product data loaded:', product);
                    
                    // Reset to General tab
                    $('.tab-btn').removeClass('active');
                    $('.tab-btn[data-tab="general"]').addClass('active');
                    $('.tab-content').removeClass('active');
                    $('.tab-content[data-tab="general"]').addClass('active');
                    
                    // General Tab
                    $('#edit-product-id').val(product.id);
                    $('#edit-title').val(product.title);
                    $('#edit-sku').val(product.sku);
                    $('#edit-regular-price').val(product.regular_price || product.price);
                    $('#edit-sale-price').val(product.sale_price || '');
                    $('#edit-short-description').val(product.short_description);
                    $('#edit-long-description').val(product.long_description);
                    
                    // Inventory Tab
                    $('#edit-manage-stock').prop('checked', product.manage_stock || false);
                    $('#edit-stock-quantity').val(product.stock_quantity);
                    $('#edit-stock-status').val(product.stock_status);
                    $('#edit-low-stock-threshold').val(product.low_stock_threshold || '');
                    $('#edit-sold-individually').prop('checked', product.sold_individually || false);
                    
                    // Show/hide stock quantity based on manage_stock
                    if (product.manage_stock) {
                        $('.stock-quantity-group').show();
                    } else {
                        $('.stock-quantity-group').hide();
                    }
                    
                    // Shipping Tab
                    $('#edit-weight').val(product.weight || '');
                    $('#edit-length').val(product.length || '');
                    $('#edit-width').val(product.width || '');
                    $('#edit-height').val(product.height || '');
                    $('#edit-shipping-class').val(product.shipping_class || '');
                    
                    // Linked Products Tab - Clear first (important!)
                    console.log('🧹 Clearing linked products selects...');
                    $('#edit-upsell-ids').empty().html('<option value="">جاري التحميل...</option>');
                    $('#edit-cross-sell-ids').empty().html('<option value="">جاري التحميل...</option>');
                    
                    // Media Tab
                    if (product.image_url) {
                        $('#edit-product-image-preview img').attr('src', product.image_url).show();
                        $('#edit-product-image-preview .remove-image').show();
                    } else {
                        $('#edit-product-image-preview img').hide();
                        $('#edit-product-image-preview .remove-image').hide();
                    }
                    $('#edit-product-image-id').val(product.image_id || '');
                    
                    // Gallery
                    if (product.gallery_ids && product.gallery_ids.length > 0) {
                        window.AIWPG.EditModal.loadGalleryImages(product.gallery_ids);
                    } else {
                        $('#edit-gallery-preview').html('');
                    }
                    $('#edit-gallery-ids').val(product.gallery_ids ? product.gallery_ids.join(',') : '');
                    
                    // Variations Tab
                    if (product.variations && product.variations.length > 0) {
                        if (typeof window.AIWPG.Variations !== 'undefined') {
                            window.AIWPG.Variations.display(product.variations);
                        }
                    } else {
                        $('#edit-variations-list').html('<p style="color: #646970; text-align: center;">No variations available</p>');
                    }
                    
                    // Settings Tab
                    $('#edit-status').val(product.status || 'publish');
                    $('#edit-catalog-visibility').val(product.catalog_visibility || 'visible');
                    $('#edit-featured').prop('checked', product.featured || false);
                    $('#edit-menu-order').val(product.menu_order || 0);
                    $('#edit-reviews-allowed').prop('checked', product.reviews_allowed !== false);
                    
                    // Load categories and tags
                    window.AIWPG.EditModal.loadCategoriesSelect(product.categories || []);
                    window.AIWPG.EditModal.initializeTagify(product.tags || []);
                    
                    // Load linked products using new system
                    console.log('🔗 Loading linked products with new system...');
                    setTimeout(function() {
                        if (typeof window.AIWPG.LinkedProducts !== 'undefined') {
                            window.AIWPG.LinkedProducts.load(
                                product.id,
                                product.upsell_ids || [],
                                product.cross_sell_ids || []
                            );
                        } else {
                            console.warn('⚠️ LinkedProducts module not loaded');
                        }
                    }, 300);
                    
                    // Update navigation buttons
                    window.AIWPG.EditModal.updateNavigationButtons();
                    
                    // Show modal
                    $('#edit-product-modal').addClass('active');
                    console.log('✅ Edit modal opened successfully');
                } else {
                    console.error('❌ Failed to load product');
                    toastr.error('Failed to load product');
                }
            },
            error: function(xhr, status, error) {
                console.error('❌ AJAX error:', {xhr, status, error});
                toastr.error('خطأ في تحميل بيانات المنتج');
            }
        });
    };
    
    /**
     * Save product edit
     */
    window.AIWPG.EditModal.save = function() {
        // Get selected categories
        const selectedCategories = $('#edit-categories').val() || [];
        
        // Get tags from Tagify
        let tags = [];
        if (window.tagifyInstance) {
            tags = window.tagifyInstance.value.map(tag => tag.value);
        }
        
        // Get linked products from new system
        let upsellIds = [];
        let crossSellIds = [];
        
        if (typeof window.AIWPG.LinkedProducts !== 'undefined') {
            const linkedData = window.AIWPG.LinkedProducts.getValues();
            upsellIds = linkedData.upsells || [];
            crossSellIds = linkedData.crossSells || [];
        } else {
            // Fallback to hidden inputs
            const upsellsVal = $('#edit-upsell-ids').val();
            const crossSellsVal = $('#edit-cross-sell-ids').val();
            
            upsellIds = upsellsVal ? upsellsVal.split(',').map(id => parseInt(id)).filter(id => id) : [];
            crossSellIds = crossSellsVal ? crossSellsVal.split(',').map(id => parseInt(id)).filter(id => id) : [];
        }
        
        console.log('💾 Saving linked products:', {upsellIds, crossSellIds});
        
        // Collect all product data from all tabs
        const productData = {
            // General Tab
            title: $('#edit-title').val(),
            sku: $('#edit-sku').val(),
            regular_price: $('#edit-regular-price').val(),
            sale_price: $('#edit-sale-price').val(),
            short_description: $('#edit-short-description').val(),
            long_description: $('#edit-long-description').val(),
            
            // Inventory Tab
            manage_stock: $('#edit-manage-stock').is(':checked'),
            stock_quantity: $('#edit-stock-quantity').val(),
            stock_status: $('#edit-stock-status').val(),
            low_stock_threshold: $('#edit-low-stock-threshold').val(),
            sold_individually: $('#edit-sold-individually').is(':checked'),
            
            // Shipping Tab
            weight: $('#edit-weight').val(),
            length: $('#edit-length').val(),
            width: $('#edit-width').val(),
            height: $('#edit-height').val(),
            shipping_class: $('#edit-shipping-class').val(),
            
            // Linked Products Tab
            upsell_ids: upsellIds,
            cross_sell_ids: crossSellIds,
            
            // Media Tab
            image_id: $('#edit-product-image-id').val(),
            gallery_ids: $('#edit-gallery-ids').val() ? $('#edit-gallery-ids').val().split(',') : [],
            
            // Settings Tab
            status: $('#edit-status').val(),
            catalog_visibility: $('#edit-catalog-visibility').val(),
            featured: $('#edit-featured').is(':checked'),
            menu_order: $('#edit-menu-order').val(),
            reviews_allowed: $('#edit-reviews-allowed').is(':checked'),
            categories: selectedCategories,
            tags: tags
        };
        
        const productId = $('#edit-product-id').val();
        const $button = $('#save-product-edit');
        const originalText = $button.html();
        
        $button.prop('disabled', true).html('<span class="spinner is-active"></span> Saving...');
        
        $.ajax({
            url: aiwpgData.ajaxUrl,
            type: 'POST',
            data: {
                action: 'aiwpg_update_product',
                nonce: aiwpgData.nonce,
                product_id: productId,
                product: JSON.stringify(productData)
            },
            success: function(response) {
                if (response.success) {
                    toastr.success(response.data.message || 'Product updated successfully');
                    $('#edit-product-modal').removeClass('active');
                    if (typeof window.AIWPG.ProductsDisplay !== 'undefined') {
                        window.AIWPG.ProductsDisplay.load(window.AIWPG.ProductsList.currentPage);
                    }
                    if (typeof window.AIWPG.Statistics !== 'undefined') {
                        window.AIWPG.Statistics.load();
                    }
                } else {
                    toastr.error(response.data.message || 'Failed to update product');
                }
            },
            error: function(xhr, status, error) {
                window.AIWPG.Common.handleAjaxError(xhr, status, error);
            },
            complete: function() {
                $button.prop('disabled', false).html(originalText);
            }
        });
    };
    
    /**
     * Improve field with AI (for edit modal)
     */
    window.AIWPG.EditModal.improveField = function(fieldId) {
        const $field = $('#' + fieldId);
        const text = $field.val().trim();
        
        if (!text) {
            toastr.error('Please enter text first');
            return;
        }
        
        // Get field name from label
        const $label = $field.closest('.form-group').find('label');
        const fieldName = $label.text().replace(':', '').trim() || 'field';
        
        const $button = $('.improve-field-btn[data-field="' + fieldId + '"]');
        const originalHtml = $button.html();
        
        $button.prop('disabled', true).html('<span class="spinner is-active" style="float: none;"></span>');
        
        $.ajax({
            url: aiwpgData.ajaxUrl,
            type: 'POST',
            data: {
                action: 'aiwpg_improve_field',
                nonce: aiwpgData.nonce,
                text: text,
                field_name: fieldName
            },
            success: function(response) {
                if (response.success) {
                    // Clean markdown from improved text
                    const cleanedText = window.AIWPG.Common.cleanMarkdown(response.data.improved_text);
                    $field.val(cleanedText);
                    toastr.success('Text improved successfully');
                } else {
                    toastr.error(response.data.message || 'Failed to improve text');
                }
            },
            error: function(xhr, status, error) {
                window.AIWPG.Common.handleAjaxError(xhr, status, error);
            },
            complete: function() {
                $button.prop('disabled', false).html(originalHtml);
            }
        });
    };
    
    /**
     * Load categories from WooCommerce and populate select
     */
    window.AIWPG.EditModal.loadCategoriesSelect = function(selectedCategories = []) {
        $.ajax({
            url: aiwpgData.ajaxUrl,
            type: 'POST',
            data: {
                action: 'aiwpg_get_categories',
                nonce: aiwpgData.nonce
            },
            success: function(response) {
                if (response.success) {
                    const categories = response.data.categories;
                    const escapeHtml = window.AIWPG.Common.escapeHtml;
                    let options = '';
                    
                    categories.forEach(cat => {
                        const selected = selectedCategories.includes(cat.name) ? 'selected' : '';
                        options += `<option value="${escapeHtml(cat.name)}" ${selected}>${escapeHtml(cat.name)}</option>`;
                    });
                    
                    $('#edit-categories').html(options);
                } else {
                    console.error('Failed to load categories');
                }
            },
            error: function() {
                console.error('Network error loading categories');
            }
        });
    };
    
    /**
     * Initialize Tagify for tags input
     */
    window.AIWPG.EditModal.initializeTagify = function(initialTags = []) {
        // Destroy existing instance if exists
        if (window.tagifyInstance) {
            window.tagifyInstance.destroy();
        }
        
        const input = document.querySelector('#edit-tags');
        
        // Check if Tagify is loaded
        if (typeof Tagify === 'undefined') {
            console.warn('Tagify library not loaded, using simple input');
            $('#edit-tags').val(initialTags.join(', '));
            return;
        }
        
        // Create new Tagify instance
        window.tagifyInstance = new Tagify(input, {
            whitelist: [],
            maxTags: 50,
            dropdown: {
                maxItems: 20,
                classname: 'tags-look',
                enabled: 0,
                closeOnSelect: false
            },
            placeholder: 'Add tags...'
        });
        
        // Set initial values
        if (initialTags && initialTags.length > 0) {
            window.tagifyInstance.addTags(initialTags);
        }
    };
    
    /**
     * Update navigation buttons state
     */
    window.AIWPG.EditModal.updateNavigationButtons = function() {
        const $prevBtn = $('#prev-product-btn');
        const $nextBtn = $('#next-product-btn');
        
        // Disable/Enable Previous button
        if (window.AIWPG.ProductsList.currentEditingProductIndex <= 0) {
            $prevBtn.prop('disabled', true);
        } else {
            $prevBtn.prop('disabled', false);
        }
        
        // Disable/Enable Next button
        if (window.AIWPG.ProductsList.currentEditingProductIndex >= window.AIWPG.ProductsList.currentProductsList.length - 1 || 
            window.AIWPG.ProductsList.currentEditingProductIndex === -1) {
            $nextBtn.prop('disabled', true);
        } else {
            $nextBtn.prop('disabled', false);
        }
    };
    
    /**
     * Load gallery images
     */
    window.AIWPG.EditModal.loadGalleryImages = function(galleryIds) {
        if (!galleryIds || galleryIds.length === 0) {
            $('#edit-gallery-preview').html('');
            return;
        }
        
        // Load images via AJAX
        $.ajax({
            url: aiwpgData.ajaxUrl,
            type: 'POST',
            data: {
                action: 'aiwpg_get_gallery_images',
                nonce: aiwpgData.nonce,
                image_ids: galleryIds
            },
            success: function(response) {
                if (response.success && response.data.images) {
                    let html = '';
                    response.data.images.forEach(function(image) {
                        html += `
                            <div class="gallery-item" data-id="${image.id}">
                                <img src="${image.url}" alt="Gallery Image">
                                <button type="button" class="remove-gallery-image">
                                    <span class="dashicons dashicons-no"></span>
                                </button>
                            </div>
                        `;
                    });
                    $('#edit-gallery-preview').html(html);
                } else {
                    // Fallback: show placeholders
                    let html = '';
                    galleryIds.forEach(id => {
                        html += `
                            <div class="gallery-item" data-id="${id}">
                                <img src="https://placehold.co/100x100/333/FFFFFF?text=Gallery" alt="Gallery Image">
                                <button type="button" class="remove-gallery-image">
                                    <span class="dashicons dashicons-no"></span>
                                </button>
                            </div>
                        `;
                    });
                    $('#edit-gallery-preview').html(html);
                }
            },
            error: function() {
                // Fallback: show placeholders
                let html = '';
                galleryIds.forEach(id => {
                    html += `
                        <div class="gallery-item" data-id="${id}">
                            <img src="https://placehold.co/100x100/333/FFFFFF?text=Gallery" alt="Gallery Image">
                            <button type="button" class="remove-gallery-image">
                                <span class="dashicons dashicons-no"></span>
                            </button>
                        </div>
                    `;
                });
                $('#edit-gallery-preview').html(html);
            }
        });
    };
    
    /**
     * Initialize context menu for Edit Product modal
     */
    window.AIWPG.EditModal.initContextMenu = function() {
        // Show context menu on right click in Edit Product modal
        $(document).on('contextmenu', '#edit-product-modal .modal-body, #edit-product-modal .modal-body *', function(e) {
            // Only show if modal is active
            if (!$('#edit-product-modal').hasClass('active')) {
                return true; // Allow default context menu
            }
            
            e.preventDefault();
            e.stopPropagation();
            
            const $contextMenu = $('#edit-product-context-menu');
            
            // Make sure context menu exists
            if ($contextMenu.length === 0) {
                console.error('Context menu element not found');
                return false;
            }
            
            // Update active state
            const currentTab = $('#edit-product-modal .tab-content.active').data('tab');
            $contextMenu.find('.context-menu-item').removeClass('active');
            $contextMenu.find(`.context-menu-item[data-tab="${currentTab}"]`).addClass('active');
            
            // Position context menu at cursor position
            $contextMenu.css({
                'display': 'block',
                'left': e.clientX + 'px',
                'top': e.clientY + 'px'
            });
            
            return false;
        });
        
        // Hide context menu on click outside
        $(document).on('click', function(e) {
            if (!$(e.target).closest('#edit-product-context-menu').length) {
                window.AIWPG.EditModal.hideContextMenu();
            }
        });
        
        // Hide context menu on Escape key
        $(document).on('keydown', function(e) {
            if ((e.key === 'Escape' || e.keyCode === 27) && $('#edit-product-modal').hasClass('active')) {
                window.AIWPG.EditModal.hideContextMenu();
            }
        });
        
        // Handle context menu item click
        $(document).on('click', '#edit-product-context-menu .context-menu-item', function() {
            const tab = $(this).data('tab');
            
            // Add click animation
            $(this).css('transform', 'scale(0.95)');
            
            // Switch to the selected tab
            $('#edit-product-modal .tab-btn').removeClass('active');
            $(`#edit-product-modal .tab-btn[data-tab="${tab}"]`).addClass('active');
            
            $('#edit-product-modal .tab-content').removeClass('active');
            $(`#edit-product-modal .tab-content[data-tab="${tab}"]`).addClass('active');
            
            // Hide context menu
            window.AIWPG.EditModal.hideContextMenu();
            
            // Show success message
            const tabNames = {
                'general': 'عام',
                'inventory': 'المخزون',
                'shipping': 'الشحن',
                'linked': 'المنتجات المرتبطة',
                'media': 'الوسائط',
                'variations': 'المتغيرات',
                'settings': 'الإعدادات'
            };
            toastr.success(`تم الانتقال إلى تبويب ${tabNames[tab] || tab}`);
        });
        
        // Hide context menu when modal is closed
        $(document).on('click', '.modal-close, .close-modal', function() {
            window.AIWPG.EditModal.hideContextMenu();
        });
    };
    
    /**
     * Hide context menu with animation
     */
    window.AIWPG.EditModal.hideContextMenu = function() {
        const $menu = $('#edit-product-context-menu');
        if ($menu.is(':visible')) {
            $menu.addClass('hiding');
            setTimeout(function() {
                $menu.css('display', 'none').removeClass('hiding');
            }, 200);
        }
    };
    
    /**
     * Initialize media upload using WordPress Media Library
     */
    window.AIWPG.EditModal.initMediaUpload = function() {
        // Check if wp.media is available
        if (typeof wp === 'undefined' || typeof wp.media === 'undefined') {
            console.error('WordPress Media Library is not loaded. Make sure wp_enqueue_media() is called.');
            return;
        }
        
        // Product Image Upload
        $(document).on('click', '.upload-image-btn', function(e) {
            e.preventDefault();
            
            // Check if wp.media is available
            if (typeof wp === 'undefined' || typeof wp.media === 'undefined') {
                console.error('WordPress Media Library is not available');
                toastr.error('Media library is not available. Please refresh the page.');
                return;
            }
            
            // If the media frame already exists, reopen it
            if (productImageFrame) {
                productImageFrame.open();
                return;
            }
            
            // Create the media frame
            productImageFrame = wp.media({
                title: 'Select Product Image',
                button: {
                    text: 'Use this image'
                },
                multiple: false
            });
            
            // When an image is selected, run a callback
            productImageFrame.on('select', function() {
                const attachment = productImageFrame.state().get('selection').first().toJSON();
                
                // Set the image preview
                $('#edit-product-image-preview img').attr('src', attachment.url).show();
                $('#edit-product-image-preview .remove-image').show();
                $('#edit-product-image-id').val(attachment.id);
            });
            
            // Open the modal
            productImageFrame.open();
        });
        
        // Remove product image
        $(document).on('click', '#edit-product-image-preview .remove-image', function(e) {
            e.preventDefault();
            $('#edit-product-image-preview img').attr('src', '').hide();
            $('#edit-product-image-preview .remove-image').hide();
            $('#edit-product-image-id').val('');
        });
        
        // Gallery Images Upload
        $(document).on('click', '.upload-gallery-btn', function(e) {
            e.preventDefault();
            
            // Check if wp.media is available
            if (typeof wp === 'undefined' || typeof wp.media === 'undefined') {
                console.error('WordPress Media Library is not available');
                toastr.error('Media library is not available. Please refresh the page.');
                return;
            }
            
            // If the media frame already exists, reopen it
            if (galleryImageFrame) {
                galleryImageFrame.open();
                return;
            }
            
            // Create the media frame
            galleryImageFrame = wp.media({
                title: 'Select Gallery Images',
                button: {
                    text: 'Add to gallery'
                },
                multiple: true
            });
            
            // When images are selected, run a callback
            galleryImageFrame.on('select', function() {
                const attachments = galleryImageFrame.state().get('selection').toJSON();
                
                // Get existing gallery IDs
                let galleryIds = $('#edit-gallery-ids').val() ? $('#edit-gallery-ids').val().split(',') : [];
                
                // Add new images to gallery
                attachments.forEach(function(attachment) {
                    if (galleryIds.indexOf(String(attachment.id)) === -1) {
                        galleryIds.push(attachment.id);
                        
                        // Add image to preview
                        const imageHtml = `
                            <div class="gallery-item" data-id="${attachment.id}">
                                <img src="${attachment.url}" alt="Gallery Image">
                                <button type="button" class="remove-gallery-image">
                                    <span class="dashicons dashicons-no"></span>
                                </button>
                            </div>
                        `;
                        $('#edit-gallery-preview').append(imageHtml);
                    }
                });
                
                // Update hidden input
                $('#edit-gallery-ids').val(galleryIds.join(','));
            });
            
            // Open the modal
            galleryImageFrame.open();
        });
        
        // Remove gallery image
        $(document).on('click', '.remove-gallery-image', function(e) {
            e.preventDefault();
            const $item = $(this).closest('.gallery-item');
            const imageId = $item.data('id');
            
            // Remove from DOM
            $item.remove();
            
            // Update hidden input
            let galleryIds = $('#edit-gallery-ids').val() ? $('#edit-gallery-ids').val().split(',') : [];
            galleryIds = galleryIds.filter(id => id !== String(imageId));
            $('#edit-gallery-ids').val(galleryIds.join(','));
        });
    };
    
    // Old Select2 code removed - Using new LinkedProducts module instead
    
})(jQuery);

