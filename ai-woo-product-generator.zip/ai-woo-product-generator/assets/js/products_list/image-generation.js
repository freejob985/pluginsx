/**
 * Image Generation
 * Handles AI-powered product image generation
 */

(function($) {
    'use strict';
    
    window.AIWPG = window.AIWPG || {};
    window.AIWPG.ImageGeneration = {};
    
    /**
     * Initialize image generation
     */
    window.AIWPG.ImageGeneration.init = function() {
        // Event handlers are attached dynamically when needed
    };
    
    /**
     * Generate product image using AI
     */
    window.AIWPG.ImageGeneration.generate = function(productId) {
        const $button = $('.generate-image-btn');
        const originalHtml = $button.html();
        
        $button.prop('disabled', true).html('<span class="spinner is-active" style="float: none;"></span> Generating...');
        
        $.ajax({
            url: aiwpgData.ajaxUrl,
            type: 'POST',
            data: {
                action: 'aiwpg_generate_product_image',
                nonce: aiwpgData.nonce,
                product_id: productId
            },

            
            success: function(response) {
                if (response.success) {
                    toastr.success(response.data.message || 'Image generated successfully');
                    
                    // Update the image in the modal
                    if (response.data.image_url) {
                        $('#view-product-image').attr('src', response.data.image_url);
                        
                        // Add fade-in effect
                        $('#view-product-image').hide().fadeIn(500);
                    }
                    
                    // Refresh products list in background
                    if ($('#products-container').length) {
                        if (typeof window.AIWPG.ProductsDisplay !== 'undefined') {
                            window.AIWPG.ProductsDisplay.load(window.AIWPG.ProductsList.currentPage);
                        }
                    }
                } else {
                    toastr.error(response.data.message || 'Failed to generate image');
                }
            },
            error: function(xhr, status, error) {
                window.AIWPG.Common.handleAjaxError(xhr, status, error);
            },
            complete: function() {
                $button.prop('disabled', false).html(originalHtml);
            }
        });
    };
    
})(jQuery);

