/**
 * Products Display
 * Handles products grid display
 */

(function($) {
    'use strict';
    
    window.AIWPG = window.AIWPG || {};
    window.AIWPG.ProductsDisplay = {};
    
    /**
     * Load products
     */
    window.AIWPG.ProductsDisplay.load = function(page = 1, search = '') {
        $('#products-container').html('<div class="aiwpg-loading"><span class="spinner is-active"></span><p>Loading products...</p></div>');
        
        $.ajax({
            url: aiwpgData.ajaxUrl,
            type: 'POST',
            data: {
                action: 'aiwpg_get_products',
                nonce: aiwpgData.nonce,
                page: page,
                per_page: 12,
                search: search
            },
            success: function(response) {
                if (response.success) {
                    window.AIWPG.ProductsDisplay.display(response.data.products);
                    if (typeof window.AIWPG.Pagination !== 'undefined') {
                        window.AIWPG.Pagination.display(response.data.pages, response.data.current_page);
                    }
                } else {
                    $('#products-container').html('<p>Error loading products</p>');
                }
            },
            error: function() {
                $('#products-container').html('<p>Network error</p>');
            }
        });
    };
    
    /**
     * Display products in grid
     */
    window.AIWPG.ProductsDisplay.display = function(products) {
        if (products.length === 0) {
            $('#products-container').html('<div class="aiwpg-no-products"><p>No products found</p></div>');
            window.AIWPG.ProductsList.currentProductsList = [];
            return;
        }
        
        // Store products list for navigation
        window.AIWPG.ProductsList.currentProductsList = products;
        
        const escapeHtml = window.AIWPG.Common.escapeHtml;
        const getProductTypeBadge = window.AIWPG.Common.getProductTypeBadge;
        
        let html = '';
        
        products.forEach(product => {
            const imageUrl = product.image_url || '';
            const price = product.price ? '$' + parseFloat(product.price).toFixed(2) : 'N/A';
            const stockStatus = product.stock_status === 'instock' ? 'In Stock' : 'Out of Stock';
            const stockClass = product.stock_status === 'instock' ? 'in-stock' : 'out-of-stock';
            
            // Image or placeholder
            let imageHtml = '';
            if (imageUrl) {
                imageHtml = `<img src="${imageUrl}" alt="${escapeHtml(product.title)}">`;
            } else {
                imageHtml = `<img src="https://placehold.co/300x300/333/FFFFFF?text=No+Image" alt="${escapeHtml(product.title)}">`;
            }
            
            const productTypeBadge = getProductTypeBadge(product.product_type);
            
            html += `
                <div class="product-card" data-product-id="${product.id}">
                    <div class="card-header">
                        ${productTypeBadge}
                        ${imageHtml}
                        <div class="card-title-wrapper">
                            <h3>${escapeHtml(product.title)}</h3>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="product-price">${price}</div>
                        <div class="product-stock ${stockClass}">${stockStatus}</div>
                        <div class="product-quantity">Stock: ${product.stock_quantity || 0}</div>
                        ${product.categories && product.categories.length > 0 ? `<div class="product-category">${product.categories.join(', ')}</div>` : ''}
                        ${product.short_description ? `<div class="product-description">${escapeHtml(product.short_description.substring(0, 100))}...</div>` : ''}
                    </div>
                    <div class="card-footer">
                        <button class="button button-secondary view-product" data-id="${product.id}">
                            <span class="dashicons dashicons-visibility"></span> View
                        </button>
                        <button class="button button-primary edit-product" data-id="${product.id}">
                            <span class="dashicons dashicons-edit"></span> Edit
                        </button>
                    </div>
                </div>
            `;
        });
        
        $('#products-container').html(html);
        
        // Attach event handlers
        $('.view-product').on('click', function() {
            if (typeof window.AIWPG.ViewModal !== 'undefined') {
                window.AIWPG.ViewModal.view($(this).data('id'));
            }
        });
        
        $('.edit-product').on('click', function() {
            if (typeof window.AIWPG.EditModal !== 'undefined') {
                window.AIWPG.EditModal.edit($(this).data('id'));
            }
        });
    };
    
})(jQuery);

