/**
 * Search and Autocomplete
 * Handles product search with autocomplete functionality
 */

(function($) {
    'use strict';
    
    window.AIWPG = window.AIWPG || {};
    window.AIWPG.Search = {};
    
    /**
     * Initialize search
     */
    window.AIWPG.Search.init = function() {
        // Search with debounce and arrow navigation
        $('#product-search').on('keydown', function(e) {
            const $results = $('#autocomplete-results');
            const $items = $results.find('.autocomplete-item');
            const $selected = $items.filter('.selected');
            
            // Arrow Down - Navigate down in autocomplete
            if (e.keyCode === 40 && $results.is(':visible') && $items.length > 0) {
                e.preventDefault();
                
                if ($selected.length === 0) {
                    $items.first().addClass('selected');
                } else {
                    const $next = $selected.next('.autocomplete-item');
                    if ($next.length > 0) {
                        $selected.removeClass('selected');
                        $next.addClass('selected');
                        
                        // Scroll into view
                        $next[0].scrollIntoView({ block: 'nearest', behavior: 'smooth' });
                    }
                }
                return false;
            }
            
            // Arrow Up - Navigate up in autocomplete
            if (e.keyCode === 38 && $results.is(':visible') && $items.length > 0) {
                e.preventDefault();
                
                if ($selected.length === 0) {
                    $items.last().addClass('selected');
                } else {
                    const $prev = $selected.prev('.autocomplete-item');
                    if ($prev.length > 0) {
                        $selected.removeClass('selected');
                        $prev.addClass('selected');
                        
                        // Scroll into view
                        $prev[0].scrollIntoView({ block: 'nearest', behavior: 'smooth' });
                    }
                }
                return false;
            }
            
            // Enter - Select highlighted item
            if (e.keyCode === 13) {
                if ($results.is(':visible') && $selected.length > 0) {
                    e.preventDefault();
                    e.stopPropagation();
                    
                    // Trigger click on selected item
                    const productId = $selected.data('id');
                    const productTitle = $selected.find('.item-title').text();
                    
                    // Add to search input
                    $(this).val(productTitle);
                    
                    // Hide autocomplete
                    $results.hide();
                    
                    // Scroll to product or open modal
                    const $card = $(`.product-card[data-product-id="${productId}"]`);
                    if ($card.length) {
                        $('html, body').animate({
                            scrollTop: $card.offset().top - 100
                        }, 500);
                        $card.addClass('highlight');
                        setTimeout(() => $card.removeClass('highlight'), 2000);
                    } else {
                        if (typeof window.AIWPG.ViewModal !== 'undefined') {
                            window.AIWPG.ViewModal.view(productId);
                        }
                    }
                    
                    return false;
                }
            }
        });
        
        $('#product-search').on('keyup', function(e) {
            // Skip arrow keys and Enter as they're handled in keydown
            if ([13, 37, 38, 39, 40].includes(e.keyCode)) {
                return;
            }
            
            clearTimeout(window.AIWPG.ProductsList.searchTimeout);
            const query = $(this).val().trim();
            
            // Show validation message if empty and any key pressed (except Tab, Shift, Ctrl, Alt, Arrow keys)
            const ignoredKeys = [9, 16, 17, 18, 20, 27, 37, 38, 39, 40, 91, 93]; // Tab, Shift, Ctrl, Alt, CapsLock, Esc, Arrows, Windows keys
            if (query.length === 0 && !ignoredKeys.includes(e.keyCode)) {
                toastr.warning('رجاء ادخال نص البحث');
                $('#autocomplete-results').hide();
                return;
            }
            
            if (query.length === 0) {
                $('#autocomplete-results').hide();
                return;
            }
            
            if (query.length < 2) {
                $('#autocomplete-results').hide();
                return;
            }
            
            window.AIWPG.ProductsList.searchTimeout = setTimeout(function() {
                window.AIWPG.Search.searchProducts(query);
            }, 500);
        });
        
        // Enter key on search
        $('#product-search').on('keypress', function(e) {
            if (e.which === 13) { // Enter key
                e.preventDefault();
                const query = $(this).val().trim();
                
                if (query.length === 0) {
                    toastr.warning('من فضلك أدخل كلمة البحث');
                    return;
                }
                
                window.AIWPG.ProductsList.currentPage = 1;
                window.AIWPG.ProductsDisplay.load(1, query);
                $('#autocomplete-results').hide();
            }
        });
        
        // Click outside to close autocomplete
        $(document).on('click', function(e) {
            if (!$(e.target).closest('.search-wrapper').length) {
                $('#autocomplete-results').hide();
            }
        });
    };
    
    /**
     * Search products (autocomplete)
     */
    window.AIWPG.Search.searchProducts = function(query) {
        $.ajax({
            url: aiwpgData.ajaxUrl,
            type: 'POST',
            data: {
                action: 'aiwpg_search_products',
                nonce: aiwpgData.nonce,
                search: query
            },
            success: function(response) {
                if (response.success) {
                    window.AIWPG.Search.displayAutocomplete(response.data.products);
                } else {
                    $('#autocomplete-results').hide();
                }
            },
            error: function() {
                $('#autocomplete-results').hide();
            }
        });
    };
    
    /**
     * Display autocomplete results
     */
    window.AIWPG.Search.displayAutocomplete = function(products) {
        if (products.length === 0) {
            $('#autocomplete-results').hide();
            return;
        }
        
        const escapeHtml = window.AIWPG.Common.escapeHtml;
        
        let html = '';
        
        products.forEach(product => {
            const imageUrl = product.image_url || 'https://placehold.co/300x300/333/FFFFFF?text=No+Image';
            const price = product.price ? '$' + parseFloat(product.price).toFixed(2) : 'N/A';
            
            html += `
                <div class="autocomplete-item" data-id="${product.id}">
                    <img src="${imageUrl}" alt="${escapeHtml(product.title)}">
                    <div class="item-info">
                        <div class="item-title">${escapeHtml(product.title)}</div>
                        <div class="item-meta">${escapeHtml(product.short_description)}</div>
                        <div class="item-price">${price}</div>
                    </div>
                </div>
            `;
        });
        
        $('#autocomplete-results').html(html).show();
        
        // Attach click handler
        $('.autocomplete-item').on('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            
            const productId = $(this).data('id');
            const productTitle = $(this).find('.item-title').text();
            
            // Add to search input
            $('#product-search').val(productTitle);
            
            // Hide autocomplete
            $('#autocomplete-results').hide();
            
            // Scroll to product card or open view modal
            const $card = $(`.product-card[data-product-id="${productId}"]`);
            if ($card.length) {
                $('html, body').animate({
                    scrollTop: $card.offset().top - 100
                }, 500);
                $card.addClass('highlight');
                setTimeout(() => $card.removeClass('highlight'), 2000);
            } else {
                if (typeof window.AIWPG.ViewModal !== 'undefined') {
                    window.AIWPG.ViewModal.view(productId);
                }
            }
        });
        
        // Attach hover handler to update selected state
        $('.autocomplete-item').on('mouseenter', function() {
            $('.autocomplete-item').removeClass('selected');
            $(this).addClass('selected');
        });
    };
    
})(jQuery);

