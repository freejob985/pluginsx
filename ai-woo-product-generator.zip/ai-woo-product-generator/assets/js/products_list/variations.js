/**
 * Variations Management
 * Handles product variations editing
 */

(function($) {
    'use strict';
    
    window.AIWPG = window.AIWPG || {};
    window.AIWPG.Variations = {};
    
    /**
     * Initialize variations
     */
    window.AIWPG.Variations.init = function() {
        // Event handlers are attached dynamically when variations are displayed
    };
    
    /**
     * Display variations (editable)
     */
    window.AIWPG.Variations.display = function(variations) {
        const escapeHtml = window.AIWPG.Common.escapeHtml;
        
        let html = '<div class="variations-container" style="max-height: 400px; overflow-y: auto;">';
        
        variations.forEach((variation, index) => {
            html += `
                <div class="variation-item" data-variation-id="${variation.id}" data-index="${index}" style="padding: 15px; margin-bottom: 12px; background: #fff; border: 1px solid #ddd; border-radius: 6px; border-left: 3px solid #2271b1;">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
                        <div style="font-weight: 600; font-size: 14px; color: #1d2327;">
                            ${escapeHtml(variation.name || 'Variation ' + (index + 1))}
                        </div>
                        <button type="button" class="button button-small toggle-variation-edit" data-index="${index}" style="padding: 4px 10px;">
                            <span class="dashicons dashicons-edit" style="font-size: 16px; width: 16px; height: 16px; margin-top: 2px;"></span>
                            Edit
                        </button>
                    </div>
                    
                    <!-- Read-only view -->
                    <div class="variation-view" data-index="${index}">
                        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 10px; font-size: 13px; color: #646970;">
                            <div><strong>SKU:</strong> ${escapeHtml(variation.sku || 'N/A')}</div>
                            <div><strong>Price:</strong> $${parseFloat(variation.price || 0).toFixed(2)}</div>
                            <div><strong>Stock:</strong> ${variation.stock_quantity || 0}</div>
                            <div><strong>Status:</strong> ${variation.stock_status || 'instock'}</div>
                        </div>
                    </div>
                    
                    <!-- Edit form (hidden by default) -->
                    <div class="variation-edit-form" data-index="${index}" style="display: none;">
                        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-top: 10px;">
                            <div class="form-group">
                                <label style="display: block; margin-bottom: 4px; font-weight: 500; font-size: 12px;">SKU</label>
                                <input type="text" class="variation-sku" value="${escapeHtml(variation.sku || '')}" style="width: 100%; padding: 6px 10px; border: 1px solid #ddd; border-radius: 4px;">
                            </div>
                            <div class="form-group">
                                <label style="display: block; margin-bottom: 4px; font-weight: 500; font-size: 12px;">Regular Price ($)</label>
                                <input type="number" class="variation-price" value="${parseFloat(variation.price || 0).toFixed(2)}" step="0.01" min="0" style="width: 100%; padding: 6px 10px; border: 1px solid #ddd; border-radius: 4px;">
                            </div>
                            <div class="form-group">
                                <label style="display: block; margin-bottom: 4px; font-weight: 500; font-size: 12px;">Stock Quantity</label>
                                <input type="number" class="variation-stock" value="${variation.stock_quantity || 0}" min="0" style="width: 100%; padding: 6px 10px; border: 1px solid #ddd; border-radius: 4px;">
                            </div>
                            <div class="form-group">
                                <label style="display: block; margin-bottom: 4px; font-weight: 500; font-size: 12px;">Stock Status</label>
                                <select class="variation-stock-status" style="width: 100%; padding: 6px 10px; border: 1px solid #ddd; border-radius: 4px;">
                                    <option value="instock" ${variation.stock_status === 'instock' ? 'selected' : ''}>In Stock</option>
                                    <option value="outofstock" ${variation.stock_status === 'outofstock' ? 'selected' : ''}>Out of Stock</option>
                                    <option value="onbackorder" ${variation.stock_status === 'onbackorder' ? 'selected' : ''}>On Backorder</option>
                                </select>
                            </div>
                        </div>
                        <div style="margin-top: 12px; display: flex; gap: 8px;">
                            <button type="button" class="button button-primary save-variation" data-index="${index}" style="padding: 6px 16px;">
                                <span class="dashicons dashicons-yes" style="font-size: 16px; width: 16px; height: 16px; margin-top: 2px;"></span>
                                Save
                            </button>
                            <button type="button" class="button cancel-variation-edit" data-index="${index}" style="padding: 6px 16px;">
                                <span class="dashicons dashicons-no" style="font-size: 16px; width: 16px; height: 16px; margin-top: 2px;"></span>
                                Cancel
                            </button>
                        </div>
                    </div>
                </div>
            `;
        });
        
        html += '</div>';
        $('#edit-variations-list').html(html);
        
        // Initialize variation edit handlers
        window.AIWPG.Variations.initEditHandlers();
    };
    
    /**
     * Initialize variation edit handlers
     */
    window.AIWPG.Variations.initEditHandlers = function() {
        const escapeHtml = window.AIWPG.Common.escapeHtml;
        
        // Toggle edit mode
        $('.toggle-variation-edit').off('click').on('click', function() {
            const index = $(this).data('index');
            const $item = $(`.variation-item[data-index="${index}"]`);
            
            $item.find('.variation-view').hide();
            $item.find('.variation-edit-form').show();
            $(this).hide();
        });
        
        // Cancel edit
        $('.cancel-variation-edit').off('click').on('click', function() {
            const index = $(this).data('index');
            const $item = $(`.variation-item[data-index="${index}"]`);
            
            $item.find('.variation-view').show();
            $item.find('.variation-edit-form').hide();
            $item.find('.toggle-variation-edit').show();
        });
        
        // Save variation
        $('.save-variation').off('click').on('click', function() {
            const index = $(this).data('index');
            const $item = $(`.variation-item[data-index="${index}"]`);
            const $form = $item.find('.variation-edit-form');
            
            const variationId = $item.data('variation-id');
            const variationData = {
                sku: $form.find('.variation-sku').val(),
                price: $form.find('.variation-price').val(),
                stock_quantity: $form.find('.variation-stock').val(),
                stock_status: $form.find('.variation-stock-status').val()
            };
            
            // Show loading
            const $button = $(this);
            const originalText = $button.html();
            $button.prop('disabled', true).html('<span class="spinner is-active"></span> Saving...');
            
            // Save via AJAX
            $.ajax({
                url: aiwpgData.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'aiwpg_update_variation',
                    nonce: aiwpgData.nonce,
                    variation_id: variationId,
                    variation: JSON.stringify(variationData)
                },
                success: function(response) {
                    if (response.success) {
                        toastr.success('Variation updated successfully');
                        
                        // Update view
                        $item.find('.variation-view').html(`
                            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 10px; font-size: 13px; color: #646970;">
                                <div><strong>SKU:</strong> ${escapeHtml(variationData.sku || 'N/A')}</div>
                                <div><strong>Price:</strong> $${parseFloat(variationData.price || 0).toFixed(2)}</div>
                                <div><strong>Stock:</strong> ${variationData.stock_quantity || 0}</div>
                                <div><strong>Status:</strong> ${variationData.stock_status || 'instock'}</div>
                            </div>
                        `);
                        
                        // Hide form, show view
                        $item.find('.variation-view').show();
                        $item.find('.variation-edit-form').hide();
                        $item.find('.toggle-variation-edit').show();
                    } else {
                        toastr.error(response.data.message || 'Failed to update variation');
                    }
                },
                error: function() {
                    toastr.error('Network error occurred');
                },
                complete: function() {
                    $button.prop('disabled', false).html(originalText);
                }
            });
        });
    };
    
})(jQuery);

