/**
 * Variations Management
 * Handles product variations editing
 */

(function($) {
    'use strict';
    
    window.AIWPG = window.AIWPG || {};
    window.AIWPG.Variations = {};
    
    // Store media frames for each variation
    window.AIWPG.Variations.mediaFrames = {};
    
    /**
     * Initialize variations
     */
    window.AIWPG.Variations.init = function() {
        // Event handlers are attached dynamically when variations are displayed
    };
    
    /**
     * Display variations (editable)
     */
    window.AIWPG.Variations.display = function(variations) {
        const escapeHtml = window.AIWPG.Common.escapeHtml;
        
        let html = '<div class="variations-container" style="max-height: 400px; overflow-y: auto;">';
        
        variations.forEach((variation, index) => {
            html += `
                <div class="variation-item" data-variation-id="${variation.id}" data-index="${index}" style="padding: 15px; margin-bottom: 12px; background: #fff; border: 1px solid #ddd; border-radius: 6px; border-left: 3px solid #2271b1;">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
                        <div style="font-weight: 600; font-size: 14px; color: #1d2327;">
                            ${escapeHtml(variation.name || 'Variation ' + (index + 1))}
                        </div>
                        <button type="button" class="button button-small toggle-variation-edit" data-index="${index}" style="padding: 4px 10px;">
                            <span class="dashicons dashicons-edit" style="font-size: 16px; width: 16px; height: 16px; margin-top: 2px;"></span>
                            Edit
                        </button>
                    </div>
                    
                    <!-- Read-only view -->
                    <div class="variation-view" data-index="${index}">
                        <div style="display: flex; gap: 15px; align-items: flex-start;">
                            ${variation.image_url ? `
                                <div class="variation-image-preview" style="flex-shrink: 0; width: 100px; height: 100px; border: 1px solid #ddd; border-radius: 6px; overflow: hidden; background: #f5f5f5; display: flex; align-items: center; justify-content: center;">
                                    <img src="${variation.image_url}" alt="Variation Image" style="max-width: 100%; max-height: 100%; object-fit: cover; display: block;">
                                </div>
                            ` : `
                                <div class="variation-image-placeholder" style="flex-shrink: 0; width: 100px; height: 100px; border: 1px dashed #ddd; border-radius: 6px; background: #f9f9f9; display: flex; align-items: center; justify-content: center; color: #999; font-size: 11px; text-align: center; padding: 5px;">
                                    <span>No Image</span>
                                </div>
                            `}
                            <div style="flex: 1; display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 10px; font-size: 13px; color: #646970;">
                                <div><strong>SKU:</strong> ${escapeHtml(variation.sku || 'N/A')}</div>
                                <div><strong>Price:</strong> $${parseFloat(variation.price || 0).toFixed(2)}</div>
                                <div><strong>Stock:</strong> ${variation.stock_quantity || 0}</div>
                                <div><strong>Status:</strong> ${variation.stock_status || 'instock'}</div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Edit form (hidden by default) -->
                    <div class="variation-edit-form" data-index="${index}" style="display: none;">
                        <!-- Image Upload Section -->
                        <div class="form-group" style="margin-bottom: 15px;">
                            <label style="display: block; margin-bottom: 8px; font-weight: 500; font-size: 12px;">Variation Image</label>
                            <div class="variation-image-upload-area" style="display: flex; gap: 12px; align-items: flex-start;">
                                <div class="variation-image-preview-edit" style="width: 120px; height: 120px; border: 1px solid #ddd; border-radius: 6px; overflow: hidden; background: #f9f9f9; display: flex; align-items: center; justify-content: center; flex-shrink: 0;">
                                    ${variation.image_url ? `
                                        <img src="${variation.image_url}" alt="Variation Image" style="max-width: 100%; max-height: 100%; object-fit: cover; display: block;">
                                    ` : `
                                        <span style="color: #999; font-size: 11px; text-align: center; padding: 10px;">No Image</span>
                                    `}
                                </div>
                                <div style="flex: 1;">
                                    <button type="button" class="button button-secondary upload-variation-image-btn" data-index="${index}" style="margin-bottom: 8px;">
                                        <span class="dashicons dashicons-upload" style="font-size: 16px; width: 16px; height: 16px; margin-top: 2px;"></span>
                                        ${variation.image_url ? 'Change Image' : 'Upload Image'}
                                    </button>
                                    ${variation.image_url ? `
                                        <button type="button" class="button button-link remove-variation-image-btn" data-index="${index}" style="display: block; color: #b32d2e;">
                                            <span class="dashicons dashicons-trash" style="font-size: 16px; width: 16px; height: 16px; margin-top: 2px;"></span>
                                            Remove Image
                                        </button>
                                    ` : ''}
                                    <input type="hidden" class="variation-image-id" value="${variation.image_id || ''}">
                                </div>
                            </div>
                        </div>
                        
                        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-top: 10px;">
                            <div class="form-group">
                                <label style="display: block; margin-bottom: 4px; font-weight: 500; font-size: 12px;">SKU</label>
                                <input type="text" class="variation-sku" value="${escapeHtml(variation.sku || '')}" style="width: 100%; padding: 6px 10px; border: 1px solid #ddd; border-radius: 4px;">
                            </div>
                            <div class="form-group">
                                <label style="display: block; margin-bottom: 4px; font-weight: 500; font-size: 12px;">Regular Price ($)</label>
                                <input type="number" class="variation-price" value="${parseFloat(variation.price || 0).toFixed(2)}" step="0.01" min="0" style="width: 100%; padding: 6px 10px; border: 1px solid #ddd; border-radius: 4px;">
                            </div>
                            <div class="form-group">
                                <label style="display: block; margin-bottom: 4px; font-weight: 500; font-size: 12px;">Stock Quantity</label>
                                <input type="number" class="variation-stock" value="${variation.stock_quantity || 0}" min="0" style="width: 100%; padding: 6px 10px; border: 1px solid #ddd; border-radius: 4px;">
                            </div>
                            <div class="form-group">
                                <label style="display: block; margin-bottom: 4px; font-weight: 500; font-size: 12px;">Stock Status</label>
                                <select class="variation-stock-status" style="width: 100%; padding: 6px 10px; border: 1px solid #ddd; border-radius: 4px;">
                                    <option value="instock" ${variation.stock_status === 'instock' ? 'selected' : ''}>In Stock</option>
                                    <option value="outofstock" ${variation.stock_status === 'outofstock' ? 'selected' : ''}>Out of Stock</option>
                                    <option value="onbackorder" ${variation.stock_status === 'onbackorder' ? 'selected' : ''}>On Backorder</option>
                                </select>
                            </div>
                        </div>
                        <div style="margin-top: 12px; display: flex; gap: 8px;">
                            <button type="button" class="button button-primary save-variation" data-index="${index}" style="padding: 6px 16px;">
                                <span class="dashicons dashicons-yes" style="font-size: 16px; width: 16px; height: 16px; margin-top: 2px;"></span>
                                Save
                            </button>
                            <button type="button" class="button cancel-variation-edit" data-index="${index}" style="padding: 6px 16px;">
                                <span class="dashicons dashicons-no" style="font-size: 16px; width: 16px; height: 16px; margin-top: 2px;"></span>
                                Cancel
                            </button>
                        </div>
                    </div>
                </div>
            `;
        });
        
        html += '</div>';
        $('#edit-variations-list').html(html);
        
        // Initialize variation edit handlers
        window.AIWPG.Variations.initEditHandlers();
    };
    
    /**
     * Initialize variation edit handlers
     */
    window.AIWPG.Variations.initEditHandlers = function() {
        const escapeHtml = window.AIWPG.Common.escapeHtml;
        
        // Toggle edit mode
        $('.toggle-variation-edit').off('click').on('click', function() {
            const index = $(this).data('index');
            const $item = $(`.variation-item[data-index="${index}"]`);
            
            $item.find('.variation-view').hide();
            $item.find('.variation-edit-form').show();
            $(this).hide();
        });
        
        // Cancel edit
        $('.cancel-variation-edit').off('click').on('click', function() {
            const index = $(this).data('index');
            const $item = $(`.variation-item[data-index="${index}"]`);
            
            $item.find('.variation-view').show();
            $item.find('.variation-edit-form').hide();
            $item.find('.toggle-variation-edit').show();
        });
        
        // Save variation
        $('.save-variation').off('click').on('click', function() {
            const index = $(this).data('index');
            const $item = $(`.variation-item[data-index="${index}"]`);
            const $form = $item.find('.variation-edit-form');
            
            const variationId = $item.data('variation-id');
            const variationData = {
                sku: $form.find('.variation-sku').val(),
                price: $form.find('.variation-price').val(),
                stock_quantity: $form.find('.variation-stock').val(),
                stock_status: $form.find('.variation-stock-status').val(),
                image_id: $form.find('.variation-image-id').val() || ''
            };
            
            // Show loading
            const $button = $(this);
            const originalText = $button.html();
            $button.prop('disabled', true).html('<span class="spinner is-active"></span> Saving...');
            
            // Save via AJAX
            $.ajax({
                url: aiwpgData.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'aiwpg_update_variation',
                    nonce: aiwpgData.nonce,
                    variation_id: variationId,
                    variation: JSON.stringify(variationData)
                },
                success: function(response) {
                    if (response.success) {
                        toastr.success('Variation updated successfully');
                        
                        // Get image URL from response
                        const imageUrl = response.data.variation && response.data.variation.image_url 
                            ? response.data.variation.image_url 
                            : '';
                        
                        // Update view with image
                        const imageHtml = imageUrl ? `
                            <div class="variation-image-preview" style="flex-shrink: 0; width: 100px; height: 100px; border: 1px solid #ddd; border-radius: 6px; overflow: hidden; background: #f5f5f5; display: flex; align-items: center; justify-content: center;">
                                <img src="${imageUrl}" alt="Variation Image" style="max-width: 100%; max-height: 100%; object-fit: cover; display: block;">
                            </div>
                        ` : `
                            <div class="variation-image-placeholder" style="flex-shrink: 0; width: 100px; height: 100px; border: 1px dashed #ddd; border-radius: 6px; background: #f9f9f9; display: flex; align-items: center; justify-content: center; color: #999; font-size: 11px; text-align: center; padding: 5px;">
                                <span>No Image</span>
                            </div>
                        `;
                        
                        $item.find('.variation-view').html(`
                            <div style="display: flex; gap: 15px; align-items: flex-start;">
                                ${imageHtml}
                                <div style="flex: 1; display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 10px; font-size: 13px; color: #646970;">
                                    <div><strong>SKU:</strong> ${escapeHtml(variationData.sku || 'N/A')}</div>
                                    <div><strong>Price:</strong> $${parseFloat(variationData.price || 0).toFixed(2)}</div>
                                    <div><strong>Stock:</strong> ${variationData.stock_quantity || 0}</div>
                                    <div><strong>Status:</strong> ${variationData.stock_status || 'instock'}</div>
                                </div>
                            </div>
                        `);
                        
                        // Also update the image in the edit form preview if it's still open
                        if (imageUrl) {
                            $form.find('.variation-image-preview-edit').html(`<img src="${imageUrl}" alt="Variation Image" style="max-width: 100%; max-height: 100%; object-fit: cover; display: block;">`);
                        }
                        
                        // Hide form, show view
                        $item.find('.variation-view').show();
                        $item.find('.variation-edit-form').hide();
                        $item.find('.toggle-variation-edit').show();
                    } else {
                        toastr.error(response.data.message || 'Failed to update variation');
                    }
                },
                error: function() {
                    toastr.error('Network error occurred');
                },
                complete: function() {
                    $button.prop('disabled', false).html(originalText);
                }
            });
        });
        
        // Upload variation image
        $('.upload-variation-image-btn').off('click').on('click', function(e) {
            e.preventDefault();
            const index = $(this).data('index');
            const $item = $(`.variation-item[data-index="${index}"]`);
            const $form = $item.find('.variation-edit-form');
            const $preview = $form.find('.variation-image-preview-edit');
            const $imageId = $form.find('.variation-image-id');
            const $uploadBtn = $(this);
            const $removeBtn = $form.find('.remove-variation-image-btn');
            
            // Check if wp.media is available
            if (typeof wp === 'undefined' || typeof wp.media === 'undefined') {
                console.error('WordPress Media Library is not available');
                toastr.error('Media library is not available. Please refresh the page.');
                return;
            }
            
            // Create or reuse media frame for this variation
            if (!window.AIWPG.Variations.mediaFrames[index]) {
                window.AIWPG.Variations.mediaFrames[index] = wp.media({
                    title: 'Select Variation Image',
                    button: {
                        text: 'Use this image'
                    },
                    multiple: false
                });
                
                // When an image is selected, run a callback
                window.AIWPG.Variations.mediaFrames[index].on('select', function() {
                    const attachment = window.AIWPG.Variations.mediaFrames[index].state().get('selection').first().toJSON();
                    
                    // Update preview
                    $preview.html(`<img src="${attachment.url}" alt="Variation Image" style="max-width: 100%; max-height: 100%; object-fit: cover; display: block;">`);
                    
                    // Update hidden input
                    $imageId.val(attachment.id);
                    
                    // Update button text
                    $uploadBtn.html('<span class="dashicons dashicons-upload" style="font-size: 16px; width: 16px; height: 16px; margin-top: 2px;"></span> Change Image');
                    
                    // Show remove button if not already shown
                    if ($removeBtn.length === 0 || $removeBtn.is(':hidden')) {
                        $uploadBtn.after(`
                            <button type="button" class="button button-link remove-variation-image-btn" data-index="${index}" style="display: block; color: #b32d2e; margin-top: 8px;">
                                <span class="dashicons dashicons-trash" style="font-size: 16px; width: 16px; height: 16px; margin-top: 2px;"></span>
                                Remove Image
                            </button>
                        `);
                        // Re-attach remove handler
                        $form.find('.remove-variation-image-btn').off('click').on('click', function(e) {
                            e.preventDefault();
                            $preview.html('<span style="color: #999; font-size: 11px; text-align: center; padding: 10px;">No Image</span>');
                            $imageId.val('');
                            $uploadBtn.html('<span class="dashicons dashicons-upload" style="font-size: 16px; width: 16px; height: 16px; margin-top: 2px;"></span> Upload Image');
                            $(this).remove();
                        });
                    }
                });
            }
            
            // Open the modal
            window.AIWPG.Variations.mediaFrames[index].open();
        });
        
        // Remove variation image
        $('.remove-variation-image-btn').off('click').on('click', function(e) {
            e.preventDefault();
            const index = $(this).data('index');
            const $item = $(`.variation-item[data-index="${index}"]`);
            const $form = $item.find('.variation-edit-form');
            const $preview = $form.find('.variation-image-preview-edit');
            const $imageId = $form.find('.variation-image-id');
            const $uploadBtn = $form.find('.upload-variation-image-btn');
            
            $preview.html('<span style="color: #999; font-size: 11px; text-align: center; padding: 10px;">No Image</span>');
            $imageId.val('');
            $uploadBtn.html('<span class="dashicons dashicons-upload" style="font-size: 16px; width: 16px; height: 16px; margin-top: 2px;"></span> Upload Image');
            $(this).remove();
        });
    };
    
})(jQuery);

