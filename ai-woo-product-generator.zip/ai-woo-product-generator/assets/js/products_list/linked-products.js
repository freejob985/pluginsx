/**
 * Linked Products Module
 * Advanced search with autocomplete and drag & drop
 */

(function($) {
    'use strict';
    
    window.AIWPG = window.AIWPG || {};
    window.AIWPG.LinkedProducts = {};
    
    // State
    let searchTimeout = null;
    let currentProductId = null;
    let allProducts = [];
    let upsells = [];
    let crossSells = [];
    let selectedTarget = 'upsell'; // Default target
    
    console.log('✅ Linked Products module loaded successfully!');
    
    /**
     * Initialize Linked Products
     */
    window.AIWPG.LinkedProducts.init = function() {
        console.log('🔗 Initializing Linked Products module...');
        
        // Check if aiwpgData is available
        if (typeof aiwpgData === 'undefined') {
            console.error('❌ aiwpgData is not defined! Linked Products will not work.');
            return;
        }
        
        console.log('✅ aiwpgData found:', {
            ajaxUrl: aiwpgData.ajaxUrl,
            nonce: aiwpgData.nonce ? 'OK' : 'MISSING'
        });
        
        // Toggle buttons
        $(document).on('click', '.toggle-btn', function() {
            $('.toggle-btn').removeClass('active');
            $(this).addClass('active');
            selectedTarget = $(this).data('target');
            console.log('📍 Selected target:', selectedTarget);
            
            // Update placeholder
            const placeholder = selectedTarget === 'upsell' ? 
                'Search and press Enter to add to Upsells...' : 
                'Search and press Enter to add to Cross-sells...';
            $('#linked-products-search').attr('placeholder', placeholder);
        });
        
        // Search input - using both delegated and direct binding for reliability
        $(document).on('input', '#linked-products-search', function() {
            console.log('🔍 [DELEGATED] Search input event triggered, value:', $(this).val());
            window.AIWPG.LinkedProducts.handleSearch($(this).val());
        });
        
        // Also bind directly when modal opens (backup method)
        $('#linked-products-search').on('input', function() {
            console.log('🔍 [DIRECT] Search input event triggered, value:', $(this).val());
            window.AIWPG.LinkedProducts.handleSearch($(this).val());
        });
        
        // Additional event listeners for debugging
        $(document).on('keyup', '#linked-products-search', function() {
            console.log('⌨️ Keyup event on search, value:', $(this).val());
        });
        
        // Enter key to add first result
        $(document).on('keydown', '#linked-products-search', function(e) {
            if (e.key === 'Enter' || e.keyCode === 13) {
                e.preventDefault();
                const $firstItem = $('.autocomplete-item:first');
                
                if ($firstItem.length > 0) {
                    const productId = $firstItem.data('id');
                    const productTitle = $firstItem.data('title');
                    
                    window.AIWPG.LinkedProducts.addProduct(productId, productTitle, selectedTarget);
                    
                    // Clear search
                    $('#linked-products-search').val('');
                    $('#linked-products-autocomplete').hide();
                    
                    toastr.success("✅");
                }
            }
        });
        
        // Click outside to close autocomplete
        $(document).on('click', function(e) {
            if (!$(e.target).closest('.linked-products-search-wrapper').length) {
                $('#linked-products-autocomplete').hide();
            }
        });
        
        // Focus to show products (even if empty)
        $(document).on('focus', '#linked-products-search', function() {
            console.log('🎯 Search input focused!');
            const value = $(this).val();
            
            if (value.length >= 1) {
                // إذا كان هناك نص، ابحث
                window.AIWPG.LinkedProducts.handleSearch(value);
            } else if (allProducts.length > 0) {
                // إذا كان فارغ، اعرض أول 5 منتجات
                console.log('   - Showing first 5 products on focus');
                const firstProducts = allProducts.slice(0, 5);
                window.AIWPG.LinkedProducts.renderAutocomplete(firstProducts, '');
            }
        });
        
        // Click on autocomplete result button
        $(document).on('click', '.autocomplete-result-btn', function(e) {
            const productId = $(this).data('id');
            const productTitle = $(this).data('title');
            
            // إذا كان المنتج مضاف بالفعل، احذفه من القسم
            if ($(this).hasClass('added')) {
                console.log('🗑️ Removing already added product:', productTitle);
                
                // حذف المنتج من القسم المختار
                window.AIWPG.LinkedProducts.removeProduct(productId, selectedTarget);
                
                // تحديث حالة الزر
                $(this).removeClass('added');
                $(this).find('.added-badge').remove();
                
                toastr.info("تم الحذف");
                return;
            }
            
            // إضافة المنتج للقسم المختار
            window.AIWPG.LinkedProducts.addProduct(productId, productTitle, selectedTarget);
            
            // تحديث حالة الزر
            $(this).addClass('added');
            if (!$(this).find('.added-badge').length) {
                $(this).find('.product-name').after('<span class="added-badge">✓</span>');
            }
        });
        
        // Remove product
        $(document).on('click', '.remove-linked-product', function(e) {
            e.stopPropagation();
            const $item = $(this).closest('.linked-product-item');
            const productId = $item.data('id');
            const type = $item.closest('.linked-products-list').data('type');
            
            window.AIWPG.LinkedProducts.removeProduct(productId, type);
        });
        
        // Drag & Drop
        window.AIWPG.LinkedProducts.initDragDrop();
        
        console.log('✅ Linked Products module initialized');
    };
    
    /**
     * Rebind search events (called when modal opens)
     */
    window.AIWPG.LinkedProducts.rebindEvents = function() {
        console.log('🔄 Rebinding search events...');
        
        const $searchInput = $('#linked-products-search');
        const $autocomplete = $('#linked-products-autocomplete');
        
        if ($searchInput.length === 0) {
            console.error('❌ Search input not found!');
            return;
        }
        
        console.log('✅ Search input found:', $searchInput);
        console.log('✅ Autocomplete element found:', $autocomplete.length > 0);
        
        // Remove old events to avoid duplicates
        $searchInput.off('input.linkedproducts keyup.linkedproducts');
        
        // Bind new events
        $searchInput.on('input.linkedproducts', function() {
            const value = $(this).val();
            console.log('📝 [REBIND] Input changed:', value);
            window.AIWPG.LinkedProducts.handleSearch(value);
        });
        
        $searchInput.on('keyup.linkedproducts', function(e) {
            console.log('⌨️ [REBIND] Key pressed:', e.key, 'Value:', $(this).val());
        });
        
        console.log('✅ Events rebound successfully');
    };
    
    /**
     * Load linked products data
     */
    window.AIWPG.LinkedProducts.load = function(productId, upsellIds, crossSellIds) {
        console.log('📦 ========================================');
        console.log('📦 LOADING LINKED PRODUCTS');
        console.log('📦 ========================================');
        console.log('   - Product ID:', productId);
        console.log('   - Upsells:', upsellIds);
        console.log('   - Cross-sells:', crossSellIds);
        console.log('   - AJAX URL:', aiwpgData ? aiwpgData.ajaxUrl : 'UNDEFINED');
        console.log('   - Nonce:', aiwpgData && aiwpgData.nonce ? 'OK' : 'MISSING');
        
        currentProductId = productId;
        upsells = upsellIds || [];
        crossSells = crossSellIds || [];
        
        // Clear previous products
        allProducts = [];
        
        // Rebind events to ensure they work
        window.AIWPG.LinkedProducts.rebindEvents();
        
        // Show loading state
        $('#linked-products-autocomplete').html(`
            <div class="autocomplete-no-results">
                <span class="spinner is-active"></span>
                <p><strong>Loading products...</strong></p>
            </div>
        `).show();
        
        // Check if aiwpgData is available
        if (typeof aiwpgData === 'undefined') {
            console.error('❌ aiwpgData is undefined! Cannot load products.');
            return;
        }
        
        console.log('✅ aiwpgData is available, sending AJAX request...');
        
        // Load all products
        $.ajax({
            url: aiwpgData.ajaxUrl,
            type: 'POST',
            data: {
                action: 'aiwpg_get_all_products_list',
                nonce: aiwpgData.nonce,
                exclude_id: productId
            },
            beforeSend: function() {
                console.log('⏳ Sending AJAX request to:', aiwpgData.ajaxUrl);
                console.log('   - Action: aiwpg_get_all_products_list');
                console.log('   - Nonce:', aiwpgData.nonce);
                console.log('   - Exclude ID:', productId);
            },
            success: function(response) {
                console.log('📨 AJAX response received:', response);
                
                if (response.success && response.data && response.data.products) {
                    allProducts = response.data.products;
                    console.log('✅ ========================================');
                    console.log('✅ PRODUCTS LOADED SUCCESSFULLY!');
                    console.log('✅ Total products:', allProducts.length);
                    console.log('✅ ========================================');
                    
                    if (allProducts.length > 0) {
                        console.log('📋 Sample products (first 5):');
                        allProducts.slice(0, 5).forEach((p, i) => {
                            console.log(`   ${i+1}. ID: ${p.id}, Title: ${p.title}`);
                        });
                    } else {
                        console.warn('⚠️ No products returned from server');
                    }
                    
                    // Render current upsells and cross-sells
                    window.AIWPG.LinkedProducts.renderProducts();
                    
                    if (allProducts.length > 0) {
                        console.log('🎉 ========================================');
                        console.log('🎉 Products ready! Showing first 5 products...');
                        console.log('🎉 Total products available:', allProducts.length);
                        console.log('🎉 ========================================');
                        
                        // ✨ عرض أول 5 منتجات تلقائياً بعد التحميل
                        setTimeout(function() {
                            const firstProducts = allProducts.slice(0, 5);
                            console.log('🎯 Rendering first 5 products automatically...');
                            console.log('🎯 Products to show:', firstProducts.map(p => p.title));
                            
                            window.AIWPG.LinkedProducts.renderAutocomplete(firstProducts, '');
                            
                            console.log('🎯 Autocomplete should be visible now!');
                            console.log('🎯 Checking visibility...');
                            console.log('   - Display:', $('#linked-products-autocomplete').css('display'));
                            console.log('   - Visibility:', $('#linked-products-autocomplete').css('visibility'));
                            console.log('   - Opacity:', $('#linked-products-autocomplete').css('opacity'));
                            console.log('   - Height:', $('#linked-products-autocomplete').height());
                        }, 500);
                        
                    } else {
                        console.warn('⚠️ No products in store!');
                        $('#linked-products-autocomplete').hide();
                    }
                } else {
                    console.error('❌ Failed to load products:', response);
                    $('#linked-products-autocomplete').html(`
                        <div class="autocomplete-no-results">
                            <span class="dashicons dashicons-warning"></span>
                            <p>Failed to load products</p>
                        </div>
                    `);
                }
            },
            error: function(xhr, status, error) {
                console.error('❌ AJAX error:', {
                    status: status,
                    error: error,
                    xhr: xhr,
                    responseText: xhr.responseText,
                    readyState: xhr.readyState,
                    statusCode: xhr.status
                });
                $('#linked-products-autocomplete').html(`
                    <div class="autocomplete-no-results">
                        <span class="dashicons dashicons-warning"></span>
                        <p>Server error</p>
                    </div>
                `);
            }
        });
    };
    
    /**
     * Handle search with autocomplete
     */
    window.AIWPG.LinkedProducts.handleSearch = function(query) {
        clearTimeout(searchTimeout);
        
        console.log('🔍 ========================================');
        console.log('🔍 SEARCH TRIGGERED');
        console.log('   - Query:', query);
        console.log('   - Query length:', query.length);
        console.log('   - All products count:', allProducts.length);
        console.log('🔍 ========================================');
        
        // إذا كان البحث فارغ، عرض أول 5 منتجات
        if (query.length < 1) {
            console.log('   - Query empty, showing first 5 products');
            if (allProducts.length > 0) {
                const firstProducts = allProducts.slice(0, 5);
                window.AIWPG.LinkedProducts.renderAutocomplete(firstProducts, '');
            } else {
                $('#linked-products-autocomplete').hide();
            }
            return;
        }
        
        // Check if products are loaded
        if (allProducts.length === 0) {
            console.warn('⚠️ No products loaded yet! Cannot search.');
            console.warn('   - Make sure load() was called successfully');
            console.warn('   - Check AJAX response in Network tab');
            
            $('#linked-products-autocomplete').html(`
                <div class="autocomplete-no-results">
                    <span class="dashicons dashicons-warning" style="color: #ff9800;"></span>
                    <p><strong>Loading...</strong></p>
                </div>
            `).show();
            return;
        }
        
        console.log('✅ Products are loaded, proceeding with search...');
        
        // Show loading
        $('.search-spinner').show();
        
        searchTimeout = setTimeout(function() {
            console.log('🔍 Executing search after 300ms delay...');
            const results = window.AIWPG.LinkedProducts.searchProducts(query);
            console.log('📦 Search completed, found:', results.length, 'results');
            window.AIWPG.LinkedProducts.renderAutocomplete(results, query);
            $('.search-spinner').hide();
        }, 300);
    };
    
    /**
     * Search products locally
     */
    window.AIWPG.LinkedProducts.searchProducts = function(query) {
        const lowerQuery = query.toLowerCase();
        
        console.log('🔍 Searching in', allProducts.length, 'products for:', lowerQuery);
        
        // Filter products that match the query
        const matches = allProducts.filter(function(product) {
            const titleMatch = product.title && product.title.toLowerCase().includes(lowerQuery);
            console.log('  - Checking:', product.title, '→', titleMatch);
            return titleMatch;
        });
        
        console.log('✅ Matches found:', matches.length);
        
        // Return max 5 results
        return matches.slice(0, 5);
    };
    
    /**
     * Render autocomplete results as draggable buttons
     */
    window.AIWPG.LinkedProducts.renderAutocomplete = function(results, query) {
        const $autocomplete = $('#linked-products-autocomplete');
        
        console.log('🎨 ========== RENDERING AUTOCOMPLETE ==========');
        console.log('   - Results count:', results.length);
        console.log('   - Query:', query);
        console.log('   - Autocomplete element exists:', $autocomplete.length > 0);
        console.log('   - Autocomplete element:', $autocomplete[0]);
        
        if ($autocomplete.length === 0) {
            console.error('❌ #linked-products-autocomplete NOT FOUND in DOM!');
            return;
        }
        
        if (results.length === 0) {
            console.log('⚠️ No results, showing no-results message');
            const searchText = query ? `لـ "${window.AIWPG.Common.escapeHtml(query)}"` : '';
            $autocomplete.html(`
                <div class="autocomplete-no-results">
                    <span class="dashicons dashicons-warning"></span>
                    <p>لا توجد نتائج ${searchText}</p>
                    <p style="font-size: 12px; margin-top: 5px;">جرّب كلمة بحث أخرى</p>
                </div>
            `).show();
            console.log('✅ No-results message displayed');
            return;
        }
        
        const targetName = selectedTarget === 'upsell' ? 'Upsells' : 'Cross-sells';
        const targetIcon = selectedTarget === 'upsell' ? 'arrow-up-alt' : 'randomize';
        
        console.log('   - Target:', selectedTarget, '→', targetName);
        console.log('   - Building HTML...');
        
        // تحديد النص المناسب للعنوان
        const headerText = query ? `نتائج البحث (${results.length})` : `اقتراحات (${results.length})`;
        const targetArrow = selectedTarget === 'upsell' ? '🔼' : '🔀';
        
        let html = `
            <div class="autocomplete-header">
                <span class="dashicons dashicons-search"></span>
                ${headerText} - ${targetArrow} ${targetName}
            </div>
            <div class="autocomplete-results-grid">
        `;
        
        console.log('   - Processing products...');
        results.forEach(function(product, index) {
            const isInUpsells = upsells.includes(product.id) || upsells.includes(String(product.id));
            const isInCrossSells = crossSells.includes(product.id) || crossSells.includes(String(product.id));
            const isAdded = (selectedTarget === 'upsell' && isInUpsells) || 
                           (selectedTarget === 'cross-sell' && isInCrossSells);
            
            // Escape HTML to prevent XSS
            const safeTitle = window.AIWPG.Common.escapeHtml(product.title);
            
            console.log(`     ${index + 1}. ${safeTitle} (ID: ${product.id}) - Added: ${isAdded}`);
            
            html += `
                <button type="button" 
                        class="autocomplete-result-btn ${isAdded ? 'added' : ''}" 
                        data-id="${product.id}" 
                        data-title="${safeTitle}"
                        draggable="true">
                    <span class="dashicons dashicons-products"></span>
                    <span class="product-name">${safeTitle}</span>
                    ${isAdded ? '<span class="added-badge">✓</span>' : ''}
                    <span class="drag-indicator">
                        <span class="dashicons dashicons-move"></span>
                    </span>
                </button>
            `;
        });
        
        html += '</div>';
        
        console.log('   - HTML built successfully, length:', html.length);
        console.log('   - Setting HTML to autocomplete...');
        
        $autocomplete.html(html);
        
        console.log('   - Showing autocomplete...');
        
        // إظهار العنصر
        $autocomplete.show();
        
        console.log('   - Autocomplete display:', $autocomplete.css('display'));
        console.log('   - Autocomplete visibility:', $autocomplete.is(':visible'));
        console.log('   - Autocomplete z-index:', $autocomplete.css('z-index'));
        
        // Verify buttons were created
        const buttonCount = $autocomplete.find('.autocomplete-result-btn').length;
        console.log('   - Buttons created:', buttonCount);
        
        if (buttonCount === 0) {
            console.error('❌ No buttons were created!');
        } else {
            console.log('   - First button:', $autocomplete.find('.autocomplete-result-btn').first()[0]);
        }
        
        // Setup drag & drop for results
        console.log('   - Setting up drag & drop...');
        window.AIWPG.LinkedProducts.setupResultsDragDrop();
        
        console.log('✅ ========== AUTOCOMPLETE RENDERED ==========');
        console.log('✅ Buttons should be visible now!');
    };
    
    /**
     * Add product to list
     */
    window.AIWPG.LinkedProducts.addProduct = function(productId, productTitle, type) {
        productId = parseInt(productId);
        
        if (type === 'upsell') {
            if (!upsells.includes(productId)) {
                upsells.push(productId);
                console.log('➕ Added to upsells:', productId);
            }
        } else if (type === 'cross-sell') {
            if (!crossSells.includes(productId)) {
                crossSells.push(productId);
                console.log('➕ Added to cross-sells:', productId);
            }
        }
        
        window.AIWPG.LinkedProducts.renderProducts();
        window.AIWPG.LinkedProducts.updateHiddenInputs();
    };
    
    /**
     * Remove product from list
     */
    window.AIWPG.LinkedProducts.removeProduct = function(productId, type) {
        productId = parseInt(productId);
        
        if (type === 'upsell') {
            upsells = upsells.filter(id => id !== productId);
            console.log('➖ Removed from upsells:', productId);
        } else if (type === 'cross-sell') {
            crossSells = crossSells.filter(id => id !== productId);
            console.log('➖ Removed from cross-sells:', productId);
        }
        
        // تحديث حالة الزر في الاقتراحات - إزالة علامة ✓
        const $btn = $(`.autocomplete-result-btn[data-id="${productId}"]`);
        if ($btn.length > 0 && $btn.hasClass('added')) {
            // التحقق من أن المنتج ليس في القسم الآخر
            const isInOtherSection = (type === 'upsell' && crossSells.includes(productId)) || 
                                    (type === 'cross-sell' && upsells.includes(productId));
            
            if (!isInOtherSection) {
                $btn.removeClass('added');
                $btn.find('.added-badge').remove();
                console.log('✅ Updated button state for product:', productId);
            }
        }
        
        window.AIWPG.LinkedProducts.renderProducts();
        window.AIWPG.LinkedProducts.updateHiddenInputs();
    };
    
    /**
     * Render products lists
     */
    window.AIWPG.LinkedProducts.renderProducts = function() {
        // Render Upsells
        window.AIWPG.LinkedProducts.renderList('upsell', upsells, '#upsells-list');
        $('#upsells-count').text('(' + upsells.length + ')');
        
        // Render Cross-sells
        window.AIWPG.LinkedProducts.renderList('cross-sell', crossSells, '#cross-sells-list');
        $('#cross-sells-count').text('(' + crossSells.length + ')');
    };
    
    /**
     * Render a specific list
     */
    window.AIWPG.LinkedProducts.renderList = function(type, productIds, selector) {
        const $list = $(selector);
        
        if (productIds.length === 0) {
            // إظهار الـ empty state (الموجود في HTML مع الترجمة)
            $list.find('.empty-state').show();
            $list.find('.linked-product-item').remove();
            return;
        }
        
        // إخفاء الـ empty state
        $list.find('.empty-state').hide();
        
        let html = '';
        productIds.forEach(function(productId) {
            const product = allProducts.find(p => p.id === productId);
            if (product) {
                html += `
                    <div class="linked-product-item" data-id="${product.id}" draggable="true">
                        <span class="drag-handle dashicons dashicons-menu"></span>
                        <span class="dashicons dashicons-products"></span>
                        <span class="product-title">${product.title}</span>
                        <button type="button" class="remove-linked-product">
                            <span class="dashicons dashicons-no-alt"></span>
                        </button>
                    </div>
                `;
            }
        });
        
        $list.find('.linked-product-item').remove();
        $list.append(html);
    };
    
    /**
     * Update hidden inputs with product IDs
     */
    window.AIWPG.LinkedProducts.updateHiddenInputs = function() {
        $('#edit-upsell-ids').val(upsells.join(','));
        $('#edit-cross-sell-ids').val(crossSells.join(','));
    };
    
    /**
     * Setup Drag & Drop for autocomplete results
     */
    window.AIWPG.LinkedProducts.setupResultsDragDrop = function() {
        let draggedProduct = null;
        
        // Drag start from autocomplete results
        $('.autocomplete-result-btn').on('dragstart', function(e) {
            if ($(this).prop('disabled')) {
                e.preventDefault();
                return;
            }
            
            draggedProduct = {
                id: $(this).data('id'),
                title: $(this).data('title'),
                source: 'autocomplete'
            };
            
            $(this).addClass('dragging');
            e.originalEvent.dataTransfer.effectAllowed = 'copy';
            e.originalEvent.dataTransfer.setData('text/plain', draggedProduct.id);
            
            console.log('🎯 Started dragging product:', draggedProduct.title);
        });
        
        // Drag end
        $('.autocomplete-result-btn').on('dragend', function() {
            $(this).removeClass('dragging');
            $('.drag-over-zone').removeClass('drag-over-zone');
            draggedProduct = null;
        });
    };
    
    /**
     * Initialize Drag & Drop for lists
     */
    window.AIWPG.LinkedProducts.initDragDrop = function() {
        let draggedItem = null;
        
        // Drag start from linked products lists
        $(document).on('dragstart', '.linked-product-item', function(e) {
            draggedItem = $(this);
            $(this).addClass('dragging');
            e.originalEvent.dataTransfer.effectAllowed = 'move';
        });
        
        // Drag end
        $(document).on('dragend', '.linked-product-item', function() {
            $(this).removeClass('dragging');
            $('.drag-over').removeClass('drag-over');
            $('.drag-over-zone').removeClass('drag-over-zone');
        });
        
        // Drag over list items (for reordering)
        $(document).on('dragover', '.linked-product-item', function(e) {
            e.preventDefault();
            e.originalEvent.dataTransfer.dropEffect = 'move';
            
            if (draggedItem && draggedItem[0] !== this) {
                $(this).addClass('drag-over');
            }
        });
        
        // Drag leave
        $(document).on('dragleave', '.linked-product-item', function() {
            $(this).removeClass('drag-over');
        });
        
        // Drop on list item (for reordering)
        $(document).on('drop', '.linked-product-item', function(e) {
            e.preventDefault();
            
            if (draggedItem && draggedItem[0] !== this) {
                const $list = $(this).closest('.linked-products-list');
                const type = $list.data('type');
                
                // Reorder items
                if ($(this).index() > draggedItem.index()) {
                    $(this).after(draggedItem);
                } else {
                    $(this).before(draggedItem);
                }
                
                // Update order in array
                window.AIWPG.LinkedProducts.updateOrderFromDOM(type);
            }
            
            $(this).removeClass('drag-over');
        });
        
        // Drag over lists (for dropping from autocomplete)
        $(document).on('dragover', '.linked-products-list', function(e) {
            e.preventDefault();
            e.originalEvent.dataTransfer.dropEffect = 'copy';
            $(this).addClass('drag-over-zone');
        });
        
        $(document).on('dragleave', '.linked-products-list', function(e) {
            // Only remove if we're actually leaving the list
            if (!$(e.relatedTarget).closest('.linked-products-list').length) {
                $(this).removeClass('drag-over-zone');
            }
        });
        
        // Drop on lists (from autocomplete)
        $(document).on('drop', '.linked-products-list', function(e) {
            e.preventDefault();
            $(this).removeClass('drag-over-zone');
            
            const type = $(this).data('type');
            const productId = parseInt(e.originalEvent.dataTransfer.getData('text/plain'));
            
            if (!productId) {
                console.error('❌ No product ID in drop event');
                return;
            }
            
            // Find product in allProducts
            const product = allProducts.find(p => p.id === productId);
            
            if (!product) {
                console.error('❌ Product not found:', productId);
                return;
            }
            
            // Check if already added
            const alreadyAdded = (type === 'upsell' && upsells.includes(productId)) ||
                               (type === 'cross-sell' && crossSells.includes(productId));
            
            if (alreadyAdded) {
                return;
            }
            
            // Add product
            window.AIWPG.LinkedProducts.addProduct(productId, product.title, type);
            
            // Update autocomplete button state
            const $btn = $(`.autocomplete-result-btn[data-id="${productId}"]`);
            if ($btn.length) {
                $btn.addClass('added');
                if (!$btn.find('.added-badge').length) {
                    $btn.find('.product-name').after('<span class="added-badge">✓</span>');
                }
            }
            
            console.log('✅ Product dropped successfully:', product.title, '→', type);
        });
    };
    
    /**
     * Update array order from DOM
     */
    window.AIWPG.LinkedProducts.updateOrderFromDOM = function(type) {
        const selector = type === 'upsell' ? '#upsells-list' : '#cross-sells-list';
        const newOrder = [];
        
        $(selector).find('.linked-product-item').each(function() {
            newOrder.push(parseInt($(this).data('id')));
        });
        
        if (type === 'upsell') {
            upsells = newOrder;
        } else {
            crossSells = newOrder;
        }
        
        window.AIWPG.LinkedProducts.updateHiddenInputs();
        console.log('🔄 Updated order for', type, ':', newOrder);
    };
    
    /**
     * Get current values
     */
    window.AIWPG.LinkedProducts.getValues = function() {
        return {
            upsells: upsells,
            crossSells: crossSells
        };
    };
    
    /**
     * TEST FUNCTION: Force show test results
     * Call from console: AIWPG.LinkedProducts.testRender()
     */
    window.AIWPG.LinkedProducts.testRender = function() {
        console.log('🧪 ========== TEST RENDER ==========');
        
        // Create fake products for testing
        const testProducts = [
            {id: 1, title: 'Test Product 1'},
            {id: 2, title: 'Test Product 2'},
            {id: 3, title: 'Test Product 3'},
            {id: 4, title: 'Test Product 4'},
            {id: 5, title: 'Test Product 5'}
        ];
        
        console.log('🧪 Rendering test products...');
        window.AIWPG.LinkedProducts.renderAutocomplete(testProducts, 'test');
        
        console.log('✅ Test render complete! Check if buttons appear.');
    };
    
    /**
     * DEBUG FUNCTION: Show current state
     * Call from console: AIWPG.LinkedProducts.debug()
     */
    window.AIWPG.LinkedProducts.debug = function() {
        console.log('🔍 ========== DEBUG INFO ==========');
        console.log('All products loaded:', allProducts.length);
        console.log('Upsells:', upsells);
        console.log('Cross-sells:', crossSells);
        console.log('Selected target:', selectedTarget);
        console.log('Search input exists:', $('#linked-products-search').length > 0);
        console.log('Autocomplete element exists:', $('#linked-products-autocomplete').length > 0);
        console.log('Autocomplete is visible:', $('#linked-products-autocomplete').is(':visible'));
        console.log('Autocomplete display:', $('#linked-products-autocomplete').css('display'));
        console.log('Autocomplete HTML length:', $('#linked-products-autocomplete').html().length);
        console.log('Button count:', $('.autocomplete-result-btn').length);
        
        // Test if we can manually show it
        const $auto = $('#linked-products-autocomplete');
        if ($auto.length > 0) {
            console.log('Element position:', $auto.position());
            console.log('Element offset:', $auto.offset());
            console.log('Element dimensions:', {
                width: $auto.width(),
                height: $auto.height()
            });
        }
        
        console.log('=====================================');
    };
    
})(jQuery);

