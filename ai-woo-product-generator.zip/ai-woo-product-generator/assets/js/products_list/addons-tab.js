/**
 * Add-ons & AI Suggestions Tab
 * Handles all functionality for the product add-ons management tab
 * 
 * @package AIWPG
 * @since 1.0.0
 */

(function($) {
    'use strict';
    
    window.AIWPG = window.AIWPG || {};
    window.AIWPG.AddonsTab = {};
    
    // Current product ID
    let currentProductId = null;
    
    // Current filter source
    let currentFilterSource = 'all';
    
    /**
     * Initialize add-ons tab
     */
    window.AIWPG.AddonsTab.init = function() {
        // Load add-ons when tab is clicked
        $(document).on('click', '.tab-btn[data-tab="addons_ai"]', function() {
            const productId = $('#edit-product-id').val();
            if (productId) {
                currentProductId = parseInt(productId);
                loadAddons(currentProductId);
            }
        });
        
        // Source filter buttons
        $(document).on('click', '.filter-btn', function() {
            $('.filter-btn').removeClass('active');
            $(this).addClass('active');
            currentFilterSource = $(this).data('source') || 'all';
            if (currentProductId) {
                loadAddons(currentProductId, currentFilterSource);
            }
        });
        
        // Manual add-on form
        $('#add-manual-addon').on('click', function() {
            createManualAddon();
        });
        
        // AI suggestions
        $('#generate-ai-suggestions').on('click', function() {
            generateAISuggestions();
        });
        
        // Bulk actions
        $('#apply-bulk-action').on('click', function() {
            applyBulkAction();
        });
        
        // Sync external add-ons
        $('#sync-external-addons').on('click', function() {
            syncExternalAddons();
        });
        
        // Select all checkbox
        $(document).on('change', '#select-all-addons', function() {
            const checked = $(this).is(':checked');
            $('#addons-table-body input[type="checkbox"][name="addon_ids[]"]').prop('checked', checked);
        });
        
        // Individual addon actions
        $(document).on('click', '.addon-action-btn', function() {
            const action = $(this).data('action');
            const addonId = $(this).data('id');
            
            if (action === 'edit') {
                editAddon(addonId);
            } else if (action === 'attach') {
                updateAddonStatus(addonId, 'attached');
            } else if (action === 'detach') {
                updateAddonStatus(addonId, 'suggested');
            } else if (action === 'delete') {
                deleteAddon(addonId);
            }
        });
        
        // Inline editing
        $(document).on('blur', '.editable-field', function() {
            const addonId = $(this).data('id');
            const field = $(this).data('field');
            const value = $(this).val() || $(this).text();
            
            updateAddonField(addonId, field, value);
        });
    };
    
    /**
     * Load add-ons for a product
     */
    function loadAddons(productId, source = null) {
        if (!productId) {
            return;
        }
        
        const $tbody = $('#addons-table-body');
        $tbody.html('<tr><td colspan="9"><p>Loading add-ons...</p></td></tr>');
        
        $.ajax({
            url: aiwpgData.ajaxUrl,
            type: 'POST',
            data: {
                action: 'aiwpg_get_product_addons',
                nonce: aiwpgData.nonce,
                product_id: productId,
                source: source || currentFilterSource !== 'all' ? currentFilterSource : null
            },
            success: function(response) {
                if (response.success && response.data.addons) {
                    renderAddonsTable(response.data.addons);
                    updateFilterCounts(response.data.counts || {});
                } else {
                    $tbody.html('<tr><td colspan="9"><p>No add-ons found.</p></td></tr>');
                }
            },
            error: function() {
                $tbody.html('<tr><td colspan="9"><p class="error">Error loading add-ons.</p></td></tr>');
            }
        });
    }
    
    /**
     * Render add-ons table
     */
    function renderAddonsTable(addons) {
        const $tbody = $('#addons-table-body');
        
        if (!addons || addons.length === 0) {
            $tbody.html('<tr><td colspan="9"><p>No add-ons found.</p></td></tr>');
            return;
        }
        
        let html = '';
        
        addons.forEach(function(addon) {
            const sourceBadge = getSourceBadge(addon.source);
            const statusBadge = getStatusBadge(addon.status);
            const canDelete = addon.source === 'manual';
            
            html += `
                <tr data-addon-id="${addon.id}" data-source="${addon.source}" data-status="${addon.status}">
                    <th class="check-column">
                        <input type="checkbox" name="addon_ids[]" value="${addon.id}">
                    </th>
                    <td>
                        <strong>${escapeHtml(addon.addon_name)}</strong>
                    </td>
                    <td>${escapeHtml(addon.addon_group || '-')}</td>
                    <td>${sourceBadge}</td>
                    <td>${statusBadge}</td>
                    <td>
                        <input type="number" 
                               class="editable-field small-text" 
                               data-id="${addon.id}" 
                               data-field="price" 
                               value="${addon.price || 0}" 
                               step="0.01" 
                               min="0">
                    </td>
                    <td>
                        <select class="editable-field" data-id="${addon.id}" data-field="selection_type">
                            <option value="single_choice" ${addon.selection_type === 'single_choice' ? 'selected' : ''}>Single Choice</option>
                            <option value="multiple_choice" ${addon.selection_type === 'multiple_choice' ? 'selected' : ''}>Multiple Choice</option>
                            <option value="checkbox" ${addon.selection_type === 'checkbox' ? 'selected' : ''}>Checkbox</option>
                        </select>
                    </td>
                    <td>
                        <select class="editable-field" data-id="${addon.id}" data-field="scope">
                            <option value="this_product" ${addon.scope === 'this_product' ? 'selected' : ''}>This Product</option>
                            <option value="category" ${addon.scope === 'category' ? 'selected' : ''}>Category</option>
                            <option value="kitchen" ${addon.scope === 'kitchen' ? 'selected' : ''}>Kitchen</option>
                        </select>
                    </td>
                    <td>
                        <div class="addon-actions">
                            ${addon.status === 'attached' 
                                ? `<button type="button" class="button button-small addon-action-btn" data-action="detach" data-id="${addon.id}" title="Detach">Detach</button>`
                                : `<button type="button" class="button button-small button-primary addon-action-btn" data-action="attach" data-id="${addon.id}" title="Attach">Attach</button>`
                            }
                            ${canDelete 
                                ? `<button type="button" class="button button-small button-link-delete addon-action-btn" data-action="delete" data-id="${addon.id}" title="Delete">Delete</button>`
                                : ''
                            }
                        </div>
                    </td>
                </tr>
            `;
        });
        
        $tbody.html(html);
    }
    
    /**
     * Get source badge HTML
     */
    function getSourceBadge(source) {
        const badges = {
            'sheet': '<span class="source-badge source-sheet">Sheet</span>',
            'woo_food': '<span class="source-badge source-woo-food">Woo Food</span>',
            'wc_addons': '<span class="source-badge source-wc-addons">WC Add-ons</span>',
            'manual': '<span class="source-badge source-manual">Manual</span>',
            'ai': '<span class="source-badge source-ai">AI</span>'
        };
        
        return badges[source] || '<span class="source-badge">' + source + '</span>';
    }
    
    /**
     * Get status badge HTML
     */
    function getStatusBadge(status) {
        const badges = {
            'suggested': '<span class="status-badge status-suggested">Suggested</span>',
            'attached': '<span class="status-badge status-attached">Attached</span>',
            'ignored': '<span class="status-badge status-ignored">Ignored</span>'
        };
        
        return badges[status] || '<span class="status-badge">' + status + '</span>';
    }
    
    /**
     * Update filter counts
     */
    function updateFilterCounts(counts) {
        $('.filter-btn').each(function() {
            const source = $(this).data('source');
            if (source && source !== 'all') {
                const count = counts[source] || 0;
                const $btn = $(this);
                let text = $btn.text().replace(/\s*\(\d+\)\s*$/, '');
                if (count > 0) {
                    $btn.text(text + ' (' + count + ')');
                }
            }
        });
    }
    
    /**
     * Create manual add-on
     */
    function createManualAddon() {
        const data = {
            product_id: currentProductId,
            addon_name: $('#manual-addon-name').val(),
            addon_group: $('#manual-addon-group').val() || null,
            price: parseFloat($('#manual-addon-price').val()) || 0,
            price_type: $('#manual-addon-price-type').val(),
            selection_type: $('#manual-addon-selection-type').val(),
            scope: $('#manual-addon-scope').val(),
            status: 'suggested'
        };
        
        if (!data.addon_name) {
            toastr.error('Add-on name is required');
            return;
        }
        
        $.ajax({
            url: aiwpgData.ajaxUrl,
            type: 'POST',
            data: {
                action: 'aiwpg_create_addon',
                nonce: aiwpgData.nonce,
                ...data
            },
            success: function(response) {
                if (response.success) {
                    toastr.success(response.data.message || 'Add-on created successfully');
                    // Clear form
                    $('#manual-addon-name, #manual-addon-group, #manual-addon-price').val('');
                    $('#manual-addon-price').val('0.00');
                    // Reload add-ons
                    loadAddons(currentProductId);
                } else {
                    toastr.error(response.data.message || 'Failed to create add-on');
                }
            },
            error: function() {
                toastr.error('Error creating add-on');
            }
        });
    }
    
    /**
     * Generate AI suggestions
     */
    function generateAISuggestions() {
        if (!currentProductId) {
            toastr.error('Product ID is required');
            return;
        }
        
        const $btn = $('#generate-ai-suggestions');
        const originalText = $btn.html();
        $btn.prop('disabled', true).html('<span class="spinner is-active"></span> Generating...');
        
        $.ajax({
            url: aiwpgData.ajaxUrl,
            type: 'POST',
            data: {
                action: 'aiwpg_generate_ai_suggestions',
                nonce: aiwpgData.nonce,
                product_id: currentProductId
            },
            success: function(response) {
                if (response.success) {
                    toastr.success(response.data.message || 'AI suggestions generated successfully');
                    loadAddons(currentProductId);
                } else {
                    toastr.error(response.data.message || 'Failed to generate AI suggestions');
                }
            },
            error: function() {
                toastr.error('Error generating AI suggestions');
            },
            complete: function() {
                $btn.prop('disabled', false).html(originalText);
            }
        });
    }
    
    /**
     * Apply bulk action
     */
    function applyBulkAction() {
        const action = $('#bulk-action-select').val();
        if (!action) {
            toastr.warning('Please select a bulk action');
            return;
        }
        
        const selectedIds = [];
        $('#addons-table-body input[name="addon_ids[]"]:checked').each(function() {
            selectedIds.push($(this).val());
        });
        
        if (selectedIds.length === 0) {
            toastr.warning('Please select at least one add-on');
            return;
        }
        
        $.ajax({
            url: aiwpgData.ajaxUrl,
            type: 'POST',
            data: {
                action: 'aiwpg_bulk_update_addons',
                nonce: aiwpgData.nonce,
                ids: selectedIds,
                action_type: action
            },
            success: function(response) {
                if (response.success) {
                    toastr.success(response.data.message || 'Bulk action applied successfully');
                    loadAddons(currentProductId);
                    $('#select-all-addons').prop('checked', false);
                } else {
                    toastr.error(response.data.message || 'Failed to apply bulk action');
                }
            },
            error: function() {
                toastr.error('Error applying bulk action');
            }
        });
    }
    
    /**
     * Sync external add-ons
     */
    function syncExternalAddons() {
        if (!currentProductId) {
            toastr.error('Product ID is required');
            return;
        }
        
        const $btn = $('#sync-external-addons');
        const originalText = $btn.html();
        $btn.prop('disabled', true).html('<span class="spinner is-active"></span> Syncing...');
        
        $.ajax({
            url: aiwpgData.ajaxUrl,
            type: 'POST',
            data: {
                action: 'aiwpg_sync_external_addons',
                nonce: aiwpgData.nonce,
                product_id: currentProductId
            },
            success: function(response) {
                if (response.success) {
                    toastr.success(response.data.message || 'External add-ons synced successfully');
                    loadAddons(currentProductId);
                } else {
                    toastr.error(response.data.message || 'Failed to sync external add-ons');
                }
            },
            error: function() {
                toastr.error('Error syncing external add-ons');
            },
            complete: function() {
                $btn.prop('disabled', false).html(originalText);
            }
        });
    }
    
    /**
     * Update add-on status
     */
    function updateAddonStatus(addonId, status) {
        updateAddonField(addonId, 'status', status);
    }
    
    /**
     * Update add-on field
     */
    function updateAddonField(addonId, field, value) {
        const data = {};
        data[field] = value;
        
        $.ajax({
            url: aiwpgData.ajaxUrl,
            type: 'POST',
            data: {
                action: 'aiwpg_update_addon',
                nonce: aiwpgData.nonce,
                id: addonId,
                ...data
            },
            success: function(response) {
                if (response.success) {
                    // Update row status class if status changed
                    if (field === 'status') {
                        const $row = $(`tr[data-addon-id="${addonId}"]`);
                        $row.attr('data-status', value);
                        $row.find('td:nth-child(5)').html(getStatusBadge(value));
                        // Update action button
                        if (value === 'attached') {
                            $row.find('.addon-action-btn[data-action="attach"]')
                                .replaceWith(`<button type="button" class="button button-small addon-action-btn" data-action="detach" data-id="${addonId}" title="Detach">Detach</button>`);
                        } else {
                            $row.find('.addon-action-btn[data-action="detach"]')
                                .replaceWith(`<button type="button" class="button button-small button-primary addon-action-btn" data-action="attach" data-id="${addonId}" title="Attach">Attach</button>`);
                        }
                    }
                } else {
                    toastr.error(response.data.message || 'Failed to update add-on');
                }
            },
            error: function() {
                toastr.error('Error updating add-on');
            }
        });
    }
    
    /**
     * Delete add-on
     */
    function deleteAddon(addonId) {
        if (!confirm('Are you sure you want to delete this add-on?')) {
            return;
        }
        
        $.ajax({
            url: aiwpgData.ajaxUrl,
            type: 'POST',
            data: {
                action: 'aiwpg_delete_addon',
                nonce: aiwpgData.nonce,
                id: addonId
            },
            success: function(response) {
                if (response.success) {
                    toastr.success(response.data.message || 'Add-on deleted successfully');
                    $(`tr[data-addon-id="${addonId}"]`).fadeOut(function() {
                        $(this).remove();
                        // Check if table is empty
                        if ($('#addons-table-body tr').length === 0) {
                            $('#addons-table-body').html('<tr><td colspan="9"><p>No add-ons found.</p></td></tr>');
                        }
                    });
                } else {
                    toastr.error(response.data.message || 'Failed to delete add-on');
                }
            },
            error: function() {
                toastr.error('Error deleting add-on');
            }
        });
    }
    
    /**
     * Escape HTML
     */
    function escapeHtml(text) {
        const map = {
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#039;'
        };
        return text ? text.replace(/[&<>"']/g, m => map[m]) : '';
    }
    
})(jQuery);
