/**
 * Add Product Modal
 * Multi-step wizard for adding WooCommerce products
 * Supports: Simple, Grouped, External/Affiliate, Variable
 * Options: Virtual, Downloadable
 */

(function($) {
    'use strict';
    
    window.AIWPG = window.AIWPG || {};
    window.AIWPG.AddProductModal = {};
    
    // Modal state
    let currentStep = 1;
    const totalSteps = 5;
    let productType = 'simple';
    let productData = {};
    let selectedImageId = null;
    let selectedGalleryIds = [];
    
    /**
     * Initialize Add Product Modal
     */
    window.AIWPG.AddProductModal.init = function() {
        // Open modal button
        $(document).on('click', '[data-action="add-product"]', function() {
            window.AIWPG.AddProductModal.open();
        });
        
        // Product type selection
        $(document).on('click', '#add-product-modal .product-type-selector .type-option', function() {
            $('#add-product-modal .product-type-selector .type-option').removeClass('selected');
            $(this).addClass('selected');
            productType = $(this).data('type');
            window.AIWPG.AddProductModal.updateFieldsVisibility();
        });
        
        // Virtual and Downloadable checkboxes
        $(document).on('change', '#add-virtual', function() {
            if ($(this).is(':checked')) {
                $('.shipping-fields').slideUp();
            } else {
                $('.shipping-fields').slideDown();
            }
        });
        
        $(document).on('change', '#add-downloadable', function() {
            if ($(this).is(':checked')) {
                $('.downloadable-fields').slideDown();
            } else {
                $('.downloadable-fields').slideUp();
            }
        });
        
        // Add downloadable file row
        $(document).on('click', '.add-downloadable-file', function() {
            window.AIWPG.AddProductModal.addDownloadableFileRow();
        });
        
        // Remove downloadable file row
        $(document).on('click', '.remove-downloadable-file', function() {
            $(this).closest('tr').remove();
        });
        
        // Choose file from WordPress media library
        $(document).on('click', '.choose-downloadable-file', function(e) {
            e.preventDefault();
            const $button = $(this);
            const $row = $button.closest('tr');
            
            // Create WordPress media frame
            const frame = wp.media({
                title: 'Select Downloadable File',
                button: {
                    text: 'Use this file'
                },
                multiple: false
            });
            
            // When file is selected
            frame.on('select', function() {
                const attachment = frame.state().get('selection').first().toJSON();
                $row.find('.downloadable-file-url').val(attachment.url);
                
                // Auto-fill name if empty
                if (!$row.find('.downloadable-file-name').val()) {
                    $row.find('.downloadable-file-name').val(attachment.title || attachment.filename);
                }
            });
            
            frame.open();
        });
        
        // Manage stock toggle
        $(document).on('change', '#add-manage-stock', function() {
            if ($(this).is(':checked')) {
                $('.stock-quantity-group').slideDown();
            } else {
                $('.stock-quantity-group').slideUp();
            }
        });
        
        // Real-time price validation
        $(document).on('input', '#add-sale-price', function() {
            const salePrice = parseFloat($(this).val());
            const regularPrice = parseFloat($('#add-regular-price').val());
            
            if (!isNaN(salePrice) && !isNaN(regularPrice)) {
                if (salePrice >= regularPrice) {
                    $(this).css('border-color', '#dc3232');
                    if (!$('.sale-price-error').length) {
                        $(this).after('<p class="sale-price-error" style="color: #dc3232; font-size: 12px; margin: 5px 0 0 0;">⚠️ Sale price must be less than regular price</p>');
                    }
                } else {
                    $(this).css('border-color', '');
                    $('.sale-price-error').remove();
                }
            } else {
                $(this).css('border-color', '');
                $('.sale-price-error').remove();
            }
        });
        
        // Update sale price validation when regular price changes
        $(document).on('input', '#add-regular-price', function() {
            if ($('#add-sale-price').val()) {
                $('#add-sale-price').trigger('input');
            }
        });
        
        // Navigation buttons
        $(document).on('click', '#add-product-next', function() {
            if (window.AIWPG.AddProductModal.validateStep(currentStep)) {
                window.AIWPG.AddProductModal.saveStepData(currentStep);
                window.AIWPG.AddProductModal.nextStep();
            }
        });
        
        $(document).on('click', '#add-product-prev', function() {
            window.AIWPG.AddProductModal.prevStep();
        });
        
        $(document).on('click', '#add-product-save', function() {
            if (window.AIWPG.AddProductModal.validateStep(currentStep)) {
                window.AIWPG.AddProductModal.saveStepData(currentStep);
                window.AIWPG.AddProductModal.saveProduct();
            }
        });
        
        // Step indicators click
        $(document).on('click', '#add-product-modal .step-indicator:not(.disabled)', function() {
            const step = $(this).data('step');
            if (step < currentStep) {
                window.AIWPG.AddProductModal.goToStep(step);
            }
        });
        
        // Tags input
        $(document).on('keydown', '#add-tags-input', function(e) {
            if (e.key === 'Enter' || e.key === ',') {
                e.preventDefault();
                const tag = $(this).val().trim();
                if (tag) {
                    window.AIWPG.AddProductModal.addTag(tag);
                    $(this).val('');
                }
            }
        });
        
        // Remove tag
        $(document).on('click', '.tag-remove', function() {
            $(this).closest('.tag-item').remove();
        });
        
        // Select product image
        $(document).on('click', '#add-product-image-btn', function(e) {
            e.preventDefault();
            window.AIWPG.AddProductModal.selectProductImage();
        });
        
        // Remove product image
        $(document).on('click', '#remove-product-image-btn', function(e) {
            e.preventDefault();
            window.AIWPG.AddProductModal.removeProductImage();
        });
        
        // Select gallery images
        $(document).on('click', '#add-product-gallery-btn', function(e) {
            e.preventDefault();
            window.AIWPG.AddProductModal.selectGalleryImages();
        });
        
        // Remove gallery image
        $(document).on('click', '.remove-gallery-image', function(e) {
            e.preventDefault();
            const imageId = $(this).data('id');
            window.AIWPG.AddProductModal.removeGalleryImage(imageId);
        });
    };
    
    /**
     * Open modal
     */
    window.AIWPG.AddProductModal.open = function() {
        currentStep = 1;
        productType = 'simple';
        productData = {};
        
        $('#add-product-modal').addClass('active');
        window.AIWPG.AddProductModal.goToStep(1);
        window.AIWPG.AddProductModal.updateFieldsVisibility();
        window.AIWPG.AddProductModal.updateNavigation();
        window.AIWPG.AddProductModal.loadCategories();
    };
    
    /**
     * Go to specific step
     */
    window.AIWPG.AddProductModal.goToStep = function(step) {
        currentStep = step;
        
        // Update step indicators
        $('.step-indicator').removeClass('active completed');
        $('.step-indicator').each(function() {
            const stepNum = $(this).data('step');
            if (stepNum < currentStep) {
                $(this).addClass('completed');
            } else if (stepNum === currentStep) {
                $(this).addClass('active');
            }
        });
        
        // Show/hide step content
        $('.add-step-content').removeClass('active');
        $(`.add-step-content[data-step="${step}"]`).addClass('active');
        
        window.AIWPG.AddProductModal.updateNavigation();
    };
    
    /**
     * Next step
     */
    window.AIWPG.AddProductModal.nextStep = function() {
        if (currentStep < totalSteps) {
            window.AIWPG.AddProductModal.goToStep(currentStep + 1);
        }
    };
    
    /**
     * Previous step
     */
    window.AIWPG.AddProductModal.prevStep = function() {
        if (currentStep > 1) {
            window.AIWPG.AddProductModal.goToStep(currentStep - 1);
        }
    };
    
    /**
     * Update navigation buttons
     */
    window.AIWPG.AddProductModal.updateNavigation = function() {
        // Previous button
        if (currentStep === 1) {
            $('#add-product-prev').prop('disabled', true);
        } else {
            $('#add-product-prev').prop('disabled', false);
        }
        
        // Next/Save button
        if (currentStep === totalSteps) {
            $('#add-product-next').hide();
            $('#add-product-save').show();
        } else {
            $('#add-product-next').show();
            $('#add-product-save').hide();
        }
    };
    
    /**
     * Update fields visibility based on product type
     */
    window.AIWPG.AddProductModal.updateFieldsVisibility = function() {
        // Hide all type-specific fields first
        $('.field-simple, .field-grouped, .field-external, .field-variable').hide();
        
        // Show fields based on product type
        switch(productType) {
            case 'simple':
                $('.field-simple').show();
                $('.virtual-downloadable-options').show();
                break;
            case 'grouped':
                $('.field-grouped').show();
                $('.virtual-downloadable-options').hide();
                $('#add-virtual, #add-downloadable').prop('checked', false);
                break;
            case 'external':
                $('.field-external').show();
                $('.virtual-downloadable-options').hide();
                $('#add-virtual, #add-downloadable').prop('checked', false);
                break;
            case 'variable':
                $('.field-variable').show();
                $('.virtual-downloadable-options').show();
                break;
        }
        
        // Update virtual/downloadable visibility
        if ($('#add-virtual').is(':checked')) {
            $('.shipping-fields').hide();
        } else {
            $('.shipping-fields').show();
        }
        
        if ($('#add-downloadable').is(':checked')) {
            $('.downloadable-fields').show();
        } else {
            $('.downloadable-fields').hide();
        }
    };
    
    /**
     * Validate current step
     */
    window.AIWPG.AddProductModal.validateStep = function(step) {
        let isValid = true;
        
        switch(step) {
            case 1: // Product Type & Basic Info
                const name = $('#add-product-name').val().trim();
                if (!name) {
                    toastr.error('Product name is required');
                    $('#add-product-name').focus();
                    isValid = false;
                }
                break;
                
            case 2: // Pricing
                if (productType === 'simple' || productType === 'external') {
                    const price = $('#add-regular-price').val();
                    if (!price || parseFloat(price) < 0) {
                        toastr.error('Please enter a valid regular price');
                        $('#add-regular-price').focus();
                        isValid = false;
                    }
                }
                break;
                
            case 3: // Inventory
                if (productType === 'simple' && $('#add-manage-stock').is(':checked')) {
                    const stock = $('#add-stock-quantity').val();
                    if (!stock || parseInt(stock) < 0) {
                        toastr.error('Please enter a valid stock quantity');
                        $('#add-stock-quantity').focus();
                        isValid = false;
                    }
                }
                break;
                
            case 4: // Media
                // Optional - images are not required
                break;
                
            case 5: // Categories & Settings
                // Optional validation
                break;
        }
        
        return isValid;
    };
    
    /**
     * Save step data
     */
    window.AIWPG.AddProductModal.saveStepData = function(step) {
        switch(step) {
            case 1: // Product Type & Basic Info
                productData.type = productType;
                productData.name = $('#add-product-name').val().trim();
                productData.description = $('#add-product-description').val().trim();
                productData.short_description = $('#add-product-short-description').val().trim();
                productData.sku = $('#add-product-sku').val().trim();
                productData.virtual = $('#add-virtual').is(':checked');
                productData.downloadable = $('#add-downloadable').is(':checked');
                
                // Type-specific fields
                if (productType === 'external') {
                    productData.external_url = $('#add-external-url').val().trim();
                    productData.button_text = $('#add-button-text').val().trim();
                }
                break;
                
            case 2: // Pricing
                productData.regular_price = $('#add-regular-price').val();
                productData.sale_price = $('#add-sale-price').val();
                productData.tax_status = $('#add-tax-status').val();
                productData.tax_class = $('#add-tax-class').val();
                break;
                
            case 3: // Inventory
                productData.manage_stock = $('#add-manage-stock').is(':checked');
                productData.stock_quantity = $('#add-stock-quantity').val();
                productData.stock_status = $('#add-stock-status').val();
                productData.sold_individually = $('#add-sold-individually-add').is(':checked');
                
                // Shipping (if not virtual)
                if (!productData.virtual) {
                    productData.weight = $('#add-weight').val();
                    productData.length = $('#add-length').val();
                    productData.width = $('#add-width').val();
                    productData.height = $('#add-height').val();
                }
                
                // Downloadable files
                if (productData.downloadable) {
                    productData.downloadable_files = window.AIWPG.AddProductModal.getDownloadableFiles();
                    productData.download_limit = $('#add-download-limit').val();
                    productData.download_expiry = $('#add-download-expiry').val();
                }
                break;
                
            case 4: // Media (Images)
                productData.image_id = selectedImageId;
                productData.gallery_ids = selectedGalleryIds;
                break;
                
            case 5: // Categories & Settings
                productData.categories = $('#add-categories').val() || [];
                productData.tags = window.AIWPG.AddProductModal.getTags();
                productData.status = $('#add-status').val();
                productData.featured = $('#add-featured').is(':checked');
                productData.catalog_visibility = $('#add-catalog-visibility').val();
                productData.reviews_allowed = $('#add-reviews-allowed').is(':checked');
                break;
        }
    };
    
    /**
     * Validate product data before sending
     */
    window.AIWPG.AddProductModal.validateProductData = function(data) {
        console.log('Validating product data...');
        
        const errors = [];
        
        // Check name
        if (!data.name || data.name.trim() === '') {
            errors.push('Product name is required');
        }
        
        // Check type
        if (!data.type) {
            errors.push('Product type is required');
        }
        
        // For simple products, check price
        if (data.type === 'simple') {
            if (!data.regular_price || data.regular_price === '') {
                errors.push('Regular price is required for simple products');
            } else {
                const price = parseFloat(data.regular_price);
                if (isNaN(price) || price < 0) {
                    errors.push('Regular price must be a positive number');
                }
            }
            
            // Check sale price if provided
            if (data.sale_price && data.sale_price !== '') {
                const salePrice = parseFloat(data.sale_price);
                const regularPrice = parseFloat(data.regular_price);
                if (isNaN(salePrice) || salePrice < 0) {
                    errors.push('Sale price must be a positive number');
                } else if (salePrice >= regularPrice) {
                    errors.push('Sale price must be less than regular price');
                }
            }
            
            // Check stock
            if (data.manage_stock && (!data.stock_quantity || data.stock_quantity === '')) {
                errors.push('Stock quantity is required when managing stock');
            }
        }
        
        // For variable products, check variations
        if (data.type === 'variable') {
            if (!data.attributes || data.attributes.length === 0) {
                errors.push('Variable products must have at least one attribute');
            }
            
            if (!data.variations || data.variations.length === 0) {
                errors.push('Variable products must have at least one variation');
            } else {
                // Validate each variation
                data.variations.forEach((variation, index) => {
                    if (!variation.regular_price || variation.regular_price === '') {
                        errors.push(`Variation #${index + 1} is missing regular price`);
                    } else {
                        const price = parseFloat(variation.regular_price);
                        if (isNaN(price) || price < 0) {
                            errors.push(`Variation #${index + 1} has invalid price`);
                        }
                    }
                });
            }
        }
        
        if (errors.length > 0) {
            console.error('❌ Validation errors:', errors);
            return {
                valid: false,
                errors: errors
            };
        }
        
        console.log('✅ Validation passed');
        return {
            valid: true,
            errors: []
        };
    };
    
    /**
     * Save product
     */
    window.AIWPG.AddProductModal.saveProduct = function() {
        console.log('=== Add Product Modal - Save Product ===');
        console.log('Product Data:', productData);
        
        // Validate data first
        const validation = window.AIWPG.AddProductModal.validateProductData(productData);
        if (!validation.valid) {
            console.error('Product data validation failed:', validation.errors);
            toastr.error('Validation failed: ' + validation.errors.join(', '));
            return;
        }
        
        const $button = $('#add-product-save');
        const originalText = $button.html();
        
        $button.prop('disabled', true).html('<span class="spinner is-active"></span> Saving...');
        
        $.ajax({
            url: aiwpgData.ajaxUrl,
            type: 'POST',
            data: {
                action: 'aiwpg_create_product',
                nonce: aiwpgData.nonce,
                product: JSON.stringify(productData)
            },
            success: function(response) {
                console.log('Create product response:', response);
                
                if (response.success) {
                    toastr.success('Product created successfully');
                    console.log('Product created with ID:', response.data.product_id);
                    
                    $('#add-product-modal').removeClass('active');
                    
                    // Refresh products list
                    if (typeof window.AIWPG.ProductsDisplay !== 'undefined') {
                        window.AIWPG.ProductsDisplay.load(1);
                    }
                    if (typeof window.AIWPG.Statistics !== 'undefined') {
                        window.AIWPG.Statistics.load();
                    }
                    
                    // Reset form
                    window.AIWPG.AddProductModal.resetForm();
                } else {
                    console.error('❌ Failed to create product:');
                    console.error('Error Message:', response.data.message);
                    console.error('Error Code:', response.data.error_code);
                    console.error('Full Response:', response);
                    console.error('Product Data Sent:', productData);
                    
                    // Show detailed error message
                    let errorMsg = response.data.message || 'Failed to create product';
                    if (response.data.error_code) {
                        errorMsg += ' (Error: ' + response.data.error_code + ')';
                    }
                    toastr.error(errorMsg);
                }
            },
            error: function(xhr, status, error) {
                console.error('AJAX error creating product:', {
                    status: status,
                    error: error,
                    response: xhr.responseText
                });
                window.AIWPG.Common.handleAjaxError(xhr, status, error);
            },
            complete: function() {
                $button.prop('disabled', false).html(originalText);
            }
        });
    };
    
    /**
     * Reset form
     */
    window.AIWPG.AddProductModal.resetForm = function() {
        $('#add-product-modal form')[0].reset();
        currentStep = 1;
        productType = 'simple';
        productData = {};
        selectedImageId = null;
        selectedGalleryIds = [];
        
        $('.product-type-selector .type-option').removeClass('selected');
        $('.product-type-selector .type-option[data-type="simple"]').addClass('selected');
        
        // Clear downloadable files list
        $('#downloadable-files-list').empty();
        
        // Clear tags
        $('#add-tags-container').empty();
        
        // Clear product image
        $('#add-product-image-preview').html(`
            <div class="media-placeholder">
                <span class="dashicons dashicons-format-image"></span>
                <p>No image selected</p>
            </div>
        `);
        $('#remove-product-image-btn').hide();
        
        // Clear gallery
        $('#add-product-gallery-preview').empty();
        
        // Hide conditional fields
        $('.downloadable-fields').hide();
        $('.shipping-fields').show();
        $('.stock-quantity-group').hide();
    };
    
    /**
     * Add downloadable file row
     */
    window.AIWPG.AddProductModal.addDownloadableFileRow = function() {
        const rowId = 'file-' + Date.now();
        const row = `
            <tr data-file-id="${rowId}">
                <td>
                    <input type="text" class="widefat downloadable-file-name" placeholder="File name">
                </td>
                <td>
                    <input type="url" class="widefat downloadable-file-url" placeholder="https://example.com/file.pdf">
                </td>
                <td class="text-center">
                    <button type="button" class="button choose-downloadable-file" title="Choose from media library">
                        <span class="dashicons dashicons-admin-media"></span>
                    </button>
                </td>
                <td class="text-center">
                    <button type="button" class="button button-link-delete remove-downloadable-file" title="Remove file">
                        <span class="dashicons dashicons-trash"></span>
                    </button>
                </td>
            </tr>
        `;
        
        $('#downloadable-files-list').append(row);
    };
    
    /**
     * Get downloadable files data
     */
    window.AIWPG.AddProductModal.getDownloadableFiles = function() {
        const files = [];
        
        $('#downloadable-files-list tr').each(function() {
            const name = $(this).find('.downloadable-file-name').val().trim();
            const url = $(this).find('.downloadable-file-url').val().trim();
            
            if (name && url) {
                files.push({
                    name: name,
                    file: url
                });
            }
        });
        
        return files;
    };
    
    /**
     * Add tag
     */
    window.AIWPG.AddProductModal.addTag = function(tag) {
        // Check if tag already exists
        const existingTags = window.AIWPG.AddProductModal.getTags();
        if (existingTags.includes(tag)) {
            return;
        }
        
        const tagHtml = `
            <span class="tag-item">
                <span class="tag-text">${$('<div>').text(tag).html()}</span>
                <button type="button" class="tag-remove" title="Remove tag">
                    <span class="dashicons dashicons-no-alt"></span>
                </button>
            </span>
        `;
        
        $('#add-tags-container').append(tagHtml);
    };
    
    /**
     * Get all tags
     */
    window.AIWPG.AddProductModal.getTags = function() {
        const tags = [];
        
        $('#add-tags-container .tag-item').each(function() {
            const tag = $(this).find('.tag-text').text().trim();
            if (tag) {
                tags.push(tag);
            }
        });
        
        return tags;
    };
    
    /**
     * Select product image from media library
     */
    window.AIWPG.AddProductModal.selectProductImage = function() {
        const frame = wp.media({
            title: 'Select Product Image',
            button: {
                text: 'Use this image'
            },
            multiple: false
        });
        
        frame.on('select', function() {
            const attachment = frame.state().get('selection').first().toJSON();
            selectedImageId = attachment.id;
            
            const imageHtml = `
                <img src="${attachment.url}" alt="${attachment.title}">
            `;
            
            $('#add-product-image-preview').html(imageHtml);
            $('#remove-product-image-btn').show();
        });
        
        frame.open();
    };
    
    /**
     * Remove product image
     */
    window.AIWPG.AddProductModal.removeProductImage = function() {
        selectedImageId = null;
        $('#add-product-image-preview').html(`
            <div class="media-placeholder">
                <span class="dashicons dashicons-format-image"></span>
                <p>No image selected</p>
            </div>
        `);
        $('#remove-product-image-btn').hide();
    };
    
    /**
     * Select gallery images from media library
     */
    window.AIWPG.AddProductModal.selectGalleryImages = function() {
        const frame = wp.media({
            title: 'Select Gallery Images',
            button: {
                text: 'Add to gallery'
            },
            multiple: true
        });
        
        frame.on('select', function() {
            const attachments = frame.state().get('selection').toJSON();
            
            attachments.forEach(function(attachment) {
                // Check if image already exists
                if (!selectedGalleryIds.includes(attachment.id)) {
                    selectedGalleryIds.push(attachment.id);
                    
                    const imageHtml = `
                        <div class="gallery-image-item" data-id="${attachment.id}">
                            <img src="${attachment.url}" alt="${attachment.title}">
                            <button type="button" class="remove-gallery-image" data-id="${attachment.id}">
                                <span class="dashicons dashicons-no-alt"></span>
                            </button>
                        </div>
                    `;
                    
                    $('#add-product-gallery-preview').append(imageHtml);
                }
            });
        });
        
        frame.open();
    };
    
    /**
     * Remove gallery image
     */
    window.AIWPG.AddProductModal.removeGalleryImage = function(imageId) {
        selectedGalleryIds = selectedGalleryIds.filter(id => id !== imageId);
        $(`.gallery-image-item[data-id="${imageId}"]`).remove();
    };
    
    /**
     * Load categories
     */
    window.AIWPG.AddProductModal.loadCategories = function() {
        console.log('Loading categories for Add Product modal...');
        
        $.ajax({
            url: aiwpgData.ajaxUrl,
            type: 'POST',
            data: {
                action: 'aiwpg_get_categories',
                nonce: aiwpgData.nonce
            },
            success: function(response) {
                console.log('Categories response:', response);
                
                if (response.success) {
                    const categories = response.data.categories;
                    const escapeHtml = window.AIWPG.Common.escapeHtml;
                    let options = '';
                    
                    console.log('Total categories:', categories.length);
                    
                    categories.forEach(cat => {
                        options += `<option value="${escapeHtml(cat.name)}">${escapeHtml(cat.name)}</option>`;
                    });
                    
                    $('#add-categories').html(options);
                    console.log('Categories loaded successfully');
                } else {
                    console.error('Failed to load categories - response not successful');
                }
            },
            error: function(xhr, status, error) {
                console.error('AJAX error loading categories:', {
                    status: status,
                    error: error,
                    response: xhr.responseText
                });
            }
        });
    };
    
})(jQuery);

