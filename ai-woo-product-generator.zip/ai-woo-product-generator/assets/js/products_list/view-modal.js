/**
 * View Product Modal
 * Handles viewing product details in modal
 */

(function($) {
    'use strict';
    
    window.AIWPG = window.AIWPG || {};
    window.AIWPG.ViewModal = {};
    
    /**
     * Initialize view modal
     */
    window.AIWPG.ViewModal.init = function() {
        // Already initialized by modals.js
    };
    
    /**
     * View product (modal)
     */
    window.AIWPG.ViewModal.view = function(productId) {
        $.ajax({
            url: aiwpgData.ajaxUrl,
            type: 'POST',
            data: {
                action: 'aiwpg_get_product',
                nonce: aiwpgData.nonce,
                product_id: productId
            },
            success: function(response) {
                if (response.success) {
                    const product = response.data.product;
                    const escapeHtml = window.AIWPG.Common.escapeHtml;
                    const imageUrl = product.image_url || 'https://placehold.co/300x300/333/FFFFFF?text=No+Image';
                    const price = product.price ? '$' + parseFloat(product.price).toFixed(2) : 'N/A';
                    
                    const html = `
                        <div class="product-view">
                            <div class="product-image-wrapper">
                                <img src="${imageUrl}" alt="${escapeHtml(product.title)}" class="product-image" id="view-product-image">
                                <button type="button" class="generate-image-btn" data-product-id="${product.id}" title="Generate AI Image">
                                    <span class="dashicons dashicons-format-image"></span>
                                    <span class="btn-text">Generate Image</span>
                                </button>
                            </div>
                            <h3>${escapeHtml(product.title)}</h3>
                            <div class="product-meta">
                                <span><strong>Price:</strong> ${price}</span>
                                <span><strong>SKU:</strong> ${escapeHtml(product.sku)}</span>
                                <span><strong>Stock:</strong> ${product.stock_quantity}</span>
                            </div>
                            <div class="product-content">
                                <h4>Description</h4>
                                <p>${escapeHtml(product.long_description)}</p>
                            </div>
                            <div class="product-taxonomy">
                                <div><strong>Categories:</strong> ${(product.categories || []).join(', ')}</div>
                                <div><strong>Tags:</strong> ${(product.tags || []).join(', ')}</div>
                            </div>
                        </div>
                    `;
                    
                    $('#view-modal-body').html(html);
                    $('#view-product-modal').addClass('active');
                    
                    // Attach click handler for generate image button
                    $('.generate-image-btn').on('click', function() {
                        const prodId = $(this).data('product-id');
                        if (typeof window.AIWPG.ImageGeneration !== 'undefined') {
                            window.AIWPG.ImageGeneration.generate(prodId);
                        }
                    });
                } else {
                    toastr.error('Failed to load product');
                }
            }
        });
    };
    
})(jQuery);

