/**
 * Products List - Initialization
 * Initializes all products list related modules
 */

(function($) {
    'use strict';
    
    window.AIWPG = window.AIWPG || {};
    window.AIWPG.ProductsList = {};
    
    // Global variables for products list
    window.AIWPG.ProductsList.currentPage = 1;
    window.AIWPG.ProductsList.searchTimeout = null;
    window.AIWPG.ProductsList.currentProductsList = [];
    window.AIWPG.ProductsList.currentEditingProductIndex = -1;
    
    /**
     * Initialize products list page
     */
    window.AIWPG.ProductsList.init = function() {
        if ($('#products-container').length === 0) {
            return; // Not on products list page
        }
        
        // Load initial data
        if (typeof window.AIWPG.Statistics !== 'undefined') {
            window.AIWPG.Statistics.load();
        }
        
        if (typeof window.AIWPG.ProductsDisplay !== 'undefined') {
            window.AIWPG.ProductsDisplay.load();
        }
        
        // Initialize modules
        if (typeof window.AIWPG.Search !== 'undefined') {
            window.AIWPG.Search.init();
        }
        
        if (typeof window.AIWPG.ViewModal !== 'undefined') {
            window.AIWPG.ViewModal.init();
        }
        
        if (typeof window.AIWPG.EditModal !== 'undefined') {
            window.AIWPG.EditModal.init();
        }
        
        if (typeof window.AIWPG.ImageGeneration !== 'undefined') {
            window.AIWPG.ImageGeneration.init();
        }
        
        if (typeof window.AIWPG.Variations !== 'undefined') {
            window.AIWPG.Variations.init();
        }
        
        // Refresh button
        $('#refresh-products').on('click', function() {
            window.AIWPG.ProductsList.currentPage = 1;
            window.AIWPG.Statistics.load();
            window.AIWPG.ProductsDisplay.load();
        });
    };
    
})(jQuery);

