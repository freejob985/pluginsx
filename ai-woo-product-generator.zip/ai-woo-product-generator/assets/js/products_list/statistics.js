/**
 * Statistics Display
 * Handles dashboard statistics display and animation
 */

(function($) {
    'use strict';
    
    window.AIWPG = window.AIWPG || {};
    window.AIWPG.Statistics = {};
    
    // Store active animation timers and timeout timers
    let animationTimers = {};
    let animationTimeouts = {};
    
    /**
     * Load statistics for dashboard
     */
    window.AIWPG.Statistics.load = function() {
        // Show loading spinners
        $('#stat-total-value, #stat-published-value, #stat-draft-value, #stat-value-value').html(
            '<span class="spinner is-active" style="float: none; margin: 0;"></span>'
        );
        
        $.ajax({
            url: aiwpgData.ajaxUrl,
            type: 'POST',
            timeout: 30000, // 30 seconds timeout
            data: {
                action: 'aiwpg_get_statistics',
                nonce: aiwpgData.nonce
            },
            success: function(response) {
                // Clear all spinners first
                $('#stat-total-value, #stat-published-value, #stat-draft-value, #stat-value-value').empty();
                
                if (response && response.success && response.data) {
                    const stats = response.data;
                    
                    // Update values with animation (only if value > 0)
                    if (stats.total !== undefined && stats.total > 0) {
                        window.AIWPG.Statistics.animateValue('stat-total-value', 0, parseInt(stats.total), 800);
                    } else {
                        $('#stat-total-value').html('0');
                    }
                    
                    if (stats.published !== undefined && stats.published > 0) {
                        window.AIWPG.Statistics.animateValue('stat-published-value', 0, parseInt(stats.published), 900);
                    } else {
                        $('#stat-published-value').html('0');
                    }
                    
                    if (stats.drafts !== undefined && stats.drafts > 0) {
                        window.AIWPG.Statistics.animateValue('stat-draft-value', 0, parseInt(stats.drafts), 1000);
                    } else {
                        $('#stat-draft-value').html('0');
                    }
                    
                    // Stock value and out of stock (no animation)
                    $('#stat-value-value').html(stats.stock_value_formatted || '0');
                    $('#stat-out-of-stock-value').html(stats.out_of_stock !== undefined ? stats.out_of_stock : '0');
                } else {
                    // Clear spinners and show error
                    $('#stat-total-value, #stat-published-value, #stat-draft-value, #stat-value-value').html('--');
                }
            },
            error: function(xhr, status, error) {
                // Clear spinners and show error
                $('#stat-total-value, #stat-published-value, #stat-draft-value, #stat-value-value').html('--');
                console.error('Statistics loading error:', status, error);
            }
        });
    };

    
    
    /**
     * Animate number counting
     */
    window.AIWPG.Statistics.animateValue = function(elementId, start, end, duration) {
        const element = $('#' + elementId);
        
        // Clear any existing animation for this element
        if (animationTimers[elementId]) {
            clearInterval(animationTimers[elementId]);
            delete animationTimers[elementId];
        }
        if (animationTimeouts[elementId]) {
            clearTimeout(animationTimeouts[elementId]);
            delete animationTimeouts[elementId];
        }
        
        // Ensure element is empty before starting animation
        element.empty();
        
        // If start equals end, just display the value
        if (start === end) {
            element.html(end.toLocaleString());
            return;
        }
        
        const range = end - start;
        
        // Prevent division by zero
        if (range === 0) {
            element.html(end.toLocaleString());
            return;
        }
        
        const increment = end > start ? 1 : -1;
        // Ensure minimum step time to prevent too fast animation
        const stepTime = Math.max(10, Math.abs(Math.floor(duration / range)));
        let current = start;
        
        // Set initial value
        element.html(current.toLocaleString());
        
        // Safety timeout: force stop animation after duration + 1 second
        animationTimeouts[elementId] = setTimeout(function() {
            if (animationTimers[elementId]) {
                clearInterval(animationTimers[elementId]);
                delete animationTimers[elementId];
            }
            element.html(end.toLocaleString());
            delete animationTimeouts[elementId];
        }, duration + 1000);
        
        animationTimers[elementId] = setInterval(function() {
            current += increment;
            element.html(current.toLocaleString());
            
            // Check if we've reached the target (handle both increment directions)
            if ((increment > 0 && current >= end) || (increment < 0 && current <= end)) {
                element.html(end.toLocaleString());
                clearInterval(animationTimers[elementId]);
                delete animationTimers[elementId];
                if (animationTimeouts[elementId]) {
                    clearTimeout(animationTimeouts[elementId]);
                    delete animationTimeouts[elementId];
                }
            }
        }, stepTime);
    };
    
})(jQuery);

