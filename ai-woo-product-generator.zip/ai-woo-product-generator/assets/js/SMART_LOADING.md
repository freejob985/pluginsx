# Smart Loading System ⚡

## نظام التحميل الذكي للملفات حسب الصفحة

تم تطبيق نظام تحميل ذكي يقوم بتحميل ملفات JavaScript فقط للصفحة الحالية، مما يحسن الأداء بشكل كبير.

## كيف يعمل النظام؟

في ملف `class-aiwpg-admin-controller.php`، يتم تحديد الصفحة الحالية أولاً:

```php
// Determine current page
$is_generator_page = strpos($hook, 'aiwpg-generator') !== false;
$is_products_page = strpos($hook, 'aiwpg-products') !== false && strpos($hook, 'aiwpg-generator') === false;
$is_settings_page = strpos($hook, 'aiwpg-settings') !== false;
```

ثم يتم تحميل الملفات بناءً على الصفحة:

```php
// Shared modules (load on all pages)
wp_enqueue_script('aiwpg-common-js', ...);
wp_enqueue_script('aiwpg-tabs-js', ...);
wp_enqueue_script('aiwpg-modals-js', ...);

// Generator Page Only
if ($is_generator_page) {
    wp_enqueue_script('aiwpg-generate-init-js', ...);
    wp_enqueue_script('aiwpg-single-product-js', ...);
    // ... المزيد من ملفات التوليد
}

// Products List Page Only
if ($is_products_page) {
    wp_enqueue_script('aiwpg-products-list-init-js', ...);
    wp_enqueue_script('aiwpg-statistics-js', ...);
    // ... المزيد من ملفات القائمة
}

// Settings Page Only
if ($is_settings_page) {
    wp_enqueue_script('aiwpg-settings-init-js', ...);
    wp_enqueue_script('aiwpg-settings-form-js', ...);
    // ... المزيد من ملفات الإعدادات
}
```

## ما الذي يتم تحميله في كل صفحة؟

### 🌐 في جميع الصفحات (4 ملفات):
- `shared/common.js` - الوظائف المساعدة
- `shared/tabs.js` - إدارة التبويبات
- `shared/modals.js` - إدارة النوافذ المنبثقة
- `main.js` - الملف الرئيسي

**المكتبات الخارجية:** jQuery, Toastr

---

### 📄 صفحة توليد المنتجات (11 ملف):
**الملفات المشتركة** + **7 ملفات إضافية:**
- `generate_products/init.js`
- `generate_products/product-type-toggle.js`
- `generate_products/single-product.js`
- `generate_products/multiple-products.js`
- `generate_products/excel-import.js`
- `generate_products/voice-input.js`
- `generate_products/improve-prompts.js`

**المكتبات الإضافية:** XLSX (للإكسل)

---

### 📄 صفحة قائمة المنتجات (13 ملف):
**الملفات المشتركة** + **9 ملفات إضافية:**
- `products_list/init.js`
- `products_list/statistics.js`
- `products_list/products-display.js`
- `products_list/pagination.js`
- `products_list/search.js`
- `products_list/view-modal.js`
- `products_list/edit-modal.js`
- `products_list/image-generation.js`
- `products_list/variations.js`

**المكتبات الإضافية:** SweetAlert2, Tagify

---

### 📄 صفحة الإعدادات (7 ملفات):
**الملفات المشتركة** + **3 ملفات إضافية:**
- `settings/init.js`
- `settings/settings-form.js`
- `settings/delete-products.js`

**المكتبات الإضافية:** SweetAlert2

---

## المقارنة: قبل وبعد

### ❌ قبل التحميل الذكي:
```
كل صفحة تحمل: 23 ملف JavaScript
├── صفحة توليد المنتجات: 23 ملف
├── صفحة قائمة المنتجات: 23 ملف
└── صفحة الإعدادات: 23 ملف
```

### ✅ بعد التحميل الذكي:
```
كل صفحة تحمل فقط ما تحتاجه:
├── صفحة توليد المنتجات: 11 ملف (-52%)
├── صفحة قائمة المنتجات: 13 ملف (-43%)
└── صفحة الإعدادات: 7 ملفات (-70%)
```

## فوائد التحميل الذكي

### 1. ⚡ أداء أسرع
- **تقليل عدد الطلبات** - أقل ملفات للتحميل
- **أقل حجم** - لا تحميل ملفات غير مستخدمة
- **وقت تحميل أسرع** - الصفحة تفتح بشكل أسرع

### 2. 💾 استهلاك أقل للذاكرة
- تحميل فقط الكود المطلوب
- تقليل استهلاك ذاكرة المتصفح
- أداء أفضل على الأجهزة الضعيفة

### 3. 🔧 صيانة أفضل
- كود منظم حسب الصفحات
- سهولة تحديد المشاكل
- اختبار أسهل لكل صفحة

### 4. 📦 تخزين مؤقت أفضل
- الملفات المشتركة تُخزن مؤقتاً مرة واحدة
- الملفات الخاصة تُخزن حسب الحاجة
- تحسين في التحديثات المستقبلية

## كيفية إضافة ملف جديد؟

### 1. إنشاء الملف في المكان المناسب:
```javascript
// مثال: إضافة ملف جديد في generate_products
assets/js/generate_products/new-feature.js
```

### 2. إضافة الملف في `class-aiwpg-admin-controller.php`:
```php
// داخل شرط الصفحة المناسب
if ($is_generator_page) {
    // ... الملفات الموجودة
    
    wp_enqueue_script(
        'aiwpg-new-feature-js',
        AIWPG_PLUGIN_URL . 'assets/js/generate_products/new-feature.js',
        array('jquery', 'aiwpg-common-js'),
        AIWPG_VERSION . '-' . time(),
        true
    );
}
```

### 3. استدعاء init في ملف init.js المناسب:
```javascript
// في generate_products/init.js
if (typeof window.AIWPG.NewFeature !== 'undefined') {
    window.AIWPG.NewFeature.init();
}
```

## اختبار التحميل

للتحقق من أن الملفات تحمل بشكل صحيح:

### في صفحة توليد المنتجات:
```javascript
console.log('AIWPG.GenerateProducts:', window.AIWPG.GenerateProducts);
// يجب أن يرجع object
console.log('AIWPG.ProductsList:', window.AIWPG.ProductsList);
// يجب أن يرجع undefined (لأنه غير محمل)
```

### في صفحة قائمة المنتجات:
```javascript
console.log('AIWPG.ProductsList:', window.AIWPG.ProductsList);
// يجب أن يرجع object
console.log('AIWPG.Settings:', window.AIWPG.Settings);
// يجب أن يرجع undefined (لأنه غير محمل)
```

### في صفحة الإعدادات:
```javascript
console.log('AIWPG.Settings:', window.AIWPG.Settings);
// يجب أن يرجع object
console.log('AIWPG.GenerateProducts:', window.AIWPG.GenerateProducts);
// يجب أن يرجع undefined (لأنه غير محمل)
```

## ملاحظات هامة

⚠️ **الملفات المشتركة تحمل دائماً:**
- `shared/common.js`
- `shared/tabs.js`
- `shared/modals.js`
- `main.js`

✅ **الوظائف المشتركة متاحة في جميع الصفحات:**
- `window.AIWPG.Common.*`
- `window.AIWPG.Tabs.*`
- `window.AIWPG.Modals.*`

🎯 **الملفات الخاصة تحمل فقط في صفحاتها:**
- ملفات `generate_products/` فقط في صفحة التوليد
- ملفات `products_list/` فقط في صفحة القائمة
- ملفات `settings/` فقط في صفحة الإعدادات

---

**هذا النظام يجمع بين:**
- ✅ الأداء العالي
- ✅ التنظيم الممتاز
- ✅ سهولة الصيانة
- ✅ قابلية التوسع

