/**
 * Common Utilities and Helpers
 * Shared functions used across all modules
 */

(function($) {
    'use strict';
    
    // Create global namespace
    window.AIWPG = window.AIWPG || {};
    window.AIWPG.Common = {};
    
    /**
     * Escape HTML
     */
    window.AIWPG.Common.escapeHtml = function(text) {
        const map = {
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#039;'
        };
        return String(text).replace(/[&<>"']/g, m => map[m]);
    };
    
    /**
     * Clean markdown from text
     */
    window.AIWPG.Common.cleanMarkdown = function(text) {
        if (!text) return text;
        
        // Remove markdown headers (# ## ### etc)
        text = text.replace(/^#{1,6}\s+/gm, '');
        
        // Remove bold (**text** or __text__)
        text = text.replace(/(\*\*|__)(.*?)\1/g, '$2');
        
        // Remove italic (*text* or _text_)
        text = text.replace(/(\*|_)(.*?)\1/g, '$2');
        
        // Remove strikethrough (~~text~~)
        text = text.replace(/~~(.*?)~~/g, '$1');
        
        // Remove inline code (`code`)
        text = text.replace(/`([^`]+)`/g, '$1');
        
        // Remove code blocks (```code```)
        text = text.replace(/```[\s\S]*?```/g, '');
        
        // Remove links [text](url)
        text = text.replace(/\[([^\]]+)\]\([^\)]+\)/g, '$1');
        
        // Remove images ![alt](url)
        text = text.replace(/!\[([^\]]*)\]\([^\)]+\)/g, '$1');
        
        // Remove horizontal rules (---, ***, ___)
        text = text.replace(/^(-{3,}|\*{3,}|_{3,})$/gm, '');
        
        // Remove blockquotes (> text)
        text = text.replace(/^>\s+/gm, '');
        
        // Remove unordered list markers (- * +)
        text = text.replace(/^[\*\-\+]\s+/gm, '');
        
        // Remove ordered list markers (1. 2. etc)
        text = text.replace(/^\d+\.\s+/gm, '');
        
        // Clean up extra whitespace
        text = text.replace(/\n{3,}/g, '\n\n');
        text = text.trim();
        
        return text;
    };
    
    /**
     * Format price display
     */
    window.AIWPG.Common.formatPrice = function(regularPrice, salePrice) {
        const regular = regularPrice || 'N/A';
        const sale = salePrice || '';
        
        let priceDisplay = '';
        if (sale && parseFloat(sale) < parseFloat(regular)) {
            priceDisplay = `<span style="text-decoration: line-through; color: #999;">${regular}</span> <span style="color: #d63638; font-weight: bold;">${sale}</span>`;
        } else {
            priceDisplay = `<span style="font-weight: bold;">${regular}</span>`;
        }
        
        return priceDisplay;
    };
    
    /**
     * Format price display for table rows
     */
    window.AIWPG.Common.formatPriceTable = function(regularPrice, salePrice) {
        const regular = regularPrice || 'N/A';
        const sale = salePrice || '';
        
        let priceDisplay = '';
        if (sale && parseFloat(sale) < parseFloat(regular)) {
            priceDisplay = `<span style="text-decoration: line-through; color: #999;">${regular}</span><br><span style="color: #d63638; font-weight: bold;">${sale}</span>`;
        } else {
            priceDisplay = `<span style="font-weight: bold;">${regular}</span>`;
        }
        
        return priceDisplay;
    };
    
    /**
     * Get product type badge HTML
     */
    window.AIWPG.Common.getProductTypeBadge = function(productType) {
        let badge = '';
        if (productType === 'simple') {
            badge = '<span class="product-type-badge type-simple"><span class="dashicons dashicons-products"></span> Simple</span>';
        } else if (productType === 'variable') {
            badge = '<span class="product-type-badge type-variable"><span class="dashicons dashicons-networking"></span> Variable</span>';
        }
        return badge;
    };
    
    /**
     * Handle AJAX error
     */
    window.AIWPG.Common.handleAjaxError = function(xhr, status, error) {
        let errorMessage = 'Network error occurred';
        if (xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message) {
            errorMessage = xhr.responseJSON.data.message;
        } else if (xhr.statusText) {
            errorMessage = 'Network error: ' + xhr.statusText;
        } else if (error) {
            errorMessage = 'Error: ' + error;
        }
        toastr.error(errorMessage);
        console.error('AIWPG Error:', {
            status: xhr.status,
            statusText: xhr.statusText,
            error: error,
            response: xhr.responseText
        });
    };
    
    /**
     * Toastr Configuration
     */
    if (typeof toastr !== 'undefined') {
        toastr.options = {
            closeButton: true,
            progressBar: true,
            positionClass: 'toast-top-right',
            timeOut: 3000,
        };
    }
    
})(jQuery);

