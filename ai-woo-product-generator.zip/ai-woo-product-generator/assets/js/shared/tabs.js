/**
 * Tabs Management
 * Handles tab switching functionality
 */

(function($) {
    'use strict';
    
    window.AIWPG = window.AIWPG || {};
    window.AIWPG.Tabs = {};
    
    /**
     * Initialize tabs
     */
    window.AIWPG.Tabs.init = function() {
        $('.nav-tab').on('click', function(e) {
            e.preventDefault();
            const tab = $(this).data('tab');
            
            $('.nav-tab').removeClass('nav-tab-active');
            $(this).addClass('nav-tab-active');
            
            $('.aiwpg-tab-content').removeClass('active');
            $('#tab-' + tab).addClass('active');
        });
        
        // Product tabs navigation (in modals)
        $(document).on('click', '.tab-btn', function() {
            const tabName = $(this).data('tab');
            
            // Update active tab button
            $('.tab-btn').removeClass('active');
            $(this).addClass('active');
            
            // Update active tab content
            $('.tab-content').removeClass('active');
            $(`.tab-content[data-tab="${tabName}"]`).addClass('active');
        });
    };
    
})(jQuery);

