/**
 * Modal Management
 * Handles modal open/close and fullscreen functionality
 */

(function($) {
    'use strict';
    
    window.AIWPG = window.AIWPG || {};
    window.AIWPG.Modals = {};
    
    /**
     * Initialize modals
     */
    window.AIWPG.Modals.init = function() {
        // Close modal buttons
        $('.modal-close, .close-modal').on('click', function() {
            const $modal = $(this).closest('.aiwpg-modal');
            $modal.removeClass('active fullscreen');
            $('body').removeClass('modal-fullscreen-active');
        });
        
        // Close on overlay click
        $('.modal-overlay').on('click', function() {
            const $modal = $(this).closest('.aiwpg-modal');
            $modal.removeClass('active fullscreen');
            $('body').removeClass('modal-fullscreen-active');
        });
        
        // Close modal on ESC key
        $(document).on('keydown', function(e) {
            if (e.key === 'Escape' || e.keyCode === 27) {
                const $modal = $('.aiwpg-modal.active');
                $modal.removeClass('active fullscreen');
                $('body').removeClass('modal-fullscreen-active');
                $('#edit-product-context-menu').css('display', 'none');
            }
        });
        
        // Fullscreen toggle button
        $('#toggle-fullscreen-btn').on('click', function() {
            window.AIWPG.Modals.toggleFullscreen();
        });
        
        // ESC key to exit fullscreen
        $(document).on('keydown', function(e) {
            if (e.key === 'F11' || e.keyCode === 122) {
                e.preventDefault();
                window.AIWPG.Modals.toggleFullscreen();
            }
        });
    };
    
    /**
     * Toggle fullscreen mode
     */
    window.AIWPG.Modals.toggleFullscreen = function() {
        const $modal = $('#edit-product-modal');
        
        if ($modal.hasClass('fullscreen')) {
            // Exit fullscreen
            $modal.removeClass('fullscreen');
            $('body').removeClass('modal-fullscreen-active');
        } else {
            // Enter fullscreen
            $modal.addClass('fullscreen');
            $('body').addClass('modal-fullscreen-active');
        }
    };
    
})(jQuery);

