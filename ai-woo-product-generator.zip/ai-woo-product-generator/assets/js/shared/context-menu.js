/**
 * Global Context Menu
 * Context menu for main pages (Generate Products, Products List, Settings)
 * Does NOT work with Edit Product modal context menu
 */

(function($) {
    'use strict';
    
    window.AIWPG = window.AIWPG || {};
    window.AIWPG.ContextMenu = {};
    
    /**
     * Initialize global context menu
     */
    window.AIWPG.ContextMenu.init = function() {
        // Show context menu on right click (excluding Edit Product modal)
        $(document).on('contextmenu', '.aiwpg-wrap', function(e) {
            // Don't show if Edit Product modal is active
            if ($('#edit-product-modal').hasClass('active')) {
                return true; // Allow Edit Product context menu to work
            }
            
            // Don't show if clicking on Edit Product modal or its context menu
            if ($(e.target).closest('#edit-product-modal, #edit-product-context-menu').length > 0) {
                return true;
            }
            
            e.preventDefault();
            e.stopPropagation();
            
            const $contextMenu = $('#global-context-menu');
            
            // Make sure context menu exists
            if ($contextMenu.length === 0) {
                console.error('Global context menu element not found');
                return false;
            }
            
            // Position context menu at cursor position
            $contextMenu.css({
                'display': 'block',
                'left': e.clientX + 'px',
                'top': e.clientY + 'px'
            });
            
            return false;
        });
        
        // Hide context menu on click outside
        $(document).on('click', function(e) {
            if (!$(e.target).closest('#global-context-menu').length) {
                window.AIWPG.ContextMenu.hide();
            }
        });
        
        // Hide context menu on scroll
        $(window).on('scroll', function() {
            window.AIWPG.ContextMenu.hide();
        });
        
        // Hide context menu on Escape key
        $(document).on('keydown', function(e) {
            if (e.key === 'Escape' || e.keyCode === 27) {
                window.AIWPG.ContextMenu.hide();
            }
        });
        
        // Handle context menu item clicks
        $(document).on('click', '#global-context-menu .context-menu-item', function() {
            const action = $(this).data('action');
            
            // Add click animation
            $(this).css('transform', 'scale(0.95)');
            
            // Hide context menu
            window.AIWPG.ContextMenu.hide();
            
            // Handle different actions
            switch(action) {
                case 'generate-products':
                    // Navigate to Generate Products page
                    window.location.href = aiwpgData.generatePageUrl;
                    break;
                    
                case 'products-list':
                    // Navigate to Products List page
                    window.location.href = aiwpgData.productsListPageUrl;
                    break;
                    
                case 'settings':
                    // Navigate to Settings page
                    window.location.href = aiwpgData.settingsPageUrl;
                    break;
                    
                case 'add-product':
                    // Open Add Product Modal
                    if (typeof window.AIWPG.AddProductModal !== 'undefined') {
                        window.AIWPG.AddProductModal.open();
                    } else {
                        toastr.info('Add Product modal is being implemented...');
                    }
                    break;
                    
                case 'refresh':
                    // Refresh current page
                    location.reload();
                    break;
                    
                default:
                    console.log('Unknown action:', action);
            }
        });
        
        // Hide both context menus when Edit Product modal opens
        $(document).on('click', '.product-card .edit-product', function() {
            window.AIWPG.ContextMenu.hide();
        });
    };
    
    /**
     * Hide context menu with animation
     */
    window.AIWPG.ContextMenu.hide = function() {
        const $menu = $('#global-context-menu');
        if ($menu.is(':visible')) {
            $menu.addClass('hiding');
            setTimeout(function() {
                $menu.css('display', 'none').removeClass('hiding');
            }, 200);
        }
    };
    
})(jQuery);

