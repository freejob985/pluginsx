/**
 * Add-Ons Import
 * Handles manual add-ons import functionality
 */

(function($) {
    'use strict';
    
    window.AIWPG = window.AIWPG || {};
    window.AIWPG.AddonsImport = {};
    
    /**
     * Initialize add-ons import
     */
    window.AIWPG.AddonsImport.init = function() {
        // Run import button
        $('#run-addons-import').on('click', function(e) {
            e.preventDefault();
            window.AIWPG.AddonsImport.runImport();
        });
    };
    
    /**
     * Run add-ons import
     */
    window.AIWPG.AddonsImport.runImport = function() {
        const $button = $('#run-addons-import');
        const $results = $('#addons-import-results');
        const $summary = $results.find('.addons-import-summary');
        
        // Disable button and show loading
        $button.prop('disabled', true).html('<span class="spinner is-active"></span> ' + 'Importing...');
        $results.hide();
        
        $.ajax({
            url: aiwpgData.ajaxUrl,
            type: 'POST',
            data: {
                action: 'aiwpg_import_addons',
                nonce: aiwpgData.nonce
            },
            success: function(response) {
                $button.prop('disabled', false).html('<span class="dashicons dashicons-update"></span> ' + 'Run Add-Ons Import Now');
                
                if (response.success) {
                    const summary = response.data.summary || {};
                    
                    let html = '<div class="notice notice-success inline"><p><strong>Import Completed!</strong></p>';
                    html += '<ul>';
                    html += '<li><strong>Groups Created:</strong> ' + (summary.groups_created || 0) + '</li>';
                    html += '<li><strong>Groups Updated:</strong> ' + (summary.groups_updated || 0) + '</li>';
                    html += '<li><strong>Products Linked:</strong> ' + (summary.products_linked || 0) + '</li>';
                    
                    if (summary.errors && summary.errors.length > 0) {
                        html += '<li><strong>Errors:</strong> ' + summary.errors.length + '</li>';
                    }
                    html += '</ul>';
                    
                    if (summary.errors && summary.errors.length > 0) {
                        html += '<details style="margin-top: 10px;"><summary>Error Details</summary><ul>';
                        summary.errors.forEach(function(error) {
                            html += '<li style="color: #d63638;">' + error + '</li>';
                        });
                        html += '</ul></details>';
                    }
                    
                    html += '</div>';
                    
                    $summary.html(html);
                    $results.show();
                    
                    toastr.success(response.data.message || 'Add-ons import completed');
                } else {
                    $summary.html('<div class="notice notice-error inline"><p>' + (response.data.message || 'Import failed') + '</p></div>');
                    $results.show();
                    toastr.error(response.data.message || 'Failed to import add-ons');
                }
            },
            error: function(xhr, status, error) {
                $button.prop('disabled', false).html('<span class="dashicons dashicons-update"></span> ' + 'Run Add-Ons Import Now');
                $summary.html('<div class="notice notice-error inline"><p>Error: ' + error + '</p></div>');
                $results.show();
                toastr.error('Failed to import add-ons: ' + error);
            }
        });
    };
    
})(jQuery);
