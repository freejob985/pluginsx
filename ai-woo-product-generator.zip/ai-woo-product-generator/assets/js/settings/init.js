/**
 * Settings - Initialization
 * Initializes all settings related modules
 */

(function($) {
    'use strict';
    
    window.AIWPG = window.AIWPG || {};
    window.AIWPG.Settings = {};
    
    /**
     * Initialize settings modules
     */
    window.AIWPG.Settings.init = function() {
        if (typeof window.AIWPG.SettingsForm !== 'undefined') {
            window.AIWPG.SettingsForm.init();
        }
        
        if (typeof window.AIWPG.DeleteProducts !== 'undefined') {
            window.AIWPG.DeleteProducts.init();
        }
        
        if (typeof window.AIWPG.APIKeys !== 'undefined') {
            window.AIWPG.APIKeys.init();
        }
    };
    
})(jQuery);

