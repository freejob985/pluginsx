/**
 * Settings Form
 * Handles plugin settings management
 */

(function($) {
    'use strict';
    
    window.AIWPG = window.AIWPG || {};
    window.AIWPG.SettingsForm = {};
    
    /**
     * Initialize settings form
     */
    window.AIWPG.SettingsForm.init = function() {
        // Settings form
        $('#settings-form').on('submit', function(e) {
            e.preventDefault();
            window.AIWPG.SettingsForm.save();
        });
    };
    
    /**
     * Save settings
     */
    window.AIWPG.SettingsForm.save = function() {
        const settings = {
            products_per_page: $('#products_per_page').val(),
            default_stock_status: $('#default_stock_status').val(),
            auto_publish: $('#auto_publish').is(':checked'),
            enable_addons_import: $('#enable_addons_import').is(':checked')
        };
        
        $.ajax({
            url: aiwpgData.ajaxUrl,
            type: 'POST',
            data: {
                action: 'aiwpg_save_settings',
                nonce: aiwpgData.nonce,
                ...settings
            },
            success: function(response) {
                if (response.success) {
                    toastr.success(response.data.message || 'Settings saved');
                } else {
                    toastr.error(response.data.message || 'Failed to save settings');
                }
            }
        });
    };
    
})(jQuery);

