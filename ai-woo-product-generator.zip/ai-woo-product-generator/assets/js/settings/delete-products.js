/**
 * Delete Products
 * Handles bulk product deletion (AI products and all products)
 */

(function($) {
    'use strict';
    
    window.AIWPG = window.AIWPG || {};
    window.AIWPG.DeleteProducts = {};
    
    /**
     * Initialize delete products buttons
     */
    window.AIWPG.DeleteProducts.init = function() {
        // Delete AI products
        $('#delete-ai-products').on('click', function() {
            window.AIWPG.DeleteProducts.confirmDelete('ai');
        });
        
        // Delete all products
        $('#delete-all-products').on('click', function() {
            window.AIWPG.DeleteProducts.confirmDelete('all');
        });
    };
    
    /**
     * Confirm delete with SweetAlert
     */
    window.AIWPG.DeleteProducts.confirmDelete = function(type) {
        const isAll = type === 'all';
        
        Swal.fire({
            title: isAll ? 'Delete ALL Products?' : 'Delete AI Products?',
            html: isAll ? 
                'This will delete <strong>ALL WooCommerce products</strong> in your store!<br>Type <strong>DELETE</strong> to confirm:' :
                'This will delete all AI-generated products.<br>Type <strong>DELETE</strong> to confirm:',
            icon: 'warning',
            input: 'text',
            inputPlaceholder: 'Type DELETE',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            cancelButtonColor: '#3085d6',
            confirmButtonText: 'Yes, delete them!',
            preConfirm: (value) => {
                if (value !== 'DELETE') {
                    Swal.showValidationMessage('You must type DELETE to confirm');
                    return false;
                }
                return value;
            }
        }).then((result) => {
            if (result.isConfirmed) {
                window.AIWPG.DeleteProducts.executeDelete(type);
            }
        });
    };
    
    /**
     * Execute delete operation
     */
    window.AIWPG.DeleteProducts.executeDelete = function(type) {
        const action = type === 'all' ? 'aiwpg_delete_all_products' : 'aiwpg_delete_ai_products';
        
        Swal.fire({
            title: 'Deleting...',
            text: 'Please wait',
            allowOutsideClick: false,
            didOpen: () => {
                Swal.showLoading();
            }
        });
        
        $.ajax({
            url: aiwpgData.ajaxUrl,
            type: 'POST',
            data: {
                action: action,
                nonce: aiwpgData.nonce,
                confirmation: 'DELETE'
            },
            success: function(response) {
                if (response.success) {
                    Swal.fire({
                        icon: 'success',
                        title: 'Deleted!',
                        text: response.data.message,
                        timer: 3000
                    });
                    
                    // Reload products list if on that page
                    if ($('#products-container').length) {
                        if (typeof window.AIWPG.ProductsDisplay !== 'undefined') {
                            window.AIWPG.ProductsDisplay.load(1);
                        }
                    }
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: response.data.message
                    });
                }
            },
            error: function() {
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: 'Network error occurred'
                });
            }
        });
    };
    
})(jQuery);

