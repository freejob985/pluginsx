/**
 * API Keys Settings
 * Handles API key management, testing, and saving
 */

(function($) {
    'use strict';
    
    window.AIWPG = window.AIWPG || {};
    window.AIWPG.APIKeys = {};
    
    /**
     * Initialize API keys management
     */
    window.AIWPG.APIKeys.init = function() {
        // Tab switching
        $('.nav-tab').on('click', function(e) {
            e.preventDefault();
            const tab = $(this).data('tab');
            
            // Update active tab
            $('.nav-tab').removeClass('nav-tab-active');
            $(this).addClass('nav-tab-active');
            
            // Show corresponding content
            $('.tab-content').hide();
            $('#' + tab + '-tab').show();
        });
        
        // Toggle password visibility
        $('.toggle-password').on('click', function() {
            const targetId = $(this).data('target');
            const $input = $('#' + targetId);
            const $icon = $(this).find('.dashicons');
            
            if ($input.attr('type') === 'password') {
                $input.attr('type', 'text');
                $icon.removeClass('dashicons-visibility').addClass('dashicons-hidden');
            } else {
                $input.attr('type', 'password');
                $icon.removeClass('dashicons-hidden').addClass('dashicons-visibility');
            }
        });
        
        // Test API key
        $('.test-api-key').on('click', function() {
            const $button = $(this);
            const keyType = $button.data('key-type');
            const keyIndex = $button.data('key-index');
            const $input = $('#' + keyType + '_key_' + keyIndex);
            const $status = $('#' + keyType + '_status_' + keyIndex);
            const apiKey = $input.val();
            
            if (!apiKey) {
                toastr.error('Please enter an API key first');
                return;
            }
            
            // Disable button
            $button.prop('disabled', true);
            const originalHtml = $button.html();
            $button.html('<span class="spinner is-active" style="margin: 0;"></span>');
            
            // Show testing status
            $status.html('<span style="color: #666;">Testing...</span>');
            
            // Test the key
            $.ajax({
                url: aiwpgData.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'aiwpg_test_api_key',
                    nonce: aiwpgData.nonce,
                    key_type: keyType,
                    api_key: apiKey
                },
                success: function(response) {
                    if (response.success) {
                        $status.html('<span style="color: #5cb85c;">✓ Valid</span>');
                        toastr.success(response.data.message);
                    } else {
                        $status.html('<span style="color: #d63638;">✗ Invalid</span>');
                        toastr.error(response.data.message);
                    }
                },
                error: function(xhr, status, error) {
                    $status.html('<span style="color: #d63638;">✗ Error</span>');
                    window.AIWPG.Common.handleAjaxError(xhr, status, error);
                },
                complete: function() {
                    $button.prop('disabled', false).html(originalHtml);
                }
            });
        });
        
        // Save Gemini keys
        $('#gemini-keys-form').on('submit', function(e) {
            e.preventDefault();
            window.AIWPG.APIKeys.saveKeys('gemini', $(this));
        });
        
        // Save Freepik keys
        $('#freepik-keys-form').on('submit', function(e) {
            e.preventDefault();
            window.AIWPG.APIKeys.saveKeys('freepik', $(this));
        });
    };
    
    /**
     * Save API keys
     */
    window.AIWPG.APIKeys.saveKeys = function(keyType, $form) {
        const $button = $form.find('button[type="submit"]');
        $button.prop('disabled', true);
        const originalHtml = $button.html();
        $button.html('<span class="spinner is-active" style="margin: 0;"></span> Saving...');
        
        // Collect all keys
        const formData = {
            action: 'aiwpg_save_api_keys',
            nonce: aiwpgData.nonce,
            key_type: keyType
        };
        
        // Add keys to form data
        for (let i = 1; i <= 5; i++) {
            const keyValue = $('#' + keyType + '_key_' + i).val();
            formData[keyType + '_key_' + i] = keyValue;
        }
        
        $.ajax({
            url: aiwpgData.ajaxUrl,
            type: 'POST',
            data: formData,
            success: function(response) {
                if (response.success) {
                    toastr.success(response.data.message);
                    
                    // Clear all status indicators
                    for (let i = 1; i <= 5; i++) {
                        $('#' + keyType + '_status_' + i).html('');
                    }
                } else {
                    toastr.error(response.data.message);
                }
            },
            error: function(xhr, status, error) {
                window.AIWPG.Common.handleAjaxError(xhr, status, error);
            },
            complete: function() {
                $button.prop('disabled', false).html(originalHtml);
            }
        });
    };
    
})(jQuery);

