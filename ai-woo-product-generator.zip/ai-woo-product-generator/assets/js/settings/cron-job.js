/**
 * Cron Job Management
 * Handles cron job settings and progress tracking
 */

(function($) {
    'use strict';
    
    let progressInterval = null;
    
    $(document).ready(function() {
        // Save cron settings
        $('#cron-settings-form').on('submit', function(e) {
            e.preventDefault();
            
            const formData = {
                action: 'aiwpg_save_cron_settings',
                nonce: aiwpgData.nonce,
                api_key: $('#cron_api_key').val(),
                interval: $('#cron_interval').val(),
                timezone: $('#cron_timezone').val()
            };
            
            $.ajax({
                url: aiwpgData.ajaxUrl,
                type: 'POST',
                data: formData,
                success: function(response) {
                    if (response.success) {
                        toastr.success(response.data.message);
                    } else {
                        toastr.error(response.data.message);
                    }
                },
                error: function() {
                    toastr.error('An error occurred while saving settings');
                }
            });
        });
        
        // Create/Update cron job
        $('#create-cron-job').on('click', function() {
            const $button = $(this);
            const originalText = $button.html();
            
            $button.prop('disabled', true).html('<span class="dashicons dashicons-update"></span> Creating...');
            
            $.ajax({
                url: aiwpgData.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'aiwpg_create_cron_job',
                    nonce: aiwpgData.nonce
                },
                success: function(response) {
                    if (response.success) {
                        toastr.success(response.data.message);
                        // Start progress tracking
                        startProgressTracking();
                    } else {
                        toastr.error(response.data.message);
                    }
                },
                error: function() {
                    toastr.error('An error occurred while creating cron job');
                },
                complete: function() {
                    $button.prop('disabled', false).html(originalText);
                }
            });
        });
        
        // Reset progress
        $('#reset-progress').on('click', function() {
            if (!confirm('Are you sure you want to reset the progress? This will start the generation from the beginning.')) {
                return;
            }
            
            $.ajax({
                url: aiwpgData.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'aiwpg_reset_cron_progress',
                    nonce: aiwpgData.nonce
                },
                success: function(response) {
                    if (response.success) {
                        toastr.success(response.data.message);
                        stopProgressTracking();
                        $('#cron-progress-container').hide();
                    } else {
                        toastr.error(response.data.message);
                    }
                },
                error: function() {
                    toastr.error('An error occurred while resetting progress');
                }
            });
        });
        
        // Check for existing progress on page load
        checkProgress();
    });
    
    /**
     * Start progress tracking
     */
    function startProgressTracking() {
        if (progressInterval) {
            clearInterval(progressInterval);
        }
        
        // Check immediately
        checkProgress();
        
        // Then check every 5 seconds
        progressInterval = setInterval(checkProgress, 5000);
    }
    
    /**
     * Stop progress tracking
     */
    function stopProgressTracking() {
        if (progressInterval) {
            clearInterval(progressInterval);
            progressInterval = null;
        }
    }
    
    /**
     * Check current progress
     */
    function checkProgress() {
        $.ajax({
            url: aiwpgData.ajaxUrl,
            type: 'POST',
            data: {
                action: 'aiwpg_get_cron_progress',
                nonce: aiwpgData.nonce
            },
            success: function(response) {
                if (response.success && response.data.status !== 'not_started') {
                    updateProgressUI(response.data);
                    $('#cron-progress-container').show();
                    
                    // Stop tracking if completed
                    if (response.data.status === 'completed') {
                        stopProgressTracking();
                    }
                } else {
                    $('#cron-progress-container').hide();
                }
            },
            error: function() {
                console.error('Error checking progress');
            }
        });
    }
    
    /**
     * Update progress UI
     */
    function updateProgressUI(progress) {
        const total = progress.total || 0;
        const completed = progress.completed || 0;
        const failed = progress.failed || 0;
        const processed = completed + failed;
        const percentage = total > 0 ? Math.round((processed / total) * 100) : 0;
        
        // Update progress bar
        $('#cron-progress-fill').css('width', percentage + '%');
        $('#cron-progress-text').text(percentage + '%');
        
        // Update details
        $('#cron-status-text').text(progress.status === 'completed' ? 'Completed' : 'Running');
        $('#cron-completed').text(completed);
        $('#cron-total').text(total);
        $('#cron-failed').text(failed);
        
        // Update status text color
        if (progress.status === 'completed') {
            $('#cron-status-text').css('color', '#00a32a');
        } else if (progress.status === 'running') {
            $('#cron-status-text').css('color', '#2271b1');
        }
    }
    
    // Cleanup on page unload
    $(window).on('beforeunload', function() {
        stopProgressTracking();
    });
    
})(jQuery);

