# 🔍 دليل استكشاف الأخطاء وإصلاحها

## نظرة عامة

تم إضافة نظام logging شامل لتتبع المشاكل وحلها بسرعة.

---

## 📋 المشاكل الشائعة والحلول

### 1. Linked Products لا تظهر (Upsells & Cross-sells)

#### الأعراض
- قوائم Upsells و Cross-sells فارغة
- تظهر رسالة "لا توجد منتجات متاحة"
- القوائم لا تتحمل

#### خطوات التشخيص

##### الخطوة 1: افتح Console المتصفح
```
1. اضغط F12 في المتصفح
2. انتقل إلى تبويب Console
3. افتح Edit Product لأي منتج
4. انتقل إلى تبويب Linked
```

##### الخطوة 2: تحقق من Logs في Console

**رسائل يجب أن تظهر:**
```javascript
Loading linked products for product ID: 123
Upsell IDs: []
Cross-sell IDs: []
Linked products response: {success: true, data: {...}}
Total products available: 15
Linked products loaded successfully
```

##### الخطوة 3: تحليل الرسائل

**🟢 إذا ظهر "Total products available: 0"**
- **السبب**: لا توجد منتجات منشورة أخرى
- **الحل**: أضف منتجات أخرى في WooCommerce

**🔴 إذا ظهر "No products in response or request failed"**
- **السبب**: مشكلة في AJAX response
- **الحل**: تحقق من PHP logs (الخطوة 4)

**🔴 إذا ظهر "AJAX error loading linked products"**
- **السبب**: خطأ في الاتصال
- **الحل**: تحقق من Network tab في Console

##### الخطوة 4: تحقق من PHP Logs

**مكان ملف Log:**
```
wp-content/uploads/aiwpg-logs/aiwpg-YYYY-MM-DD.log
```

**رسائل يجب أن تظهر:**
```
[INFO] Getting all products list | exclude_id: 123
[INFO] WP_Query executed | found_posts: 15
[INFO] Products list retrieved | total_products: 15
```

**🔴 إذا ظهر "Permission denied"**
- **الحل**: تحقق من صلاحيات المستخدم (يجب أن يكون Admin أو Shop Manager)

**🔴 إذا لم تظهر أي رسائل**
- **الحل**: تأكد من أن AJAX action مسجل بشكل صحيح

##### الخطوة 5: تحقق من Network

```
1. في Developer Tools، افتح تبويب Network
2. اختر XHR/Fetch
3. ابحث عن طلب "aiwpg_get_all_products_list"
4. انقر عليه وتحقق من:
   - Status: يجب أن يكون 200
   - Response: يجب أن يحتوي على {success: true, data: {products: [...]}}
```

---

### 2. Add Product Modal - الأخطاء

#### الأعراض
- لا يتم حفظ المنتج
- رسالة خطأ عند الحفظ
- الموديول لا يُغلق بعد الحفظ

#### خطوات التشخيص

##### الخطوة 1: افتح Console المتصفح

##### الخطوة 2: افتح Add Product Modal وأكمل الخطوات

##### الخطوة 3: اضغط "Create Product" وراقب Logs

**رسائل يجب أن تظهر:**
```javascript
=== Add Product Modal - Save Product ===
Product Data: {name: "...", type: "simple", ...}
Create product response: {success: true, data: {...}}
Product created with ID: 456
```

##### الخطوة 4: تحليل الأخطاء

**🔴 إذا ظهر "Product Data is missing name"**
```javascript
Product Data: {description: "...", ...} // لا يوجد name
```
- **السبب**: لم يتم حفظ اسم المنتج في الخطوة 1
- **الحل**: تأكد من ملء حقل Product Name

**🔴 إذا ظهر "AJAX error creating product"**
- **السبب**: خطأ في الطلب
- **الحل**: تحقق من PHP logs

##### الخطوة 5: تحقق من PHP Logs

**رسائل يجب أن تظهر:**
```
[INFO] Create product request received | has_data: true
[INFO] Product created successfully | product_id: 456
```

**🔴 إذا ظهر "Invalid product data"**
- **السبب**: البيانات المرسلة غير صحيحة
- **الحل**: تحقق من JavaScript console

##### الخطوة 6: تحقق من Categories Loading

**رسائل يجب أن تظهر عند فتح Modal:**
```javascript
Loading categories for Add Product modal...
Categories response: {success: true, data: {...}}
Total categories: 5
Categories loaded successfully
```

**🔴 إذا ظهر "Failed to load categories"**
- **السبب**: مشكلة في تحميل التصنيفات
- **الحل**: تحقق من أن WooCommerce مفعل وهناك تصنيفات

---

## 🛠️ أدوات التشخيص

### 1. Console Logs

#### كيفية قراءة Logs

```javascript
// ✅ رسالة نجاح
Loading linked products for product ID: 123
Total products available: 15
Linked products loaded successfully

// ⚠️ تحذير
Total products available: 0

// ❌ خطأ
AJAX error loading linked products: {status: 500, error: "..."}
```

### 2. PHP Logs

#### كيفية الوصول
```
FTP → wp-content/uploads/aiwpg-logs/
أو
File Manager → wp-content/uploads/aiwpg-logs/
```

#### صيغة الرسائل
```
[2025-11-23 10:30:45] [INFO] [products_controller] Getting all products list | {"exclude_id":123}
[2025-11-23 10:30:45] [INFO] [products_controller] Products list retrieved | {"total_products":15}
```

### 3. Network Tab

#### ما يجب التحقق منه

**Request Headers:**
```
X-WP-Nonce: abc123...
```

**Request Payload:**
```json
{
  "action": "aiwpg_get_all_products_list",
  "nonce": "abc123...",
  "exclude_id": 123
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "products": [
      {"id": 124, "title": "Product 1"},
      {"id": 125, "title": "Product 2"}
    ]
  }
}
```

---

## 📝 حالات الأخطاء الشائعة

### Error 1: "لا توجد منتجات متاحة"

**السبب المحتمل:**
1. ✅ لا توجد منتجات منشورة أخرى (طبيعي)
2. ❌ جميع المنتجات في حالة Draft
3. ❌ مشكلة في WP_Query

**الحل:**
```php
// تحقق من أن هناك منتجات منشورة
WooCommerce → Products → تأكد من وجود منتجات بحالة "Published"
```

### Error 2: "فشل تحميل المنتجات"

**السبب المحتمل:**
1. ❌ AJAX request فشل
2. ❌ Nonce غير صحيح
3. ❌ Permission denied

**الحل:**
1. تحديث الصفحة (Ctrl + F5)
2. تسجيل الخروج والدخول مرة أخرى
3. تحقق من صلاحيات المستخدم

### Error 3: "خطأ في التحميل"

**السبب المحتمل:**
1. ❌ Server error (500)
2. ❌ Connection timeout
3. ❌ PHP error

**الحل:**
1. تحقق من PHP error log
2. تحقق من server status
3. تحقق من memory limit في PHP

---

## 🔧 الإصلاحات السريعة

### إصلاح 1: تحديث الصفحة
```
Ctrl + F5 (Windows/Linux)
Cmd + Shift + R (Mac)
```

### إصلاح 2: مسح Cache
```
1. إعدادات المتصفح → Clear Cache
2. WordPress → إعدادات → حذف Cache (إذا كنت تستخدم caching plugin)
```

### إصلاح 3: تفعيل Debug Mode

**في wp-config.php:**
```php
define('WP_DEBUG', true);
define('WP_DEBUG_LOG', true);
define('WP_DEBUG_DISPLAY', false);
```

### إصلاح 4: إعادة تنشيط الإضافة
```
Plugins → Deactivate AI Woo Product Generator
Plugins → Activate AI Woo Product Generator
```

---

## 📊 جدول الأخطاء والحلول

| الخطأ | السبب | الحل |
|------|-------|------|
| Console لا يظهر logs | Cache قديم | Ctrl + F5 |
| Permission denied | صلاحيات المستخدم | تسجيل دخول كـ Admin |
| 500 Internal Server Error | PHP error | تحقق من error log |
| Nonce verification failed | Session expired | تسجيل خروج ودخول |
| Products not loading | No published products | أضف منتجات |
| Modal not closing | JavaScript error | تحقق من Console |
| Categories empty | No categories in WooCommerce | أضف تصنيفات |

---

## 🎯 نصائح للتشخيص السريع

### 1. دائماً افتح Console أولاً
```
F12 → Console
```

### 2. راقب Network Tab
```
F12 → Network → XHR
```

### 3. تحقق من PHP Logs
```
wp-content/uploads/aiwpg-logs/
```

### 4. استخدم WordPress Debug
```
wp-config.php → WP_DEBUG = true
```

### 5. تحقق من صلاحيات الملفات
```
Folders: 755
Files: 644
```

---

## 📞 طلب المساعدة

### المعلومات المطلوبة

عند طلب المساعدة، أرسل:

1. **Console Logs:**
   - Screenshot من Console
   - جميع الرسائل باللون الأحمر

2. **PHP Logs:**
   - آخر 20 سطر من aiwpg-*.log

3. **Network Tab:**
   - Screenshot من Request/Response

4. **معلومات النظام:**
   - إصدار WordPress
   - إصدار WooCommerce
   - إصدار PHP
   - المتصفح المستخدم

5. **خطوات إعادة إنتاج المشكلة:**
   - الخطوات بالتفصيل

---

## ✅ قائمة التحقق

قبل طلب المساعدة، تأكد من:

- [ ] Console مفتوح وتم فحصه
- [ ] PHP logs تم فحصها
- [ ] Network tab تم فحصه
- [ ] تم تحديث الصفحة (Ctrl + F5)
- [ ] تم مسح Cache
- [ ] المستخدم لديه صلاحيات Admin
- [ ] WooCommerce مفعل
- [ ] توجد منتجات منشورة

---

## 🆘 مشاكل معروفة

### مشكلة: Linked Products تستغرق وقتاً طويلاً
**السبب:** عدد كبير من المنتجات (1000+)
**الحل:** سيتم إضافة Pagination قريباً

### مشكلة: Categories لا تُحمّل
**السبب:** مشكلة في WooCommerce
**الحل:** أعد تثبيت WooCommerce

---

**آخر تحديث**: نوفمبر 2025  
**الإصدار**: 1.1.0

