# تشخيص مشكلة Linked Products

## الخطوات للتشخيص:

### 1. افتح Console في المتصفح
```
- اضغط F12
- اذهب لتبويب Console
```

### 2. افتح Edit Product Modal
```
- اذهب للصفحة Products
- اضغط Edit على أي منتج
- اذهب لتبويب Linked Products
```

### 3. تحقق من الرسائل في Console:

#### ✅ إذا رأيت هذه الرسائل (كل شيء يعمل):
```
🔗 Initializing Linked Products module...
✅ aiwpgData found: {ajaxUrl: "...", nonce: "OK"}
📦 Loading linked products for product: 123
⏳ Sending AJAX request...
📨 AJAX response received: {success: true, data: {...}}
✅ Products loaded successfully: 50
✅ Linked Products module initialized
```

#### ❌ إذا رأيت:
```
❌ aiwpgData is not defined!
```
**الحل:** المشكلة في تحميل ملفات JavaScript. تأكد من:
- الـ plugin مفعّل بشكل صحيح
- لا توجد أخطاء في تحميل ملفات JS
- Cache المتصفح محدّث (Ctrl+Shift+R)

#### ❌ إذا رأيت:
```
❌ AJAX error: ...
```
**الحل:** المشكلة في الاتصال بالسيرفر. تحقق من:
- WordPress AJAX يعمل
- الـ nonce صحيح
- لا توجد أخطاء في PHP (تحقق من error_log)

#### ❌ إذا رأيت:
```
⚠️ No products loaded yet!
```
**الحل:** لم يتم تحميل المنتجات بعد. انتظر قليلاً أو:
- تحقق من وجود منتجات في المتجر
- تحقق من صلاحيات المستخدم

### 4. اختبر البحث:
```
- اكتب أي حرف في مربع البحث
- تحقق من الرسائل:
  🔍 Search query: "a", allProducts length: 50
  🔍 جاري البحث...
  🔍 Searching in 50 products for: "a"
  ✅ Matches found: 5
  🎨 Rendering autocomplete: 5 results
  ✅ Autocomplete rendered and shown
```

### 5. نصائح إضافية:

#### مسح Cache المتصفح:
```
Ctrl + Shift + R (Windows)
Cmd + Shift + R (Mac)
```

#### تحقق من تحميل ملفات JS:
```
- في Console → Network tab
- ابحث عن: linked-products.js
- تأكد أنه loaded بنجاح (Status: 200)
```

#### تحقق من WordPress Debug:
في `wp-config.php`:
```php
define('WP_DEBUG', true);
define('WP_DEBUG_LOG', true);
define('WP_DEBUG_DISPLAY', false);
```

ثم تحقق من: `wp-content/debug.log`

## المشاكل الشائعة والحلول:

### المشكلة 1: لا توجد اقتراحات
**السبب:** `allProducts` array فارغة
**الحل:** تحقق من AJAX response في Console

### المشكلة 2: AJAX يفشل
**السبب:** مشكلة في nonce أو permissions
**الحل:** تأكد من تسجيل الدخول كـ admin

### المشكلة 3: Autocomplete لا يظهر
**السبب:** مشكلة في CSS
**الحل:** تحقق من أن `#linked-products-autocomplete` موجود في HTML

### المشكلة 4: Toggle buttons لا تعمل
**السبب:** مشكلة في event handlers
**الحل:** تحقق من أن `linked-products.js` محمّل بشكل صحيح

## معلومات إضافية:

### AJAX Action:
```
Action: aiwpg_get_all_products_list
Controller: class-aiwpg-products-controller.php
Method: get_all_products_list()
```

### JavaScript Files:
```
1. assets/js/products_list/linked-products.js (الوحدة الرئيسية)
2. assets/js/products_list/edit-modal.js (يستدعي load())
3. assets/js/products_list/init.js (يستدعي init())
```

### HTML Elements:
```
#linked-products-search (مربع البحث)
#linked-products-autocomplete (نتائج البحث)
#upsells-list (قائمة Upsells)
#cross-sells-list (قائمة Cross-sells)
.toggle-btn (أزرار التبديل)
```

---

إذا استمرت المشكلة، أرسل لقطة شاشة من Console مع كل الرسائل.

