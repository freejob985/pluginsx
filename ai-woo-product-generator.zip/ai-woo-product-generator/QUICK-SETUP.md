# 🚀 Quick Setup - .env Configuration

## Option 1: Copy Template (Recommended)

```bash
# Navigate to plugin directory
cd wp-content/plugins/ai-woo-product-generator/

# Copy template to .env
cp env.template .env

# Edit with your favorite editor
nano .env
# or
vi .env

# Set secure permissions
chmod 600 .env
```

## Option 2: Create from Scratch

```bash
# Navigate to plugin directory
cd wp-content/plugins/ai-woo-product-generator/

# Create .env file
cat > .env << 'EOF'
# Google Gemini API Keys
AIWPG_GEMINI_API_KEY_1=AIzaSyD7jSzV7S-XwRa8L90KVBxM08g7LSMDeGk
AIWPG_GEMINI_API_KEY_2=AIzaSyCTYH7rvcxwjemRqYO1zy6fftpXtJ7x7s
AIWPG_GEMINI_API_KEY_3=AIzaSyCwYAwZIqKE727iTqIbYWLBvrt8ebW-0k
AIWPG_GEMINI_API_KEY_4=AIzaSyC2uWuYocXExJfqQxeBaV90ZIvdx1EibCc
AIWPG_GEMINI_API_KEY_5=AIzaSyDa-Ad3iE6JwBMy5mg9me2vfXbrdI3bLQo

# Freepik API Keys
AIWPG_FREEPIK_API_KEY_1=FPSX92452c6f2d4fa55c28aada8cf90ca9b5
AIWPG_FREEPIK_API_KEY_2=FPSXfc69924b6277229b426ebe763a08c492
AIWPG_FREEPIK_API_KEY_3=FPSX0aeba49147ef1227332719d498be9a6d
AIWPG_FREEPIK_API_KEY_4=FPSX6067f6de3fa5753b99d144e8b39c3d5f
AIWPG_FREEPIK_API_KEY_5=FPSXfab91d35c22b8659c9c8495bfd6084dc
EOF

# Set secure permissions
chmod 600 .env
```

## Verify Setup

```bash
# Test if .env file exists and is readable
ls -la .env

# Check if keys are loaded (simple test)
grep "AIWPG_GEMINI_API_KEY_1" .env
```

## ✅ Done!

Reload your WordPress admin page and the error should be gone.

---

## 📖 Full Documentation

- Arabic Guide: [ENV-SETUP-AR.md](./ENV-SETUP-AR.md)
- Template File: [env.template](./env.template)

