# Excel AI Integration - Implementation Summary

## نظرة عامة | Overview

تم تحديث ميزة "Multiple Products (Excel)" لدعم تدفق عمل مدعوم بالذكاء الاصطناعي لتصنيف المنتجات تلقائياً، تعيين المطابخ، والكشف عن الإضافات (Add-ons).

The "Multiple Products (Excel)" feature has been updated to support an AI-powered workflow for automatic product classification, kitchen assignment, and add-on detection.

## الميزات الجديدة | New Features

### 1. قالب Excel محدث | Updated Excel Template

**الأعمدة الجديدة:**
- **Product Name** (مطلوب) - اسم المنتج
- **Description** (اختياري) - وصف المنتج
- **Base Price** (مطلوب) - السعر الأساسي
- **SKU** (اختياري) - رمز المنتج
- **Raw Category** (اختياري) - الفئة الأولية
- **Raw Tags** (اختياري) - العلامات الأولية
- **Notes** (اختياري) - ملاحظات (مثل "extra / side / add-on")

### 2. تصنيف AI تلقائي | Automatic AI Classification

يقوم AI بتصنيف كل منتج تلقائياً:
- **Type**: Food أو Beverage
- **Category**: فئة WooCommerce مناسبة
- **Kitchen**: محطة المطبخ (Main Kitchen, Barista Station, etc.)
- **Tags**: علامات ذات صلة
- **Is Add-on**: هل المنتج إضافة/إضافي
- **Add-on Group**: مجموعة الإضافات (إذا كان add-on)

### 3. خيارات الاستيراد | Import Options

- **Dry-run Mode**: معاينة فقط بدون إنشاء منتجات
- **Create Only**: إنشاء منتجات جديدة فقط
- **Create & Update**: إنشاء منتجات جديدة وتحديث الموجودة
- **Use AI**: تفعيل/تعطيل التصنيف بالذكاء الاصطناعي
- **Treat Ambiguous as Draft**: حفظ المنتجات غير الواضحة كمسودات

### 4. جدول معاينة محسّن | Enhanced Preview Table

يعرض الجدول:
- Original Name
- AI Type (Food/Beverage)
- AI Category
- Kitchen
- Is Add-on
- Add-on Group
- Price
- Status

### 5. إحصائيات الاستيراد | Import Statistics

- Total Rows
- Successfully Processed
- Errors
- AI Calls Count

## التغييرات في الملفات | File Changes

### 1. `views/admin-ai-generator-page.php`
- ✅ تحديث واجهة تبويب Excel
- ✅ إضافة حقول: Import Mode, Use AI, Treat Ambiguous as Draft
- ✅ تحديث جدول المعاينة لعرض بيانات AI

### 2. `assets/js/generate_products/excel-import.js`
- ✅ تحديث قالب Excel ليتضمن الأعمدة الجديدة
- ✅ تحديث `uploadAndProcess()` لدعم رفع الملفات
- ✅ تحديث `displayPreview()` لعرض بيانات AI
- ✅ تحديث `confirmImport()` لحفظ المنتجات بعد التأكيد

### 3. `controllers/class-aiwpg-products-controller.php`
- ✅ تحديث `generate_from_excel()` لدعم رفع الملفات ومعالجة AI
- ✅ إضافة `convert_row_to_product_data()` لتحويل البيانات
- ✅ إضافة `save_excel_products()` لحفظ المنتجات بعد التأكيد
- ✅ إضافة `apply_product_metadata()` لتطبيق Kitchen و Add-on Groups
- ✅ إضافة `assign_to_woo_food_addon_group()` لربط Add-on Groups

### 4. `models/class-aiwpg-excel-parser.php`
- ✅ يدعم بالفعل الأعمدة الجديدة (لا يحتاج تغيير)

### 5. `models/class-aiwpg-ai-service.php`
- ✅ تحديث `get_existing_addon_groups()` لاستخراج Add-on Groups من Woo Food

### 6. `models/class-aiwpg-product-model.php`
- ✅ إضافة دعم Kitchen في `create_product()`
- ✅ إضافة دعم Add-on Groups في `create_product()`
- ✅ إضافة `assign_to_woo_food_addon_group()` لإنشاء/ربط Add-on Groups

## تدفق العمل | Workflow

1. **رفع الملف**: المستخدم يرفع ملف Excel
2. **تحليل الملف**: يتم تحليل الملف باستخدام Excel Parser
3. **تصنيف AI** (إذا كان مفعّل):
   - معالجة كل صف في دفعات (10 صفوف في كل مرة)
   - استدعاء AI لتصنيف كل منتج
   - استخدام Fallback Classification في حالة فشل AI
4. **معاينة**: عرض النتائج في جدول معاينة
5. **التأكيد**: المستخدم يراجع ويؤكد الاستيراد
6. **الحفظ**: إنشاء/تحديث المنتجات في WooCommerce
7. **تطبيق Metadata**: حفظ Kitchen و Add-on Groups

## دعم Woo Food Plugin

### Add-on Groups

إذا كان Woo Food plugin نشطاً:
- يتم استخراج Add-on Groups الموجودة من `exwo_options` meta
- يتم إنشاء Add-on Groups جديدة إذا لم تكن موجودة
- يتم ربط المنتجات بـ Add-on Groups المناسبة

### Kitchen Assignment

- يتم حفظ Kitchen في `_aiwpg_kitchen` meta
- يمكن استخدامها لاحقاً في Kitchen Screens

## Hooks المتاحة | Available Hooks

```php
// قبل معالجة صف
do_action('aiwpg_before_import_row', $row);

// بعد معالجة صف
do_action('aiwpg_after_import_row', $product_id, $product_data);

// بعد تعيين Add-on Group
do_action('aiwpg_woo_food_addon_assigned', $product_id, $addon_group_name, $group_exists);

// قبل/بعد تصنيف AI
apply_filters('aiwpg_ai_enrich_row', $enriched_data, $row);
```

## ملاحظات مهمة | Important Notes

1. **الأداء**: يتم معالجة AI في دفعات (10 صفوف) لتجنب Rate Limiting
2. **Fallback**: في حالة فشل AI، يتم استخدام تصنيف بسيط يعتمد على الكلمات المفتاحية
3. **Woo Food**: الميزة تعمل بشكل طبيعي حتى لو لم يكن Woo Food نشطاً
4. **Dry-run**: وضع المعاينة يسمح بمراجعة قرارات AI قبل الاستيراد الفعلي

## كيفية الاستخدام | How to Use

1. انتقل إلى: **AI Product Generator > Multiple Products (Excel)**
2. اضغط **Download Excel Template** لتحميل القالب
3. املأ القالب بالبيانات (Product Name و Base Price مطلوبان)
4. اختر **Import Mode** و **Use AI** حسب الحاجة
5. ارفع الملف واضغط **Upload and Process**
6. راجع النتائج في جدول المعاينة
7. اضغط **Confirm Import** لحفظ المنتجات

## أمثلة | Examples

### مثال 1: منتج عادي
```
Product Name: Latte Coffee
Description: Medium hot latte with steamed milk
Base Price: 3.5
```

**AI Output:**
- Type: Beverage
- Category: Hot Drinks
- Kitchen: Barista Station
- Is Add-on: No

### مثال 2: Add-on
```
Product Name: Extra Cheese
Description: Extra mozzarella cheese
Base Price: 1
Notes: extra / side
```

**AI Output:**
- Type: Food
- Category: Pizza Add-ons
- Kitchen: Main Kitchen
- Is Add-on: Yes
- Add-on Group: Pizza Extras

---

**تاريخ التحديث | Update Date:** 2025-01-27
**الإصدار | Version:** 1.0.0
