# Bug Fix: Internal Server Error When Adding Products

## Date: November 25, 2025

---

## 🐛 The Problem

When trying to add a new product from the "Add New Product" modal, the following error appears:

```
Network error: Internal Server Error
```

---

## 🔍 Problem Diagnosis

### Root Cause

After updating the Add Product modal and adding the new **Tag Input** feature, the way Tags are sent changed:

**Before:**
```javascript
// Tags were sent as a string
productData.tags = "Electronics,Wireless,Audio"
```

**After:**
```javascript
// Tags are now sent as an array
productData.tags = ["Electronics", "Wireless", "Audio"]
```

### Code Causing the Error

In `controllers/class-aiwpg-products-controller.php` line 750:

```php
'tags' => isset($product_data['tags']) ? explode(',', $product_data['tags']) : array(),
```

**The Problem:** 
- Code tries to `explode()` an **array** 
- `explode()` only works with **string**
- This causes a PHP Fatal Error

---

## ✅ The Solution

### 1. Add Helper Function `prepare_tags()`

**Location:** `controllers/class-aiwpg-products-controller.php`

```php
/**
 * Prepare tags - handle both array and string formats
 */
private function prepare_tags($product_data) {
    if (!isset($product_data['tags'])) {
        return array();
    }
    
    $tags = $product_data['tags'];
    
    // If already an array, return as is
    if (is_array($tags)) {
        return array_filter($tags); // Remove empty values
    }
    
    // If string, split by comma
    if (is_string($tags) && !empty($tags)) {
        return array_filter(array_map('trim', explode(',', $tags)));
    }
    
    return array();
}
```

**Features:**
- ✅ Supports Array (new format)
- ✅ Supports String (old format - backward compatibility)
- ✅ Removes empty values
- ✅ Trims whitespace

### 2. Update prepare_tags Usage

```php
// Before
'tags' => isset($product_data['tags']) ? explode(',', $product_data['tags']) : array(),

// After
'tags' => $this->prepare_tags($product_data),
```

---

## 🔧 Additional Improvements

### 1. Improve image_id Handling

**Potential Issue:** Non-numeric values

```php
// Before
if (!empty($product_data['image_id'])) {
    set_post_thumbnail($product_id, $product_data['image_id']);
}

// After
if (!empty($product_data['image_id']) && is_numeric($product_data['image_id'])) {
    set_post_thumbnail($product_id, intval($product_data['image_id']));
}
```

**Improvements:**
- ✅ Verify value is numeric
- ✅ Explicit integer conversion
- ✅ Prevent potential errors

### 2. Improve gallery_ids Handling

**Potential Issue:** Null or empty values in array

```php
// Before
if (!empty($product_data['gallery_ids']) && is_array($product_data['gallery_ids'])) {
    update_post_meta($product_id, '_product_image_gallery', implode(',', $product_data['gallery_ids']));
}

// After
if (!empty($product_data['gallery_ids']) && is_array($product_data['gallery_ids'])) {
    // Filter out empty values and ensure all are numeric
    $gallery_ids = array_filter($product_data['gallery_ids'], function($id) {
        return !empty($id) && is_numeric($id);
    });
    if (!empty($gallery_ids)) {
        update_post_meta($product_id, '_product_image_gallery', implode(',', $gallery_ids));
    }
}
```

**Improvements:**
- ✅ Filter empty values
- ✅ Ensure all values are numeric
- ✅ Don't save metadata if list is empty

---

## 📋 Modified Files

### 1. controllers/class-aiwpg-products-controller.php
- ✅ Added `prepare_tags()` function
- ✅ Updated tags handling in `create_product()`

### 2. models/class-aiwpg-product-model.php
- ✅ Improved `image_id` handling
- ✅ Improved `gallery_ids` handling

---

## 🧪 Testing

### Test Cases

#### ✅ Test 1: Tags as Array (New Format)
```json
{
  "tags": ["Electronics", "Wireless", "Audio"]
}
```
**Result:** ✅ Success

#### ✅ Test 2: Tags as String (Backward Compatibility)
```json
{
  "tags": "Electronics,Wireless,Audio"
}
```
**Result:** ✅ Success

#### ✅ Test 3: Empty Tags
```json
{
  "tags": []
}
```
**Result:** ✅ Success

#### ✅ Test 4: No Tags
```json
{
  "name": "Product Name"
}
```
**Result:** ✅ Success

#### ✅ Test 5: With Product Image
```json
{
  "image_id": 123
}
```
**Result:** ✅ Success

#### ✅ Test 6: With Gallery Images
```json
{
  "gallery_ids": [124, 125, 126]
}
```
**Result:** ✅ Success

---

## 🎯 Summary

### The Problem
Conflict between old Tags format (string) and new format (array)

### The Solution
`prepare_tags()` function that supports both formats

### Additional Improvements
- Enhanced image handling
- Filter invalid values
- Protection against potential errors

---

## ✨ Result

✅ **Problem completely solved**
✅ **Backward compatibility with both formats**
✅ **Improved security and stability**
✅ **No linter errors**

---

## 📝 Future Notes

When changing data format in Frontend:
1. ✅ Update Backend handling
2. ✅ Support backward compatibility
3. ✅ Add data type verification
4. ✅ Test all possible cases

---

**Fix Date:** November 25, 2025
**Status:** ✅ Fixed and Tested
**Developer:** AI Assistant

