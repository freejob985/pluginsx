<?php
/**
 * Plugin Name: AI Woo Product Generator
 * Plugin URI: https://example.com/ai-woo-product-generator
 * Description: Generate WooCommerce products using Google Gemini 2.0 Flash AI with advanced MVC architecture, AJAX operations, and professional admin UI.
 * Version: 1.0.0
 * Author: Your Name
 * Author URI: https://example.com
 * Text Domain: ai-woo-product-generator
 * Domain Path: /languages
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('AIWPG_VERSION', '1.0.0');
define('AIWPG_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('AIWPG_PLUGIN_URL', plugin_dir_url(__FILE__));
define('AIWPG_PLUGIN_BASENAME', plugin_basename(__FILE__));

// Load environment variables from .env file (if exists)
require_once AIWPG_PLUGIN_DIR . 'env-loader.php';

// ============================================================================
// API KEYS CONFIGURATION - SECURITY UPDATE
// ============================================================================
// CRITICAL SECURITY: API keys are NO LONGER hardcoded in plugin files.
// 
// To configure API keys, add these constants to your wp-config.php file:
// 
// Google Gemini API Keys (for product generation with automatic failover):
// define('AIWPG_GEMINI_API_KEY_1', 'your-gemini-key-1-here');
// define('AIWPG_GEMINI_API_KEY_2', 'your-gemini-key-2-here');
// define('AIWPG_GEMINI_API_KEY_3', 'your-gemini-key-3-here');
// define('AIWPG_GEMINI_API_KEY_4', 'your-gemini-key-4-here');
// define('AIWPG_GEMINI_API_KEY_5', 'your-gemini-key-5-here');
//
// Freepik API Keys (for AI image generation with automatic failover):
// define('AIWPG_FREEPIK_API_KEY_1', 'your-freepik-key-1-here');
// define('AIWPG_FREEPIK_API_KEY_2', 'your-freepik-key-2-here');
// define('AIWPG_FREEPIK_API_KEY_3', 'your-freepik-key-3-here');
// define('AIWPG_FREEPIK_API_KEY_4', 'your-freepik-key-4-here');
// define('AIWPG_FREEPIK_API_KEY_5', 'your-freepik-key-5-here');
//
// Alternative: Use environment variables (recommended for production):
// - Set environment variables in your server configuration
// - Variables: AIWPG_GEMINI_API_KEY_1, AIWPG_FREEPIK_API_KEY_1, etc.
// ============================================================================

// Load API keys from wp-config.php (preferred) or environment variables
// Gemini API Keys
if (!defined('AIWPG_GEMINI_API_KEY_1')) {
    define('AIWPG_GEMINI_API_KEY_1', getenv('AIWPG_GEMINI_API_KEY_1') ?: '');
}
if (!defined('AIWPG_GEMINI_API_KEY_2')) {
    define('AIWPG_GEMINI_API_KEY_2', getenv('AIWPG_GEMINI_API_KEY_2') ?: '');
}
if (!defined('AIWPG_GEMINI_API_KEY_3')) {
    define('AIWPG_GEMINI_API_KEY_3', getenv('AIWPG_GEMINI_API_KEY_3') ?: '');
}
if (!defined('AIWPG_GEMINI_API_KEY_4')) {
    define('AIWPG_GEMINI_API_KEY_4', getenv('AIWPG_GEMINI_API_KEY_4') ?: '');
}
if (!defined('AIWPG_GEMINI_API_KEY_5')) {
    define('AIWPG_GEMINI_API_KEY_5', getenv('AIWPG_GEMINI_API_KEY_5') ?: '');
}

// Freepik API Keys
if (!defined('AIWPG_FREEPIK_API_KEY_1')) {
    define('AIWPG_FREEPIK_API_KEY_1', getenv('AIWPG_FREEPIK_API_KEY_1') ?: '');
}
if (!defined('AIWPG_FREEPIK_API_KEY_2')) {
    define('AIWPG_FREEPIK_API_KEY_2', getenv('AIWPG_FREEPIK_API_KEY_2') ?: '');
}
if (!defined('AIWPG_FREEPIK_API_KEY_3')) {
    define('AIWPG_FREEPIK_API_KEY_3', getenv('AIWPG_FREEPIK_API_KEY_3') ?: '');
}
if (!defined('AIWPG_FREEPIK_API_KEY_4')) {
    define('AIWPG_FREEPIK_API_KEY_4', getenv('AIWPG_FREEPIK_API_KEY_4') ?: '');
}
if (!defined('AIWPG_FREEPIK_API_KEY_5')) {
    define('AIWPG_FREEPIK_API_KEY_5', getenv('AIWPG_FREEPIK_API_KEY_5') ?: '');
}

/**
 * Main Plugin Class
 */
class AI_Woo_Product_Generator {
    
    /**
     * Single instance of the class
     */
    private static $instance = null;
    
    /**
     * Get instance
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructor
     */
    private function __construct() {
        $this->load_dependencies();
        $this->init_hooks();
    }
    
    /**
     * Load required files
     */

     
    private function load_dependencies() {
        // Models - Load logger first
        require_once AIWPG_PLUGIN_DIR . 'models/class-aiwpg-logger.php';
        require_once AIWPG_PLUGIN_DIR . 'models/class-aiwpg-gemini-client.php';
        require_once AIWPG_PLUGIN_DIR . 'models/class-aiwpg-product-model.php';
        require_once AIWPG_PLUGIN_DIR . 'models/class-aiwpg-image-client.php';
        
        // Controllers
        require_once AIWPG_PLUGIN_DIR . 'controllers/class-aiwpg-admin-controller.php';
        require_once AIWPG_PLUGIN_DIR . 'controllers/class-aiwpg-products-controller.php';
        require_once AIWPG_PLUGIN_DIR . 'controllers/class-aiwpg-settings-controller.php';
        require_once AIWPG_PLUGIN_DIR . 'controllers/class-aiwpg-images-controller.php';
    }
    
    /**
     * Initialize hooks
     */
    private function init_hooks() {
        // Activation/Deactivation
        register_activation_hook(__FILE__, array($this, 'activate'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate'));
        
        // Check if WooCommerce is active
        add_action('plugins_loaded', array($this, 'check_woocommerce'));
        
        // Check if API keys are configured
        add_action('admin_init', array($this, 'check_api_keys'));
        
        // Initialize controllers
        add_action('plugins_loaded', array($this, 'init_controllers'));
        
        // Load text domain
        add_action('plugins_loaded', array($this, 'load_textdomain'));
        
        // Register custom image size for product thumbnails (300x300)
        add_action('after_setup_theme', array($this, 'register_image_sizes'));
    }
    

    
    /**
     * Register custom image sizes
     */
    public function register_image_sizes() {
        // Register 300x300 product thumbnail size
        add_image_size('aiwpg_product_thumbnail', 300, 300, true); // true = hard crop (square)
    }
    
    /**
     * Plugin activation
     */
    public function activate() {
        // Check WooCommerce
        if (!class_exists('WooCommerce')) {
            deactivate_plugins(AIWPG_PLUGIN_BASENAME);
            wp_die(
                __('AI Woo Product Generator requires WooCommerce to be installed and activated.', 'ai-woo-product-generator'),
                'Plugin Activation Error',
                array('back_link' => true)
            );
        }
        
        // Set default options
        if (!get_option('aiwpg_settings')) {
            update_option('aiwpg_settings', array(
                'products_per_page' => 12,
                'default_stock_status' => 'instock',
                'auto_publish' => false,
            ));
        }
        
        // Flush rewrite rules
        flush_rewrite_rules();
    }
    
    /**
     * Plugin deactivation
     */
    public function deactivate() {
        // Flush rewrite rules
        flush_rewrite_rules();
    }
    
    /**
     * Check if WooCommerce is active
     */
    public function check_woocommerce() {
        if (!class_exists('WooCommerce')) {
            add_action('admin_notices', array($this, 'woocommerce_missing_notice'));
        }
    }
    
    /**
     * Check if API keys are configured
     */
    public function check_api_keys() {
        // Check if at least one Gemini key is configured
        $has_gemini_key = false;
        for ($i = 1; $i <= 5; $i++) {
            $constant = 'AIWPG_GEMINI_API_KEY_' . $i;
            if (defined($constant) && !empty(constant($constant))) {
                $has_gemini_key = true;
                break;
            }
        }
        
        // Check if at least one Freepik key is configured
        $has_freepik_key = false;
        for ($i = 1; $i <= 5; $i++) {
            $constant = 'AIWPG_FREEPIK_API_KEY_' . $i;
            if (defined($constant) && !empty(constant($constant))) {
                $has_freepik_key = true;
                break;
            }
        }
        
        // Show notices if keys are missing
        if (!$has_gemini_key) {
            add_action('admin_notices', array($this, 'gemini_keys_missing_notice'));
        }
        
        if (!$has_freepik_key) {
            add_action('admin_notices', array($this, 'freepik_keys_missing_notice'));
        }
    }
    
    /**
     * WooCommerce missing notice
     */
    public function woocommerce_missing_notice() {
        ?>
        <div class="notice notice-error">
            <p>
                <?php 
                echo sprintf(
                    /* translators: 1: Plugin name, 2: WooCommerce link */
                    __('%1$s requires %2$s to be installed and activated.', 'ai-woo-product-generator'),
                    '<strong>AI Woo Product Generator</strong>',
                    '<a href="https://wordpress.org/plugins/woocommerce/" target="_blank">WooCommerce</a>'
                );
                ?>
            </p>
        </div>
        <?php
    }
    
    /**
     * Gemini API keys missing notice
     */
    public function gemini_keys_missing_notice() {
        ?>
        <div class="notice notice-warning is-dismissible">
            <p>
                <strong>AI Woo Product Generator:</strong> 
                <?php _e('Google Gemini API keys are not configured. Product generation will not work.', 'ai-woo-product-generator'); ?>
            </p>
            <p>
                <?php 
                echo sprintf(
                    __('Please add your API keys to %s. See plugin documentation for details.', 'ai-woo-product-generator'),
                    '<code>wp-config.php</code>'
                );
                ?>
            </p>
            <p>
                <code>define('AIWPG_GEMINI_API_KEY_1', 'your-key-here');</code>
            </p>
        </div>
        <?php
    }
    
    /**
     * Freepik API keys missing notice
     */
    public function freepik_keys_missing_notice() {
        ?>
        <div class="notice notice-warning is-dismissible">
            <p>
                <strong>AI Woo Product Generator:</strong> 
                <?php _e('Freepik API keys are not configured. Image generation will not work.', 'ai-woo-product-generator'); ?>
            </p>
            <p>
                <?php 
                echo sprintf(
                    __('Please add your API keys to %s. See plugin documentation for details.', 'ai-woo-product-generator'),
                    '<code>wp-config.php</code>'
                );
                ?>
            </p>
            <p>
                <code>define('AIWPG_FREEPIK_API_KEY_1', 'your-key-here');</code>
            </p>
        </div>
        <?php
    }
    
    /**
     * Initialize controllers
     */
    public function init_controllers() {
        if (class_exists('WooCommerce')) {
            AIWPG_Admin_Controller::get_instance();
            AIWPG_Products_Controller::get_instance();
            AIWPG_Settings_Controller::get_instance();
            AIWPG_Images_Controller::get_instance();
        }
    }
    
    /**
     * Load plugin text domain
     */
    public function load_textdomain() {
        load_plugin_textdomain(
            'ai-woo-product-generator',
            false,
            dirname(AIWPG_PLUGIN_BASENAME) . '/languages'
        );
    }
}

/**
 * Initialize the plugin
 */
function aiwpg_init() {
    return AI_Woo_Product_Generator::get_instance();
}

// Start the plugin
aiwpg_init();
