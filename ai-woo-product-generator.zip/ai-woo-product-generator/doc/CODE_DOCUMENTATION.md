# Code Documentation | توثيق الكود

[English](#english) | [العربية](#arabic)

---

<a name="english"></a>
# 💻 Complete Code Documentation

## Overview

This document provides detailed code documentation for all classes, methods, and functions in the **AI Woo Product Generator** plugin.

---

## Table of Contents

1. [Main Plugin Class](#main-class)
2. [Controllers](#controllers)
3. [Models](#models)
4. [Code Standards](#code-standards)
5. [Best Practices](#best-practices)
6. [Development Guide](#development-guide)

---

## 1. Main Plugin Class

### Class: `AI_Woo_Product_Generator`

**File**: `ai-woo-product-generator.php`

**Description**: Main plugin class that initializes the plugin and manages dependencies.

#### Properties

```php
/**
 * Single instance of the class
 * 
 * @var AI_Woo_Product_Generator|null
 * @access private
 * @static
 */
private static $instance = null;
```

#### Methods

##### `get_instance()`

```php
/**
 * Get single instance of the plugin
 * 
 * Implements Singleton pattern to ensure only one instance exists
 * 
 * @return AI_Woo_Product_Generator The single instance
 * @static
 * @access public
 */
public static function get_instance() {
    if (null === self::$instance) {
        self::$instance = new self();
    }
    return self::$instance;
}
```

**Usage**:
```php
$plugin = AI_Woo_Product_Generator::get_instance();
```

---

##### `__construct()`

```php
/**
 * Private constructor
 * 
 * Prevents direct instantiation. Use get_instance() instead.
 * 
 * @access private
 */
private function __construct() {
    $this->load_dependencies();
    $this->init_hooks();
}
```

**Flow**:
1. Load all dependencies (Models, Controllers)
2. Initialize WordPress hooks
3. Set up plugin infrastructure

---

##### `load_dependencies()`

```php
/**
 * Load required files
 * 
 * Loads all Model and Controller classes in the correct order.
 * Logger must be loaded first as other classes depend on it.
 * 
 * @access private
 * @return void
 */
private function load_dependencies() {
    // Models - Load logger first
    require_once AIWPG_PLUGIN_DIR . 'models/class-aiwpg-logger.php';
    require_once AIWPG_PLUGIN_DIR . 'models/class-aiwpg-gemini-client.php';
    require_once AIWPG_PLUGIN_DIR . 'models/class-aiwpg-product-model.php';
    require_once AIWPG_PLUGIN_DIR . 'models/class-aiwpg-image-client.php';
    
    // Controllers
    require_once AIWPG_PLUGIN_DIR . 'controllers/class-aiwpg-admin-controller.php';
    require_once AIWPG_PLUGIN_DIR . 'controllers/class-aiwpg-products-controller.php';
    require_once AIWPG_PLUGIN_DIR . 'controllers/class-aiwpg-settings-controller.php';
    require_once AIWPG_PLUGIN_DIR . 'controllers/class-aiwpg-images-controller.php';
}
```

**Order Importance**:
- Logger must be loaded first (other classes use it)
- Models before Controllers (Controllers use Models)

---

##### `init_hooks()`

```php
/**
 * Initialize WordPress hooks
 * 
 * Registers all necessary WordPress actions and filters
 * 
 * @access private
 * @return void
 */
private function init_hooks() {
    // Activation/Deactivation
    register_activation_hook(__FILE__, array($this, 'activate'));
    register_deactivation_hook(__FILE__, array($this, 'deactivate'));
    
    // Check if WooCommerce is active
    add_action('plugins_loaded', array($this, 'check_woocommerce'));
    
    // Initialize controllers
    add_action('plugins_loaded', array($this, 'init_controllers'));
    
    // Load text domain
    add_action('plugins_loaded', array($this, 'load_textdomain'));
    
    // Register custom image size
    add_action('after_setup_theme', array($this, 'register_image_sizes'));
}
```

---

##### `activate()`

```php
/**
 * Plugin activation callback
 * 
 * Runs when plugin is activated. Sets up default options,
 * checks dependencies, and prepares the plugin for use.
 * 
 * @access public
 * @return void
 */
public function activate() {
    // Check WooCommerce dependency
    if (!class_exists('WooCommerce')) {
        deactivate_plugins(AIWPG_PLUGIN_BASENAME);
        wp_die(
            __('AI Woo Product Generator requires WooCommerce to be installed and activated.', 'ai-woo-product-generator'),
            'Plugin Activation Error',
            array('back_link' => true)
        );
    }
    
    // Set default options
    if (!get_option('aiwpg_settings')) {
        update_option('aiwpg_settings', array(
            'products_per_page' => 12,
            'default_stock_status' => 'instock',
            'auto_publish' => false,
        ));
    }
    
    // Flush rewrite rules
    flush_rewrite_rules();
}
```

**Actions**:
1. Check WooCommerce dependency
2. Create default settings
3. Flush rewrite rules

---

## 2. Controllers

### Class: `AIWPG_Products_Controller`

**File**: `controllers/class-aiwpg-products-controller.php`

**Description**: Handles all product-related AJAX operations and coordination between models and views.

#### Properties

```php
/**
 * Gemini client instance
 * 
 * @var AIWPG_Gemini_Client
 * @access private
 */
private $gemini_client;

/**
 * Product model instance
 * 
 * @var AIWPG_Product_Model
 * @access private
 */
private $product_model;

/**
 * Logger instance
 * 
 * @var AIWPG_Logger
 * @access private
 */
private $logger;
```

---

#### Methods

##### `generate_single_product()`

```php
/**
 * Generate single product from description
 * 
 * AJAX handler for generating a single product using AI.
 * Validates input, generates product data via Gemini API,
 * and returns formatted product data.
 * 
 * @access public
 * @return void Outputs JSON response
 * 
 * @example
 * // JavaScript usage:
 * $.ajax({
 *     url: ajaxurl,
 *     data: {
 *         action: 'aiwpg_generate_single',
 *         nonce: nonce,
 *         prompt: 'Wireless headphones with noise cancellation',
 *         product_type: 'automatic'
 *     }
 * });
 */
public function generate_single_product() {
    // Verify nonce
    check_ajax_referer('aiwpg_nonce', 'nonce');
    
    // Check permissions
    if (!current_user_can('manage_woocommerce')) {
        $this->logger->log('Permission denied', 'products_controller', [], 'warning');
        wp_send_json_error(['message' => __('Permission denied', 'ai-woo-product-generator')]);
    }
    
    // Sanitize input
    $prompt = isset($_POST['prompt']) ? sanitize_textarea_field($_POST['prompt']) : '';
    $product_type = isset($_POST['product_type']) ? sanitize_text_field($_POST['product_type']) : 'automatic';
    
    if (empty($prompt)) {
        $this->logger->log('Empty prompt', 'products_controller', [], 'warning');
        wp_send_json_error(['message' => __('Prompt is required', 'ai-woo-product-generator')]);
    }
    
    try {
        // Generate product
        $result = $this->gemini_client->generate_single_product($prompt, $product_type);
        
        if (is_wp_error($result)) {
            $this->logger->log(
                'Failed to generate product',
                'products_controller',
                ['error' => $result->get_error_message()],
                'error'
            );
            wp_send_json_error(['message' => $result->get_error_message()]);
        }
        
        $this->logger->log(
            'Product generated successfully',
            'products_controller',
            ['prompt_length' => strlen($prompt)],
            'info'
        );
        
        wp_send_json_success([
            'message' => __('Product generated successfully', 'ai-woo-product-generator'),
            'product' => $result
        ]);
        
    } catch (Exception $e) {
        $this->logger->log(
            'Exception in generate_single_product',
            'products_controller',
            ['exception' => $e->getMessage()],
            'error'
        );
        wp_send_json_error(['message' => __('An error occurred', 'ai-woo-product-generator')]);
    }
}
```

**Process Flow**:
1. Verify nonce (security)
2. Check user permissions
3. Sanitize input data
4. Validate required fields
5. Call Gemini client
6. Handle response
7. Log operation
8. Return JSON response

---

##### `save_products()`

```php
/**
 * Save multiple products
 * 
 * Creates multiple WooCommerce products from provided data.
 * Implements batch processing with error collection.
 * 
 * @access public
 * @return void Outputs JSON response
 * 
 * @example
 * $.ajax({
 *     url: ajaxurl,
 *     data: {
 *         action: 'aiwpg_save_products',
 *         nonce: nonce,
 *         products: JSON.stringify([
 *             {title: 'Product 1', ...},
 *             {title: 'Product 2', ...}
 *         ])
 *     }
 * });
 */
public function save_products() {
    check_ajax_referer('aiwpg_nonce', 'nonce');
    
    if (!current_user_can('manage_woocommerce')) {
        wp_send_json_error(['message' => __('Permission denied', 'ai-woo-product-generator')]);
    }
    
    $products_data = isset($_POST['products']) ? json_decode(stripslashes($_POST['products']), true) : [];
    
    if (empty($products_data)) {
        wp_send_json_error(['message' => __('Products data is required', 'ai-woo-product-generator')]);
    }
    
    $created = [];
    $errors = [];
    
    foreach ($products_data as $index => $product_data) {
        $product_id = $this->product_model->create_product($product_data);
        
        if (is_wp_error($product_id)) {
            $errors[] = sprintf(
                __('Product #%d: %s', 'ai-woo-product-generator'),
                $index + 1,
                $product_id->get_error_message()
            );
        } else {
            $created[] = $product_id;
        }
    }
    
    wp_send_json_success([
        'message' => sprintf(
            __('%d products saved successfully', 'ai-woo-product-generator'),
            count($created)
        ),
        'created' => count($created),
        'errors' => $errors
    ]);
}
```

**Features**:
- Batch processing
- Individual error collection
- Success count tracking
- Detailed error reporting

---

## 3. Models

### Class: `AIWPG_Gemini_Client`

**File**: `models/class-aiwpg-gemini-client.php`

**Description**: Handles communication with Google Gemini 2.0 Flash API with failover and rate limiting.

#### Constants

```php
/**
 * Gemini API endpoint
 * 
 * @const string
 */
private const API_ENDPOINT = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent';
```

---

#### Properties

```php
/**
 * API keys array
 * 
 * @var array Array of 5 API keys for failover
 * @access private
 */
private $api_keys = [];

/**
 * Rate limiting - max requests per minute per key
 * 
 * @var int
 * @access private
 */
private $rate_limit_per_minute = 10;

/**
 * Max retry attempts with exponential backoff
 * 
 * @var int
 * @access private
 */
private $max_retry_attempts = 3;

/**
 * Request timestamps for rate limiting
 * 
 * @var array Array of timestamp arrays, one per key
 * @access private
 */
private $request_timestamps = [];
```

---

#### Methods

##### `generate_single_product()`

```php
/**
 * Generate single product from description
 * 
 * Creates a comprehensive prompt with instructions and sends it to
 * Gemini API. Implements failover, rate limiting, and retry logic.
 * 
 * @param string $prompt User's product description
 * @param string $product_type Product type: automatic|simple|variable
 * 
 * @return array|WP_Error Product data array on success, WP_Error on failure
 * 
 * @example
 * $client = new AIWPG_Gemini_Client();
 * $result = $client->generate_single_product(
 *     'Wireless Bluetooth headphones with noise cancellation',
 *     'automatic'
 * );
 * 
 * if (!is_wp_error($result)) {
 *     echo $result['title']; // Product title
 * }
 */
public function generate_single_product($prompt, $product_type = 'automatic') {
    // Build comprehensive prompt
    $system_prompt = $this->build_single_product_prompt($prompt, $product_type);
    
    // Call API with failover
    $response = $this->call_api($system_prompt);
    
    if (is_wp_error($response)) {
        return $response;
    }
    
    // Parse and validate response
    return $this->parse_single_product_response($response, $product_type);
}
```

**Returns**:
```php
[
    'product_type' => 'simple',
    'title' => 'Product Name',
    'short_description' => '...',
    'long_description' => '...',
    'sku' => 'AIWPG-12345678',
    'regular_price' => '99.99',
    'sale_price' => '79.99',
    'stock_quantity' => 10,
    'categories' => ['Category1'],
    'tags' => ['tag1', 'tag2'],
    'brand' => 'BrandName'
]
```

---

##### `call_api()`

```php
/**
 * Call Gemini API with failover
 * 
 * Implements 5-key failover system with rate limiting and
 * exponential backoff retry. Tries each key up to 3 times
 * before moving to the next key.
 * 
 * @param string $prompt The prompt to send to API
 * 
 * @return string|WP_Error Response text on success, WP_Error on failure
 * 
 * @access private
 */
private function call_api($prompt) {
    $errors = [];
    
    // Try each API key
    for ($i = 0; $i < count($this->api_keys); $i++) {
        $key = $this->api_keys[$i];
        
        // Skip placeholder keys
        if (strpos($key, 'PLACEHOLDER') !== false) {
            $errors[] = "Key " . ($i + 1) . ": Placeholder key";
            continue;
        }
        
        // Check rate limiting
        if (!$this->check_rate_limit($i)) {
            $errors[] = "Key " . ($i + 1) . ": Rate limit exceeded";
            continue;
        }
        
        // Try with exponential backoff
        $response = $this->make_request_with_retry($key, $prompt, $i);
        
        if (!is_wp_error($response)) {
            // Success! Record timestamp
            $this->record_request($i);
            return $response;
        }
        
        $error_msg = $response->get_error_message();
        $errors[] = "Key " . ($i + 1) . ": " . $error_msg;
        
        // If 429 error, skip to next key immediately
        if (strpos($error_msg, '429') !== false) {
            continue;
        }
    }
    
    // All keys failed
    return new WP_Error(
        'all_keys_failed',
        'All Gemini API keys failed. Errors: ' . implode(' | ', $errors)
    );
}
```

**Failover Logic**:
1. Loop through 5 API keys
2. For each key:
   - Skip if placeholder
   - Check rate limit
   - Try with retry (up to 3 attempts)
   - If success → return result
   - If 429 error → skip to next key
   - Other errors → retry with backoff
3. If all fail → return error with details

---

##### `check_rate_limit()`

```php
/**
 * Check rate limit for a specific key
 * 
 * Implements sliding window rate limiting. Keeps track of
 * request timestamps and checks if key is within limit.
 * 
 * @param int $key_index Index of the API key to check
 * 
 * @return bool True if within limit, false if exceeded
 * 
 * @access private
 */
private function check_rate_limit($key_index) {
    $now = time();
    $one_minute_ago = $now - 60;
    
    // Clean old timestamps (older than 1 minute)
    $this->request_timestamps[$key_index] = array_filter(
        $this->request_timestamps[$key_index],
        function($timestamp) use ($one_minute_ago) {
            return $timestamp > $one_minute_ago;
        }
    );
    
    // Check if we're within limit (10 requests/minute)
    return count($this->request_timestamps[$key_index]) < $this->rate_limit_per_minute;
}
```

**Algorithm**:
1. Get current time
2. Remove timestamps older than 1 minute
3. Count remaining timestamps
4. Compare with limit (10)
5. Return true if under limit

---

##### `make_request_with_retry()`

```php
/**
 * Make request with exponential backoff retry
 * 
 * Attempts the request up to max_retry_attempts times.
 * Waits exponentially longer between attempts: 2^n seconds.
 * 
 * @param string $api_key API key to use
 * @param string $prompt Prompt to send
 * @param int $key_index Key index for logging
 * 
 * @return string|WP_Error Response or error
 * 
 * @access private
 */
private function make_request_with_retry($api_key, $prompt, $key_index) {
    $attempt = 0;
    $last_error = null;
    
    while ($attempt < $this->max_retry_attempts) {
        $attempt++;
        
        if ($attempt > 1) {
            // Exponential backoff
            $wait_time = pow(2, $attempt - 1);
            // Wait: 2^1=2s, 2^2=4s, 2^3=8s
            sleep($wait_time);
        }
        
        $response = $this->make_request($api_key, $prompt);
        
        if (!is_wp_error($response)) {
            return $response; // Success!
        }
        
        $last_error = $response;
        $error_msg = $response->get_error_message();
        
        // Don't retry on certain errors
        if (strpos($error_msg, '400') !== false || 
            strpos($error_msg, 'Invalid') !== false) {
            break; // Bad request
        }
        
        // Don't retry 429 - move to next key
        if (strpos($error_msg, '429') !== false) {
            break;
        }
    }
    
    return $last_error;
}
```

**Retry Strategy**:
- Attempt 1: Immediate (0s wait)
- Attempt 2: After 2 seconds
- Attempt 3: After 4 seconds (total 6s)
- Some errors (400, 429) don't retry

---

### Class: `AIWPG_Product_Model`

**File**: `models/class-aiwpg-product-model.php`

**Description**: Handles all WooCommerce product CRUD operations.

#### Methods

##### `create_product()`

```php
/**
 * Create WooCommerce product
 * 
 * Creates a simple or variable WooCommerce product from provided data.
 * Handles attributes, variations, categories, tags, and brand.
 * 
 * @param array $product_data Product data from AI generation
 * 
 * @return int|WP_Error Product ID on success, WP_Error on failure
 * 
 * @example
 * $model = new AIWPG_Product_Model();
 * $product_id = $model->create_product([
 *     'product_type' => 'simple',
 *     'title' => 'Product Name',
 *     'regular_price' => '99.99',
 *     'stock_quantity' => 10,
 *     ...
 * ]);
 */
public function create_product($product_data) {
    try {
        // Determine product type
        $product_type = $product_data['product_type'] ?? 'simple';
        $is_variable = ($product_type === 'variable' && !empty($product_data['attributes']));
        
        // Create product object
        if ($is_variable) {
            $product = new WC_Product_Variable();
        } else {
            $product = new WC_Product_Simple();
        }
        
        // Set basic data
        $product->set_name($product_data['title']);
        $product->set_description($product_data['long_description']);
        $product->set_short_description($product_data['short_description']);
        $product->set_sku($product_data['sku']);
        
        // Set prices (only for simple products)
        if (!$is_variable) {
            if (isset($product_data['regular_price'])) {
                $product->set_regular_price($product_data['regular_price']);
            }
            if (isset($product_data['sale_price'])) {
                $product->set_sale_price($product_data['sale_price']);
            }
            
            // Set stock
            $product->set_manage_stock(true);
            $product->set_stock_quantity($product_data['stock_quantity']);
            $product->set_stock_status('instock');
        }
        
        // Set status
        $product->set_status('draft'); // Default to draft for review
        
        // Save to get ID
        $product_id = $product->save();
        
        if (!$product_id) {
            return new WP_Error('create_failed', 'Failed to create product');
        }
        
        // Set taxonomies
        $this->set_categories($product_id, $product_data['categories'] ?? []);
        $this->set_tags($product_id, $product_data['tags'] ?? []);
        $this->set_brand($product_id, $product_data['brand'] ?? '');
        
        // Handle variable product
        if ($is_variable) {
            $this->create_product_attributes($product_id, $product_data['attributes']);
            if (!empty($product_data['variations'])) {
                $this->create_product_variations($product_id, $product_data['variations'], $product_data['attributes']);
            }
        }
        
        // Mark as AI-generated
        update_post_meta($product_id, self::META_KEY, time());
        
        return $product_id;
        
    } catch (Exception $e) {
        error_log('AIWPG Create Product Error: ' . $e->getMessage());
        return new WP_Error('exception', $e->getMessage());
    }
}
```

**Process**:
1. Determine product type
2. Create WooCommerce product object
3. Set basic data (name, descriptions, SKU)
4. Set prices and stock (simple only)
5. Save to get product ID
6. Set taxonomies (categories, tags, brand)
7. Create attributes and variations (variable only)
8. Mark as AI-generated
9. Return product ID

---

##### `create_product_attributes()`

```php
/**
 * Create product attributes for variable products
 * 
 * Creates WooCommerce product attributes and registers taxonomies.
 * Handles attribute creation, term creation, and product association.
 * 
 * @param int $product_id Product ID
 * @param array $attributes Attributes data from AI
 * 
 * @return void
 * 
 * @access private
 * 
 * @example
 * $attributes = [
 *     [
 *         'name' => 'Color',
 *         'options' => ['Black', 'White', 'Blue'],
 *         'visible' => true,
 *         'variation' => true
 *     ],
 *     [
 *         'name' => 'Size',
 *         'options' => ['S', 'M', 'L'],
 *         'visible' => true,
 *         'variation' => true
 *     ]
 * ];
 */
private function create_product_attributes($product_id, $attributes) {
    $product_attributes = [];
    
    foreach ($attributes as $index => $attribute_data) {
        $attribute_name = $attribute_data['name'];
        $attribute_options = $attribute_data['options'];
        
        // Create taxonomy name (pa_color, pa_size, etc.)
        $taxonomy = 'pa_' . wc_sanitize_taxonomy_name($attribute_name);
        
        // Create attribute if doesn't exist
        if (!taxonomy_exists($taxonomy)) {
            $attribute_id = wc_create_attribute([
                'name' => $attribute_name,
                'slug' => wc_sanitize_taxonomy_name($attribute_name),
                'type' => 'select',
                'order_by' => 'menu_order',
                'has_archives' => false
            ]);
            
            // Register taxonomy
            register_taxonomy($taxonomy, ['product'], [
                'hierarchical' => false,
                'label' => $attribute_name,
                'query_var' => true,
                'rewrite' => ['slug' => $taxonomy]
            ]);
        }
        
        // Add terms
        $term_ids = [];
        foreach ($attribute_options as $option) {
            $term = term_exists($option, $taxonomy);
            if (!$term) {
                $term = wp_insert_term($option, $taxonomy);
            }
            if (!is_wp_error($term)) {
                $term_ids[] = $term['term_id'];
            }
        }
        
        // Set terms for product
        wp_set_object_terms($product_id, $term_ids, $taxonomy);
        
        // Add to product attributes array
        $product_attributes[$taxonomy] = [
            'name' => $taxonomy,
            'value' => '',
            'position' => $index,
            'is_visible' => $attribute_data['visible'] ?? true,
            'is_variation' => $attribute_data['variation'] ?? true,
            'is_taxonomy' => 1
        ];
    }
    
    // Update product attributes
    update_post_meta($product_id, '_product_attributes', $product_attributes);
}
```

**Process**:
1. Loop through attributes
2. For each attribute:
   - Create taxonomy (pa_color, pa_size)
   - Register taxonomy if new
   - Create terms (Black, White, S, M, L)
   - Associate terms with product
   - Add to product attributes array
3. Save product attributes meta

---

## 4. Code Standards

### Naming Conventions

#### Classes
```php
// Format: AIWPG_ClassName
class AIWPG_Product_Model {}
class AIWPG_Gemini_Client {}
```

#### Methods
```php
// Format: snake_case
public function generate_single_product() {}
private function call_api() {}
```

#### Variables
```php
// Format: snake_case
$product_id = 123;
$gemini_client = new AIWPG_Gemini_Client();
```

#### Constants
```php
// Format: SCREAMING_SNAKE_CASE
define('AIWPG_VERSION', '1.0.0');
private const API_ENDPOINT = 'https://...';
```

---

### DocBlock Standards

#### Class DocBlock
```php
/**
 * Product Model
 * 
 * Handles WooCommerce product CRUD operations
 * 
 * @package AI_Woo_Product_Generator
 * @subpackage Models
 * @since 1.0.0
 */
class AIWPG_Product_Model {
    // ...
}
```

#### Method DocBlock
```php
/**
 * Create WooCommerce product
 * 
 * Detailed description of what the method does,
 * its behavior, and any important notes.
 * 
 * @param array $product_data Product data from AI
 * @param bool $auto_publish Whether to publish immediately
 * 
 * @return int|WP_Error Product ID on success, WP_Error on failure
 * 
 * @throws Exception If database error occurs
 * 
 * @access public
 * @since 1.0.0
 * 
 * @example
 * $model = new AIWPG_Product_Model();
 * $product_id = $model->create_product($data);
 */
public function create_product($product_data, $auto_publish = false) {
    // ...
}
```

---

### Code Style

#### Indentation
```php
// Use 4 spaces (not tabs)
if ($condition) {
    // Code here
    if ($nested_condition) {
        // Nested code
    }
}
```

#### Braces
```php
// Opening brace on same line
if ($condition) {
    // Code
}

// Function braces on same line
function my_function() {
    // Code
}
```

#### Spacing
```php
// Spaces around operators
$result = $a + $b;
$array = array('key' => 'value');

// Spaces after commas
function_call($param1, $param2, $param3);

// No spaces inside parentheses
if ($condition) {
    // Code
}
```

---

## 5. Best Practices

### Error Handling

```php
/**
 * Good error handling example
 */
public function generate_product($prompt) {
    try {
        // Validate input
        if (empty($prompt)) {
            throw new InvalidArgumentException('Prompt is required');
        }
        
        // Attempt operation
        $result = $this->gemini_client->generate($prompt);
        
        // Check for WP_Error
        if (is_wp_error($result)) {
            $this->logger->log(
                'Generation failed',
                'context',
                ['error' => $result->get_error_message()],
                'error'
            );
            return $result;
        }
        
        // Success
        return $result;
        
    } catch (Exception $e) {
        // Catch any exceptions
        $this->logger->log(
            'Exception caught',
            'context',
            [
                'exception' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ],
            'error'
        );
        
        return new WP_Error(
            'exception',
            'An unexpected error occurred: ' . $e->getMessage()
        );
    }
}
```

---

### Security

#### Nonce Verification
```php
// Always verify nonce for AJAX
check_ajax_referer('aiwpg_nonce', 'nonce');
```

#### Permission Checks
```php
// Always check user permissions
if (!current_user_can('manage_woocommerce')) {
    wp_send_json_error(['message' => 'Permission denied']);
}
```

#### Input Sanitization
```php
// Always sanitize user input
$text = sanitize_textarea_field($_POST['text']);
$id = intval($_POST['id']);
$email = sanitize_email($_POST['email']);
$url = esc_url_raw($_POST['url']);
```

#### Output Escaping
```php
// Escape output
echo esc_html($user_input);
echo esc_attr($attribute_value);
echo esc_url($url);
```

---

### Performance

#### Database Queries
```php
// Use WP_Query instead of raw SQL
$query = new WP_Query([
    'post_type' => 'product',
    'posts_per_page' => 12,
    'paged' => $page
]);

// Use transients for expensive operations
$cache_key = 'aiwpg_stats_' . $user_id;
$stats = get_transient($cache_key);

if (false === $stats) {
    $stats = $this->calculate_stats();
    set_transient($cache_key, $stats, HOUR_IN_SECONDS);
}
```

#### Minimize API Calls
```php
// Batch operations when possible
$products = $this->gemini_client->generate_multiple_products($prompts);

// Use caching
$categories = wp_cache_get('aiwpg_categories');
if (false === $categories) {
    $categories = $this->get_categories();
    wp_cache_set('aiwpg_categories', $categories, '', 3600);
}
```

---

## 6. Development Guide

### Setting Up Development Environment

```bash
# Clone repository
git clone https://github.com/your-repo/ai-woo-product-generator.git

# Create wp-content/plugins/ directory
cd /path/to/wordpress/wp-content/plugins/

# Symlink for development
ln -s /path/to/ai-woo-product-generator ai-woo-product-generator

# Enable WP_DEBUG
# In wp-config.php:
define('WP_DEBUG', true);
define('WP_DEBUG_LOG', true);
define('WP_DEBUG_DISPLAY', false);
```

---

### Adding a New Feature

#### 1. Create Model (if needed)

```php
// models/class-aiwpg-new-model.php

class AIWPG_New_Model {
    public function __construct() {
        // Initialize
    }
    
    public function do_something() {
        // Implementation
    }
}
```

#### 2. Create Controller

```php
// controllers/class-aiwpg-new-controller.php

class AIWPG_New_Controller {
    private $model;
    
    public function __construct() {
        $this->model = new AIWPG_New_Model();
        
        // Register AJAX actions
        add_action('wp_ajax_aiwpg_new_action', [$this, 'ajax_handler']);
    }
    
    public function ajax_handler() {
        check_ajax_referer('aiwpg_nonce', 'nonce');
        
        // Implementation
        
        wp_send_json_success(['result' => 'success']);
    }
}
```

#### 3. Load in Main Plugin

```php
// ai-woo-product-generator.php

private function load_dependencies() {
    // ... existing includes
    
    require_once AIWPG_PLUGIN_DIR . 'models/class-aiwpg-new-model.php';
    require_once AIWPG_PLUGIN_DIR . 'controllers/class-aiwpg-new-controller.php';
}

private function init_controllers() {
    // ... existing controllers
    
    AIWPG_New_Controller::get_instance();
}
```

#### 4. Add JavaScript

```javascript
// assets/js/aiwpg-admin.js

function initNewFeature() {
    $('.new-feature-btn').on('click', function() {
        $.ajax({
            url: aiwpgData.ajaxUrl,
            type: 'POST',
            data: {
                action: 'aiwpg_new_action',
                nonce: aiwpgData.nonce
            },
            success: function(response) {
                if (response.success) {
                    toastr.success('Feature executed!');
                }
            }
        });
    });
}

// Call in document ready
$(document).ready(function() {
    initNewFeature();
});
```

---

### Testing

#### Manual Testing Checklist

```
□ Test with valid input
□ Test with invalid input
□ Test with empty input
□ Test with special characters
□ Test with different user roles
□ Test with WooCommerce disabled
□ Test with conflicting plugins
□ Test on different browsers
□ Test responsive design
□ Test AJAX error handling
□ Test API failover
□ Check console for errors
□ Check network tab for API calls
□ Review generated logs
```

---

### Debugging

#### Enable Logging

```php
// In wp-config.php
define('WP_DEBUG', true);
define('WP_DEBUG_LOG', true);
define('WP_DEBUG_DISPLAY', false);
```

#### View Logs

```bash
# WordPress debug log
tail -f /path/to/wp-content/debug.log

# Plugin log
tail -f /path/to/wp-content/uploads/aiwpg-logs/aiwpg-*.log

# PHP error log
tail -f /var/log/php-error.log
```

#### Add Debug Logging

```php
// Temporary debug logging
error_log('AIWPG Debug: ' . print_r($variable, true));

// Plugin logging
$this->logger->log('Debug message', 'context', ['data' => $data], 'debug');
```

---

<a name="arabic"></a>
# 💻 توثيق الكود الكامل

## نظرة عامة

يوفر هذا المستند توثيقاً مفصلاً للكود لجميع الـ classes والـ methods والـ functions في إضافة **AI Woo Product Generator**.

---

## الفهرس

1. [Class الإضافة الرئيسي](#ar-main-class)
2. [المتحكمات (Controllers)](#ar-controllers)
3. [النماذج (Models)](#ar-models)
4. [معايير الكود](#ar-standards)
5. [أفضل الممارسات](#ar-practices)
6. [دليل التطوير](#ar-development)

---

<a name="ar-main-class"></a>
## 1. Class الإضافة الرئيسي

### Class: `AI_Woo_Product_Generator`

**الملف**: `ai-woo-product-generator.php`

**الوصف**: Class الإضافة الرئيسي الذي يقوم بتهيئة الإضافة وإدارة التبعيات.

#### الخصائص

```php
/**
 * نسخة واحدة من الـ class
 * 
 * @var AI_Woo_Product_Generator|null
 * @access private
 * @static
 */
private static $instance = null;
```

---

#### الأساليب (Methods)

##### `get_instance()`

```php
/**
 * الحصول على نسخة واحدة من الإضافة
 * 
 * ينفذ نمط Singleton لضمان وجود نسخة واحدة فقط
 * 
 * @return AI_Woo_Product_Generator النسخة الوحيدة
 * @static
 * @access public
 */
public static function get_instance() {
    if (null === self::$instance) {
        self::$instance = new self();
    }
    return self::$instance;
}
```

**الاستخدام**:
```php
$plugin = AI_Woo_Product_Generator::get_instance();
```

---

<a name="ar-controllers"></a>
## 2. المتحكمات (Controllers)

### Class: `AIWPG_Products_Controller`

**الملف**: `controllers/class-aiwpg-products-controller.php`

**الوصف**: يتعامل مع جميع عمليات AJAX المتعلقة بالمنتجات.

---

<a name="ar-models"></a>
## 3. النماذج (Models)

### Class: `AIWPG_Gemini_Client`

**الملف**: `models/class-aiwpg-gemini-client.php`

**الوصف**: يتعامل مع التواصل مع Google Gemini API.

#### الثوابت

```php
/**
 * نقطة نهاية Gemini API
 * 
 * @const string
 */
private const API_ENDPOINT = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent';
```

---

<a name="ar-standards"></a>
## 4. معايير الكود

### اصطلاحات التسمية

#### Classes
```php
// التنسيق: AIWPG_ClassName
class AIWPG_Product_Model {}
```

#### Methods
```php
// التنسيق: snake_case
public function generate_single_product() {}
```

---

<a name="ar-practices"></a>
## 5. أفضل الممارسات

### معالجة الأخطاء

```php
try {
    // محاولة العملية
    $result = $this->do_something();
    
    if (is_wp_error($result)) {
        // تسجيل الخطأ
        $this->logger->log('فشلت العملية', 'context', [], 'error');
        return $result;
    }
    
    return $result;
    
} catch (Exception $e) {
    // التقاط الاستثناءات
    $this->logger->log('استثناء', 'context', ['error' => $e->getMessage()], 'error');
    return new WP_Error('exception', $e->getMessage());
}
```

---

### الأمان

#### التحقق من Nonce
```php
check_ajax_referer('aiwpg_nonce', 'nonce');
```

#### التحقق من الصلاحيات
```php
if (!current_user_can('manage_woocommerce')) {
    wp_send_json_error(['message' => 'الوصول مرفوض']);
}
```

#### تنظيف المدخلات
```php
$text = sanitize_textarea_field($_POST['text']);
$id = intval($_POST['id']);
```

---

<a name="ar-development"></a>
## 6. دليل التطوير

### إعداد بيئة التطوير

```bash
# تفعيل WP_DEBUG
# في wp-config.php:
define('WP_DEBUG', true);
define('WP_DEBUG_LOG', true);
define('WP_DEBUG_DISPLAY', false);
```

---

### إضافة ميزة جديدة

#### 1. إنشاء Model

```php
// models/class-aiwpg-new-model.php
class AIWPG_New_Model {
    public function __construct() {
        // التهيئة
    }
    
    public function do_something() {
        // التنفيذ
    }
}
```

#### 2. إنشاء Controller

```php
// controllers/class-aiwpg-new-controller.php
class AIWPG_New_Controller {
    private $model;
    
    public function __construct() {
        $this->model = new AIWPG_New_Model();
        add_action('wp_ajax_aiwpg_new_action', [$this, 'ajax_handler']);
    }
    
    public function ajax_handler() {
        check_ajax_referer('aiwpg_nonce', 'nonce');
        wp_send_json_success(['result' => 'success']);
    }
}
```

---

### التصحيح (Debugging)

#### تفعيل التسجيل

```php
define('WP_DEBUG', true);
define('WP_DEBUG_LOG', true);
```

#### عرض السجلات

```bash
# سجل WordPress
tail -f /wp-content/debug.log

# سجل الإضافة
tail -f /wp-content/uploads/aiwpg-logs/aiwpg-*.log
```

---

**آخر تحديث:** يناير 2024  
**الإصدار:** 1.0.0
