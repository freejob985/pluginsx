# AI Woo Product Generator - Complete User Guide

## Overview

**AI Woo Product Generator** is an advanced WordPress plugin for automatically creating WooCommerce products using Artificial Intelligence. The plugin uses Google Gemini 2.0 Flash AI technology for content generation and Freepik AI API for image generation.

### Key Features

#### 🤖 Intelligent Product Generation
- **Three Product Types**: Automatic, Simple, Variable
- **Single Product Generation**: Enter one description and generate a complete product
- **Multiple Products Generation**: Enter multiple descriptions at once
- **Excel Import**: Upload an Excel file containing product data

#### 🎨 AI-Powered Image Generation
- **Automatic Image Generation**: Product images are automatically created based on descriptions
- **Professional Images**: 300x300 pixel images optimized for e-commerce
- **5 Backup API Keys**: Failsafe system ensures continuous operation

#### 📊 Advanced Product Management
- **Beautiful Card Interface**: Display products in a professional card grid
- **Search and Filter**: Instant search with autocomplete suggestions
- **Advanced Editing**: Modal window with 7 comprehensive sections
- **Dashboard Statistics**: Comprehensive product statistics display

#### 🔧 Advanced Technical Features
- **MVC Architecture**: Organized and maintainable code
- **Comprehensive Logging**: Log all operations and errors
- **5 Gemini API Keys**: Failsafe system with automatic switching
- **AJAX Processing**: Fast operations without page reload

---

## Requirements

### Basic Requirements
- **WordPress**: 5.8 or newer
- **PHP**: 7.4 or newer
- **WooCommerce**: Any recent version
- **MySQL**: 5.6 or newer

### Required API Keys
1. **Google Gemini API Keys** (5 keys for products)
   - Get them from: https://makersuite.google.com/app/apikey
   
2. **Freepik API Keys** (5 keys for images)
   - Get them from: https://www.freepik.com/api

---

## Installation

### Method 1: Manual Installation

1. **Upload the Plugin**
   ```bash
   # Copy the plugin folder to wp-content/plugins/
   cp -r ai-woo-product-generator /path/to/wordpress/wp-content/plugins/
   ```

2. **Configure API Keys**
   - Open file: `ai-woo-product-generator.php`
   - Edit lines 28 to 42:
   
   ```php
   // Gemini API Keys
   define('AIWPG_GEMINI_API_KEY_1', 'YOUR_KEY_HERE');
   define('AIWPG_GEMINI_API_KEY_2', 'YOUR_KEY_HERE');
   define('AIWPG_GEMINI_API_KEY_3', 'YOUR_KEY_HERE');
   define('AIWPG_GEMINI_API_KEY_4', 'YOUR_KEY_HERE');
   define('AIWPG_GEMINI_API_KEY_5', 'YOUR_KEY_HERE');
   
   // Freepik API Keys
   define('AIWPG_FREEPIK_API_KEY_1', 'YOUR_KEY_HERE');
   define('AIWPG_FREEPIK_API_KEY_2', 'YOUR_KEY_HERE');
   define('AIWPG_FREEPIK_API_KEY_3', 'YOUR_KEY_HERE');
   define('AIWPG_FREEPIK_API_KEY_4', 'YOUR_KEY_HERE');
   define('AIWPG_FREEPIK_API_KEY_5', 'YOUR_KEY_HERE');
   ```

3. **Activate the Plugin**
   - Go to: Dashboard > Plugins
   - Find "AI Woo Product Generator"
   - Click "Activate"

### Method 2: Installation via WP-CLI

```bash
# Navigate to WordPress directory
cd /path/to/wordpress

# Copy the plugin
cp -r /path/to/ai-woo-product-generator wp-content/plugins/

# Activate the plugin
wp plugin activate ai-woo-product-generator
```

---

## User Guide

### 1. Generate Single Product

#### Steps:
1. Go to: **AI Products > Generate Products**
2. Select **"Single Product"** tab
3. Choose product type:
   - **Automatic**: AI decides type based on description
   - **Simple**: Product without variations
   - **Variable**: Product with options (colors, sizes, etc.)

4. Enter product description, example:
   ```
   Premium wireless Bluetooth headphones with noise cancellation, 40-hour battery life,
   and premium sound quality. Available in three colors: Black, White, Blue, priced at $299
   ```

5. Click **"Generate Product"**
6. Wait for product preview to appear
7. Review the data and click **"Save Product"**

#### Description Examples:

**Simple Product:**
```
Smartwatch with waterproof design, AMOLED display, heart rate monitoring, 
built-in GPS system, 7-day battery life, priced at $599
```

**Variable Product:**
```
100% cotton t-shirt, available in 4 colors (Black, White, Blue, Gray)
and 5 sizes (S, M, L, XL, XXL), comfortable for daily wear, priced at $79
```

### 2. Generate Multiple Products (Textarea)

#### Steps:
1. Go to **"Multiple Products (Textarea)"** tab
2. Choose product type (Automatic/Simple/Variable)
3. Enter each product description on a separate line:
   ```
   Wireless ergonomic mouse | 50
   RGB gaming keyboard | 30
   27-inch computer monitor | 15
   ```
   
   **Format**: `Product description | Quantity (optional)`

4. Click **"Generate Products"**
5. Review all products in the table
6. Select products you want to save
7. Click **"Save Selected Products"**

#### Tips:
- You can add up to 50 products at once
- If you don't specify quantity, default value (10) will be used
- You can use "Improve Descriptions" button to enhance descriptions with AI

### 3. Generate Products from Excel

#### Preparing Excel File:

1. **Download Template**:
   - Click **"Download Excel Template"**
   - Open file in Excel or Google Sheets

2. **File Structure**:
   | Column | Description | Required? |
   |--------|------------|-----------|
   | description | Product description | ✅ Yes |
   | quantity | Available quantity | ❌ No (default: 10) |

3. **Data Example**:
   ```
   | description                                          | quantity |
   |-----------------------------------------------------|----------|
   | Gaming laptop with i7 processor and RTX 3060        | 20       |
   | Bluetooth headphones with active noise cancellation | 50       |
   | Professional digital camera 24 megapixels           | 10       |
   ```

4. **Upload File**:
   - Save file as `.xlsx` or `.xls`
   - In **"Multiple Products (Excel)"** section
   - Click **"Choose File"** and select the file
   - Click **"Upload and Generate Products"**

### 4. Product Management

#### View Products:
- Go to: **AI Products > Products List**
- You will see:
  - **Statistics Dashboard**: Total products, published, drafts, stock value
  - **Search Bar**: For instant product search
  - **Card Grid**: Display all products

#### Search and Filter:
```
💡 Tip: Search works in real-time - type and results appear instantly
```

- Type in search box
- Auto-suggest will show with 4 results
- Click any result to navigate to product

#### Edit Product:

1. **Open Edit Window**:
   - Click **"Edit"** button on product card
   - Or double-click on the card

2. **Available Sections**:

   **a. General**
   - Product name
   - Long description
   - Short description
   - SKU
   - Regular price and sale price
   - 🤖 You can use "Improve with AI" button for any field

   **b. Inventory**
   - Manage stock
   - Available quantity
   - Stock status
   - Low stock threshold
   - Sold individually

   **c. Shipping**
   - Weight
   - Dimensions (length, width, height)
   - Shipping class

   **d. Linked Products**
   - Upsell products
   - Cross-sell products

   **e. Media**
   - Main product image
   - Image gallery
   - 📸 You can generate images with AI

   **f. Variations**
   - View all product variations
   - Edit price and quantity for each variation

   **g. Settings**
   - Status (published/draft)
   - Catalog visibility
   - Featured product
   - Categories and tags

3. **Save Changes**:
   - Review all modifications
   - Click **"Save Changes"**
   - Product will be updated instantly

#### Generate Product Image:

1. On product card, click **📷 camera** icon
2. Or in edit window > Media section > "Generate Image" button
3. AI will:
   - Analyze product name and description
   - Create appropriate image prompt
   - Generate professional 300x300 image
   - Upload to media library
   - Set as featured product image

#### Delete Product:
- Click **"Delete"** button on product card
- Confirm deletion in popup message
- Product will be permanently deleted

### 5. Settings

#### General Settings:
- Go to: **AI Products > Settings**

1. **Products Per Page**: Number of products per page (1-100)
2. **Default Stock Status**: Default inventory status
3. **Auto-Publish Products**: Publish products automatically or save as drafts

#### API Keys Status:
- You can review status of all 10 API keys
- ✅ Configured: Key is configured and ready
- ⚠️ Not Configured: Key is not configured

#### Danger Zone:

**Delete AI-Generated Products:**
- Deletes only products created by this plugin
- Safe - won't delete other products

**Delete ALL WooCommerce Products:**
- ⚠️ Warning: Deletes all products in store
- Requires typing "DELETE" to confirm
- Cannot be undone

---

## Advanced Features

### 1. API Failover System

The plugin uses 10 API keys with automatic switching:

```
📊 How the System Works:
1. Starts with Key #1
2. If it fails (rate limit/error) → switches to Key #2
3. If #2 fails → switches to Key #3
... and so on
4. If all keys fail → shows detailed error message
```

**System Benefits:**
- ✅ Very high success rate
- ✅ No service interruption
- ✅ Detailed error logging
- ✅ Automatic retry with Exponential Backoff

### 2. Logging System

**Log Files Location:**
```
/wp-content/uploads/aiwpg-logs/
├── aiwpg-2024-01-15.log
├── aiwpg-2024-01-15.log.12345.bak
└── .htaccess (file protection)
```

**Logging Levels:**
- `ERROR`: Critical errors
- `WARNING`: Warnings
- `INFO`: General information
- `DEBUG`: Development details

**Log Example:**
```
[2024-01-15 14:30:45] [ERROR] [products_controller] [admin] [ID:1] 
Failed to generate product | Data: {"prompt": "test"} | 
Trace: AIWPG_Products_Controller::generate_single_product() in class-aiwpg-products-controller.php:99
```

**Log Management:**
- Automatic rotation at 5MB
- Keep last 10 backups
- Protected from direct access

### 3. MVC Architecture

```
ai-woo-product-generator/
├── models/           (Business logic and data)
│   ├── AIWPG_Gemini_Client      → Gemini API communication
│   ├── AIWPG_Image_Client       → Freepik API communication
│   ├── AIWPG_Product_Model      → Product CRUD operations
│   └── AIWPG_Logger             → Logging system
├── controllers/      (Request and command handling)
│   ├── AIWPG_Admin_Controller   → Menus and pages
│   ├── AIWPG_Products_Controller → Product AJAX operations
│   ├── AIWPG_Images_Controller  → Image generation
│   └── AIWPG_Settings_Controller → Settings
└── views/            (User interface)
    ├── admin-ai-generator-page.php
    ├── admin-products-list-page.php
    └── admin-settings-page.php
```

**Architecture Benefits:**
- ✅ Organized and readable code
- ✅ Easy maintenance and development
- ✅ Reusability
- ✅ Separation of concerns

### 4. Advanced AJAX System

**Available AJAX Operations:**

```javascript
// Generate single product
wp_ajax_aiwpg_generate_single

// Generate multiple products
wp_ajax_aiwpg_generate_multiple

// Generate from Excel
wp_ajax_aiwpg_generate_excel

// Save product
wp_ajax_aiwpg_save_product

// Update product
wp_ajax_aiwpg_update_product

// Delete product
wp_ajax_aiwpg_delete_product

// Generate image
wp_ajax_aiwpg_generate_product_image

// Improve text with AI
wp_ajax_aiwpg_improve_field

// Get products
wp_ajax_aiwpg_get_products

// Search products
wp_ajax_aiwpg_search_products

// Statistics
wp_ajax_aiwpg_get_statistics
```

**Error Handling:**
```javascript
// Error handling example
$.ajax({
    // ... AJAX settings
    error: function(xhr, status, error) {
        // User message
        toastr.error('Operation failed: ' + error);
        
        // Console logging
        console.error('AJAX Error:', {
            status: status,
            error: error,
            response: xhr.responseText
        });
    }
});
```

### 5. Variable Products Generation

**How it Works:**

1. **Automatic Detection**:
   ```php
   // If description contains:
   "Available in 3 colors and multiple sizes"
   
   // AI does:
   - Create "Color" attribute with 3 options
   - Create "Size" attribute with multiple sizes
   - Generate all variations (Color × Size)
   ```

2. **Create Attributes**:
   ```php
   // Attribute example
   {
       "name": "Color",
       "options": ["Black", "White", "Blue"],
       "visible": true,
       "variation": true
   }
   ```

3. **Create Variations**:
   ```php
   // Variation example
   {
       "attributes": {"Color": "Black", "Size": "M"},
       "sku": "SHIRT-BLK-M",
       "regular_price": "79.99",
       "sale_price": "59.99",
       "stock_quantity": 10
   }
   ```

**Best Practices:**
- ✅ Mention attributes clearly in description
- ✅ Specify number of options for each attribute
- ✅ Mention price (will apply to all variations)

### 6. Advanced User Interface

**Components:**

1. **Modal Windows**:
   - Smooth modals with CSS3 effects
   - Click outside to close
   - Fullscreen button for editing
   - Navigate between products (Previous/Next)

2. **Autocomplete Search**:
   - Instant search without pressing Enter
   - Display 4 results with images
   - 300ms delay for better performance
   - Highlight matching text

3. **Toast Notifications**:
   - Beautiful non-intrusive notifications
   - 4 types: Success, Error, Warning, Info
   - Automatic progress bar
   - Close button

4. **Statistics Dashboard**:
   - Colored cards with icons
   - Automatic update on page load
   - Formatted values display
   - Smooth animations

---

## Troubleshooting

### Issue: Products Not Being Generated

**Possible Causes:**

1. **Incorrect API Keys**
   ```
   ✓ Solution: Check keys in ai-woo-product-generator.php
   ✓ Ensure no spaces before or after the key
   ✓ Verify keys haven't expired
   ```

2. **API Rate Limit Reached**
   ```
   ✓ Solution: Wait for limit reset
   ✓ Add additional API keys
   ✓ Review logs in /wp-content/uploads/aiwpg-logs/
   ```

3. **Internet Connection Issue**
   ```
   ✓ Solution: Check server internet connection
   ✓ Check Firewall settings
   ```

### Issue: Images Not Being Generated

**Possible Causes:**

1. **Incorrect Freepik API Keys**
   ```
   ✓ Solution: Check AIWPG_FREEPIK_API_KEY_* keys
   ✓ Ensure API is activated in your Freepik account
   ```

2. **Generation Timeout**
   ```
   ✓ Solution: Increase PHP timeout value
   ✓ In wp-config.php add:
   set_time_limit(300);
   ```

3. **Write Permission Issue**
   ```
   ✓ Solution: Check /wp-content/uploads/ permissions
   chmod 755 /wp-content/uploads/
   ```

### Issue: White Screen or 500 Error

**Solution:**

1. **Enable Debugging**:
   ```php
   // In wp-config.php
   define('WP_DEBUG', true);
   define('WP_DEBUG_LOG', true);
   define('WP_DEBUG_DISPLAY', false);
   ```

2. **Review Error Logs**:
   ```bash
   # PHP log
   tail -f /path/to/php-error.log
   
   # WordPress log
   tail -f /wp-content/debug.log
   
   # Plugin log
   tail -f /wp-content/uploads/aiwpg-logs/aiwpg-*.log
   ```

3. **Check PHP Requirements**:
   ```bash
   php -v  # Should be 7.4 or newer
   php -m  # Check JSON, cURL extensions installed
   ```

### Issue: Slow Performance

**Solutions:**

1. **Optimize Database**:
   ```sql
   OPTIMIZE TABLE wp_posts;
   OPTIMIZE TABLE wp_postmeta;
   ```

2. **Enable Caching**:
   - Use cache plugin like WP Super Cache
   - Enable Object Cache
   - Use Redis or Memcached

3. **Increase PHP Resources**:
   ```ini
   # In php.ini
   memory_limit = 256M
   max_execution_time = 300
   max_input_time = 300
   ```

---

## Security and Privacy

### Protect API Keys

**Don't share your API keys:**
```php
// ❌ Don't do this:
echo AIWPG_GEMINI_API_KEY_1;

// ✅ Do this:
// Keep keys in main file only
// Use .gitignore if using Git
```

### Protect Logs

```apache
# .htaccess file automatically created in /aiwpg-logs/
deny from all
```

### User Permissions

Only users with `manage_woocommerce` capability can:
- Generate products
- Edit products
- Delete products
- Access settings

---

## Frequently Asked Questions (FAQ)

### Q: Can I use only one API key?
**A:** Yes, but it's recommended to use 5 keys to ensure no interruption when rate limit is reached.

### Q: How many products can I generate?
**A:** There's no limit in the plugin, but the limit depends on:
- Google Gemini API limits (60 requests/minute per free key)
- Freepik API limits
- Your server resources

### Q: Does the plugin support other languages?
**A:** Yes! The plugin supports any language. Just write the description in the language you want.

### Q: How do I update the plugin?
**A:** 
1. Backup API keys
2. Delete old folder
3. Upload new version
4. Re-enter API keys
5. Activate plugin

### Q: Can I customize AI Prompts?
**A:** Yes! You can modify prompts in:
```
models/class-aiwpg-gemini-client.php
- Lines 193-346: build_single_product_prompt()
- Lines 355-456: build_multi_product_prompt()
```

### Q: Are generated images copyrighted?
**A:** It depends on Freepik API terms. Review their terms of use.

---

## Support and Contribution

### Getting Help

1. **Review this guide first**
2. **Check logs**: `/wp-content/uploads/aiwpg-logs/`
3. **Enable WP_DEBUG** and review errors

### Bug Reports

When reporting a bug, include:
- WordPress and PHP version
- Complete error message
- Relevant log content
- Steps to reproduce the issue

---

## License

This plugin is licensed under GPL v2 or later.

```
AI Woo Product Generator
Copyright (C) 2024

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
```

---

## Changelog

### Version 1.0.0 (Current)
- ✅ Generate simple and variable products
- ✅ AI-powered image generation
- ✅ Advanced management interface
- ✅ API failover system
- ✅ Comprehensive logging
- ✅ Excel import
- ✅ Complete MVC architecture

---

## Acknowledgments

- **Google Gemini**: For providing powerful AI API
- **Freepik**: For providing Image Generation API
- **WooCommerce**: For the excellent e-commerce platform
- **WordPress**: For the flexible framework

---

**Last Updated:** January 2024  
**Version:** 1.0.0  
**Author:** AI Woo Product Generator Team
