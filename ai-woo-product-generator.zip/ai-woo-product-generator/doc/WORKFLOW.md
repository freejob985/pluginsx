# Workflow Documentation | توثيق سير العمل

[English](#english) | [العربية](#arabic)

---

<a name="english"></a>
# 🔄 Complete Workflow Documentation

## Overview

This document explains all workflows and processes in the **AI Woo Product Generator** plugin, from user interaction to database storage.

---

## Table of Contents

1. [Plugin Initialization](#plugin-initialization)
2. [Single Product Generation](#single-product-generation)
3. [Multiple Products Generation](#multiple-products-generation)
4. [Excel Import](#excel-import)
5. [Product Management](#product-management)
6. [Image Generation](#image-generation)
7. [AI Improvement](#ai-improvement)
8. [Search and Filter](#search-and-filter)
9. [API Failover System](#api-failover-system)
10. [Error Handling](#error-handling)

---

## 1. Plugin Initialization

### Workflow Diagram

```
WordPress Load
    ↓
Load ai-woo-product-generator.php
    ↓
Define Constants & API Keys
    ↓
Load Dependencies (Models, Controllers, Views)
    ↓
Register Activation Hook
    ↓
Register Deactivation Hook
    ↓
Check WooCommerce Dependency
    ↓
Initialize Controllers
    ├─> AIWPG_Admin_Controller
    ├─> AIWPG_Products_Controller
    ├─> AIWPG_Images_Controller
    └─> AIWPG_Settings_Controller
    ↓
Register Hooks & Actions
    ├─> admin_menu (Create menu)
    ├─> admin_enqueue_scripts (Load assets)
    └─> wp_ajax_* (Register AJAX endpoints)
    ↓
Plugin Ready ✓
```

### Detailed Steps

#### Step 1: Load Main File
```php
// WordPress includes plugin
require_once ABSPATH . 'wp-content/plugins/ai-woo-product-generator/ai-woo-product-generator.php';
```

#### Step 2: Define Constants
```php
define('AIWPG_VERSION', '1.0.0');
define('AIWPG_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('AIWPG_PLUGIN_URL', plugin_dir_url(__FILE__));
define('AIWPG_PLUGIN_BASENAME', plugin_basename(__FILE__));
```

#### Step 3: Define API Keys
```php
// Gemini Keys (5 keys for failover)
define('AIWPG_GEMINI_API_KEY_1', 'YOUR_KEY_HERE');
// ... through KEY_5

// Freepik Keys (5 keys for failover)
define('AIWPG_FREEPIK_API_KEY_1', 'YOUR_KEY_HERE');
// ... through KEY_5
```

#### Step 4: Initialize Plugin Class
```php
class AI_Woo_Product_Generator {
    private static $instance = null;
    
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        $this->load_dependencies();
        $this->init_hooks();
    }
}

// Start plugin
aiwpg_init();
```

#### Step 5: Load Dependencies
```php
private function load_dependencies() {
    // Models (in order)
    require_once 'models/class-aiwpg-logger.php';
    require_once 'models/class-aiwpg-gemini-client.php';
    require_once 'models/class-aiwpg-product-model.php';
    require_once 'models/class-aiwpg-image-client.php';
    
    // Controllers
    require_once 'controllers/class-aiwpg-admin-controller.php';
    require_once 'controllers/class-aiwpg-products-controller.php';
    require_once 'controllers/class-aiwpg-settings-controller.php';
    require_once 'controllers/class-aiwpg-images-controller.php';
}
```

#### Step 6: Initialize Controllers
```php
public function init_controllers() {
    if (class_exists('WooCommerce')) {
        AIWPG_Admin_Controller::get_instance();
        AIWPG_Products_Controller::get_instance();
        AIWPG_Settings_Controller::get_instance();
        AIWPG_Images_Controller::get_instance();
    }
}
```

---

## 2. Single Product Generation

### Complete Workflow

```
User Interface
    ↓
User enters description
    ↓
User selects product type (Automatic/Simple/Variable)
    ↓
User clicks "Generate Product"
    ↓
JavaScript (aiwpg-admin.js)
    ├─> Validate input
    ├─> Show loading spinner
    └─> Send AJAX request
        ↓
        POST /wp-admin/admin-ajax.php
        action: aiwpg_generate_single
        nonce: security_token
        prompt: product_description
        product_type: automatic/simple/variable
            ↓
            AIWPG_Products_Controller::generate_single_product()
                ├─> Verify nonce
                ├─> Check permissions
                ├─> Sanitize input
                └─> Call Gemini Client
                    ↓
                    AIWPG_Gemini_Client::generate_single_product()
                        ├─> Build comprehensive prompt
                        │   ├─> User description
                        │   ├─> Existing categories
                        │   ├─> Existing brands
                        │   ├─> Product type instructions
                        │   └─> JSON structure
                        ├─> Call API with failover
                        │   ├─> Try Key #1
                        │   │   ├─> Check rate limit
                        │   │   ├─> Make request
                        │   │   └─> If fails → Try Key #2
                        │   ├─> Try Key #2
                        │   │   └─> If fails → Try Key #3
                        │   └─> ... up to Key #5
                        ├─> Parse JSON response
                        │   ├─> Clean markdown code blocks
                        │   ├─> Validate required fields
                        │   └─> Set defaults
                        └─> Return product data
                            ↓
                            {
                                "product_type": "variable",
                                "title": "Product Name",
                                "short_description": "...",
                                "long_description": "...",
                                "sku": "AIWPG-12345678",
                                "regular_price": "99.99",
                                "sale_price": "79.99",
                                "stock_quantity": 10,
                                "categories": ["Category1"],
                                "tags": ["tag1", "tag2"],
                                "brand": "Brand Name",
                                "attributes": [...],
                                "variations": [...]
                            }
                            ↓
                    Return to Controller
                        ↓
                        Log success
                        ↓
                        wp_send_json_success(['product' => $result])
                            ↓
                        AJAX Response to JavaScript
                            ↓
                            JavaScript receives response
                                ├─> Hide loading spinner
                                ├─> Render preview card
                                │   ├─> Display title
                                │   ├─> Display descriptions
                                │   ├─> Display price
                                │   ├─> Display categories
                                │   └─> Display attributes/variations
                                └─> Show "Save Product" button
                                    ↓
                                    User clicks "Save Product"
                                        ↓
                                        Send AJAX to save
                                            ↓
                                            AIWPG_Products_Controller::save_product()
                                                ↓
                                                AIWPG_Product_Model::create_product()
                                                    ├─> Determine product type
                                                    ├─> Create WC_Product object
                                                    ├─> Set basic data
                                                    ├─> Set prices
                                                    ├─> Set stock
                                                    ├─> Save → get product_id
                                                    ├─> Set categories
                                                    ├─> Set tags
                                                    ├─> Set brand
                                                    ├─> Create attributes (if variable)
                                                    ├─> Create variations (if variable)
                                                    └─> Mark as AI-generated
                                                        ↓
                                                        Return product_id
                                                            ↓
                                                        Show success notification
                                                            ↓
                                                        Product Created ✓
```

### Timing Analysis

| Step | Average Time | Max Time |
|------|-------------|----------|
| User input | 30 seconds | - |
| AJAX request | 50ms | 200ms |
| Gemini API call | 3-8 seconds | 15 seconds |
| Parse response | 100ms | 500ms |
| Save to database | 200ms | 1 second |
| **Total** | **4-9 seconds** | **17 seconds** |

---

## 3. Multiple Products Generation

### Workflow Diagram

```
User Interface
    ↓
User enters multiple descriptions (one per line)
Example:
    Wireless Mouse | 50
    Gaming Keyboard | 30
    Monitor 27" | 15
    ↓
User selects product type
    ↓
User clicks "Generate Products"
    ↓
JavaScript
    ├─> Parse lines
    ├─> Extract descriptions and quantities
    │   ["Wireless Mouse", 50]
    │   ["Gaming Keyboard", 30]
    │   ["Monitor 27\"", 15]
    └─> Send AJAX request
        ↓
        POST /wp-admin/admin-ajax.php
        action: aiwpg_generate_multiple
        prompts: [descriptions_array]
        product_type: automatic/simple/variable
            ↓
            AIWPG_Products_Controller::generate_multiple_products()
                ├─> Parse prompts
                ├─> Validate format
                └─> Call Gemini Client
                    ↓
                    AIWPG_Gemini_Client::generate_multiple_products()
                        ├─> Build comprehensive prompt
                        │   Product List:
                        │   1. Description: Wireless Mouse | Quantity: 50
                        │   2. Description: Gaming Keyboard | Quantity: 30
                        │   3. Description: Monitor 27" | Quantity: 15
                        │   
                        │   Instructions: Generate JSON array with all products
                        ├─> Call API with failover
                        ├─> Parse JSON response
                        │   {
                        │       "products": [
                        │           {product_1_data},
                        │           {product_2_data},
                        │           {product_3_data}
                        │       ]
                        │   }
                        └─> Return products array
                            ↓
                    Return to Controller
                        ↓
                        wp_send_json_success(['products' => $results])
                            ↓
                        JavaScript receives response
                            ├─> Hide loading
                            ├─> Render preview table
                            │   ┌────────────────────────────────────┐
                            │   │ ☑ | Title | Description | Price │
                            │   ├────────────────────────────────────┤
                            │   │ ☑ | Wireless Mouse | ... | $29  │
                            │   │ ☑ | Gaming Keyboard | ... | $59 │
                            │   │ ☑ | Monitor 27" | ... | $299   │
                            │   └────────────────────────────────────┘
                            └─> Show "Save Selected Products"
                                ↓
                                User selects products
                                    ↓
                                    User clicks "Save Selected"
                                        ↓
                                        Send AJAX to save multiple
                                            ↓
                                            AIWPG_Products_Controller::save_products()
                                                ↓
                                                Loop through selected products
                                                    ├─> Create product 1
                                                    ├─> Create product 2
                                                    └─> Create product 3
                                                        ↓
                                                        Return results
                                                            ├─> Created: 3
                                                            └─> Errors: []
                                                                ↓
                                                            Show success notification
                                                                ↓
                                                            Products Created ✓
```

### Batch Processing

```php
// Controller method
public function save_products() {
    $products_data = json_decode(stripslashes($_POST['products']), true);
    
    $created = [];
    $errors = [];
    
    foreach ($products_data as $index => $product_data) {
        $product_id = $this->product_model->create_product($product_data);
        
        if (is_wp_error($product_id)) {
            $errors[] = sprintf('Product #%d: %s', $index + 1, $product_id->get_error_message());
        } else {
            $created[] = $product_id;
        }
    }
    
    wp_send_json_success([
        'message' => sprintf('%d products saved successfully', count($created)),
        'created' => count($created),
        'errors' => $errors
    ]);
}
```

---

## 4. Excel Import

### Complete Workflow

```
User Interface
    ↓
User clicks "Download Excel Template"
    ↓
JavaScript generates template
    ├─> Create XLSX file
    │   Column A: description
    │   Column B: quantity
    └─> Trigger download
        ↓
        User fills template
            | description                    | quantity |
            |-------------------------------|----------|
            | Wireless Bluetooth headphones | 50       |
            | Smart watch fitness tracker   | 30       |
            | USB-C charging cable          | 100      |
            ↓
            User uploads filled file
                ↓
                <input type="file" accept=".xlsx,.xls">
                    ↓
                    JavaScript reads file
                        ├─> Use SheetJS (XLSX library)
                        ├─> Parse worksheet
                        └─> Extract data
                            [
                                {description: "...", quantity: 50},
                                {description: "...", quantity: 30},
                                {description: "...", quantity: 100}
                            ]
                            ↓
                        Validate data
                            ├─> Check required columns
                            ├─> Validate data types
                            └─> Remove empty rows
                                ↓
                            Send AJAX request
                                ↓
                                POST /wp-admin/admin-ajax.php
                                action: aiwpg_generate_excel
                                products_data: [parsed_data]
                                    ↓
                                    (Same as Multiple Products Generation)
                                    ↓
                                    Generate → Preview → Save
```

### Excel Template Structure

```javascript
function downloadExcelTemplate() {
    // Create workbook
    const wb = XLSX.utils.book_new();
    
    // Create worksheet data
    const ws_data = [
        ['description', 'quantity'], // Header
        ['Wireless Mouse with ergonomic design', '25'], // Example 1
        ['USB-C charging cable 2 meters', '50'], // Example 2
        ['Gaming keyboard with RGB lighting', '15'] // Example 3
    ];
    
    // Create worksheet
    const ws = XLSX.utils.aoa_to_sheet(ws_data);
    
    // Set column widths
    ws['!cols'] = [
        {wch: 50}, // description column
        {wch: 10}  // quantity column
    ];
    
    // Add worksheet to workbook
    XLSX.utils.book_append_sheet(wb, ws, 'Products');
    
    // Generate file
    XLSX.writeFile(wb, 'aiwpg-products-template.xlsx');
}
```

---

## 5. Product Management

### View Products Workflow

```
User navigates to Products List
    ↓
Page load → JavaScript
    ├─> Load statistics
    │   ↓
    │   AJAX: aiwpg_get_statistics
    │   ↓
    │   Return:
    │   {
    │       total: 150,
    │       published: 120,
    │       drafts: 30,
    │       stock_value: 45000,
    │       out_of_stock: 5
    │   }
    │   ↓
    │   Update dashboard cards
    │
    └─> Load products (page 1)
        ↓
        AJAX: aiwpg_get_products
        page: 1
        per_page: 12
        ↓
        Query database
        ↓
        Return:
        {
            products: [
                {id, title, price, image_url, ...},
                {id, title, price, image_url, ...},
                ...
            ],
            total: 150,
            pages: 13,
            current_page: 1
        }
        ↓
        Render product cards
            ┌─────────────┬─────────────┬─────────────┐
            │  Product 1  │  Product 2  │  Product 3  │
            │  [Image]    │  [Image]    │  [Image]    │
            │  $99.99     │  $79.99     │  $149.99    │
            │  [Edit]     │  [Edit]     │  [Edit]     │
            │  [Delete]   │  [Delete]   │  [Delete]   │
            └─────────────┴─────────────┴─────────────┘
        ↓
        Render pagination
            « Previous | 1 | 2 | 3 | ... | 13 | Next »
```

### Edit Product Workflow

```
User clicks "Edit" button
    ↓
JavaScript opens modal
    ├─> Show loading
    └─> AJAX: aiwpg_get_product
        product_id: 123
            ↓
            Load complete product data
            {
                id: 123,
                title: "Product Name",
                short_description: "...",
                long_description: "...",
                sku: "AIWPG-12345",
                regular_price: "99.99",
                sale_price: "79.99",
                stock_quantity: 50,
                categories: ["Electronics"],
                tags: ["wireless", "bluetooth"],
                variations: [...],
                ...
            }
            ↓
            Populate form fields
                ├─> General tab
                ├─> Inventory tab
                ├─> Shipping tab
                ├─> Linked tab
                ├─> Media tab
                ├─> Variations tab
                └─> Settings tab
                    ↓
                    Show modal
                        ↓
                        User edits fields
                            ├─> Can use AI improvement
                            ├─> Can change tabs
                            └─> Can navigate prev/next
                                ↓
                                User clicks "Save Changes"
                                    ↓
                                    Collect form data
                                        ↓
                                        AJAX: aiwpg_update_product
                                        product_id: 123
                                        product: {updated_data}
                                            ↓
                                            AIWPG_Product_Model::update_product()
                                                ├─> Load product
                                                ├─> Update fields
                                                ├─> Save product
                                                └─> Update taxonomies
                                                    ↓
                                                    Return success
                                                        ↓
                                                    Show notification
                                                        ↓
                                                    Reload product card
                                                        ↓
                                                    Product Updated ✓
```

### Delete Product Workflow

```
User clicks "Delete" button
    ↓
SweetAlert2 confirmation
    ┌──────────────────────────────────┐
    │   Are you sure you want to      │
    │   delete this product?           │
    │                                  │
    │   This action cannot be undone   │
    │                                  │
    │   [Cancel]    [Yes, delete it!] │
    └──────────────────────────────────┘
    ↓
User clicks "Yes, delete it!"
    ↓
    AJAX: aiwpg_delete_product
    product_id: 123
        ↓
        AIWPG_Product_Model::delete_product()
            ├─> Load product
            ├─> Delete product (force = true)
            └─> Delete variations
            └─> Delete meta data
                ↓
                Return success
                    ↓
                Remove card from UI (fade out)
                    ↓
                Show success notification
                    ↓
                Update statistics
                    ↓
                Product Deleted ✓
```

---

## 6. Image Generation

### Complete Workflow

```
User clicks "Generate Image" button (📷)
    ↓
JavaScript sends AJAX request
    ↓
    POST /wp-admin/admin-ajax.php
    action: aiwpg_generate_product_image
    product_id: 123
        ↓
        AIWPG_Images_Controller::ajax_generate_product_image()
            ├─> Verify nonce
            ├─> Check permissions
            ├─> Get product details
            │   ├─> Product name
            │   ├─> Product description
            │   └─> Product categories
            └─> Call Image Client
                ↓
                AIWPG_Image_Client::generate_product_image()
                    ├─> Build AI prompt
                    │   "High-quality professional product photography 
                    │    thumbnail of {product_name}, showing {description},
                    │    category: {categories}, clean white background,
                    │    well-lit, commercial product shot, centered 
                    │    composition, square format, photorealistic,
                    │    optimized for 300x300 pixels"
                    │
                    ├─> Try with failover
                    │   ├─> Try Freepik Key #1
                    │   │   ├─> Send generation request
                    │   │   ├─> Get task_id
                    │   │   ├─> Poll for completion
                    │   │   │   ├─> Check status every 3 seconds
                    │   │   │   ├─> Max 60 attempts (180 seconds)
                    │   │   │   └─> Status: CREATED → PROCESSING → COMPLETED
                    │   │   └─> Get image URL
                    │   │       ↓
                    │   │       If fails → Try Key #2
                    │   ├─> Try Freepik Key #2
                    │   │   └─> If fails → Try Key #3
                    │   └─> ... up to Key #5
                    │
                    ├─> Download generated image
                    │   HTTP GET: image_url
                    │   ↓
                    │   image_data (binary)
                    │
                    ├─> Upload to WordPress
                    │   ├─> Save to /wp-content/uploads/
                    │   ├─> Create attachment post
                    │   ├─> Generate metadata
                    │   └─> Create 300x300 thumbnail
                    │       ├─> Use WP image editor
                    │       ├─> Resize with hard crop
                    │       └─> Save as 'aiwpg_product_thumbnail'
                    │
                    └─> Return result
                        {
                            success: true,
                            attachment_id: 456,
                            url: "https://.../image.jpg",
                            thumbnail_url: "https://.../image-300x300.jpg"
                        }
                        ↓
                Return to Controller
                    ├─> Set as featured image
                    │   set_post_thumbnail(product_id, attachment_id)
                    └─> Return response
                        ↓
                        JavaScript receives response
                            ├─> Update card image
                            ├─> Show success notification
                            └─> Image Generated ✓
```

### Image Generation States

```
State Machine:

IDLE
  ↓ User clicks button
REQUESTING
  ↓ API request sent
CREATED (task created)
  ↓ Polling started
PROCESSING (AI generating image)
  ↓ Continue polling
COMPLETED (image ready)
  ↓ Download image
UPLOADING (to WordPress)
  ↓ Create thumbnails
SUCCESS ✓

Error states:
  FAILED (generation failed)
  TIMEOUT (max polling reached)
  ERROR (API error)
```

---

## 7. AI Improvement

### Improve Description Workflow

```
User clicks "Improve with AI" button (🤖)
    ↓
JavaScript
    ├─> Get current field value
    ├─> Show loading indicator on button
    └─> Send AJAX request
        ↓
        POST /wp-admin/admin-ajax.php
        action: aiwpg_improve_field
        text: current_field_value
        field_name: "product_description"
            ↓
            AIWPG_Products_Controller::improve_field()
                ├─> Build improvement prompt
                │   "Improve and enhance the following 
                │    {field_name} text. Make it more 
                │    professional, detailed, and appealing 
                │    while keeping the original meaning. 
                │    Add missing details if needed:
                │    
                │    {current_text}"
                │
                └─> Call Gemini Client
                    ↓
                    AIWPG_Gemini_Client::generate_text()
                        ├─> Call API with failover
                        ├─> Get improved text
                        └─> Return result
                            ↓
                        Return to Controller
                            ↓
                            wp_send_json_success([
                                'improved_text' => $result
                            ])
                                ↓
                            JavaScript receives response
                                ├─> Hide loading indicator
                                ├─> Replace field value
                                ├─> Show success notification
                                │   "Text improved successfully"
                                └─> Text Improved ✓
```

### Comparison Example

**Original Text:**
```
Wireless headphones with noise cancellation
```

**Improved Text:**
```
Premium Wireless Bluetooth Headphones with Advanced Active Noise Cancellation

Experience superior audio quality with our state-of-the-art wireless Bluetooth 
headphones featuring industry-leading active noise cancellation (ANC) technology. 
These headphones deliver crystal-clear sound while effectively blocking ambient 
noise, allowing you to immerse yourself in your favorite music, podcasts, or 
calls without distractions.

Key Features:
• Advanced Bluetooth 5.0 connectivity for stable, lag-free audio
• Active Noise Cancellation (ANC) with ambient sound mode
• Premium 40mm drivers for rich, detailed sound
• Comfortable over-ear design with memory foam cushions
• Up to 40 hours of battery life on a single charge
• Quick charge: 10 minutes = 5 hours of playback
• Built-in microphone for hands-free calls
• Foldable design with premium carrying case

Perfect for:
✓ Daily commutes and travel
✓ Work-from-home professionals
✓ Audiophiles and music enthusiasts
✓ Content creators and podcasters
```

---

## 8. Search and Filter

### Real-time Search Workflow

```
User types in search box
    ↓
Input event triggered
    ↓
JavaScript
    ├─> Cancel previous search (if typing)
    ├─> Wait 300ms (debounce)
    └─> Send AJAX request
        ↓
        POST /wp-admin/admin-ajax.php
        action: aiwpg_search_products
        search: "wireless"
            ↓
            AIWPG_Products_Controller::search_products()
                ↓
                AIWPG_Product_Model::search_products()
                    ├─> WP_Query with search term
                    ├─> Limit to 4 results
                    └─> Return products
                        ↓
                    Return results
                        [
                            {id, title, image_url, price},
                            {id, title, image_url, price},
                            {id, title, image_url, price},
                            {id, title, image_url, price}
                        ]
                        ↓
                    JavaScript renders autocomplete
                        ┌──────────────────────────────────┐
                        │ Search: wireless                 │
                        ├──────────────────────────────────┤
                        │ [img] Wireless Mouse       $29   │
                        │ [img] Wireless Keyboard    $59   │
                        │ [img] Wireless Headphones  $99   │
                        │ [img] Wireless Charger     $19   │
                        └──────────────────────────────────┘
                        ↓
                    User clicks result
                        ↓
                        Scroll to product card
                            ↓
                            Highlight card (pulse animation)
                                ↓
                            Search Complete ✓
```

### Debounce Implementation

```javascript
let searchTimeout = null;

$('#product-search').on('input', function() {
    const searchTerm = $(this).val();
    
    // Clear previous timeout
    clearTimeout(searchTimeout);
    
    // If empty, hide autocomplete
    if (searchTerm.length === 0) {
        $('#autocomplete-results').hide();
        return;
    }
    
    // Wait 300ms before searching
    searchTimeout = setTimeout(function() {
        performSearch(searchTerm);
    }, 300);
});

function performSearch(term) {
    $.ajax({
        url: aiwpgData.ajaxUrl,
        type: 'POST',
        data: {
            action: 'aiwpg_search_products',
            nonce: aiwpgData.nonce,
            search: term
        },
        success: function(response) {
            if (response.success) {
                renderAutocomplete(response.data.products);
            }
        }
    });
}
```

---

## 9. API Failover System

### Failover Flow Diagram

```
Request to Generate Product
    ↓
AIWPG_Gemini_Client::call_api($prompt)
    ↓
    ┌──────────────────────────────────────┐
    │ Try Key #1                           │
    ├──────────────────────────────────────┤
    │ 1. Check if placeholder key          │
    │    ├─> Yes: Skip to Key #2          │
    │    └─> No: Continue                 │
    │                                      │
    │ 2. Check rate limit                  │
    │    ├─> Exceeded: Skip to Key #2     │
    │    └─> OK: Continue                 │
    │                                      │
    │ 3. Make request with retry           │
    │    Attempt 1: Immediate              │
    │    ├─> Success: ✓ Return response   │
    │    └─> Fail: Wait 2^1 = 2 seconds   │
    │              ↓                        │
    │    Attempt 2: After 2 seconds        │
    │    ├─> Success: ✓ Return response   │
    │    └─> Fail: Wait 2^2 = 4 seconds   │
    │              ↓                        │
    │    Attempt 3: After 4 seconds        │
    │    ├─> Success: ✓ Return response   │
    │    └─> Fail: Try Key #2             │
    └──────────────────────────────────────┘
    ↓
    ┌──────────────────────────────────────┐
    │ Try Key #2                           │
    │ (Same process as Key #1)             │
    │ ├─> Success: ✓ Return response      │
    │ └─> Fail: Try Key #3                │
    └──────────────────────────────────────┘
    ↓
    ┌──────────────────────────────────────┐
    │ Try Key #3                           │
    │ ├─> Success: ✓ Return response      │
    │ └─> Fail: Try Key #4                │
    └──────────────────────────────────────┘
    ↓
    ┌──────────────────────────────────────┐
    │ Try Key #4                           │
    │ ├─> Success: ✓ Return response      │
    │ └─> Fail: Try Key #5                │
    └──────────────────────────────────────┘
    ↓
    ┌──────────────────────────────────────┐
    │ Try Key #5 (Last attempt)            │
    │ ├─> Success: ✓ Return response      │
    │ └─> Fail: ✗ Return error            │
    │         "All API keys failed"         │
    │         with detailed error log       │
    └──────────────────────────────────────┘
```

### Rate Limiting Implementation

```php
private function check_rate_limit($key_index) {
    $now = time();
    $one_minute_ago = $now - 60;
    
    // Clean old timestamps (older than 1 minute)
    $this->request_timestamps[$key_index] = array_filter(
        $this->request_timestamps[$key_index],
        function($timestamp) use ($one_minute_ago) {
            return $timestamp > $one_minute_ago;
        }
    );
    
    // Check if we're within limit (10 requests/minute)
    return count($this->request_timestamps[$key_index]) < $this->rate_limit_per_minute;
}

private function record_request($key_index) {
    $this->request_timestamps[$key_index][] = time();
}
```

### Exponential Backoff Implementation

```php
private function make_request_with_retry($api_key, $prompt, $key_index) {
    $attempt = 0;
    $last_error = null;
    
    while ($attempt < $this->max_retry_attempts) {
        $attempt++;
        
        if ($attempt > 1) {
            // Exponential backoff: 2^attempt seconds
            $wait_time = pow(2, $attempt - 1);
            // Wait: 2^1=2s, 2^2=4s, 2^3=8s
            sleep($wait_time);
        }
        
        $response = $this->make_request($api_key, $prompt);
        
        if (!is_wp_error($response)) {
            return $response; // Success!
        }
        
        $last_error = $response;
        $error_msg = $response->get_error_message();
        
        // Don't retry on certain errors
        if (strpos($error_msg, '400') !== false || 
            strpos($error_msg, 'Invalid') !== false) {
            break; // Bad request, won't succeed
        }
        
        // Don't retry 429 errors - just move to next key
        if (strpos($error_msg, '429') !== false) {
            break; // Rate limit, try next key
        }
    }
    
    return $last_error;
}
```

---

## 10. Error Handling

### Error Hierarchy

```
Application Errors
├─> User Errors (400-level)
│   ├─> Invalid input
│   ├─> Missing fields
│   ├─> Permission denied
│   └─> Resource not found
│
├─> API Errors (500-level)
│   ├─> Rate limit exceeded (429)
│   ├─> API key invalid (403)
│   ├─> Service unavailable (503)
│   └─> Internal server error (500)
│
├─> System Errors
│   ├─> Database errors
│   ├─> File system errors
│   └─> Memory errors
│
└─> Network Errors
    ├─> Connection timeout
    ├─> DNS resolution failed
    └─> SSL certificate error
```

### Error Handling Flow

```
Operation Start
    ↓
Try {
    ├─> Execute operation
    │   ├─> Validate input
    │   │   └─> Invalid: throw WP_Error
    │   │
    │   ├─> Check permissions
    │   │   └─> Denied: throw WP_Error
    │   │
    │   ├─> Call API
    │   │   └─> Failed: throw WP_Error
    │   │
    │   └─> Save to database
    │       └─> Failed: throw WP_Error
    │
    └─> Success
        ├─> Log success
        └─> Return result
}
Catch {
    ├─> Log error
    │   ├─> Level: ERROR
    │   ├─> Context: controller/model name
    │   ├─> Data: request data
    │   └─> Trace: stack trace
    │
    ├─> Determine error type
    │   ├─> User error
    │   │   └─> Return user-friendly message
    │   │
    │   ├─> API error
    │   │   └─> Try failover or return error
    │   │
    │   └─> System error
    │       └─> Return generic error message
    │
    └─> Return WP_Error
        └─> JavaScript handles error
            ├─> Show error notification
            ├─> Log to console
            └─> Reset UI state
}
```

### Error Response Format

**Success Response:**
```json
{
    "success": true,
    "data": {
        "message": "Operation completed successfully",
        "result": {...}
    }
}
```

**Error Response:**
```json
{
    "success": false,
    "data": {
        "message": "User-friendly error message",
        "code": "error_code",
        "details": "Technical details for debugging"
    }
}
```

### Error Logging Example

```php
// In controller
try {
    $result = $this->gemini_client->generate_single_product($prompt);
    
    if (is_wp_error($result)) {
        $this->logger->log(
            'Failed to generate single product',
            'products_controller',
            [
                'error' => $result->get_error_message(),
                'prompt' => substr($prompt, 0, 100)
            ],
            'error'
        );
        
        wp_send_json_error([
            'message' => 'Failed to generate product. Please try again.'
        ]);
    }
    
    wp_send_json_success(['product' => $result]);
    
} catch (Exception $e) {
    $this->logger->log(
        'Exception in generate_single_product',
        'products_controller',
        [
            'exception' => $e->getMessage(),
            'trace' => $e->getTraceAsString()
        ],
        'error'
    );
    
    wp_send_json_error([
        'message' => 'An unexpected error occurred. Please try again.'
    ]);
}
```

---

## Performance Optimization

### Caching Strategy

```
1. Browser Cache
   ├─> Static assets (CSS, JS)
   └─> Expiry: 7 days

2. Object Cache
   ├─> Product queries
   ├─> Category lists
   └─> Statistics data

3. Transients
   ├─> API rate limit tracking
   └─> Temporary data storage
```

### Database Optimization

```sql
-- Indexes for fast queries
CREATE INDEX idx_aiwpg_generated ON wp_postmeta(meta_key, meta_value);
CREATE INDEX idx_product_type ON wp_posts(post_type, post_status);
```

### AJAX Optimization

```javascript
// Debounce search
let searchTimeout = null;
const DEBOUNCE_DELAY = 300; // ms

// Throttle scroll events
let lastScrollTime = 0;
const THROTTLE_DELAY = 100; // ms

// Batch requests
const requestQueue = [];
const BATCH_SIZE = 5;
```

---

<a name="arabic"></a>
# 🔄 توثيق سير العمل الكامل

## نظرة عامة

يشرح هذا المستند جميع سير العمل والعمليات في إضافة **AI Woo Product Generator**، من تفاعل المستخدم إلى تخزين البيانات.

---

## الفهرس

1. [تهيئة الإضافة](#ar-init)
2. [توليد منتج واحد](#ar-single)
3. [توليد منتجات متعددة](#ar-multiple)
4. [استيراد Excel](#ar-excel)
5. [إدارة المنتجات](#ar-management)
6. [توليد الصور](#ar-images)
7. [التحسين بالذكاء الاصطناعي](#ar-improvement)
8. [البحث والتصفية](#ar-search)
9. [نظام Failover](#ar-failover)
10. [معالجة الأخطاء](#ar-errors)

---

<a name="ar-init"></a>
## 1. تهيئة الإضافة

### مخطط سير العمل

```
تحميل WordPress
    ↓
تحميل ai-woo-product-generator.php
    ↓
تعريف الثوابت ومفاتيح API
    ↓
تحميل التبعيات (Models, Controllers, Views)
    ↓
تسجيل hook التفعيل
    ↓
تسجيل hook إلغاء التفعيل
    ↓
التحقق من تبعية WooCommerce
    ↓
تهيئة المتحكمات (Controllers)
    ↓
تسجيل Hooks والإجراءات
    ↓
الإضافة جاهزة ✓
```

---

<a name="ar-single"></a>
## 2. توليد منتج واحد

### سير العمل الكامل

```
واجهة المستخدم
    ↓
المستخدم يدخل الوصف
    ↓
المستخدم يختار نوع المنتج
    ↓
المستخدم ينقر "توليد المنتج"
    ↓
JavaScript
    ↓
طلب AJAX
    ↓
Controller يتحقق من الصلاحيات
    ↓
استدعاء Gemini Client
    ↓
بناء prompt شامل
    ↓
استدعاء API مع failover
    ↓
تحليل الاستجابة JSON
    ↓
إرجاع بيانات المنتج
    ↓
JavaScript يعرض المعاينة
    ↓
المستخدم ينقر "حفظ"
    ↓
حفظ في قاعدة البيانات
    ↓
المنتج تم إنشاؤه ✓
```

### تحليل التوقيت

| الخطوة | الوقت المتوسط | الوقت الأقصى |
|--------|---------------|--------------|
| إدخال المستخدم | 30 ثانية | - |
| طلب AJAX | 50ms | 200ms |
| استدعاء Gemini API | 3-8 ثواني | 15 ثانية |
| تحليل الاستجابة | 100ms | 500ms |
| الحفظ في قاعدة البيانات | 200ms | 1 ثانية |
| **الإجمالي** | **4-9 ثواني** | **17 ثانية** |

---

<a name="ar-multiple"></a>
## 3. توليد منتجات متعددة

### مخطط سير العمل

```
المستخدم يدخل أوصاف متعددة (سطر لكل منتج)
    ↓
JavaScript يحلل الأسطر
    ↓
استخراج الأوصاف والكميات
    ↓
إرسال طلب AJAX
    ↓
Controller يعالج الطلبات
    ↓
Gemini Client يولد جميع المنتجات دفعة واحدة
    ↓
تحليل مصفوفة JSON
    ↓
JavaScript يعرض جدول المعاينة
    ↓
المستخدم يختار المنتجات
    ↓
حفظ المنتجات المحددة
    ↓
المنتجات تم إنشاؤها ✓
```

---

<a name="ar-excel"></a>
## 4. استيراد Excel

### سير العمل الكامل

```
المستخدم يحمل قالب Excel
    ↓
المستخدم يملأ البيانات
    ↓
المستخدم يرفع الملف
    ↓
JavaScript يقرأ الملف (SheetJS)
    ↓
تحليل البيانات
    ↓
التحقق من صحة البيانات
    ↓
إرسال طلب AJAX
    ↓
(نفس توليد المنتجات المتعددة)
    ↓
المنتجات تم إنشاؤها ✓
```

---

<a name="ar-management"></a>
## 5. إدارة المنتجات

### عرض المنتجات

```
تحميل الصفحة
    ↓
تحميل الإحصائيات
    ↓
تحميل المنتجات (صفحة 1)
    ↓
عرض البطاقات
    ↓
عرض التصفح
```

### تحرير منتج

```
نقر "تحرير"
    ↓
فتح نافذة منبثقة
    ↓
تحميل بيانات المنتج
    ↓
ملء الحقول
    ↓
المستخدم يعدل
    ↓
نقر "حفظ التغييرات"
    ↓
تحديث المنتج
    ↓
إظهار إشعار نجاح ✓
```

---

<a name="ar-images"></a>
## 6. توليد الصور

### سير العمل الكامل

```
نقر زر "توليد صورة" 📷
    ↓
إرسال طلب AJAX
    ↓
Images Controller
    ↓
الحصول على تفاصيل المنتج
    ↓
بناء prompt للصورة
    ↓
Image Client مع failover
    ↓
إرسال طلب Freepik
    ↓
الحصول على task_id
    ↓
الانتظار (Poll) كل 3 ثواني
    ↓
الصورة جاهزة
    ↓
تحميل الصورة
    ↓
رفع إلى WordPress
    ↓
إنشاء thumbnail 300x300
    ↓
تعيين كصورة مميزة
    ↓
الصورة تم توليدها ✓
```

---

<a name="ar-improvement"></a>
## 7. التحسين بالذكاء الاصطناعي

### سير تحسين الوصف

```
نقر "تحسين بالـ AI" 🤖
    ↓
الحصول على قيمة الحقل الحالية
    ↓
إرسال طلب AJAX
    ↓
Products Controller
    ↓
بناء prompt التحسين
    ↓
Gemini Client
    ↓
الحصول على النص المحسن
    ↓
استبدال قيمة الحقل
    ↓
إظهار إشعار نجاح ✓
```

---

<a name="ar-search"></a>
## 8. البحث والتصفية

### البحث الفوري

```
المستخدم يكتب في صندوق البحث
    ↓
Debounce 300ms
    ↓
إرسال طلب AJAX
    ↓
البحث في قاعدة البيانات
    ↓
إرجاع 4 نتائج
    ↓
عرض autocomplete
    ↓
المستخدم ينقر على نتيجة
    ↓
التمرير إلى البطاقة
    ↓
تمييز البطاقة (pulse)
    ↓
البحث اكتمل ✓
```

---

<a name="ar-failover"></a>
## 9. نظام Failover

### مخطط سير Failover

```
طلب توليد منتج
    ↓
محاولة المفتاح #1
├─> تحقق من Rate Limit
├─> إرسال الطلب
├─> محاولة 1: فورية
│   └─> فشل: انتظار 2 ثانية
├─> محاولة 2: بعد 2 ثانية
│   └─> فشل: انتظار 4 ثواني
└─> محاولة 3: بعد 4 ثواني
    └─> فشل: محاولة المفتاح #2
        ↓
محاولة المفتاح #2
(نفس العملية)
    ↓
محاولة المفتاح #3
    ↓
محاولة المفتاح #4
    ↓
محاولة المفتاح #5 (آخر محاولة)
    ↓
نجاح ✓ أو فشل جميع المفاتيح ✗
```

---

<a name="ar-errors"></a>
## 10. معالجة الأخطاء

### تسلسل الأخطاء

```
أخطاء التطبيق
├─> أخطاء المستخدم (400)
│   ├─> إدخال غير صحيح
│   ├─> حقول مفقودة
│   └─> الوصول مرفوض
│
├─> أخطاء API (500)
│   ├─> تجاوز الحد (429)
│   ├─> مفتاح غير صحيح (403)
│   └─> خطأ في الخادم (500)
│
├─> أخطاء النظام
│   ├─> أخطاء قاعدة البيانات
│   └─> أخطاء الملفات
│
└─> أخطاء الشبكة
    ├─> انتهاء المهلة
    └─> خطأ SSL
```

### معالجة الأخطاء

```
بدء العملية
    ↓
Try {
    تنفيذ العملية
    └─> نجاح: إرجاع النتيجة
}
Catch {
    ├─> تسجيل الخطأ
    ├─> تحديد نوع الخطأ
    └─> إرجاع رسالة مناسبة
}
    ↓
JavaScript يعالج الخطأ
    ├─> إظهار إشعار خطأ
    ├─> تسجيل في Console
    └─> إعادة تعيين واجهة المستخدم
```

---

## تحسين الأداء

### استراتيجية التخزين المؤقت

```
1. Cache المتصفح
   └─> الموارد الثابتة (CSS, JS)

2. Object Cache
   ├─> استعلامات المنتجات
   └─> قوائم التصنيفات

3. Transients
   └─> تتبع حدود API
```

---

**آخر تحديث:** يناير 2024  
**الإصدار:** 1.0.0
