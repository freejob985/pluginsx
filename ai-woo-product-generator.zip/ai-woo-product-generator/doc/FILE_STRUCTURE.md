# File Structure Documentation | توثيق هيكل الملفات

[English](#english) | [العربية](#arabic)

---

<a name="english"></a>
# 📁 Complete File Structure Documentation

## Overview

The **AI Woo Product Generator** plugin follows a professional MVC (Model-View-Controller) architecture pattern for maximum code organization, maintainability, and scalability.

---

## Directory Tree

```
ai-woo-product-generator/
│
├── ai-woo-product-generator.php  ← Main plugin file (entry point)
│
├── assets/                        ← Frontend resources
│   ├── css/
│   │   └── aiwpg-admin.css       ← Admin interface styles
│   └── js/
│       └── aiwpg-admin.js        ← Admin interface JavaScript
│
├── controllers/                   ← Controllers (MVC)
│   ├── class-aiwpg-admin-controller.php
│   ├── class-aiwpg-images-controller.php
│   ├── class-aiwpg-products-controller.php
│   └── class-aiwpg-settings-controller.php
│
├── models/                        ← Models (MVC)
│   ├── class-aiwpg-gemini-client.php
│   ├── class-aiwpg-image-client.php
│   ├── class-aiwpg-logger.php
│   └── class-aiwpg-product-model.php
│
├── views/                         ← Views (MVC)
│   ├── admin-ai-generator-page.php
│   ├── admin-products-list-page.php
│   └── admin-settings-page.php
│
├── doc/                           ← Documentation
│   ├── README-AR.md
│   ├── README-EN.md
│   ├── FILE_STRUCTURE.md
│   ├── WORKFLOW.md
│   ├── API_DOCUMENTATION.md
│   └── CODE_DOCUMENTATION.md
│
├── test-extract-image.php         ← Image extraction testing
└── test-freepik-api.php           ← Freepik API testing
```

---

## 📄 Main Files

### 1. `ai-woo-product-generator.php`

**Purpose**: Plugin entry point and bootstrap file

**Key Components**:
```php
// Plugin metadata (header)
Plugin Name: AI Woo Product Generator
Version: 1.0.0
Requires PHP: 7.4
Requires at least: 5.8

// Constants definition
AIWPG_VERSION
AIWPG_PLUGIN_DIR
AIWPG_PLUGIN_URL
AIWPG_PLUGIN_BASENAME

// API Keys configuration
AIWPG_GEMINI_API_KEY_1 through _5
AIWPG_FREEPIK_API_KEY_1 through _5

// Main plugin class
AI_Woo_Product_Generator
```

**Responsibilities**:
- ✅ Define plugin constants
- ✅ Store API keys
- ✅ Load dependencies (Models, Controllers, Views)
- ✅ Initialize hooks
- ✅ Handle activation/deactivation
- ✅ Check WooCommerce dependency
- ✅ Register custom image sizes

**Lines of Code**: ~219 lines

---

## 🎨 Assets Directory

### `/assets/css/`

#### `aiwpg-admin.css` (2,321 lines)

**Purpose**: Complete styling for admin interface

**Key Sections**:

1. **Base Variables & Reset** (Lines 1-50)
   ```css
   :root {
       --primary-color: #0073aa;
       --success-color: #46b450;
       --danger-color: #dc3232;
       --warning-color: #f0ad4e;
   }
   ```

2. **Layout & Grid** (Lines 51-200)
   - `.aiwpg-wrap`: Main wrapper
   - `.aiwpg-card`: Card components
   - `.aiwpg-products-grid`: Product grid layout

3. **Components** (Lines 201-1000)
   - Buttons and forms
   - Modal windows
   - Tabs navigation
   - Search bar
   - Product cards

4. **Statistics Dashboard** (Lines 1001-1200)
   - Stat cards
   - Icons and colors
   - Responsive layout

5. **Modals & Overlays** (Lines 1201-1600)
   - Modal structure
   - Product editing modal
   - Tab navigation within modals
   - Fullscreen mode

6. **Responsive Design** (Lines 1601-2000)
   - Mobile optimization
   - Tablet breakpoints
   - Desktop enhancements

7. **Animations** (Lines 2001-2321)
   - Fade effects
   - Slide transitions
   - Loading spinners
   - Pulse effects

**Features**:
- ✅ Modern CSS3 features
- ✅ Flexbox & Grid layouts
- ✅ Smooth animations
- ✅ Mobile-first approach
- ✅ Beautiful color scheme
- ✅ Professional UI components

### `/assets/js/`

#### `aiwpg-admin.js` (2,700+ lines)

**Purpose**: All client-side functionality and AJAX operations

**Key Sections**:

1. **Dependencies Check** (Lines 1-50)
   ```javascript
   - jQuery verification
   - SweetAlert2 check
   - Toastr check
   - XLSX library check
   ```

2. **Configuration** (Lines 51-100)
   ```javascript
   - Toastr settings
   - Global variables
   - Speech recognition setup
   ```

3. **Initialization Functions** (Lines 101-500)
   ```javascript
   initTabs()                    // Tab switching
   initProductTypeToggle()       // Product type selection
   initSingleProductForm()       // Single product generation
   initMultipleProductsForm()    // Multiple products generation
   initExcelForm()               // Excel import
   initProductsList()            // Product list display
   initModals()                  // Modal windows
   initVoiceInput()              // Speech recognition
   ```

4. **AJAX Operations** (Lines 501-1500)
   ```javascript
   // Product Generation
   generateSingleProduct()
   generateMultipleProducts()
   generateFromExcel()
   
   // Product Management
   saveProduct()
   updateProduct()
   deleteProduct()
   
   // Image Operations
   generateProductImage()
   
   // Search & Filter
   searchProducts()
   loadProducts()
   
   // AI Improvements
   improvePrompt()
   improveField()
   ```

5. **UI Functions** (Lines 1501-2200)
   ```javascript
   renderProductCard()           // Card rendering
   renderPreviewTable()          // Table rendering
   showModal()                   // Modal display
   updateStatistics()            // Stats update
   showToast()                   // Notifications
   ```

6. **Utility Functions** (Lines 2201-2700)
   ```javascript
   formatPrice()                 // Price formatting
   formatDate()                  // Date formatting
   debounce()                    // Input debouncing
   sanitizeHTML()                // XSS prevention
   downloadExcelTemplate()       // Template generation
   ```

**External Dependencies**:
- jQuery 3.x
- SweetAlert2 11.x
- Toastr 2.1.4
- SheetJS (XLSX) 0.20.0
- Tagify 4.17.9

---

## 🎛️ Controllers Directory

Controllers handle HTTP requests, coordinate between models and views, and manage AJAX endpoints.

### 1. `class-aiwpg-admin-controller.php` (213 lines)

**Class**: `AIWPG_Admin_Controller`

**Purpose**: Admin menu, pages, and asset management

**Key Methods**:

```php
public function add_admin_menu()
// Creates WordPress admin menu structure
// Location: Dashboard > AI Products

public function enqueue_assets($hook)
// Loads CSS/JS only on plugin pages
// Includes cache busting for development

public function render_generator_page()
// Displays product generation interface

public function render_products_page()
// Displays products list interface

public function render_settings_page()
// Displays settings interface
```

**Menu Structure**:
```
AI Products (Main Menu)
├── Generate Products (generator page)
├── Products List (products page)
└── Settings (settings page)
```

**Assets Loaded**:
- ✅ aiwpg-admin.css
- ✅ aiwpg-admin.js
- ✅ SweetAlert2
- ✅ Toastr
- ✅ Tagify
- ✅ XLSX (SheetJS)

**Localized Data**:
```javascript
aiwpgData = {
    ajaxUrl: admin_url('admin-ajax.php'),
    nonce: wp_create_nonce('aiwpg_nonce'),
    pluginUrl: AIWPG_PLUGIN_URL,
    templateUrl: template_xlsx_url,
    strings: { ... }
}
```

---

### 2. `class-aiwpg-products-controller.php` (697 lines)

**Class**: `AIWPG_Products_Controller`

**Purpose**: Handle all product-related AJAX operations

**Dependencies**:
- AIWPG_Gemini_Client
- AIWPG_Product_Model
- AIWPG_Logger

**AJAX Actions** (16 total):

```php
// Generation Actions
wp_ajax_aiwpg_generate_single      → generate_single_product()
wp_ajax_aiwpg_generate_multiple    → generate_multiple_products()
wp_ajax_aiwpg_generate_excel       → generate_from_excel()

// CRUD Actions
wp_ajax_aiwpg_save_product         → save_product()
wp_ajax_aiwpg_save_products        → save_products()
wp_ajax_aiwpg_get_product          → get_product()
wp_ajax_aiwpg_get_products         → get_products()
wp_ajax_aiwpg_update_product       → update_product()
wp_ajax_aiwpg_update_variation     → update_variation()
wp_ajax_aiwpg_delete_product       → delete_product()

// Search & Filter
wp_ajax_aiwpg_search_products      → search_products()

// Statistics
wp_ajax_aiwpg_get_statistics       → get_statistics()

// AI Improvements
wp_ajax_aiwpg_improve_prompt       → improve_prompt()
wp_ajax_aiwpg_improve_field        → improve_field()

// Categories
wp_ajax_aiwpg_get_categories       → get_categories()
```

**Key Features**:
- ✅ Permission checking (`manage_woocommerce`)
- ✅ Nonce verification
- ✅ Error handling and logging
- ✅ Data sanitization
- ✅ JSON response formatting

**Example Method**:
```php
public function generate_single_product() {
    // 1. Verify nonce
    check_ajax_referer('aiwpg_nonce', 'nonce');
    
    // 2. Check permissions
    if (!current_user_can('manage_woocommerce')) {
        wp_send_json_error(['message' => 'Permission denied']);
    }
    
    // 3. Sanitize input
    $prompt = sanitize_textarea_field($_POST['prompt']);
    
    // 4. Generate product
    $result = $this->gemini_client->generate_single_product($prompt);
    
    // 5. Handle response
    if (is_wp_error($result)) {
        $this->logger->log('Failed', 'error');
        wp_send_json_error(['message' => $result->get_error_message()]);
    }
    
    // 6. Return success
    wp_send_json_success(['product' => $result]);
}
```

---

### 3. `class-aiwpg-images-controller.php` (214 lines)

**Class**: `AIWPG_Images_Controller`

**Purpose**: Handle AI image generation

**Dependencies**:
- AIWPG_Image_Client
- AIWPG_Logger

**Key Methods**:

```php
public function ajax_generate_product_image()
// AJAX handler for image generation
// Endpoint: wp_ajax_aiwpg_generate_product_image

public function generate_for_product($product_id)
// Programmatic image generation
// Used internally by other functions

public function generate_from_prompt($prompt, $reference_images = [])
// Generate image from custom prompt
```

**Image Generation Flow**:
```
1. Get product details (name, description, categories)
2. Build AI prompt for image
3. Call Freepik API (with failover)
4. Download generated image
5. Upload to WordPress media library
6. Create 300x300 thumbnail
7. Set as featured product image
```

**Response Format**:
```json
{
    "success": true,
    "message": "✓ Image generated successfully (300x300)",
    "attachment_id": 123,
    "image_url": "https://...",
    "thumbnail_url": "https://..."
}
```

---

### 4. `class-aiwpg-settings-controller.php` (131 lines)

**Class**: `AIWPG_Settings_Controller`

**Purpose**: Handle plugin settings and bulk delete operations

**Dependencies**:
- AIWPG_Product_Model

**AJAX Actions**:
```php
wp_ajax_aiwpg_save_settings        → save_settings()
wp_ajax_aiwpg_delete_all_products  → delete_all_products()
wp_ajax_aiwpg_delete_ai_products   → delete_ai_products()
```

**Settings Structure**:
```php
[
    'products_per_page' => 12,        // 1-100
    'default_stock_status' => 'instock',  // instock, outofstock
    'auto_publish' => false,          // true, false
]
```

**Delete Operations**:
- Both require typing "DELETE" for confirmation
- Both use permanent deletion (force = true)
- Both return count of deleted products

---

## 🗄️ Models Directory

Models handle business logic, data operations, and external API communication.

### 1. `class-aiwpg-gemini-client.php` (896 lines)

**Class**: `AIWPG_Gemini_Client`

**Purpose**: Communication with Google Gemini 2.0 Flash API

**Key Features**:
- ✅ 5 API keys with automatic failover
- ✅ Rate limiting (10 requests/minute per key)
- ✅ Exponential backoff retry (max 3 attempts)
- ✅ Comprehensive error handling
- ✅ Detailed logging

**API Configuration**:
```php
const API_ENDPOINT = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent';

private $rate_limit_per_minute = 10;
private $max_retry_attempts = 3;
```

**Key Methods**:

```php
public function generate_single_product($prompt, $product_type = 'automatic')
// Generate one product from description
// Returns: array|WP_Error

public function generate_multiple_products($prompts, $product_type = 'automatic')
// Generate multiple products from array of descriptions
// Returns: array|WP_Error

public function generate_text($prompt)
// Generate any text with AI
// Returns: string|WP_Error

private function build_single_product_prompt($user_prompt, $product_type)
// Build complete prompt with instructions
// Includes existing categories, brands, attributes

private function call_api($prompt)
// Make API request with failover
// Tries all 5 keys with retry logic

private function check_rate_limit($key_index)
// Check if key is within rate limit
// Returns: bool
```

**Prompt Engineering**:

The class builds comprehensive prompts that include:
- User's product description
- Existing categories (to prefer existing ones)
- Existing brands (to prefer existing ones)
- Existing attributes (for variable products)
- Product type instructions (Simple/Variable/Automatic)
- Pricing rules (use mentioned price or estimate)
- JSON structure requirements
- Output formatting rules

**Example Prompt Structure**:
```
You are a professional e-commerce product content generator...

Product Description:
{user_prompt}

EXISTING CATEGORIES: Electronics, Clothing, Accessories
EXISTING BRANDS: Nike, Apple, Samsung
EXISTING ATTRIBUTES: Color, Size, Storage

PRODUCT TYPE: Variable

IMPORTANT INSTRUCTIONS:
1. Generate ONLY valid JSON...
2. Use this exact structure: {...}
3. Create variations for all attribute combinations
4. Prices must be realistic
...

Output ONLY the JSON object, nothing else.
```

**Failover Logic**:
```php
for ($i = 0; $i < count($this->api_keys); $i++) {
    // Skip placeholder keys
    if (strpos($key, 'PLACEHOLDER') !== false) continue;
    
    // Check rate limiting
    if (!$this->check_rate_limit($i)) continue;
    
    // Try with exponential backoff
    $response = $this->make_request_with_retry($key, $prompt, $i);
    
    if (!is_wp_error($response)) {
        return $response; // Success!
    }
    
    // If 429 error, skip to next key immediately
    if (strpos($error_msg, '429') !== false) {
        continue;
    }
}
```

**Response Parsing**:
```php
private function parse_single_product_response($response, $product_type)
// Cleans JSON response (removes markdown code blocks)
// Validates required fields
// Sets defaults for optional fields
// Returns structured product data
```

---

### 2. `class-aiwpg-image-client.php` (926 lines)

**Class**: `AIWPG_Image_Client`

**Purpose**: Communication with Freepik AI API for image generation

**Key Features**:
- ✅ 5 Freepik API keys with failover
- ✅ Asynchronous image generation (polling)
- ✅ 300x300 thumbnail generation
- ✅ Automatic upload to WordPress media library
- ✅ Comprehensive error handling

**API Configuration**:
```php
private $api_endpoint = 'https://api.freepik.com/v1/ai/gemini-2-5-flash-image-preview';
private $max_poll_attempts = 60;
private $poll_interval = 3; // seconds
```

**Key Methods**:

```php
public function generate_image($prompt, $reference_images = [], $width = 300, $height = 300)
// Generate image from text prompt
// Returns: ['success' => true, 'attachment_id' => 123, ...]

public function generate_product_image($product_name, $product_description, $product_data)
// Generate image specifically for a product
// Builds optimized prompt for e-commerce
// Returns: ['success' => true, 'url' => '...', 'thumbnail_url' => '...']

private function create_product_prompt($product_name, $product_description, $product_data)
// Create e-commerce optimized prompt
// Example output:
// "High-quality professional product photography thumbnail of Wireless Headphones, 
//  showing premium design with noise cancellation, category: Electronics, 
//  clean white background, well-lit, commercial product shot, centered composition, 
//  square format suitable for thumbnail, optimized for 300x300 pixels display"

private function try_generate_with_key($api_key, $prompt, $reference_images, $width, $height)
// Attempt generation with specific API key

private function poll_for_image($api_key, $task_id)
// Poll Freepik API for image completion
// Max 60 attempts × 3 seconds = 180 seconds timeout
// Returns: ['success' => true, 'image_url' => '...']

private function upload_to_media_library($image_result, $product_name, $target_width = 300, $target_height = 300)
// Download image and upload to WordPress
// Create custom 300x300 thumbnail
// Returns: ['success' => true, 'attachment_id' => 123]

private function create_custom_thumbnail($attachment_id, $file_path, $width = 300, $height = 300)
// Create exact 300x300 thumbnail with hard crop
// Register 'aiwpg_product_thumbnail' image size
```

**Image Generation Workflow**:
```
1. Build AI prompt based on product details
   └─> Include name, description, categories, style requirements

2. Try each API key until success
   ├─> Send generation request
   ├─> Get task_id from response
   └─> Poll status every 3 seconds (max 60 times)

3. Download generated image
   └─> HTTP GET request to image URL

4. Upload to WordPress
   ├─> Save to /wp-content/uploads/
   ├─> Create attachment post
   ├─> Generate metadata
   └─> Create 300x300 thumbnail

5. Return URLs and attachment ID
```

**Polling Mechanism**:
```php
$attempts = 0;
while ($attempts < $this->max_poll_attempts) {
    $attempts++;
    
    if ($attempts > 1) {
        sleep($this->poll_interval);
    }
    
    $status_result = $this->check_task_status($task_id, $api_key);
    
    if (isset($status_result['image'])) {
        // Image ready!
        return $this->extract_image_from_response($status_result);
    }
    
    if ($current_status === 'FAILED') {
        return ['success' => false, 'error' => 'Generation failed'];
    }
    
    if (in_array($current_status, ['CREATED', 'PROCESSING', 'PENDING'])) {
        continue; // Keep polling
    }
}
```

---

### 3. `class-aiwpg-product-model.php` (874 lines)

**Class**: `AIWPG_Product_Model`

**Purpose**: WooCommerce product CRUD operations

**Key Features**:
- ✅ Create simple and variable products
- ✅ Full product data management
- ✅ Automatic attribute creation
- ✅ Variation generation
- ✅ Category/tag management
- ✅ Brand taxonomy support

**Meta Key**: `_aiwpg_generated` (marks AI-generated products)

**Key Methods**:

```php
public function create_product($product_data)
// Create WooCommerce product
// Handles both simple and variable products
// Returns: int (product_id) | WP_Error

public function update_product($product_id, $product_data)
// Update existing product
// Supports all 7 tab fields
// Returns: bool | WP_Error

public function get_product($product_id)
// Get complete product data
// Includes: general, inventory, shipping, linked, media, variations, settings
// Returns: array

public function get_products($page = 1, $per_page = 12, $search = '')
// Get products with pagination
// Returns: ['products' => [...], 'total' => 100, 'pages' => 9, 'current_page' => 1]

public function search_products($search, $limit = 4)
// Search products for autocomplete
// Returns: array of products

public function delete_product($product_id, $force = false)
// Delete single product
// Returns: bool | WP_Error

public function delete_all_products()
// Delete ALL WooCommerce products
// Returns: int (deleted count)

public function delete_all_ai_products()
// Delete only AI-generated products
// Returns: int (deleted count)

private function create_product_attributes($product_id, $attributes)
// Create product attributes for variable products
// Registers taxonomies (pa_color, pa_size, etc.)
// Creates terms and associates with product

private function create_product_variations($product_id, $variations, $attributes)
// Create all product variations
// Sets attributes, prices, stock for each variation
```

**Product Creation Flow**:

**Simple Product:**
```php
1. Create WC_Product_Simple object
2. Set basic data (name, description, SKU)
3. Set prices (regular_price, sale_price)
4. Set stock (quantity, status)
5. Save product → get product_id
6. Set categories and tags
7. Set brand (if available)
8. Mark as AI-generated
```

**Variable Product:**
```php
1. Create WC_Product_Variable object
2. Set basic data (name, description, SKU)
3. Save product → get product_id
4. Create attributes:
   ├─> Check if taxonomy exists
   ├─> Create taxonomy if needed (pa_color, pa_size)
   ├─> Create terms (Black, White, S, M, L)
   └─> Associate with product
5. Create variations:
   ├─> For each combination of attributes
   ├─> Create WC_Product_Variation
   ├─> Set attributes (Color: Black, Size: M)
   ├─> Set prices (regular, sale)
   ├─> Set stock
   └─> Save variation
6. Sync parent product
7. Set categories and tags
8. Mark as AI-generated
```

**Example Variation Creation**:
```php
$variation = new WC_Product_Variation();
$variation->set_parent_id($product_id);
$variation->set_attributes(['pa_color' => 'black', 'pa_size' => 'm']);
$variation->set_sku('SHIRT-BLK-M');
$variation->set_regular_price('79.99');
$variation->set_sale_price('59.99');
$variation->set_manage_stock(true);
$variation->set_stock_quantity(10);
$variation->set_stock_status('instock');
$variation_id = $variation->save();
```

---

### 4. `class-aiwpg-logger.php` (287 lines)

**Class**: `AIWPG_Logger`

**Purpose**: Comprehensive error tracking and logging

**Key Features**:
- ✅ 4 log levels (ERROR, WARNING, INFO, DEBUG)
- ✅ File-based logging with rotation
- ✅ Stack trace for errors
- ✅ User tracking
- ✅ Daily log files
- ✅ Automatic file rotation at 5MB
- ✅ Keep last 10 backups
- ✅ Protected directory (.htaccess)

**Log Location**:
```
/wp-content/uploads/aiwpg-logs/
├── aiwpg-2024-01-15.log          (today's log)
├── aiwpg-2024-01-15.log.1234.bak (backup 1)
├── aiwpg-2024-01-15.log.5678.bak (backup 2)
└── .htaccess                     (deny from all)
```

**Key Methods**:

```php
public static function get_instance()
// Singleton pattern

public function log($message, $context = 'general', $data = [], $level = 'error')
// Main logging method
// $message: Error message
// $context: Component name (products_controller, gemini_client, etc.)
// $data: Additional data to log
// $level: error|warning|info|debug

public function get_recent_logs($lines = 100)
// Get last N log entries
// Returns: array of log lines

public function clear_logs()
// Clear current log file

private function format_log_entry($entry)
// Format log entry for file output

private function rotate_log_file()
// Rotate log when it reaches 5MB
```

**Log Entry Format**:
```
[2024-01-15 14:30:45] [ERROR] [products_controller] [admin] [ID:1] Failed to generate product | Data: {"prompt":"test"} | Trace: AIWPG_Products_Controller::generate_single_product() in class-aiwpg-products-controller.php:99 -> wp_ajax_aiwpg_generate_single() in class-wp-hook.php:308
```

**Log Entry Structure**:
```php
[
    'timestamp' => '2024-01-15 14:30:45',
    'level' => 'ERROR',
    'context' => 'products_controller',
    'user' => 'admin',
    'user_id' => 1,
    'message' => 'Failed to generate product',
    'data' => ['prompt' => 'test'],
    'trace' => 'AIWPG_Products_Controller::generate_single_product()...'
]
```

**Usage Examples**:
```php
// Error with trace
$this->logger->log(
    'Failed to generate product',
    'products_controller',
    ['prompt' => $prompt, 'error' => $error],
    'error'
);

// Warning
$this->logger->log(
    'API key exhausted, trying next',
    'gemini_client',
    ['key_index' => 1],
    'warning'
);

// Info
$this->logger->log(
    'Product created successfully',
    'product_model',
    ['product_id' => 123],
    'info'
);

// Debug
$this->logger->log(
    'API response received',
    'gemini_client',
    ['response_length' => 1234],
    'debug'
);
```

---

## 👁️ Views Directory

Views contain the HTML/PHP templates for the admin interface.

### 1. `admin-ai-generator-page.php` (289 lines)

**Purpose**: Product generation interface with 3 tabs

**Structure**:
```html
<div class="wrap aiwpg-wrap">
    <nav class="nav-tab-wrapper">
        Tab 1: Single Product
        Tab 2: Multiple Products (Textarea)
        Tab 3: Multiple Products (Excel)
    </nav>
    
    <div id="tab-single" class="active">
        <form id="single-product-form">
            Product Type Toggle (Automatic/Simple/Variable)
            Textarea for description
            Buttons: Generate, Improve, Example, Voice
        </form>
        
        <div id="single-preview">
            Preview card with product details
            Buttons: Save, Cancel
        </div>
    </div>
    
    <div id="tab-multiple">
        <form id="multiple-products-form">
            Product Type Toggle
            Textarea for multiple descriptions
            Buttons: Generate, Improve, Example, Voice
        </form>
        
        <div id="multiple-preview">
            Preview table with all products
            Checkboxes for selection
            Buttons: Save Selected, Cancel
        </div>
    </div>
    
    <div id="tab-excel">
        <a href="#" id="download-template">Download Template</a>
        
        <form id="excel-products-form">
            <input type="file" accept=".xlsx,.xls">
            Button: Upload and Generate
        </form>
        
        <div id="excel-preview">
            Preview table
            Checkboxes
            Buttons: Save Selected, Cancel
        </div>
    </div>
</div>
```

**Features**:
- ✅ 3 generation modes
- ✅ Product type selection (Automatic/Simple/Variable)
- ✅ Real-time preview
- ✅ Bulk selection
- ✅ AI improvement buttons
- ✅ Voice input support
- ✅ Example data loading

---

### 2. `admin-products-list-page.php` (495 lines)

**Purpose**: Products list with advanced management features

**Structure**:
```html
<div class="wrap aiwpg-wrap">
    <!-- Statistics Dashboard -->
    <div class="aiwpg-stats-dashboard">
        Stat Card: Total Products
        Stat Card: Published
        Stat Card: Drafts
        Stat Card: Stock Value
        Stat Card: Out of Stock
    </div>
    
    <!-- Search Bar -->
    <div class="aiwpg-search-bar">
        <input type="text" id="product-search">
        <div id="autocomplete-results"></div>
        <button id="refresh-products">Refresh</button>
    </div>
    
    <!-- Products Grid -->
    <div id="products-container" class="aiwpg-products-grid">
        <!-- Populated via AJAX -->
    </div>
    
    <!-- Pagination -->
    <div id="products-pagination"></div>
</div>

<!-- View Product Modal -->
<div id="view-product-modal">
    Modal content for viewing product details
</div>

<!-- Edit Product Modal -->
<div id="edit-product-modal">
    <nav class="product-tabs-nav">
        7 Tabs: General, Inventory, Shipping, Linked, Media, Variations, Settings
    </nav>
    
    <form id="edit-product-form">
        Tab contents with all product fields
        AI improvement buttons on text fields
        Image upload/generate buttons
        Variations display
    </form>
</div>

<!-- Context Menu (Right-click menu for tabs) -->
<div id="edit-product-context-menu">
    Quick navigation menu items
</div>
```

**Features**:
- ✅ Statistics dashboard
- ✅ Real-time search with autocomplete
- ✅ Card grid layout
- ✅ Pagination
- ✅ View/Edit modals
- ✅ Fullscreen mode
- ✅ Previous/Next navigation
- ✅ 7-tab product editor
- ✅ AI improvements
- ✅ Image generation
- ✅ Variation management

---

### 3. `admin-settings-page.php` (151 lines)

**Purpose**: Plugin settings and dangerous operations

**Structure**:
```html
<div class="wrap aiwpg-wrap">
    <div class="aiwpg-settings-container">
        <!-- General Settings Card -->
        <div class="aiwpg-card">
            <form id="settings-form">
                Products Per Page (number input)
                Default Stock Status (select)
                Auto-Publish (checkbox)
                
                Button: Save Settings
            </form>
        </div>
        
        <!-- API Keys Status Card -->
        <div class="aiwpg-card">
            <h2>Gemini API Keys</h2>
            <ul>
                API Key 1: ✅ Configured / ⚠️ Not Configured
                API Key 2: ...
                API Key 3: ...
                API Key 4: ...
                API Key 5: ...
            </ul>
        </div>
        
        <!-- Danger Zone Card -->
        <div class="aiwpg-card aiwpg-danger-zone">
            <div class="danger-action">
                <h3>Delete AI-Generated Products</h3>
                Button: Delete AI Products
            </div>
            
            <hr>
            
            <div class="danger-action">
                <h3>Delete ALL WooCommerce Products</h3>
                Button: Delete ALL Products (requires "DELETE" confirmation)
            </div>
        </div>
    </div>
</div>
```

**Features**:
- ✅ General settings management
- ✅ API keys status display
- ✅ Safe deletion (AI products only)
- ✅ Dangerous deletion (all products)
- ✅ Confirmation dialogs
- ✅ Visual danger indicators

---

## 📚 Documentation Directory

### Current Documentation Files:

1. **README-AR.md** (Arabic documentation)
   - Complete user guide
   - Installation instructions
   - Feature explanations
   - Troubleshooting
   - FAQ

2. **README-EN.md** (English documentation)
   - Same content as Arabic version

3. **FILE_STRUCTURE.md** (This file)
   - Complete file structure explanation
   - File purposes and responsibilities
   - Code organization

4. **WORKFLOW.md** (Workflow documentation)
   - Application flow diagrams
   - Process explanations
   - Sequence diagrams

5. **API_DOCUMENTATION.md** (API documentation)
   - All AJAX endpoints
   - Request/response formats
   - API examples

6. **CODE_DOCUMENTATION.md** (Code documentation)
   - Class documentation
   - Method documentation
   - Code examples
   - Best practices

---

## 🧪 Test Files

### `test-extract-image.php`

**Purpose**: Test image extraction from Freepik API responses

**Usage**:
```bash
# Direct execution
php test-extract-image.php

# Or access via browser
https://yoursite.com/wp-content/plugins/ai-woo-product-generator/test-extract-image.php
```

---

### `test-freepik-api.php`

**Purpose**: Test Freepik API connectivity and image generation

**Usage**:
```bash
php test-freepik-api.php
```

---

## 📊 Statistics

### Plugin Size:
- **Total Files**: ~15 files
- **Total Lines**: ~8,500 lines
- **PHP Code**: ~5,800 lines
- **JavaScript**: ~2,700 lines
- **CSS**: ~2,321 lines
- **Documentation**: ~3,000 lines

### File Breakdown:
```
PHP Files:        ~5,800 lines
├── Main file:    ~219 lines
├── Controllers:  ~1,255 lines
├── Models:       ~2,983 lines
└── Views:        ~935 lines

JavaScript:       ~2,700 lines
CSS:              ~2,321 lines
Documentation:    ~3,000 lines (estimated)
```

---

## 🎯 Design Patterns

### 1. **Singleton Pattern**
Used in all major classes to ensure single instance:
```php
private static $instance = null;

public static function get_instance() {
    if (null === self::$instance) {
        self::$instance = new self();
    }
    return self::$instance;
}

private function __construct() {
    // Initialization
}
```

### 2. **MVC Pattern**
Clear separation of concerns:
- **Models**: Data and business logic
- **Views**: Presentation layer
- **Controllers**: Request handling and coordination

### 3. **Strategy Pattern**
Different strategies for API failover:
- Try first key
- If fails → try second key
- Continue until success or all fail

### 4. **Factory Pattern** (Implied)
Creating different product types:
```php
if ($is_variable) {
    $product = new WC_Product_Variable();
} else {
    $product = new WC_Product_Simple();
}
```

---

## 🔗 Dependencies

### PHP Extensions:
- ✅ json
- ✅ curl
- ✅ gd (for image manipulation)
- ✅ mbstring

### WordPress:
- ✅ WordPress 5.8+
- ✅ WooCommerce (any recent version)

### External Libraries (CDN):
- ✅ SweetAlert2 11.x
- ✅ Toastr 2.1.4
- ✅ SheetJS (XLSX) 0.20.0
- ✅ Tagify 4.17.9

---

## 🚀 Performance Considerations

### Optimization Techniques:

1. **Lazy Loading**: Assets only loaded on plugin pages
2. **AJAX Operations**: No page reloads
3. **Caching**: User rate limiting prevents API spam
4. **Pagination**: Products loaded in chunks
5. **Debouncing**: Search delayed by 300ms
6. **Code Splitting**: Separate CSS/JS files

### Best Practices:

- ✅ Nonce verification on all AJAX
- ✅ Permission checks
- ✅ Data sanitization
- ✅ Prepared SQL queries (via WP_Query)
- ✅ Error handling
- ✅ Logging for debugging

---

<a name="arabic"></a>
# 📁 توثيق هيكل الملفات الكامل

## نظرة عامة

إضافة **AI Woo Product Generator** تتبع نمط معماري احترافي MVC (Model-View-Controller) لتحقيق أقصى قدر من تنظيم الكود وسهولة الصيانة وقابلية التوسع.

---

## شجرة الملفات

```
ai-woo-product-generator/
│
├── ai-woo-product-generator.php  ← الملف الرئيسي (نقطة الدخول)
│
├── assets/                        ← موارد الواجهة الأمامية
│   ├── css/
│   │   └── aiwpg-admin.css       ← أنماط واجهة الإدارة
│   └── js/
│       └── aiwpg-admin.js        ← JavaScript واجهة الإدارة
│
├── controllers/                   ← المتحكمات (MVC)
│   ├── class-aiwpg-admin-controller.php
│   ├── class-aiwpg-images-controller.php
│   ├── class-aiwpg-products-controller.php
│   └── class-aiwpg-settings-controller.php
│
├── models/                        ← النماذج (MVC)
│   ├── class-aiwpg-gemini-client.php
│   ├── class-aiwpg-image-client.php
│   ├── class-aiwpg-logger.php
│   └── class-aiwpg-product-model.php
│
├── views/                         ← العروض (MVC)
│   ├── admin-ai-generator-page.php
│   ├── admin-products-list-page.php
│   └── admin-settings-page.php
│
├── doc/                           ← التوثيق
│   ├── README-AR.md
│   ├── README-EN.md
│   ├── FILE_STRUCTURE.md
│   ├── WORKFLOW.md
│   ├── API_DOCUMENTATION.md
│   └── CODE_DOCUMENTATION.md
│
├── test-extract-image.php         ← اختبار استخراج الصور
└── test-freepik-api.php           ← اختبار Freepik API
```

---

## ملخص سريع

### الملفات الرئيسية:
- **Main**: `ai-woo-product-generator.php` (219 سطر)
- **Controllers**: 4 ملفات (1,255 سطر)
- **Models**: 4 ملفات (2,983 سطر)
- **Views**: 3 ملفات (935 سطر)
- **Assets**: CSS (2,321 سطر) + JS (2,700 سطر)

### إجمالي الأكواد:
- **PHP**: ~5,800 سطر
- **JavaScript**: ~2,700 سطر
- **CSS**: ~2,321 سطر
- **Documentation**: ~3,000 سطر

---

## المزايا المعمارية

### 1. معمارية MVC
- **فصل واضح للمسؤوليات**
- **سهولة الصيانة والتطوير**
- **قابلية إعادة الاستخدام**
- **اختبار أسهل**

### 2. نمط Singleton
- **ضمان نسخة واحدة** من كل class
- **وصول عام** من أي مكان
- **إدارة موارد أفضل**

### 3. نظام Failover
- **5 مفاتيح API** لكل خدمة
- **تبديل تلقائي** عند الفشل
- **معدل نجاح عالي جداً**

### 4. نظام التسجيل
- **تسجيل شامل** لجميع العمليات
- **4 مستويات** (ERROR, WARNING, INFO, DEBUG)
- **تدوير تلقائي** للملفات
- **حماية الخصوصية**

---

**آخر تحديث:** يناير 2024  
**الإصدار:** 1.0.0
