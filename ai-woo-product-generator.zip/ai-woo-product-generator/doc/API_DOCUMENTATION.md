# API Documentation | توثيق الـ API

[English](#english) | [العربية](#arabic)

---

<a name="english"></a>
# 📡 Complete API Documentation

## Overview

This document provides complete documentation for all AJAX endpoints and API integrations in the **AI Woo Product Generator** plugin.

---

## Table of Contents

1. [AJAX Endpoints](#ajax-endpoints)
2. [Product Generation APIs](#product-generation)
3. [Product Management APIs](#product-management)
4. [Image Generation APIs](#image-generation)
5. [Search and Statistics APIs](#search-statistics)
6. [Settings APIs](#settings-apis)
7. [External APIs](#external-apis)
8. [Error Codes](#error-codes)

---

## 1. AJAX Endpoints

### Base URL
```
POST https://yoursite.com/wp-admin/admin-ajax.php
```

### Common Headers
```
Content-Type: application/x-www-form-urlencoded
```

### Common Parameters
```
nonce: string (required) - Security token
action: string (required) - API action name
```

---

## 2. Product Generation APIs

### 2.1 Generate Single Product

**Action**: `aiwpg_generate_single`

**Method**: `POST`

**Parameters**:
```javascript
{
    action: 'aiwpg_generate_single',
    nonce: 'security_token',
    prompt: 'Product description text',
    product_type: 'automatic' | 'simple' | 'variable'
}
```

**Success Response**:
```javascript
{
    success: true,
    data: {
        message: 'Product generated successfully',
        product: {
            product_type: 'simple',
            title: 'Product Name',
            short_description: 'Brief description...',
            long_description: 'Detailed description...',
            sku: 'AIWPG-12345678',
            regular_price: '99.99',
            sale_price: '79.99',
            stock_quantity: 10,
            categories: ['Electronics', 'Accessories'],
            tags: ['wireless', 'bluetooth', 'premium'],
            brand: 'BrandName'
        }
    }
}
```

**Error Response**:
```javascript
{
    success: false,
    data: {
        message: 'Failed to generate product',
        code: 'generation_failed'
    }
}
```

**Example JavaScript**:
```javascript
$.ajax({
    url: aiwpgData.ajaxUrl,
    type: 'POST',
    data: {
        action: 'aiwpg_generate_single',
        nonce: aiwpgData.nonce,
        prompt: 'Premium wireless headphones with noise cancellation',
        product_type: 'automatic'
    },
    success: function(response) {
        if (response.success) {
            console.log('Product:', response.data.product);
        }
    }
});
```

---

### 2.2 Generate Multiple Products

**Action**: `aiwpg_generate_multiple`

**Method**: `POST`

**Parameters**:
```javascript
{
    action: 'aiwpg_generate_multiple',
    nonce: 'security_token',
    prompts: 'Product 1 description | 50\nProduct 2 description | 30',
    product_type: 'automatic' | 'simple' | 'variable'
}
```

**Success Response**:
```javascript
{
    success: true,
    data: {
        message: '3 products generated successfully',
        products: [
            {
                product_type: 'simple',
                title: 'Product 1',
                ...
            },
            {
                product_type: 'variable',
                title: 'Product 2',
                attributes: [...],
                variations: [...],
                ...
            },
            ...
        ]
    }
}
```

**Example JavaScript**:
```javascript
$.ajax({
    url: aiwpgData.ajaxUrl,
    type: 'POST',
    data: {
        action: 'aiwpg_generate_multiple',
        nonce: aiwpgData.nonce,
        prompts: 'Wireless Mouse | 50\nGaming Keyboard | 30\nUSB Hub | 100',
        product_type: 'automatic'
    },
    success: function(response) {
        if (response.success) {
            response.data.products.forEach(function(product) {
                console.log('Product:', product.title);
            });
        }
    }
});
```

---

### 2.3 Generate from Excel

**Action**: `aiwpg_generate_excel`

**Method**: `POST`

**Parameters**:
```javascript
{
    action: 'aiwpg_generate_excel',
    nonce: 'security_token',
    products_data: JSON.stringify([
        {description: 'Product 1', quantity: 50},
        {description: 'Product 2', quantity: 30}
    ])
}
```

**Success Response**:
```javascript
{
    success: true,
    data: {
        message: '2 products generated from Excel',
        products: [...]
    }
}
```

**Example JavaScript**:
```javascript
// Read Excel file
const file = $('#excel-file')[0].files[0];
const reader = new FileReader();

reader.onload = function(e) {
    const data = new Uint8Array(e.target.result);
    const workbook = XLSX.read(data, {type: 'array'});
    const worksheet = workbook.Sheets[workbook.SheetNames[0]];
    const jsonData = XLSX.utils.sheet_to_json(worksheet);
    
    // Send to API
    $.ajax({
        url: aiwpgData.ajaxUrl,
        type: 'POST',
        data: {
            action: 'aiwpg_generate_excel',
            nonce: aiwpgData.nonce,
            products_data: JSON.stringify(jsonData)
        },
        success: function(response) {
            console.log('Products generated:', response.data.products.length);
        }
    });
};

reader.readAsArrayBuffer(file);
```

---

## 3. Product Management APIs

### 3.1 Save Product

**Action**: `aiwpg_save_product`

**Method**: `POST`

**Parameters**:
```javascript
{
    action: 'aiwpg_save_product',
    nonce: 'security_token',
    product: JSON.stringify({
        product_type: 'simple',
        title: 'Product Name',
        short_description: '...',
        long_description: '...',
        sku: 'AIWPG-12345',
        regular_price: '99.99',
        sale_price: '79.99',
        stock_quantity: 10,
        categories: ['Electronics'],
        tags: ['wireless', 'bluetooth'],
        brand: 'BrandName'
    })
}
```

**Success Response**:
```javascript
{
    success: true,
    data: {
        message: 'Product saved successfully',
        product_id: 123
    }
}
```

**Example JavaScript**:
```javascript
$.ajax({
    url: aiwpgData.ajaxUrl,
    type: 'POST',
    data: {
        action: 'aiwpg_save_product',
        nonce: aiwpgData.nonce,
        product: JSON.stringify(productData)
    },
    success: function(response) {
        if (response.success) {
            console.log('Product ID:', response.data.product_id);
            toastr.success('Product saved!');
        }
    }
});
```

---

### 3.2 Save Multiple Products

**Action**: `aiwpg_save_products`

**Method**: `POST`

**Parameters**:
```javascript
{
    action: 'aiwpg_save_products',
    nonce: 'security_token',
    products: JSON.stringify([
        {product_1_data},
        {product_2_data},
        {product_3_data}
    ])
}
```

**Success Response**:
```javascript
{
    success: true,
    data: {
        message: '3 products saved successfully',
        created: 3,
        errors: []
    }
}
```

---

### 3.3 Get Products

**Action**: `aiwpg_get_products`

**Method**: `POST`

**Parameters**:
```javascript
{
    action: 'aiwpg_get_products',
    nonce: 'security_token',
    page: 1,
    per_page: 12,
    search: 'optional_search_term'
}
```

**Success Response**:
```javascript
{
    success: true,
    data: {
        products: [
            {
                id: 123,
                title: 'Product Name',
                short_description: 'Brief description',
                price: '99.99',
                stock_quantity: 50,
                stock_status: 'instock',
                image_url: 'https://...',
                categories: ['Electronics']
            },
            ...
        ],
        total: 150,
        pages: 13,
        current_page: 1
    }
}
```

---

### 3.4 Get Single Product

**Action**: `aiwpg_get_product`

**Method**: `POST`

**Parameters**:
```javascript
{
    action: 'aiwpg_get_product',
    nonce: 'security_token',
    product_id: 123
}
```

**Success Response**:
```javascript
{
    success: true,
    data: {
        product: {
            id: 123,
            title: 'Product Name',
            short_description: '...',
            long_description: '...',
            sku: 'AIWPG-12345',
            regular_price: '99.99',
            sale_price: '79.99',
            price: '79.99',
            
            // Inventory
            manage_stock: true,
            stock_quantity: 50,
            stock_status: 'instock',
            low_stock_threshold: 5,
            sold_individually: false,
            
            // Shipping
            weight: '0.5',
            length: '10',
            width: '10',
            height: '5',
            shipping_class: 'standard',
            shipping_class_id: 1,
            
            // Linked Products
            upsell_ids: [124, 125],
            cross_sell_ids: [126, 127],
            
            // Media
            image_id: 456,
            image_url: 'https://...',
            gallery_ids: [457, 458],
            
            // Variations
            variations: [
                {
                    id: 789,
                    name: 'Black - M',
                    sku: 'AIWPG-12345-BLK-M',
                    price: '79.99',
                    stock_quantity: 10,
                    stock_status: 'instock'
                },
                ...
            ],
            
            // Settings
            status: 'publish',
            catalog_visibility: 'visible',
            featured: false,
            menu_order: 0,
            reviews_allowed: true,
            categories: ['Electronics'],
            tags: ['wireless', 'bluetooth'],
            brand: 'BrandName'
        }
    }
}
```

---

### 3.5 Update Product

**Action**: `aiwpg_update_product`

**Method**: `POST`

**Parameters**:
```javascript
{
    action: 'aiwpg_update_product',
    nonce: 'security_token',
    product_id: 123,
    product: JSON.stringify({
        title: 'Updated Product Name',
        short_description: 'Updated description',
        regular_price: '119.99',
        stock_quantity: 75,
        // ... any fields to update
    })
}
```

**Success Response**:
```javascript
{
    success: true,
    data: {
        message: 'Product updated successfully'
    }
}
```

---

### 3.6 Update Variation

**Action**: `aiwpg_update_variation`

**Method**: `POST`

**Parameters**:
```javascript
{
    action: 'aiwpg_update_variation',
    nonce: 'security_token',
    variation_id: 789,
    variation: JSON.stringify({
        sku: 'AIWPG-12345-BLK-M',
        price: '89.99',
        stock_quantity: 15,
        stock_status: 'instock'
    })
}
```

**Success Response**:
```javascript
{
    success: true,
    data: {
        message: 'Variation updated successfully',
        variation: {
            id: 789,
            sku: 'AIWPG-12345-BLK-M',
            price: '89.99',
            stock_quantity: 15,
            stock_status: 'instock'
        }
    }
}
```

---

### 3.7 Delete Product

**Action**: `aiwpg_delete_product`

**Method**: `POST`

**Parameters**:
```javascript
{
    action: 'aiwpg_delete_product',
    nonce: 'security_token',
    product_id: 123
}
```

**Success Response**:
```javascript
{
    success: true,
    data: {
        message: 'Product deleted successfully'
    }
}
```

---

## 4. Image Generation APIs

### 4.1 Generate Product Image

**Action**: `aiwpg_generate_product_image`

**Method**: `POST`

**Parameters**:
```javascript
{
    action: 'aiwpg_generate_product_image',
    nonce: 'security_token',
    product_id: 123
}
```

**Success Response**:
```javascript
{
    success: true,
    data: {
        message: '✓ Image generated and set successfully (300x300)',
        attachment_id: 456,
        image_url: 'https://example.com/wp-content/uploads/2024/01/product-image.jpg',
        thumbnail_url: 'https://example.com/wp-content/uploads/2024/01/product-image-300x300.jpg'
    }
}
```

**Error Response**:
```javascript
{
    success: false,
    data: {
        message: 'Failed to generate image. Please check: 1) API keys validity, 2) Rate limits, 3) Internet connection',
        technical_details: 'All API keys failed to generate image...'
    }
}
```

**Example JavaScript**:
```javascript
$.ajax({
    url: aiwpgData.ajaxUrl,
    type: 'POST',
    data: {
        action: 'aiwpg_generate_product_image',
        nonce: aiwpgData.nonce,
        product_id: productId
    },
    beforeSend: function() {
        // Show loading indicator
        $('.generate-image-btn').prop('disabled', true);
        $('.generate-image-btn .dashicons').addClass('spin');
    },
    success: function(response) {
        if (response.success) {
            // Update image
            $('.product-image img').attr('src', response.data.thumbnail_url);
            toastr.success('Image generated successfully!');
        }
    },
    complete: function() {
        // Hide loading indicator
        $('.generate-image-btn').prop('disabled', false);
        $('.generate-image-btn .dashicons').removeClass('spin');
    }
});
```

**Processing Time**: 10-30 seconds (varies based on API load)

**Image Specifications**:
- Format: JPEG
- Size: 300x300 pixels
- Style: Professional product photography
- Background: White or transparent
- Quality: Optimized for web

---

## 5. Search and Statistics APIs

### 5.1 Search Products

**Action**: `aiwpg_search_products`

**Method**: `POST`

**Parameters**:
```javascript
{
    action: 'aiwpg_search_products',
    nonce: 'security_token',
    search: 'search_term'
}
```

**Success Response**:
```javascript
{
    success: true,
    data: {
        products: [
            {
                id: 123,
                title: 'Wireless Mouse',
                short_description: 'Ergonomic wireless mouse...',
                image_url: 'https://...',
                price: '29.99'
            },
            {
                id: 124,
                title: 'Wireless Keyboard',
                short_description: 'Mechanical keyboard...',
                image_url: 'https://...',
                price: '59.99'
            },
            ...
        ]
    }
}
```

**Example JavaScript**:
```javascript
// Debounce search
let searchTimeout = null;

$('#product-search').on('input', function() {
    const searchTerm = $(this).val();
    
    clearTimeout(searchTimeout);
    
    if (searchTerm.length === 0) {
        $('#autocomplete-results').hide();
        return;
    }
    
    searchTimeout = setTimeout(function() {
        $.ajax({
            url: aiwpgData.ajaxUrl,
            type: 'POST',
            data: {
                action: 'aiwpg_search_products',
                nonce: aiwpgData.nonce,
                search: searchTerm
            },
            success: function(response) {
                if (response.success) {
                    renderAutocomplete(response.data.products);
                }
            }
        });
    }, 300);
});
```

---

### 5.2 Get Statistics

**Action**: `aiwpg_get_statistics`

**Method**: `POST`

**Parameters**:
```javascript
{
    action: 'aiwpg_get_statistics',
    nonce: 'security_token'
}
```

**Success Response**:
```javascript
{
    success: true,
    data: {
        total: 150,
        published: 120,
        drafts: 30,
        stock_value: 45000.00,
        stock_value_formatted: '$45,000.00',
        out_of_stock: 5
    }
}
```

**Example JavaScript**:
```javascript
function updateStatistics() {
    $.ajax({
        url: aiwpgData.ajaxUrl,
        type: 'POST',
        data: {
            action: 'aiwpg_get_statistics',
            nonce: aiwpgData.nonce
        },
        success: function(response) {
            if (response.success) {
                const stats = response.data;
                $('#stat-total-value').text(stats.total);
                $('#stat-published-value').text(stats.published);
                $('#stat-draft-value').text(stats.drafts);
                $('#stat-value-value').text(stats.stock_value_formatted);
                $('#stat-out-of-stock-value').text(stats.out_of_stock);
            }
        }
    });
}

// Update on page load
$(document).ready(function() {
    updateStatistics();
});
```

---

### 5.3 Get Categories

**Action**: `aiwpg_get_categories`

**Method**: `POST`

**Parameters**:
```javascript
{
    action: 'aiwpg_get_categories',
    nonce: 'security_token'
}
```

**Success Response**:
```javascript
{
    success: true,
    data: {
        categories: [
            {
                id: 1,
                name: 'Electronics',
                slug: 'electronics'
            },
            {
                id: 2,
                name: 'Clothing',
                slug: 'clothing'
            },
            ...
        ]
    }
}
```

---

## 6. Settings APIs

### 6.1 Save Settings

**Action**: `aiwpg_save_settings`

**Method**: `POST`

**Parameters**:
```javascript
{
    action: 'aiwpg_save_settings',
    nonce: 'security_token',
    products_per_page: 12,
    default_stock_status: 'instock',
    auto_publish: true
}
```

**Success Response**:
```javascript
{
    success: true,
    data: {
        message: 'Settings saved successfully'
    }
}
```

---

### 6.2 Delete All Products

**Action**: `aiwpg_delete_all_products`

**Method**: `POST`

**Parameters**:
```javascript
{
    action: 'aiwpg_delete_all_products',
    nonce: 'security_token',
    confirmation: 'DELETE'
}
```

**Success Response**:
```javascript
{
    success: true,
    data: {
        message: '150 products deleted successfully',
        deleted: 150
    }
}
```

---

### 6.3 Delete AI Products

**Action**: `aiwpg_delete_ai_products`

**Method**: `POST`

**Parameters**:
```javascript
{
    action: 'aiwpg_delete_ai_products',
    nonce: 'security_token',
    confirmation: 'DELETE'
}
```

**Success Response**:
```javascript
{
    success: true,
    data: {
        message: '75 AI products deleted successfully',
        deleted: 75
    }
}
```

---

## 7. AI Improvement APIs

### 7.1 Improve Prompt

**Action**: `aiwpg_improve_prompt`

**Method**: `POST`

**Parameters**:
```javascript
{
    action: 'aiwpg_improve_prompt',
    nonce: 'security_token',
    prompt: 'Simple product description'
}
```

**Success Response**:
```javascript
{
    success: true,
    data: {
        improved_prompt: 'Enhanced and detailed product description...',
        message: 'Text improved successfully'
    }
}
```

---

### 7.2 Improve Field

**Action**: `aiwpg_improve_field`

**Method**: `POST`

**Parameters**:
```javascript
{
    action: 'aiwpg_improve_field',
    nonce: 'security_token',
    text: 'Current field text',
    field_name: 'product_description'
}
```

**Success Response**:
```javascript
{
    success: true,
    data: {
        improved_text: 'Improved field text...',
        message: 'Text improved successfully'
    }
}
```

**Example JavaScript**:
```javascript
$('.improve-field-btn').on('click', function() {
    const fieldId = $(this).data('field');
    const currentText = $('#' + fieldId).val();
    const fieldName = $('#' + fieldId).attr('name');
    
    $.ajax({
        url: aiwpgData.ajaxUrl,
        type: 'POST',
        data: {
            action: 'aiwpg_improve_field',
            nonce: aiwpgData.nonce,
            text: currentText,
            field_name: fieldName
        },
        beforeSend: function() {
            $(this).prop('disabled', true).html('<span class="spinner is-active"></span>');
        },
        success: function(response) {
            if (response.success) {
                $('#' + fieldId).val(response.data.improved_text);
                toastr.success('Text improved!');
            }
        },
        complete: function() {
            $(this).prop('disabled', false).html('<span class="dashicons dashicons-admin-tools"></span>');
        }
    });
});
```

---

## 8. External APIs

### 8.1 Google Gemini 2.0 Flash API

**Base URL**: `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent`

**Method**: `POST`

**Headers**:
```
Content-Type: application/json
X-goog-api-key: YOUR_API_KEY
```

**Request Body**:
```json
{
    "contents": [
        {
            "parts": [
                {
                    "text": "Your prompt here..."
                }
            ]
        }
    ]
}
```

**Response**:
```json
{
    "candidates": [
        {
            "content": {
                "parts": [
                    {
                        "text": "Generated content..."
                    }
                ]
            }
        }
    ]
}
```

**Rate Limits**:
- Free tier: 60 requests/minute per API key
- Paid tier: Higher limits based on plan

**Error Codes**:
- `400`: Bad Request (invalid prompt)
- `403`: Forbidden (invalid API key)
- `429`: Too Many Requests (rate limit exceeded)
- `500`: Internal Server Error

---

### 8.2 Freepik AI API (Gemini 2.5 Flash Image Preview)

**Base URL**: `https://api.freepik.com/v1/ai/gemini-2-5-flash-image-preview`

**Method**: `POST`

**Headers**:
```
Content-Type: application/json
x-freepik-api-key: YOUR_API_KEY
```

**Request Body**:
```json
{
    "prompt": "High-quality product photography...",
    "width": 300,
    "height": 300
}
```

**Response (Async)**:
```json
{
    "data": {
        "status": "CREATED",
        "task_id": "task_abc123"
    }
}
```

**Status Check**:
```
GET https://api.freepik.com/v1/ai/gemini-2-5-flash-image-preview/{task_id}
```

**Status Response**:
```json
{
    "data": {
        "status": "COMPLETED",
        "generated": [
            {
                "url": "https://..."
            }
        ]
    }
}
```

**Status Values**:
- `CREATED`: Task created
- `PROCESSING`: Generating image
- `COMPLETED`: Image ready
- `FAILED`: Generation failed

**Rate Limits**: Varies by plan

---

## 9. Error Codes

### HTTP Status Codes

| Code | Meaning | Description |
|------|---------|-------------|
| 200 | OK | Request successful |
| 400 | Bad Request | Invalid parameters |
| 401 | Unauthorized | Authentication failed |
| 403 | Forbidden | Permission denied |
| 404 | Not Found | Resource not found |
| 429 | Too Many Requests | Rate limit exceeded |
| 500 | Internal Server Error | Server error |
| 503 | Service Unavailable | Service temporarily unavailable |

### Custom Error Codes

| Code | Description |
|------|-------------|
| `missing_field` | Required field missing |
| `invalid_format` | Invalid data format |
| `permission_denied` | User lacks permission |
| `not_found` | Resource not found |
| `creation_failed` | Failed to create resource |
| `update_failed` | Failed to update resource |
| `delete_failed` | Failed to delete resource |
| `generation_failed` | AI generation failed |
| `api_error` | External API error |
| `all_keys_failed` | All API keys exhausted |
| `parse_error` | Failed to parse response |
| `invalid_response` | Invalid API response |

---

## 10. Rate Limiting

### Plugin Rate Limiting

```javascript
// Debounce configuration
const DEBOUNCE_DELAY = 300; // ms

// Search debouncing
let searchTimeout = null;
$('#search').on('input', function() {
    clearTimeout(searchTimeout);
    searchTimeout = setTimeout(performSearch, DEBOUNCE_DELAY);
});
```

### API Rate Limiting

**Gemini API**:
- 10 requests per minute per key (plugin enforced)
- 60 requests per minute per key (Google limit)

**Freepik API**:
- Varies by plan
- Plugin polls every 3 seconds for image completion

**Handling Rate Limits**:
```php
// Check rate limit before request
if (!$this->check_rate_limit($key_index)) {
    // Skip to next key
    continue;
}

// Record successful request
$this->record_request($key_index);
```

---

## 11. Authentication & Security

### Nonce Verification

All AJAX requests require nonce verification:

```javascript
// Client-side
data: {
    action: 'aiwpg_generate_single',
    nonce: aiwpgData.nonce,
    ...
}
```

```php
// Server-side
check_ajax_referer('aiwpg_nonce', 'nonce');
```

### Permission Checking

All operations require `manage_woocommerce` capability:

```php
if (!current_user_can('manage_woocommerce')) {
    wp_send_json_error(['message' => 'Permission denied']);
}
```

### Data Sanitization

All input data is sanitized:

```php
$prompt = sanitize_textarea_field($_POST['prompt']);
$product_id = intval($_POST['product_id']);
$search = sanitize_text_field($_POST['search']);
```

---

<a name="arabic"></a>
# 📡 توثيق الـ API الكامل

## نظرة عامة

يوفر هذا المستند توثيقاً كاملاً لجميع نقاط نهاية AJAX وتكاملات API في إضافة **AI Woo Product Generator**.

---

## الفهرس

1. [نقاط نهاية AJAX](#ar-endpoints)
2. [APIs توليد المنتجات](#ar-generation)
3. [APIs إدارة المنتجات](#ar-management)
4. [APIs توليد الصور](#ar-images)
5. [APIs البحث والإحصائيات](#ar-search)
6. [APIs الإعدادات](#ar-settings)
7. [APIs خارجية](#ar-external)
8. [أكواد الأخطاء](#ar-errors)

---

<a name="ar-endpoints"></a>
## 1. نقاط نهاية AJAX

### الرابط الأساسي
```
POST https://yoursite.com/wp-admin/admin-ajax.php
```

### معاملات مشتركة
```javascript
{
    nonce: 'security_token',  // مطلوب
    action: 'api_action'      // مطلوب
}
```

---

<a name="ar-generation"></a>
## 2. APIs توليد المنتجات

### 2.1 توليد منتج واحد

**Action**: `aiwpg_generate_single`

**المعاملات**:
```javascript
{
    action: 'aiwpg_generate_single',
    nonce: 'security_token',
    prompt: 'وصف المنتج',
    product_type: 'automatic' | 'simple' | 'variable'
}
```

**استجابة النجاح**:
```javascript
{
    success: true,
    data: {
        message: 'تم توليد المنتج بنجاح',
        product: {
            product_type: 'simple',
            title: 'اسم المنتج',
            short_description: 'وصف مختصر...',
            long_description: 'وصف تفصيلي...',
            sku: 'AIWPG-12345678',
            regular_price: '99.99',
            sale_price: '79.99',
            stock_quantity: 10,
            categories: ['إلكترونيات'],
            tags: ['لاسلكي', 'بلوتوث'],
            brand: 'اسم العلامة التجارية'
        }
    }
}
```

---

### 2.2 توليد منتجات متعددة

**Action**: `aiwpg_generate_multiple`

**المعاملات**:
```javascript
{
    action: 'aiwpg_generate_multiple',
    nonce: 'security_token',
    prompts: 'منتج 1 | 50\nمنتج 2 | 30',
    product_type: 'automatic'
}
```

---

<a name="ar-images"></a>
## 4. APIs توليد الصور

### 4.1 توليد صورة للمنتج

**Action**: `aiwpg_generate_product_image`

**المعاملات**:
```javascript
{
    action: 'aiwpg_generate_product_image',
    nonce: 'security_token',
    product_id: 123
}
```

**استجابة النجاح**:
```javascript
{
    success: true,
    data: {
        message: '✓ تم توليد الصورة وتعيينها بنجاح (300x300)',
        attachment_id: 456,
        image_url: 'https://...',
        thumbnail_url: 'https://...'
    }
}
```

**مواصفات الصورة**:
- التنسيق: JPEG
- الحجم: 300×300 بكسل
- النمط: تصوير احترافي للمنتجات
- الخلفية: أبيض أو شفاف
- الجودة: محسنة للويب

**وقت المعالجة**: 10-30 ثانية

---

<a name="ar-search"></a>
## 5. APIs البحث والإحصائيات

### 5.1 البحث في المنتجات

**Action**: `aiwpg_search_products`

### 5.2 الحصول على الإحصائيات

**Action**: `aiwpg_get_statistics`

**الاستجابة**:
```javascript
{
    success: true,
    data: {
        total: 150,           // إجمالي المنتجات
        published: 120,       // المنشورة
        drafts: 30,          // المسودات
        stock_value: 45000,  // قيمة المخزون
        out_of_stock: 5      // نفذ المخزون
    }
}
```

---

<a name="ar-settings"></a>
## 6. APIs الإعدادات

### 6.1 حفظ الإعدادات

**Action**: `aiwpg_save_settings`

### 6.2 حذف جميع المنتجات

**Action**: `aiwpg_delete_all_products`

يتطلب تأكيد بكتابة "DELETE"

### 6.3 حذف منتجات AI

**Action**: `aiwpg_delete_ai_products`

يحذف فقط المنتجات المولدة بالإضافة

---

<a name="ar-external"></a>
## 7. APIs خارجية

### 7.1 Google Gemini 2.0 Flash API

**الرابط**: `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent`

**حدود المعدل**:
- المجاني: 60 طلب/دقيقة لكل مفتاح
- المدفوع: حدود أعلى

---

### 7.2 Freepik AI API

**الرابط**: `https://api.freepik.com/v1/ai/gemini-2-5-flash-image-preview`

**حالات التوليد**:
- `CREATED`: تم إنشاء المهمة
- `PROCESSING`: جاري التوليد
- `COMPLETED`: الصورة جاهزة
- `FAILED`: فشل التوليد

---

<a name="ar-errors"></a>
## 9. أكواد الأخطاء

### أكواد HTTP

| الكود | المعنى |
|------|--------|
| 200 | نجح الطلب |
| 400 | طلب غير صحيح |
| 401 | غير مصرح |
| 403 | محظور |
| 404 | غير موجود |
| 429 | طلبات كثيرة جداً |
| 500 | خطأ في الخادم |

### أكواد مخصصة

| الكود | الوصف |
|------|-------|
| `missing_field` | حقل مطلوب مفقود |
| `invalid_format` | تنسيق غير صحيح |
| `permission_denied` | الوصول مرفوض |
| `not_found` | المورد غير موجود |
| `generation_failed` | فشل التوليد |
| `all_keys_failed` | فشلت جميع المفاتيح |

---

## 10. حدود المعدل

### تحديد معدل الإضافة

```php
// الإضافة تفرض 10 طلبات/دقيقة لكل مفتاح
private $rate_limit_per_minute = 10;
```

### معالجة تجاوز الحد

```php
if (!$this->check_rate_limit($key_index)) {
    // الانتقال للمفتاح التالي
    continue;
}
```

---

## 11. المصادقة والأمان

### التحقق من Nonce

```php
check_ajax_referer('aiwpg_nonce', 'nonce');
```

### التحقق من الصلاحيات

```php
if (!current_user_can('manage_woocommerce')) {
    wp_send_json_error(['message' => 'الوصول مرفوض']);
}
```

### تنظيف البيانات

```php
$prompt = sanitize_textarea_field($_POST['prompt']);
$product_id = intval($_POST['product_id']);
```

---

**آخر تحديث:** يناير 2024  
**الإصدار:** 1.0.0
