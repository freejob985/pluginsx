# 🔍 كيف تتحقق من المشاكل بنفسك؟

## خطوات بسيطة جداً 🎯

---

## 1️⃣ افتح Console المتصفح

### في Google Chrome / Edge:
```
اضغط F12 على لوحة المفاتيح
أو
انقر بزر الماوس الأيمن → Inspect → Console
```

### في Firefox:
```
اضغط F12
أو
Ctrl + Shift + K
```

### في Safari:
```
Cmd + Option + C
```

---

## 2️⃣ جرّب الميزة

### مثلاً: Linked Products
```
1. افتح Products List
2. اختر منتج واضغط Edit
3. انتقل إلى تبويب Linked
4. راقب الرسائل في Console
```

### مثلاً: Add Product
```
1. انقر بزر الماوس الأيمن
2. اختر Add Product
3. املأ البيانات
4. اضغط Create Product
5. راقب الرسائل في Console
```

---

## 3️⃣ اقرأ الرسائل

### ✅ رسائل النجاح (باللون الأسود/الأزرق)
```javascript
Loading linked products for product ID: 123
Total products available: 15
Linked products loaded successfully
```
**معناها:** كل شيء تمام! ✅

---

### ⚠️ رسائل التحذير (باللون الأصفر)
```javascript
Total products available: 0
```
**معناها:** لا توجد منتجات متاحة  
**الحل:** أضف منتجات في WooCommerce

---

### ❌ رسائل الخطأ (باللون الأحمر)
```javascript
AJAX error loading linked products
```
**معناها:** حدث خطأ في التحميل  
**الحل:** 
1. حدّث الصفحة (Ctrl + F5)
2. سجل خروج ثم دخول
3. اتصل بالدعم الفني

---

## 4️⃣ الحلول السريعة

### الحل الأول: تحديث الصفحة
```
اضغط Ctrl + F5
(أو Cmd + Shift + R في Mac)
```
✅ يحل معظم المشاكل

---

### الحل الثاني: مسح الـ Cache
```
اضغط Ctrl + Shift + Delete
→ اختر Clear Cache
→ اضغط Clear Data
```

---

### الحل الثالث: تسجيل خروج ودخول
```
اضغط Logout
ثم سجل دخول مرة أخرى
```

---

## 📸 عند طلب المساعدة

إذا لم تُحل المشكلة، أرسل:

### 1. Screenshot من Console
```
F12 → Console → Ctrl + A (لتحديد الكل)
ثم اعمل Screenshot
```

### 2. وصف المشكلة
```
ماذا كنت تفعل؟
ماذا حدث؟
ماذا توقعت أن يحدث؟
```

### 3. معلومات النظام
```
- نوع المتصفح (Chrome/Firefox/Safari)
- نظام التشغيل (Windows/Mac/Linux)
```

---

## 💡 نصائح مهمة

### ✅ دائماً افتح Console قبل التجربة
```
افتح Console أولاً
ثم جرب الميزة
اقرأ الرسائل
```

### ✅ لا تغلق Console بسرعة
```
اقرأ جميع الرسائل
قد تكون مفيدة!
```

### ✅ اعمل Screenshot للرسائل الحمراء
```
كل رسالة حمراء = خطأ مهم
```

---

## 🎓 أمثلة على المشاكل والحلول

### مشكلة: "لا توجد منتجات متاحة"

**Console:**
```
Total products available: 0
```

**السبب:**  
لا توجد منتجات منشورة في WooCommerce

**الحل:**
```
WooCommerce → Products → أضف منتجات
تأكد من أن الحالة = Published
```

---

### مشكلة: "Permission denied"

**Console:**
```
Permission denied
```

**السبب:**  
حسابك ليس Admin

**الحل:**
```
اطلب من Admin أن يعطيك صلاحيات
أو
سجل دخول بحساب Admin
```

---

### مشكلة: "Network error"

**Console:**
```
AJAX error: Network error
```

**السبب:**  
مشكلة في الاتصال بالخادم

**الحل:**
```
1. تحقق من اتصال الإنترنت
2. تحقق من أن الخادم يعمل
3. تحديث الصفحة
```

---

## 📚 المزيد من المساعدة

### للحلول السريعة:
📄 **[QUICK_FIX_GUIDE.md](QUICK_FIX_GUIDE.md)**

### للمشاكل المعقدة:
📄 **[TROUBLESHOOTING.md](TROUBLESHOOTING.md)**

### للمطورين:
📄 **[DEBUGGING_SUMMARY.md](DEBUGGING_SUMMARY.md)**

---

## ✅ الخلاصة

```
افتح Console (F12)
    ↓
جرب الميزة
    ↓
اقرأ الرسائل
    ↓
طبق الحل المناسب
```

**سهل جداً! 🎉**

---

**نصيحة ذهبية:** 💎  
Console هو صديقك الأفضل للتشخيص!  
لا تخف منه - فقط اقرأ الرسائل وستجد الحل 😊

---

**تاريخ التحديث**: نوفمبر 2025  
**الإصدار**: 1.1.0

