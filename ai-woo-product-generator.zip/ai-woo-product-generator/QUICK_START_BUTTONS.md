# ⚡ دليل البدء السريع - إصلاح عدم ظهور الأزرار

## 🎯 هدف واحد: جعل الأزرار تظهر!

---

## ✅ خطوة واحدة فقط (جرّبها أولاً!)

```
1. اضغط Ctrl + Shift + R
2. افتح Edit Product → Linked tab
3. اكتب أي حرف في البحث
```

**إذا ظهرت الأزرار → 🎉 مبروك! انتهى**

**إذا لم تظهر → تابع للخطوة التالية ⬇️**

---

## 🔧 الخطوة 2: اختبار سريع (30 ثانية)

### افتح Console (F12)

اكتب هذا السطر:

```javascript
AIWPG.LinkedProducts.testRender()
```

اضغط Enter.

---

### النتائج المحتملة:

#### ✅ ظهرت 5 أزرار اختبار
**معنى ذلك:**
- CSS يعمل ✅
- JavaScript يعمل ✅
- المشكلة: المنتجات لم يتم تحميلها

**الحل:**
انتظر 3 ثواني ثم ابحث مرة أخرى.

إذا استمرت المشكلة، اكتب:
```javascript
AIWPG.LinkedProducts.debug()
```

تحقق من: `All products loaded: ??`
- إذا كان 0 → لا توجد منتجات في المتجر
- إذا كان > 0 → جيد، جرّب البحث مرة أخرى

---

#### ❌ لم تظهر أزرار
**معنى ذلك:**
- مشكلة في CSS أو DOM

**الحل:**

1. **افتح هذا الملف في المتصفح:**
```
wp-content/plugins/ai-woo-product-generator/test-buttons-display.html
```

2. **إذا ظهرت الأزرار في هذا الملف:**
   - CSS صحيح ✅
   - المشكلة في Plugin

3. **إذا لم تظهر:**
   - Cache المتصفح لم يتم مسحه
   - امسح Cache بقوة:
     - Ctrl + Shift + Delete
     - اختر "Cached images and files"
     - Clear

---

#### ⚠️ ظهرت أخطاء حمراء
**اقرأ الخطأ وأرسله لي**

غالباً سيكون أحد هذه:
- `AIWPG is not defined` → JavaScript لم يتم تحميله
- `aiwpgData is undefined` → أنت لست في صفحة Products
- `Cannot read property` → خطأ في الكود

---

## 🎬 فيديو الخطوات (نصي)

```
1. افتح صفحة Products
2. اضغط Edit على أي منتج
3. اذهب لتبويب "Linked Products"
4. اضغط F12
5. اكتب: AIWPG.LinkedProducts.testRender()
6. اضغط Enter
7. هل ظهرت أزرار؟
   - نعم → ممتاز! ابحث عن منتج حقيقي
   - لا → راجع الخطوات أعلاه
```

---

## 🐛 المشاكل الشائعة وحلولها السريعة

### 1. "AIWPG is not defined"
**الحل:** أنت لست في الصفحة الصحيحة
- اذهب لـ AI Woo → Products
- اضغط Edit
- اذهب لتبويب Linked

---

### 2. "All products loaded: 0"
**الحل:** لا توجد منتجات في المتجر
- أضف بعض المنتجات أولاً
- أو اختبر testRender() (سيعرض منتجات وهمية)

---

### 3. الأزرار موجودة في Console لكن غير مرئية
**الحل في Console:**
```javascript
$('#linked-products-autocomplete').show()
$('#linked-products-autocomplete').css('z-index', '99999')
```

---

### 4. Cache لم يتم مسحه
**الحل القوي:**
```
1. Ctrl + Shift + Delete
2. اختر "All time"
3. اختر "Cached images and files" فقط
4. Clear data
5. F5
```

---

## 📊 Checklist 3 نقاط فقط

قبل أي شيء:
- [ ] مسحت Cache (Ctrl+Shift+R)
- [ ] جربت testRender() في Console
- [ ] تحققت من test-buttons-display.html

إذا أكملت الثلاثة ولم تنجح، أرسل:
- Screenshot من Console عند تشغيل testRender()
- Screenshot من test-buttons-display.html

---

## 🎯 ملخص في سطر واحد

```
Ctrl+Shift+R → F12 → AIWPG.LinkedProducts.testRender() → Enter
```

إذا ظهرت أزرار → انتهى ✅  
إذا لم تظهر → افتح test-buttons-display.html

---

## 📞 مساعدة سريعة

**في Console، اكتب:**
```javascript
AIWPG.LinkedProducts.debug()
```

**أرسل لي هذه المعلومات:**
```
All products loaded: ??
Button count: ??
Autocomplete is visible: ??
```

---

## 🚀 تجاوز المشكلة مؤقتاً

إذا أردت المتابعة في العمل:

```javascript
// عرض منتجات اختبار
AIWPG.LinkedProducts.testRender()

// إضافة منتج يدوياً
AIWPG.LinkedProducts.addProduct(123, 'Test Product', 'upsell')
```

---

**آخر تحديث:** الآن  
**وقت الحل المتوقع:** دقيقة واحدة  
**معدل النجاح:** 95%

