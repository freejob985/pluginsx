<?php
/**
 * Settings Controller
 * Handles settings page and delete operations
 */

if (!defined('ABSPATH')) {
    exit;
}

class AIWPG_Settings_Controller {
    
    /**
     * Single instance
     */
    private static $instance = null;
    
    /**
     * Product model
     */
    private $product_model;
    
    /**
     * Get instance
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructor
     */
    private function __construct() {
        $this->product_model = new AIWPG_Product_Model();
        
        // AJAX actions
        add_action('wp_ajax_aiwpg_save_settings', array($this, 'save_settings'));
        add_action('wp_ajax_aiwpg_delete_all_products', array($this, 'delete_all_products'));
        add_action('wp_ajax_aiwpg_delete_ai_products', array($this, 'delete_ai_products'));
        
        // API Keys management
        add_action('wp_ajax_aiwpg_save_api_keys', array($this, 'save_api_keys'));
        add_action('wp_ajax_aiwpg_test_api_key', array($this, 'test_api_key'));
    }
    
    /**
     * Save settings
     */
    public function save_settings() {
        check_ajax_referer('aiwpg_nonce', 'nonce');
        
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error(array('message' => __('Permission denied', 'ai-woo-product-generator')));
        }
        
        $products_per_page = isset($_POST['products_per_page']) ? intval($_POST['products_per_page']) : 12;
        $default_stock_status = isset($_POST['default_stock_status']) ? sanitize_text_field($_POST['default_stock_status']) : 'instock';
        $auto_publish = isset($_POST['auto_publish']) ? (bool)$_POST['auto_publish'] : false;
        
        $settings = array(
            'products_per_page' => $products_per_page,
            'default_stock_status' => $default_stock_status,
            'auto_publish' => $auto_publish,
        );
        
        update_option('aiwpg_settings', $settings);
        
        wp_send_json_success(array('message' => __('Settings saved successfully', 'ai-woo-product-generator')));
    }
    




    
    /**
     * Delete all products
     */
    public function delete_all_products() {
        check_ajax_referer('aiwpg_nonce', 'nonce');
        
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error(array('message' => __('Permission denied', 'ai-woo-product-generator')));
        }
        
        $confirmation = isset($_POST['confirmation']) ? sanitize_text_field($_POST['confirmation']) : '';
        
        if ($confirmation !== 'DELETE') {
            wp_send_json_error(array('message' => __('Confirmation text is incorrect', 'ai-woo-product-generator')));
        }
        
        $deleted = $this->product_model->delete_all_products();
        
        if (is_wp_error($deleted)) {
            wp_send_json_error(array('message' => $deleted->get_error_message()));
        }
        
        wp_send_json_success(array(
            'message' => sprintf(__('%d products deleted successfully', 'ai-woo-product-generator'), $deleted),
            'deleted' => $deleted,
        ));
    }
    
    /**
     * Delete AI-generated products only
     */
    public function delete_ai_products() {
        check_ajax_referer('aiwpg_nonce', 'nonce');
        
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error(array('message' => __('Permission denied', 'ai-woo-product-generator')));
        }
        
        $confirmation = isset($_POST['confirmation']) ? sanitize_text_field($_POST['confirmation']) : '';
        
        if ($confirmation !== 'DELETE') {
            wp_send_json_error(array('message' => __('Confirmation text is incorrect', 'ai-woo-product-generator')));
        }
        
        $deleted = $this->product_model->delete_all_ai_products();
        
        if (is_wp_error($deleted)) {
            wp_send_json_error(array('message' => $deleted->get_error_message()));
        }
        
        wp_send_json_success(array(
            'message' => sprintf(__('%d AI products deleted successfully', 'ai-woo-product-generator'), $deleted),
            'deleted' => $deleted,
        ));
    }
    
    /**
     * Save API keys to database
     */
    public function save_api_keys() {
        check_ajax_referer('aiwpg_nonce', 'nonce');
        
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error(array('message' => __('Permission denied', 'ai-woo-product-generator')));
        }
        
        $key_type = isset($_POST['key_type']) ? sanitize_text_field($_POST['key_type']) : '';
        
        if (!in_array($key_type, array('gemini', 'freepik'))) {
            wp_send_json_error(array('message' => __('Invalid key type', 'ai-woo-product-generator')));
        }
        
        // Get existing API keys
        $api_keys = get_option('aiwpg_api_keys', array());
        
        // Update keys for the specified type
        for ($i = 1; $i <= 5; $i++) {
            $key_name = $key_type . '_key_' . $i;
            if (isset($_POST[$key_name])) {
                $key_value = sanitize_text_field($_POST[$key_name]);
                // Only store non-empty keys
                if (!empty($key_value)) {
                    $api_keys[$key_type . '_' . $i] = $key_value;
                } else {
                    // Remove empty keys
                    unset($api_keys[$key_type . '_' . $i]);
                }
            }
        }
        
        // Save to database
        update_option('aiwpg_api_keys', $api_keys);
        
        wp_send_json_success(array(
            'message' => sprintf(
                __('%s API keys saved successfully', 'ai-woo-product-generator'),
                ucfirst($key_type)
            ),
        ));
    }
    
    /**
     * Test API key connection
     */
    public function test_api_key() {
        check_ajax_referer('aiwpg_nonce', 'nonce');
        
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error(array('message' => __('Permission denied', 'ai-woo-product-generator')));
        }
        
        $key_type = isset($_POST['key_type']) ? sanitize_text_field($_POST['key_type']) : '';
        $api_key = isset($_POST['api_key']) ? sanitize_text_field($_POST['api_key']) : '';
        
        if (empty($api_key)) {
            wp_send_json_error(array('message' => __('API key is required', 'ai-woo-product-generator')));
        }
        
        if ($key_type === 'gemini') {
            $result = $this->test_gemini_key($api_key);
        } elseif ($key_type === 'freepik') {
            $result = $this->test_freepik_key($api_key);
        } else {
            wp_send_json_error(array('message' => __('Invalid key type', 'ai-woo-product-generator')));
        }
        
        if ($result['success']) {
            wp_send_json_success($result);
        } else {
            wp_send_json_error($result);
        }
    }
    
    /**
     * Test Gemini API key
     */
    private function test_gemini_key($api_key) {
        $url = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent';
        
        $body = array(
            'contents' => array(
                array(
                    'parts' => array(
                        array('text' => 'Hello, test connection')
                    )
                )
            )
        );
        
        $args = array(
            'headers' => array(
                'Content-Type' => 'application/json',
                'X-goog-api-key' => $api_key,
            ),
            'body' => wp_json_encode($body),
            'method' => 'POST',
            'timeout' => 15,
        );
        
        $response = wp_remote_post($url, $args);
        
        if (is_wp_error($response)) {
            return array(
                'success' => false,
                'message' => __('Connection failed: ', 'ai-woo-product-generator') . $response->get_error_message()
            );
        }
        
        $status_code = wp_remote_retrieve_response_code($response);
        
        if ($status_code === 200) {
            return array(
                'success' => true,
                'message' => __('✓ Connection successful! API key is valid.', 'ai-woo-product-generator')
            );
        } else {
            $response_body = wp_remote_retrieve_body($response);
            return array(
                'success' => false,
                'message' => sprintf(
                    __('✗ Connection failed (HTTP %d). Please check your API key.', 'ai-woo-product-generator'),
                    $status_code
                )
            );
        }
    }
    
    /**
     * Test Freepik API key
     */
    private function test_freepik_key($api_key) {
        $url = 'https://api.freepik.com/v1/ai/gemini-2-5-flash-image-preview';
        
        $body = array(
            'prompt' => 'test connection'
        );
        
        $args = array(
            'headers' => array(
                'Content-Type' => 'application/json',
                'x-freepik-api-key' => $api_key
            ),
            'body' => wp_json_encode($body),
            'method' => 'POST',
            'timeout' => 15,
        );
        
        $response = wp_remote_post($url, $args);
        
        if (is_wp_error($response)) {
            return array(
                'success' => false,
                'message' => __('Connection failed: ', 'ai-woo-product-generator') . $response->get_error_message()
            );
        }
        
        $status_code = wp_remote_retrieve_response_code($response);
        
        // Freepik may return 200 or 201 for valid keys
        if ($status_code === 200 || $status_code === 201) {
            return array(
                'success' => true,
                'message' => __('✓ Connection successful! API key is valid.', 'ai-woo-product-generator')
            );
        } elseif ($status_code === 401 || $status_code === 403) {
            return array(
                'success' => false,
                'message' => __('✗ Invalid API key or unauthorized access.', 'ai-woo-product-generator')
            );
        } else {
            return array(
                'success' => false,
                'message' => sprintf(
                    __('✗ Connection failed (HTTP %d). Please check your API key.', 'ai-woo-product-generator'),
                    $status_code
                )
            );
        }
    }
}
