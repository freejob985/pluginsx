<?php
/**
 * Images Controller
 * 
 * Handles image generation requests and AJAX endpoints
 *
 * @package AI_Woo_Product_Generator
 */

if (!defined('ABSPATH')) {
    exit;
}

class AIWPG_Images_Controller {
    /**
     * Single instance
     */
    private static $instance = null;
    
    /**
     * Image client instance
     */
    private $image_client;

    /**
     * Logger instance
     */
    private $logger;

    /**
     * Get instance
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructor
     */
    private function __construct() {
        $this->image_client = new AIWPG_Image_Client();
        $this->logger = AIWPG_Logger::get_instance();
        
        // Register AJAX handlers
        add_action('wp_ajax_aiwpg_generate_product_image', [$this, 'ajax_generate_product_image']);
    }

    /**
     * AJAX handler for generating product image
     */
    public function ajax_generate_product_image() {
        // Check nonce
        check_ajax_referer('aiwpg_nonce', 'nonce');

        // Check permissions
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error([
                'message' => 'Unauthorized access'
            ]);
        }

        // Get product ID
        $product_id = isset($_POST['product_id']) ? intval($_POST['product_id']) : 0;

        if (!$product_id) {
            wp_send_json_error([
                'message' => 'Invalid product ID'
            ]);
        }

        // Get product
        $product = wc_get_product($product_id);

        if (!$product) {
            wp_send_json_error([
                'message' => 'Product not found'
            ]);
        }

        $product_name = $product->get_name();
        $product_description = $product->get_short_description();
        if (empty($product_description)) {
            $product_description = wp_strip_all_tags($product->get_description());
            // Limit to 200 chars
            if (strlen($product_description) > 200) {
                $product_description = substr($product_description, 0, 200) . '...';
            }
        }
        
        // Get product categories
        $categories = wp_get_post_terms($product_id, 'product_cat', ['fields' => 'names']);
        $category_names = is_array($categories) ? $categories : [];
        
        
        // Build product data array
        $product_data = [
            'categories' => $category_names,
            'tags' => wp_get_post_terms($product_id, 'product_tag', ['fields' => 'names'])
        ];

        $this->logger->log("Generating image for product: {$product_name} (ID: {$product_id})", 'info');
        $this->logger->log("Product description: " . substr($product_description, 0, 100), 'debug');
        $this->logger->log("Product categories: " . implode(', ', $category_names), 'debug');

        // Generate image with product details
        $this->logger->log("⏳ بدء توليد الصورة للمنتج: {$product_name}", 'info');
        
        $result = $this->image_client->generate_product_image($product_name, $product_description, $product_data);

        if (!$result['success']) {
            $this->logger->log("✗ فشل توليد الصورة: " . $result['error'], 'error');
            
            // Provide user-friendly error message with details
            $user_message = 'فشل في توليد الصورة. ';
            
            if (isset($result['detailed_errors']) && is_array($result['detailed_errors'])) {
                $user_message .= 'يرجى التحقق من: ';
                $user_message .= '1) صحة مفاتيح API، ';
                $user_message .= '2) عدم تجاوز الحد المسموح، ';
                $user_message .= '3) اتصال الإنترنت مستقر. ';
                $user_message .= 'راجع السجلات للتفاصيل.';
            } else {
                $user_message .= $result['error'];
            }
            
            wp_send_json_error([
                'message' => $user_message,
                'technical_details' => $result['error']
            ]);
        }

        // Set as product featured image
        $attachment_id = $result['attachment_id'];
        set_post_thumbnail($product_id, $attachment_id);

        $this->logger->log("✓ تم تعيين الصورة كصورة مميزة للمنتج {$product_id}", 'info');

        // Get thumbnail URL (300x300)
        $thumbnail_url = isset($result['thumbnail_url']) ? $result['thumbnail_url'] : wp_get_attachment_image_url($attachment_id, 'aiwpg_product_thumbnail');
        if (!$thumbnail_url) {
            $thumbnail_url = wp_get_attachment_image_url($attachment_id, 'thumbnail');
            if (!$thumbnail_url) {
                $thumbnail_url = $result['url'];
            }
        }
        
        // Return success with image data
        wp_send_json_success([
            'message' => '✓ تم توليد الصورة وتعيينها بنجاح (300x300)',
            'attachment_id' => $attachment_id,
            'image_url' => $result['url'],
            'thumbnail_url' => $thumbnail_url
        ]);
        
        $this->logger->log("✓ اكتملت العملية بنجاح - Attachment ID: {$attachment_id}", 'info');
    }

    /**
     * Generate image for product programmatically
     *
     * @param int $product_id Product ID
     * @return array Result
     */
    public function generate_for_product($product_id) {
        $product = wc_get_product($product_id);

        if (!$product) {
            return [
                'success' => false,
                'error' => 'Product not found'
            ];
        }

        $product_name = $product->get_name();
        $product_description = $product->get_short_description();
        if (empty($product_description)) {
            $product_description = wp_strip_all_tags($product->get_description());
            if (strlen($product_description) > 200) {
                $product_description = substr($product_description, 0, 200) . '...';
            }
        }
        
        // Get product categories
        $categories = wp_get_post_terms($product_id, 'product_cat', ['fields' => 'names']);
        
        $product_data = [
            'categories' => is_array($categories) ? $categories : [],
            'tags' => wp_get_post_terms($product_id, 'product_tag', ['fields' => 'names'])
        ];
        
        $result = $this->image_client->generate_product_image($product_name, $product_description, $product_data);

        if ($result['success']) {
            set_post_thumbnail($product_id, $result['attachment_id']);
        }

        return $result;
    }

    /**
     * Generate image from custom prompt
     *
     * @param string $prompt Custom prompt
     * @param array $reference_images Reference images
     * @return array Result
     */
    public function generate_from_prompt($prompt, $reference_images = []) {
        return $this->image_client->generate_image($prompt, $reference_images);
    }
}
