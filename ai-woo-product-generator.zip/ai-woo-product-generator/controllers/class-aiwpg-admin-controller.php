<?php
/**
 * Admin Controller
 * Handles admin menu, pages, and asset loading
 */

if (!defined('ABSPATH')) {
    exit;
}

class AIWPG_Admin_Controller {
    
    /**
     * Single instance
     */
    private static $instance = null;
    
    /**
     * Get instance
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructor
     */
    private function __construct() {
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_assets'));
    }
    
    /**
     * Add admin menu
     */
    public function add_admin_menu() {
        // Main menu
        add_menu_page(
            __('AI Product Generator', 'ai-woo-product-generator'),
            __('AI Products', 'ai-woo-product-generator'),
            'manage_woocommerce',
            'aiwpg-generator',
            array($this, 'render_generator_page'),
            'dashicons-products',
            56
        );
        
        // Generator submenu (same as main)
        add_submenu_page(
            'aiwpg-generator',
            __('Generate Products', 'ai-woo-product-generator'),
            __('Generate Products', 'ai-woo-product-generator'),
            'manage_woocommerce',
            'aiwpg-generator',
            array($this, 'render_generator_page')
        );
        
        // Products list
        add_submenu_page(
            'aiwpg-generator',
            __('Products List', 'ai-woo-product-generator'),
            __('Products List', 'ai-woo-product-generator'),
            'manage_woocommerce',
            'aiwpg-products',
            array($this, 'render_products_page')
        );
        
        // Settings
        add_submenu_page(
            'aiwpg-generator',
            __('Settings', 'ai-woo-product-generator'),
            __('Settings', 'ai-woo-product-generator'),
            'manage_woocommerce',
            'aiwpg-settings',
            array($this, 'render_settings_page')
        );
    }
    

    /**
     * Enqueue admin assets
     */
    public function enqueue_assets($hook) {
        // Only load on our plugin pages
        if (strpos($hook, 'aiwpg-') === false && strpos($hook, 'ai-products') === false) {
            return;
        }
        
        // Determine current page
        $is_generator_page = strpos($hook, 'aiwpg-generator') !== false || strpos($hook, 'ai-products_page_aiwpg-generator') !== false;
        $is_products_page = strpos($hook, 'aiwpg-products') !== false && strpos($hook, 'aiwpg-generator') === false;
        $is_settings_page = strpos($hook, 'aiwpg-settings') !== false;
        
        // CSS - Load on all plugin pages
        wp_enqueue_style(
            'aiwpg-admin',
            AIWPG_PLUGIN_URL . 'assets/css/aiwpg-admin.css',
            array(),
            AIWPG_VERSION . '-' . time() // Cache busting for development
        );
        
        // External CSS - Toastr (all pages)
        wp_enqueue_style(
            'toastr-css',
            'https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.1.4/toastr.min.css',
            array(),
            '2.1.4'
        );
        
        // Tagify CSS for tags input (only products list page)
        if ($is_products_page) {
            wp_enqueue_style(
                'tagify-css',
                'https://cdn.jsdelivr.net/npm/@yaireo/tagify/dist/tagify.css',
                array(),
                '4.17.9'
            );
        }
        
        // JavaScript - Load jQuery first (all pages)
        wp_enqueue_script('jquery');
        
        // WordPress Media Library (for image uploads in products page)
        if ($is_products_page) {
            wp_enqueue_media();
        }
        
        // External JS - SweetAlert2 (products list and settings pages)
        if ($is_products_page || $is_settings_page) {
            wp_enqueue_script(
                'sweetalert2',
                'https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.all.min.js',
                array(),
                '11.0.0',
                true
            );
        }
        
        // External JS - Toastr (all pages)
        wp_enqueue_script(
            'toastr-js',
            'https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.1.4/toastr.min.js',
            array('jquery'),
            '2.1.4',
            true
        );
        
        // SheetJS for Excel handling (only generator page)
        if ($is_generator_page) {
            wp_enqueue_script(
                'xlsx-js',
                'https://cdn.sheetjs.com/xlsx-0.20.0/package/dist/xlsx.full.min.js',
                array(),
                '0.20.0',
                true
            );
        }
        
        // Tagify JS for tags input (only products list page)
        if ($is_products_page) {
            wp_enqueue_script(
                'tagify-js',
                'https://cdn.jsdelivr.net/npm/@yaireo/tagify',
                array('jquery'),
                '4.17.9',
                true
            );
        }
        
        // Our admin JS - Load modular files based on current page
        
        // Shared modules (load on all pages)
        wp_enqueue_script(
            'aiwpg-common-js',
            AIWPG_PLUGIN_URL . 'assets/js/shared/common.js',
            array('jquery', 'toastr-js'),
            AIWPG_VERSION . '-' . time(),
            true
        );
        
        wp_enqueue_script(
            'aiwpg-tabs-js',
            AIWPG_PLUGIN_URL . 'assets/js/shared/tabs.js',
            array('jquery'),
            AIWPG_VERSION . '-' . time(),
            true
        );
        
        wp_enqueue_script(
            'aiwpg-modals-js',
            AIWPG_PLUGIN_URL . 'assets/js/shared/modals.js',
            array('jquery'),
            AIWPG_VERSION . '-' . time(),
            true
        );
        
        wp_enqueue_script(
            'aiwpg-context-menu-js',
            AIWPG_PLUGIN_URL . 'assets/js/shared/context-menu.js',
            array('jquery', 'aiwpg-common-js'),
            AIWPG_VERSION . '-' . time(),
            true
        );
        
        // ========== Generator Page Only ==========
        if ($is_generator_page) {
            wp_enqueue_script(
                'aiwpg-generate-init-js',
                AIWPG_PLUGIN_URL . 'assets/js/generate_products/init.js',
                array('jquery'),
                AIWPG_VERSION . '-' . time(),
                true
            );
            
            wp_enqueue_script(
                'aiwpg-product-type-toggle-js',
                AIWPG_PLUGIN_URL . 'assets/js/generate_products/product-type-toggle.js',
                array('jquery'),
                AIWPG_VERSION . '-' . time(),
                true
            );
            
            wp_enqueue_script(
                'aiwpg-single-product-js',
                AIWPG_PLUGIN_URL . 'assets/js/generate_products/single-product.js',
                array('jquery', 'aiwpg-common-js'),
                AIWPG_VERSION . '-' . time(),
                true
            );
            
            wp_enqueue_script(
                'aiwpg-multiple-products-js',
                AIWPG_PLUGIN_URL . 'assets/js/generate_products/multiple-products.js',
                array('jquery', 'aiwpg-common-js'),
                AIWPG_VERSION . '-' . time(),
                true
            );
            
            wp_enqueue_script(
                'aiwpg-excel-import-js',
                AIWPG_PLUGIN_URL . 'assets/js/generate_products/excel-import.js',
                array('jquery', 'xlsx-js', 'aiwpg-common-js'),
                AIWPG_VERSION . '-' . time(),
                true
            );
            
            wp_enqueue_script(
                'aiwpg-voice-input-js',
                AIWPG_PLUGIN_URL . 'assets/js/generate_products/voice-input.js',
                array('jquery'),
                AIWPG_VERSION . '-' . time(),
                true
            );
            
            wp_enqueue_script(
                'aiwpg-improve-prompts-js',
                AIWPG_PLUGIN_URL . 'assets/js/generate_products/improve-prompts.js',
                array('jquery', 'aiwpg-common-js'),
                AIWPG_VERSION . '-' . time(),
                true
            );
            
            wp_enqueue_script(
                'aiwpg-prompt-template-js',
                AIWPG_PLUGIN_URL . 'assets/js/generate_products/prompt-template.js',
                array('jquery', 'aiwpg-common-js'),
                AIWPG_VERSION . '-' . time(),
                true
            );
        }
        
        // ========== Products List Page Only ==========
        if ($is_products_page) {
            wp_enqueue_script(
                'aiwpg-products-list-init-js',
                AIWPG_PLUGIN_URL . 'assets/js/products_list/init.js',
                array('jquery'),
                AIWPG_VERSION . '-' . time(),
                true
            );
            
            wp_enqueue_script(
                'aiwpg-statistics-js',
                AIWPG_PLUGIN_URL . 'assets/js/products_list/statistics.js',
                array('jquery'),
                AIWPG_VERSION . '-' . time(),
                true
            );
            
            wp_enqueue_script(
                'aiwpg-products-display-js',
                AIWPG_PLUGIN_URL . 'assets/js/products_list/products-display.js',
                array('jquery', 'aiwpg-common-js'),
                AIWPG_VERSION . '-' . time(),
                true
            );
            
            wp_enqueue_script(
                'aiwpg-pagination-js',
                AIWPG_PLUGIN_URL . 'assets/js/products_list/pagination.js',
                array('jquery'),
                AIWPG_VERSION . '-' . time(),
                true
            );
            
            wp_enqueue_script(
                'aiwpg-search-js',
                AIWPG_PLUGIN_URL . 'assets/js/products_list/search.js',
                array('jquery', 'aiwpg-common-js'),
                AIWPG_VERSION . '-' . time(),
                true
            );
            
            wp_enqueue_script(
                'aiwpg-view-modal-js',
                AIWPG_PLUGIN_URL . 'assets/js/products_list/view-modal.js',
                array('jquery', 'aiwpg-common-js'),
                AIWPG_VERSION . '-' . time(),
                true
            );
            
            // ⚠️ IMPORTANT: linked-products-js MUST be loaded BEFORE edit-modal-js
            wp_enqueue_script(
                'aiwpg-linked-products-js',
                AIWPG_PLUGIN_URL . 'assets/js/products_list/linked-products.js',
                array('jquery', 'aiwpg-common-js'),
                AIWPG_VERSION . '-' . time(),
                true
            );
            
            wp_enqueue_script(
                'aiwpg-edit-modal-js',
                AIWPG_PLUGIN_URL . 'assets/js/products_list/edit-modal.js',
                array('jquery', 'tagify-js', 'aiwpg-common-js', 'aiwpg-linked-products-js'),
                AIWPG_VERSION . '-' . time(),
                true
            );
            
            wp_enqueue_script(
                'aiwpg-image-generation-js',
                AIWPG_PLUGIN_URL . 'assets/js/products_list/image-generation.js',
                array('jquery', 'aiwpg-common-js'),
                AIWPG_VERSION . '-' . time(),
                true
            );
            
            wp_enqueue_script(
                'aiwpg-variations-js',
                AIWPG_PLUGIN_URL . 'assets/js/products_list/variations.js',
                array('jquery', 'aiwpg-common-js'),
                AIWPG_VERSION . '-' . time(),
                true
            );
            
            wp_enqueue_script(
                'aiwpg-addons-tab-js',
                AIWPG_PLUGIN_URL . 'assets/js/products_list/addons-tab.js',
                array('jquery', 'aiwpg-common-js'),
                AIWPG_VERSION . '-' . time(),
                true
            );
            
            wp_enqueue_script(
                'aiwpg-add-product-modal-js',
                AIWPG_PLUGIN_URL . 'assets/js/products_list/add-product-modal.js',
                array('jquery', 'aiwpg-common-js'),
                AIWPG_VERSION . '-' . time(),
                true
            );
        }
        
        // ========== Settings Page Only ==========
        if ($is_settings_page) {
            wp_enqueue_script(
                'aiwpg-settings-init-js',
                AIWPG_PLUGIN_URL . 'assets/js/settings/init.js',
                array('jquery'),
                AIWPG_VERSION . '-' . time(),
                true
            );
            
            wp_enqueue_script(
                'aiwpg-settings-form-js',
                AIWPG_PLUGIN_URL . 'assets/js/settings/settings-form.js',
                array('jquery'),
                AIWPG_VERSION . '-' . time(),
                true
            );
            
            wp_enqueue_script(
                'aiwpg-delete-products-js',
                AIWPG_PLUGIN_URL . 'assets/js/settings/delete-products.js',
                array('jquery', 'sweetalert2'),
                AIWPG_VERSION . '-' . time(),
                true
            );
            
            wp_enqueue_script(
                'aiwpg-api-keys-js',
                AIWPG_PLUGIN_URL . 'assets/js/settings/api-keys.js',
                array('jquery', 'aiwpg-common-js'),
                AIWPG_VERSION . '-' . time(),
                true
            );
            
            wp_enqueue_script(
                'aiwpg-addons-import-js',
                AIWPG_PLUGIN_URL . 'assets/js/settings/addons-import.js',
                array('jquery', 'aiwpg-common-js'),
                AIWPG_VERSION . '-' . time(),
                true
            );
            
            wp_enqueue_script(
                'aiwpg-cron-job-js',
                AIWPG_PLUGIN_URL . 'assets/js/settings/cron-job.js',
                array('jquery', 'aiwpg-common-js'),
                AIWPG_VERSION . '-' . time(),
                true
            );
        }
        
        // Main initialization file (load last on all pages)
        $main_dependencies = array('jquery', 'toastr-js', 'aiwpg-common-js');
        
        // Add page-specific dependencies
        if ($is_generator_page) {
            $main_dependencies[] = 'xlsx-js';
        }
        if ($is_products_page || $is_settings_page) {
            $main_dependencies[] = 'sweetalert2';
        }
        
        wp_enqueue_script(
            'aiwpg-main-js',
            AIWPG_PLUGIN_URL . 'assets/js/main.js',
            $main_dependencies,
            AIWPG_VERSION . '-' . time(),
            true
        );
        
        // Localize script - Must be called after enqueue
        wp_localize_script('aiwpg-main-js', 'aiwpgData', array(
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('aiwpg_nonce'),
            'pluginUrl' => AIWPG_PLUGIN_URL,
            'templateUrl' => AIWPG_PLUGIN_URL . 'assets/template/products-template.xlsx',
            'generatePageUrl' => admin_url('admin.php?page=aiwpg-generator'),
            'productsListPageUrl' => admin_url('admin.php?page=aiwpg-products'),
            'settingsPageUrl' => admin_url('admin.php?page=aiwpg-settings'),
            'strings' => array(
                'confirmDelete' => __('Are you sure?', 'ai-woo-product-generator'),
                'confirmDeleteAll' => __('This will delete ALL products. Type DELETE to confirm:', 'ai-woo-product-generator'),
                'generating' => __('Generating...', 'ai-woo-product-generator'),
                'success' => __('Success!', 'ai-woo-product-generator'),
                'error' => __('Error!', 'ai-woo-product-generator'),
                'saved' => __('Product saved successfully', 'ai-woo-product-generator'),
                'deleted' => __('Product deleted successfully', 'ai-woo-product-generator'),
            ),
        ));
        
        // Add inline script to verify libraries are loaded
        wp_add_inline_script('aiwpg-main-js', '
            console.log("AIWPG: Admin JS loaded");
            console.log("AIWPG: jQuery version:", jQuery.fn.jquery);
            console.log("AIWPG: Swal available:", typeof Swal !== "undefined");
            console.log("AIWPG: Toastr available:", typeof toastr !== "undefined");
            console.log("AIWPG: XLSX available:", typeof XLSX !== "undefined");
            console.log("AIWPG: aiwpgData:", aiwpgData);
        ', 'before');
    }
    
    /**
     * Render generator page
     */
    public function render_generator_page() {
        include AIWPG_PLUGIN_DIR . 'views/admin-ai-generator-page.php';
    }
    
    /**
     * Render products list page
     */
    public function render_products_page() {
        include AIWPG_PLUGIN_DIR . 'views/admin-products-list-page.php';
    }
    
    /**
     * Render settings page
     */
    public function render_settings_page() {
        include AIWPG_PLUGIN_DIR . 'views/admin-settings-page.php';
    }
}
