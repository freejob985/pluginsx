<?php
/**
 * Products Controller
 * Handles AJAX requests for product operations
 */

if (!defined('ABSPATH')) {
    exit;
}




class AIWPG_Products_Controller {
    
    /**
     * Single instance
     */
    private static $instance = null;
    
    /**
     * Gemini client
     */
    private $gemini_client;
    
    /**
     * Product model
     */
    private $product_model;
    

    
    /**
     * Logger
     */
    private $logger;
    
    /**
     * Get instance
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructor
     */

     
    private function __construct() {
        $this->gemini_client = new AIWPG_Gemini_Client();
        $this->product_model = new AIWPG_Product_Model();
        $this->logger = AIWPG_Logger::get_instance();
        
        // AJAX actions
        add_action('wp_ajax_aiwpg_generate_single', array($this, 'generate_single_product'));
        add_action('wp_ajax_aiwpg_generate_multiple', array($this, 'generate_multiple_products'));
        add_action('wp_ajax_aiwpg_generate_excel', array($this, 'generate_from_excel'));
        add_action('wp_ajax_aiwpg_save_product', array($this, 'save_product'));
        add_action('wp_ajax_aiwpg_save_products', array($this, 'save_products'));
        add_action('wp_ajax_aiwpg_get_products', array($this, 'get_products'));
        add_action('wp_ajax_aiwpg_search_products', array($this, 'search_products'));
        add_action('wp_ajax_aiwpg_get_product', array($this, 'get_product'));
        add_action('wp_ajax_aiwpg_update_product', array($this, 'update_product'));
        add_action('wp_ajax_aiwpg_update_variation', array($this, 'update_variation'));
        add_action('wp_ajax_aiwpg_delete_product', array($this, 'delete_product'));
        add_action('wp_ajax_aiwpg_get_statistics', array($this, 'get_statistics'));
        add_action('wp_ajax_aiwpg_improve_prompt', array($this, 'improve_prompt'));
        add_action('wp_ajax_aiwpg_improve_field', array($this, 'improve_field'));
        add_action('wp_ajax_aiwpg_get_categories', array($this, 'get_categories'));
    }
    
    /**
     * Generate single product
     */
    public function generate_single_product() {
        check_ajax_referer('aiwpg_nonce', 'nonce');
        
        if (!current_user_can('manage_woocommerce')) {
            $this->logger->log('Permission denied for generate_single_product', 'products_controller', array(), 'warning');
            wp_send_json_error(array('message' => __('Permission denied', 'ai-woo-product-generator')));
        }
        
        

        
        $prompt = isset($_POST['prompt']) ? sanitize_textarea_field($_POST['prompt']) : '';
        $product_type = isset($_POST['product_type']) ? sanitize_text_field($_POST['product_type']) : 'automatic';
        
        if (empty($prompt)) {
            $this->logger->log('Empty prompt for generate_single_product', 'products_controller', array(), 'warning');
            wp_send_json_error(array('message' => __('Prompt is required', 'ai-woo-product-generator')));
        }
        
        try {
            $result = $this->gemini_client->generate_single_product($prompt, $product_type);
            
            if (is_wp_error($result)) {
                $this->logger->log(
                    'Failed to generate single product',
                    'products_controller',
                    array('error' => $result->get_error_message(), 'prompt' => substr($prompt, 0, 100)),
                    'error'
                );
                wp_send_json_error(array('message' => $result->get_error_message()));
            }
            
            $this->logger->log(
                'Single product generated successfully',
                'products_controller',
                array('prompt_length' => strlen($prompt)),
                'info'
            );
            
            wp_send_json_success(array(
                'message' => __('Product generated successfully', 'ai-woo-product-generator'),
                'product' => $result,
            ));
        } catch (Exception $e) {
            $this->logger->log(
                'Exception in generate_single_product',
                'products_controller',
                array('exception' => $e->getMessage(), 'trace' => $e->getTraceAsString()),
                'error'
            );
            wp_send_json_error(array('message' => __('An error occurred. Please try again.', 'ai-woo-product-generator')));
        }
    }
    
    /**
     * Generate multiple products from textarea
     */
    public function generate_multiple_products() {
        check_ajax_referer('aiwpg_nonce', 'nonce');
        
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error(array('message' => __('Permission denied', 'ai-woo-product-generator')));
        }
        
        $prompts_text = isset($_POST['prompts']) ? sanitize_textarea_field($_POST['prompts']) : '';
        $product_type = isset($_POST['product_type']) ? sanitize_text_field($_POST['product_type']) : 'automatic';
        
        if (empty($prompts_text)) {
            wp_send_json_error(array('message' => __('Product descriptions are required', 'ai-woo-product-generator')));
        }
        
        // Split by lines
        $lines = array_filter(array_map('trim', explode("\n", $prompts_text)));
        
        if (empty($lines)) {
            wp_send_json_error(array('message' => __('No valid product descriptions found', 'ai-woo-product-generator')));
        }
        
        // Parse each line
        $prompts = array();
        foreach ($lines as $line) {
            // Check if line contains pipe separator
            if (strpos($line, '|') !== false) {
                $parts = array_map('trim', explode('|', $line, 2));
                $prompts[] = array(
                    'description' => $parts[0],
                    'quantity' => isset($parts[1]) && is_numeric($parts[1]) ? intval($parts[1]) : 10,
                );
            } else {
                $prompts[] = array(
                    'description' => $line,
                    'quantity' => 10,
                );
            }
        }
        
        $result = $this->gemini_client->generate_multiple_products($prompts, $product_type);
        
        if (is_wp_error($result)) {
            wp_send_json_error(array('message' => $result->get_error_message()));
        }
        
        wp_send_json_success(array(
            'message' => sprintf(__('%d products generated successfully', 'ai-woo-product-generator'), count($result)),
            'products' => $result,
        ));
    }
    
    /**
     * Generate products from Excel file
     */
    public function generate_from_excel() {
        check_ajax_referer('aiwpg_nonce', 'nonce');
        
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error(array('message' => __('Permission denied', 'ai-woo-product-generator')));
        }
        
        // This is handled on the client side with SheetJS
        // The client will parse the Excel and send the data as JSON
        $products_data = isset($_POST['products_data']) ? json_decode(stripslashes($_POST['products_data']), true) : array();
        
        if (empty($products_data)) {
            wp_send_json_error(array('message' => __('No valid product data found in file', 'ai-woo-product-generator')));
        }
        
        $result = $this->gemini_client->generate_multiple_products($products_data);
        
        if (is_wp_error($result)) {
            wp_send_json_error(array('message' => $result->get_error_message()));
        }
        
        wp_send_json_success(array(
            'message' => sprintf(__('%d products generated from Excel', 'ai-woo-product-generator'), count($result)),
            'products' => $result,
        ));
    }
    
    /**
     * Save single product
     */
    public function save_product() {
        check_ajax_referer('aiwpg_nonce', 'nonce');
        
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error(array('message' => __('Permission denied', 'ai-woo-product-generator')));
        }
        
        $product_data = isset($_POST['product']) ? json_decode(stripslashes($_POST['product']), true) : array();
        
        if (empty($product_data)) {
            wp_send_json_error(array('message' => __('Product data is required', 'ai-woo-product-generator')));
        }
        
        $product_id = $this->product_model->create_product($product_data);
        
        if (is_wp_error($product_id)) {
            wp_send_json_error(array('message' => $product_id->get_error_message()));
        }
        
        wp_send_json_success(array(
            'message' => __('Product saved successfully', 'ai-woo-product-generator'),
            'product_id' => $product_id,
        ));
    }
    
    /**
     * Save multiple products
     */
    public function save_products() {
        check_ajax_referer('aiwpg_nonce', 'nonce');
        
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error(array('message' => __('Permission denied', 'ai-woo-product-generator')));
        }
        
        $products_data = isset($_POST['products']) ? json_decode(stripslashes($_POST['products']), true) : array();
        
        if (empty($products_data)) {
            wp_send_json_error(array('message' => __('Products data is required', 'ai-woo-product-generator')));
        }
        
        $created = array();
        $errors = array();
        
        foreach ($products_data as $index => $product_data) {
            $product_id = $this->product_model->create_product($product_data);
            
            if (is_wp_error($product_id)) {
                $errors[] = sprintf(__('Product #%d: %s', 'ai-woo-product-generator'), $index + 1, $product_id->get_error_message());
            } else {
                $created[] = $product_id;
            }
        }
        
        wp_send_json_success(array(
            'message' => sprintf(__('%d products saved successfully', 'ai-woo-product-generator'), count($created)),
            'created' => count($created),
            'errors' => $errors,
        ));
    }
    
    /**
     * Get products with pagination
     */
    public function get_products() {
        check_ajax_referer('aiwpg_nonce', 'nonce');
        
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error(array('message' => __('Permission denied', 'ai-woo-product-generator')));
        }
        
        $page = isset($_POST['page']) ? intval($_POST['page']) : 1;
        $per_page = isset($_POST['per_page']) ? intval($_POST['per_page']) : 12;
        $search = isset($_POST['search']) ? sanitize_text_field($_POST['search']) : '';
        
        $result = $this->product_model->get_products($page, $per_page, $search);
        
        wp_send_json_success($result);
    }
    
    /**
     * Search products (autocomplete)
     */
    public function search_products() {
        check_ajax_referer('aiwpg_nonce', 'nonce');
        
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error(array('message' => __('Permission denied', 'ai-woo-product-generator')));
        }
        
        $search = isset($_POST['search']) ? sanitize_text_field($_POST['search']) : '';
        
        if (empty($search)) {
            wp_send_json_error(array('message' => __('Please enter a search term', 'ai-woo-product-generator')));
        }
        
        $products = $this->product_model->search_products($search, 4);
        
        wp_send_json_success(array('products' => $products));
    }
    
    /**
     * Get single product
     */
    public function get_product() {
        check_ajax_referer('aiwpg_nonce', 'nonce');
        
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error(array('message' => __('Permission denied', 'ai-woo-product-generator')));
        }
        
        $product_id = isset($_POST['product_id']) ? intval($_POST['product_id']) : 0;
        
        if (!$product_id) {
            wp_send_json_error(array('message' => __('Product ID is required', 'ai-woo-product-generator')));
        }
        
        $product = $this->product_model->get_product($product_id);
        
        if (is_wp_error($product)) {
            wp_send_json_error(array('message' => $product->get_error_message()));
        }
        
        wp_send_json_success(array('product' => $product));
    }
    
    /**
     * Update product
     */
    public function update_product() {
        check_ajax_referer('aiwpg_nonce', 'nonce');
        
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error(array('message' => __('Permission denied', 'ai-woo-product-generator')));
        }
        
        $product_id = isset($_POST['product_id']) ? intval($_POST['product_id']) : 0;
        $product_data = isset($_POST['product']) ? json_decode(stripslashes($_POST['product']), true) : array();
        
        if (!$product_id) {
            wp_send_json_error(array('message' => __('Product ID is required', 'ai-woo-product-generator')));
        }
        
        $result = $this->product_model->update_product($product_id, $product_data);
        
        if (is_wp_error($result)) {
            wp_send_json_error(array('message' => $result->get_error_message()));
        }
        
        wp_send_json_success(array('message' => __('Product updated successfully', 'ai-woo-product-generator')));
    }
    
    /**
     * Delete product
     */
    public function delete_product() {
        check_ajax_referer('aiwpg_nonce', 'nonce');
        
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error(array('message' => __('Permission denied', 'ai-woo-product-generator')));
        }
        
        $product_id = isset($_POST['product_id']) ? intval($_POST['product_id']) : 0;
        
        if (!$product_id) {
            wp_send_json_error(array('message' => __('Product ID is required', 'ai-woo-product-generator')));
        }
        
        $result = $this->product_model->delete_product($product_id, true);
        
        if (is_wp_error($result)) {
            wp_send_json_error(array('message' => $result->get_error_message()));
        }
        
        wp_send_json_success(array('message' => __('Product deleted successfully', 'ai-woo-product-generator')));
    }
    
    /**
     * Get statistics for dashboard
     */
    public function get_statistics() {
        check_ajax_referer('aiwpg_nonce', 'nonce');
        
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error(array('message' => __('Permission denied', 'ai-woo-product-generator')));
        }
        
        global $wpdb;
        
        // Total products count
        $total_products = wp_count_posts('product');
        $total = $total_products->publish + $total_products->draft + $total_products->pending + $total_products->private;
        
        // Published products
        $published = $total_products->publish;
        
        // Draft products
        $drafts = $total_products->draft + $total_products->pending;
        
        // Calculate stock value
        $stock_value = 0;
        $products_query = new WP_Query(array(
            'post_type' => 'product',
            'post_status' => 'publish',
            'posts_per_page' => -1,
            'fields' => 'ids',
        ));
        
        if ($products_query->have_posts()) {
            foreach ($products_query->posts as $product_id) {
                $product = wc_get_product($product_id);
                if ($product) {
                    $price = $product->get_price();
                    $stock = $product->get_stock_quantity();
                    if ($price && $stock) {
                        $stock_value += floatval($price) * intval($stock);
                    }
                }
            }
        }
        
        // Calculate out of stock products
        $out_of_stock_query = new WP_Query(array(
            'post_type' => 'product',
            'post_status' => 'publish',
            'meta_query' => array(
                array(
                    'key' => '_stock_status',
                    'value' => 'outofstock',
                    'compare' => '=',
                ),
            ),
            'fields' => 'ids',
        ));
        
        $out_of_stock = $out_of_stock_query->found_posts;
        
        wp_reset_postdata();
        
        // Format stock value
        $formatted_stock_value = wc_price($stock_value);
        
        wp_send_json_success(array(
            'total' => $total,
            'published' => $published,
            'drafts' => $drafts,
            'stock_value' => $stock_value,
            'stock_value_formatted' => $formatted_stock_value,
            'out_of_stock' => $out_of_stock,
        ));
    }
    
    /**
     * Improve prompt with AI
     */
    public function improve_prompt() {
        check_ajax_referer('aiwpg_nonce', 'nonce');
        
        if (!current_user_can('manage_woocommerce')) {
            $this->logger->log('Permission denied for improve_prompt', 'products_controller', array(), 'warning');
            wp_send_json_error(array('message' => __('Permission denied', 'ai-woo-product-generator')));
        }
        
        $prompt = isset($_POST['prompt']) ? sanitize_textarea_field($_POST['prompt']) : '';
        
        if (empty($prompt)) {
            $this->logger->log('Empty prompt for improve_prompt', 'products_controller', array(), 'warning');
            wp_send_json_error(array('message' => __('Text is required', 'ai-woo-product-generator')));
        }
        
        try {
            // Create improvement prompt
            $improvement_prompt = "Improve and enhance the following product description or text. Make it more professional, detailed, and appealing while keeping the original meaning. Add missing details if needed:\n\n" . $prompt;
            
            $result = $this->gemini_client->generate_text($improvement_prompt);
            
            if (is_wp_error($result)) {
                $this->logger->log(
                    'Failed to improve prompt',
                    'products_controller',
                    array('error' => $result->get_error_message(), 'prompt_length' => strlen($prompt)),
                    'error'
                );
                wp_send_json_error(array('message' => $result->get_error_message()));
            }
            
            $this->logger->log(
                'Prompt improved successfully',
                'products_controller',
                array('original_length' => strlen($prompt), 'improved_length' => strlen($result)),
                'info'
            );
            
            wp_send_json_success(array(
                'improved_prompt' => $result,
                'message' => __('Text improved successfully', 'ai-woo-product-generator'),
            ));
        } catch (Exception $e) {
            $this->logger->log(
                'Exception in improve_prompt',
                'products_controller',
                array('exception' => $e->getMessage(), 'trace' => $e->getTraceAsString()),
                'error'
            );
            wp_send_json_error(array('message' => __('An error occurred. Please try again.', 'ai-woo-product-generator')));
        }
    }
    
    /**
     * Improve specific field with AI
     */
    public function improve_field() {
        check_ajax_referer('aiwpg_nonce', 'nonce');
        
        if (!current_user_can('manage_woocommerce')) {
            $this->logger->log('Permission denied for improve_field', 'products_controller', array(), 'warning');
            wp_send_json_error(array('message' => __('Permission denied', 'ai-woo-product-generator')));
        }
        
        $text = isset($_POST['text']) ? sanitize_textarea_field($_POST['text']) : '';
        $field_name = isset($_POST['field_name']) ? sanitize_text_field($_POST['field_name']) : '';
        
        if (empty($text)) {
            $this->logger->log('Empty text for improve_field', 'products_controller', array('field' => $field_name), 'warning');
            wp_send_json_error(array('message' => __('Text is required', 'ai-woo-product-generator')));
        }
        
        try {
            // Create field-specific improvement prompt
            $improvement_prompt = sprintf(
                "Improve and enhance the following %s text. Make it more professional, detailed, and appealing while keeping the original meaning. Add missing details if needed:\n\n%s",
                $field_name,
                $text
            );
            
            $result = $this->gemini_client->generate_text($improvement_prompt);
            
            if (is_wp_error($result)) {
                $this->logger->log(
                    'Failed to improve field',
                    'products_controller',
                    array('error' => $result->get_error_message(), 'field' => $field_name, 'text_length' => strlen($text)),
                    'error'
                );
                wp_send_json_error(array('message' => $result->get_error_message()));
            }
            
            $this->logger->log(
                'Field improved successfully',
                'products_controller',
                array('field' => $field_name, 'original_length' => strlen($text), 'improved_length' => strlen($result)),
                'info'
            );
            
            wp_send_json_success(array(
                'improved_text' => $result,
                'message' => __('Text improved successfully', 'ai-woo-product-generator'),
            ));
        } catch (Exception $e) {
            $this->logger->log(
                'Exception in improve_field',
                'products_controller',
                array('exception' => $e->getMessage(), 'field' => $field_name, 'trace' => $e->getTraceAsString()),
                'error'
            );
            wp_send_json_error(array('message' => __('An error occurred. Please try again.', 'ai-woo-product-generator')));
        }
    }
    
    /**
     * Get WooCommerce product categories
     */
    public function get_categories() {
        check_ajax_referer('aiwpg_nonce', 'nonce');
        
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error(array('message' => __('Permission denied', 'ai-woo-product-generator')));
        }
        
        $categories = get_terms(array(
            'taxonomy' => 'product_cat',
            'hide_empty' => false,
            'orderby' => 'name',
            'order' => 'ASC',
        ));
        
        if (is_wp_error($categories)) {
            wp_send_json_error(array('message' => __('Failed to load categories', 'ai-woo-product-generator')));
        }
        
        $category_list = array();
        foreach ($categories as $category) {
            $category_list[] = array(
                'id' => $category->term_id,
                'name' => $category->name,
                'slug' => $category->slug,
            );
        }
        
        wp_send_json_success(array(
            'categories' => $category_list,
        ));
    }
    
    /**
     * Update variation
     */
    public function update_variation() {
        check_ajax_referer('aiwpg_nonce', 'nonce');
        
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error(array('message' => __('Permission denied', 'ai-woo-product-generator')));
        }
        
        $variation_id = isset($_POST['variation_id']) ? intval($_POST['variation_id']) : 0;
        $variation_data = isset($_POST['variation']) ? json_decode(stripslashes($_POST['variation']), true) : array();
        
        if (!$variation_id || empty($variation_data)) {
            wp_send_json_error(array('message' => __('Invalid variation data', 'ai-woo-product-generator')));
        }
        
        try {
            // Get variation object
            $variation = wc_get_product($variation_id);
            
            if (!$variation || $variation->get_type() !== 'variation') {
                wp_send_json_error(array('message' => __('Variation not found', 'ai-woo-product-generator')));
            }
            
            // Update variation data
            if (isset($variation_data['sku'])) {
                $variation->set_sku($variation_data['sku']);
            }
            
            if (isset($variation_data['price'])) {
                $variation->set_regular_price($variation_data['price']);
            }
            
            if (isset($variation_data['stock_quantity'])) {
                $variation->set_manage_stock(true);
                $variation->set_stock_quantity($variation_data['stock_quantity']);
            }
            
            if (isset($variation_data['stock_status'])) {
                $variation->set_stock_status($variation_data['stock_status']);
            }
            
            // Save variation
            $variation->save();
            
            // Sync parent product
            $parent_id = $variation->get_parent_id();
            if ($parent_id) {
                WC_Product_Variable::sync($parent_id);
                wc_delete_product_transients($parent_id);
            }
            
            wp_send_json_success(array(
                'message' => __('Variation updated successfully', 'ai-woo-product-generator'),
                'variation' => array(
                    'id' => $variation->get_id(),
                    'sku' => $variation->get_sku(),
                    'price' => $variation->get_regular_price(),
                    'stock_quantity' => $variation->get_stock_quantity(),
                    'stock_status' => $variation->get_stock_status(),
                )
            ));
            
        } catch (Exception $e) {
            $this->logger->log('Failed to update variation: ' . $e->getMessage(), 'products_controller', array(
                'variation_id' => $variation_id,
                'error' => $e->getMessage()
            ), 'error');
            
            wp_send_json_error(array('message' => __('Failed to update variation', 'ai-woo-product-generator')));
        }
    }
}
