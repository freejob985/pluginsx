<?php
/**
 * Products Controller
 * Handles AJAX requests for product operations
 */

if (!defined('ABSPATH')) {
    exit;
}




class AIWPG_Products_Controller {
    
    /**
     * Single instance
     */
    private static $instance = null;
    
    /**
     * Gemini client
     */
    private $gemini_client;
    
    /**
     * Product model
     */
    private $product_model;
    

    
    /**
     * Logger
     */
    private $logger;
    
    /**
     * Get instance
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructor
     */

     
    private function __construct() {
        $this->gemini_client = new AIWPG_Gemini_Client();
        $this->product_model = new AIWPG_Product_Model();
        $this->logger = AIWPG_Logger::get_instance();
        
        // AJAX actions
        add_action('wp_ajax_aiwpg_generate_single', array($this, 'generate_single_product'));
        add_action('wp_ajax_aiwpg_generate_multiple', array($this, 'generate_multiple_products'));
        add_action('wp_ajax_aiwpg_generate_excel', array($this, 'generate_from_excel'));
        add_action('wp_ajax_aiwpg_save_product', array($this, 'save_product'));
        add_action('wp_ajax_aiwpg_save_products', array($this, 'save_products'));
        add_action('wp_ajax_aiwpg_get_products', array($this, 'get_products'));
        add_action('wp_ajax_aiwpg_search_products', array($this, 'search_products'));
        add_action('wp_ajax_aiwpg_get_product', array($this, 'get_product'));
        add_action('wp_ajax_aiwpg_update_product', array($this, 'update_product'));
        add_action('wp_ajax_aiwpg_update_variation', array($this, 'update_variation'));
        add_action('wp_ajax_aiwpg_delete_product', array($this, 'delete_product'));
        add_action('wp_ajax_aiwpg_get_statistics', array($this, 'get_statistics'));
        add_action('wp_ajax_aiwpg_improve_prompt', array($this, 'improve_prompt'));
        add_action('wp_ajax_aiwpg_improve_field', array($this, 'improve_field'));
        add_action('wp_ajax_aiwpg_score_prompt_quality', array($this, 'score_prompt_quality'));
        add_action('wp_ajax_aiwpg_get_categories', array($this, 'get_categories'));
        add_action('wp_ajax_aiwpg_create_product', array($this, 'create_product'));
        add_action('wp_ajax_aiwpg_get_gallery_images', array($this, 'get_gallery_images'));
        add_action('wp_ajax_aiwpg_get_all_products_list', array($this, 'get_all_products_list'));
        add_action('wp_ajax_aiwpg_save_excel_products', array($this, 'save_excel_products'));
        
        // New Excel import AJAX handlers
        add_action('wp_ajax_aiwpg_parse_excel', array($this, 'parse_excel_file'));
        add_action('wp_ajax_aiwpg_enrich_excel_rows', array($this, 'enrich_excel_rows'));
        add_action('wp_ajax_aiwpg_import_excel_products', array($this, 'import_excel_products'));
    }
    
    /**
     * Generate single product
     */
    public function generate_single_product() {
        check_ajax_referer('aiwpg_nonce', 'nonce');
        
        if (!current_user_can('manage_woocommerce')) {
            $this->logger->log('Permission denied for generate_single_product', 'products_controller', array(), 'warning');
            wp_send_json_error(array('message' => __('Permission denied', 'ai-woo-product-generator')));
        }
        
        

        
        $prompt = isset($_POST['prompt']) ? sanitize_textarea_field($_POST['prompt']) : '';
        $product_type = isset($_POST['product_type']) ? sanitize_text_field($_POST['product_type']) : 'automatic';
        
        if (empty($prompt)) {
            $this->logger->log('Empty prompt for generate_single_product', 'products_controller', array(), 'warning');
            wp_send_json_error(array('message' => __('Prompt is required', 'ai-woo-product-generator')));
        }
        
        try {
            $result = $this->gemini_client->generate_single_product($prompt, $product_type);
            
            if (is_wp_error($result)) {
                $this->logger->log(
                    'Failed to generate single product',
                    'products_controller',
                    array('error' => $result->get_error_message(), 'prompt' => substr($prompt, 0, 100)),
                    'error'
                );
                wp_send_json_error(array('message' => $result->get_error_message()));
            }
            
            $this->logger->log(
                'Single product generated successfully',
                'products_controller',
                array('prompt_length' => strlen($prompt)),
                'info'
            );
            
            wp_send_json_success(array(
                'message' => __('Product generated successfully', 'ai-woo-product-generator'),
                'product' => $result,
            ));
        } catch (Exception $e) {
            $this->logger->log(
                'Exception in generate_single_product',
                'products_controller',
                array('exception' => $e->getMessage(), 'trace' => $e->getTraceAsString()),
                'error'
            );
            wp_send_json_error(array('message' => __('An error occurred. Please try again.', 'ai-woo-product-generator')));
        }
    }
    
    /**
     * Generate multiple products from textarea
     */
    public function generate_multiple_products() {
        check_ajax_referer('aiwpg_nonce', 'nonce');
        
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error(array('message' => __('Permission denied', 'ai-woo-product-generator')));
        }
        
        $prompts_text = isset($_POST['prompts']) ? sanitize_textarea_field($_POST['prompts']) : '';
        $product_type = isset($_POST['product_type']) ? sanitize_text_field($_POST['product_type']) : 'automatic';
        
        if (empty($prompts_text)) {
            wp_send_json_error(array('message' => __('Product descriptions are required', 'ai-woo-product-generator')));
        }
        
        // Split by lines
        $lines = array_filter(array_map('trim', explode("\n", $prompts_text)));
        
        if (empty($lines)) {
            wp_send_json_error(array('message' => __('No valid product descriptions found', 'ai-woo-product-generator')));
        }
        
        // Parse each line
        $prompts = array();
        foreach ($lines as $line) {
            // Check if line contains pipe separator
            if (strpos($line, '|') !== false) {
                $parts = array_map('trim', explode('|', $line, 2));
                $prompts[] = array(
                    'description' => $parts[0],
                    'quantity' => isset($parts[1]) && is_numeric($parts[1]) ? intval($parts[1]) : 10,
                );
            } else {
                $prompts[] = array(
                    'description' => $line,
                    'quantity' => 10,
                );
            }
        }
        
        $result = $this->gemini_client->generate_multiple_products($prompts, $product_type);
        
        if (is_wp_error($result)) {
            wp_send_json_error(array('message' => $result->get_error_message()));
        }
        
        wp_send_json_success(array(
            'message' => sprintf(__('%d products generated successfully', 'ai-woo-product-generator'), count($result)),
            'products' => $result,
        ));
    }
    
    /**
     * Generate products from Excel file
     */
    public function generate_from_excel() {
        check_ajax_referer('aiwpg_nonce', 'nonce');
        
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error(array('message' => __('Permission denied', 'ai-woo-product-generator')));
        }
        
        // Handle file upload
        if (!isset($_FILES['excel_file']) || $_FILES['excel_file']['error'] !== UPLOAD_ERR_OK) {
            wp_send_json_error(array('message' => __('File upload failed. Please try again.', 'ai-woo-product-generator')));
        }
        
        $file = $_FILES['excel_file'];
        $import_mode = isset($_POST['import_mode']) ? sanitize_text_field($_POST['import_mode']) : 'dry-run';
        $use_ai = isset($_POST['use_ai']) && $_POST['use_ai'] === 'true';
        $treat_ambiguous_as_draft = isset($_POST['treat_ambiguous_as_draft']) && $_POST['treat_ambiguous_as_draft'] === 'true';
        
        // Validate file type
        $allowed_types = array('application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'application/vnd.ms-excel', 'text/csv');
        $file_type = wp_check_filetype($file['name']);
        
        if (!in_array($file['type'], $allowed_types) && !in_array($file_type['ext'], array('xlsx', 'xls', 'csv'))) {
            wp_send_json_error(array('message' => __('Invalid file type. Please upload .xlsx, .xls, or .csv files.', 'ai-woo-product-generator')));
        }
        
        // Move uploaded file to temporary location
        $upload_dir = wp_upload_dir();
        $temp_dir = $upload_dir['basedir'] . '/aiwpg-temp';
        if (!file_exists($temp_dir)) {
            wp_mkdir_p($temp_dir);
        }
        
        $temp_file = $temp_dir . '/' . uniqid('excel_') . '_' . sanitize_file_name($file['name']);
        
        if (!move_uploaded_file($file['tmp_name'], $temp_file)) {
            wp_send_json_error(array('message' => __('Failed to save uploaded file.', 'ai-woo-product-generator')));
        }
        
        // Parse Excel file
        $parser = new AIWPG_Excel_Parser();
        $parsed_rows = $parser->parse($temp_file);
        
        // Clean up temp file
        @unlink($temp_file);
        
        if (is_wp_error($parsed_rows)) {
            wp_send_json_error(array('message' => $parsed_rows->get_error_message()));
        }
        
        if (empty($parsed_rows)) {
            wp_send_json_error(array('message' => __('No valid product data found in file.', 'ai-woo-product-generator')));
        }
        
        // Enrich with AI if enabled
        $enriched_rows = array();
        $ai_service = new AIWPG_AI_Service();
        $ai_calls_count = 0;
        
        if ($use_ai) {
            // Process in batches to avoid overwhelming the API
            $batch_size = 10;
            $batches = array_chunk($parsed_rows, $batch_size);
            
            foreach ($batches as $batch) {
                foreach ($batch as $row) {
                    $enriched = $ai_service->enrich_product_row($row);
                    $ai_calls_count++;
                    
                    // enrich_product_row returns array (with fallback) or WP_Error
                    if (is_wp_error($enriched)) {
                        $this->logger->log(
                            'AI enrichment failed for row',
                            'excel_import',
                            array('row' => $row['_row_index'] ?? 'unknown', 'error' => $enriched->get_error_message()),
                            'error'
                        );
                        // Use fallback classification (already handled in enrich_product_row)
                        // But if it still returns error, create minimal fallback
                        $enriched = array(
                            'type' => 'Food',
                            'category' => 'Uncategorized',
                            'tags' => array(),
                            'kitchen' => 'Main Kitchen',
                            'isaddon' => false,
                            'addongroup' => null,
                        );
                    }
                    
                    $enriched_rows[] = array_merge($row, $enriched);
                }
                
                // Small delay between batches
                if (count($batches) > 1) {
                    usleep(500000); // 0.5 second
                }
            }
        } else {
            // No AI enrichment, just use parsed data
            $enriched_rows = $parsed_rows;
        }
        
        // Convert to product format for preview
        $products_preview = array();
        $success_count = 0;
        $error_count = 0;
        
        foreach ($enriched_rows as $row) {
            try {
                $product_data = $this->convert_row_to_product_data($row, $treat_ambiguous_as_draft);
                $products_preview[] = $product_data;
                $success_count++;
            } catch (Exception $e) {
                $error_count++;
                $this->logger->log(
                    'Failed to convert row to product data',
                    'excel_import',
                    array('row' => $row['_row_index'] ?? 'unknown', 'error' => $e->getMessage()),
                    'error'
                );
                $products_preview[] = array(
                    'error' => $e->getMessage(),
                    'row_index' => $row['_row_index'] ?? 'unknown',
                    'name' => $row['name'] ?? 'Unknown',
                );
            }
        }
        
        // If dry-run mode, just return preview
        if ($import_mode === 'dry-run') {
            wp_send_json_success(array(
                'message' => sprintf(__('%d rows processed (Dry-run mode)', 'ai-woo-product-generator'), count($parsed_rows)),
                'products' => $products_preview,
                'summary' => array(
                    'total_rows' => count($parsed_rows),
                    'success_count' => $success_count,
                    'error_count' => $error_count,
                    'ai_calls' => $ai_calls_count,
                ),
                'dry_run' => true,
            ));
        }
        
        // Otherwise, return preview for confirmation
        wp_send_json_success(array(
            'message' => sprintf(__('%d rows processed. Please review and confirm import.', 'ai-woo-product-generator'), count($parsed_rows)),
            'products' => $products_preview,
            'summary' => array(
                'total_rows' => count($parsed_rows),
                'success_count' => $success_count,
                'error_count' => $error_count,
                'ai_calls' => $ai_calls_count,
            ),
            'import_mode' => $import_mode,
            'dry_run' => false,
        ));
    }
    
    /**
     * Convert enriched row to product data format
     */
    private function convert_row_to_product_data($row, $treat_ambiguous_as_draft = false) {
        // Validate required fields
        if (empty($row['name'])) {
            return array('error' => __('Product name is required', 'ai-woo-product-generator'));
        }
        
        $product_data = array(
            'title' => sanitize_text_field($row['name'] ?? ''),
            'short_description' => sanitize_textarea_field(substr($row['description'] ?? '', 0, 200)),
            'description' => sanitize_textarea_field($row['description'] ?? ''),
            'sku' => !empty($row['sku']) ? sanitize_text_field(trim($row['sku'])) : $this->generate_sku_from_name($row['name']),
            'regular_price' => !empty($row['baseprice']) ? $this->sanitize_price($row['baseprice']) : '0.00',
            'stock_quantity' => 10, // Default
            'stock_status' => 'instock',
            'status' => 'draft', // Default to draft for review
        );
        
        // Add AI enrichment data if available
        if (isset($row['type'])) {
            $product_data['_ai_type'] = sanitize_text_field($row['type']);
        }
        
        if (isset($row['category']) && !empty($row['category'])) {
            $product_data['categories'] = is_array($row['category']) ? $row['category'] : array($row['category']);
        }
        
        if (isset($row['tags']) && is_array($row['tags']) && !empty($row['tags'])) {
            $product_data['tags'] = array_map('sanitize_text_field', $row['tags']);
        }
        
        if (isset($row['kitchen']) && !empty($row['kitchen'])) {
            $product_data['_ai_kitchen'] = sanitize_text_field($row['kitchen']);
        }
        
        // Handle isaddon in multiple formats
        $is_addon = false;
        if (isset($row['isaddon'])) {
            if ($row['isaddon'] === true || $row['isaddon'] === 'true' || $row['isaddon'] === '1' || $row['isaddon'] === 1) {
                $is_addon = true;
            }
        }
        
        // Check additions column - if it has value, likely an add-on
        if (!$is_addon && !empty($row['additions'])) {
            $is_addon = true;
        }
        
        // Fallback: Check keywords if not explicitly set
        if (!$is_addon) {
            $search_text = strtolower(($row['name'] ?? '') . ' ' . ($row['notes'] ?? '') . ' ' . ($row['description'] ?? '') . ' ' . ($row['additions'] ?? ''));
            if (preg_match('/\b(extra|add-on|addon|side|topping|sauce|cheese|additional|supplement|optional|plus|add|إضافي|إضافة|جانبي)\b/i', $search_text)) {
                $is_addon = true;
            }
        }
        
        if ($is_addon) {
            $product_data['_ai_isaddon'] = true;
            
            // Get add-on group
            $addon_group = null;
            if (!empty($row['addongroup'])) {
                $addon_group = sanitize_text_field($row['addongroup']);
            } elseif (!empty($row['addon_group'])) {
                $addon_group = sanitize_text_field($row['addon_group']);
            } else {
                // Suggest default group based on product name
                $name_lower = strtolower($row['name'] ?? '');
                if (strpos($name_lower, 'pizza') !== false) {
                    $addon_group = 'Pizza Extras';
                } elseif (strpos($name_lower, 'burger') !== false) {
                    $addon_group = 'Burger Add-ons';
                } elseif (strpos($name_lower, 'salad') !== false) {
                    $addon_group = 'Salad Toppings';
                } elseif (strpos($name_lower, 'coffee') !== false || strpos($name_lower, 'drink') !== false) {
                    $addon_group = 'Drink Extras';
                } else {
                    $addon_group = 'Extras';
                }
            }
            
            $product_data['_ai_addongroup'] = $addon_group;
        }
        
        // Use raw category if provided and no AI category
        if (empty($product_data['categories']) && !empty($row['rawcategory'])) {
            $product_data['categories'] = array(sanitize_text_field($row['rawcategory']));
        }
        
        // Use raw tags if provided and no AI tags
        if (empty($product_data['tags']) && !empty($row['rawtags'])) {
            $tags_array = array_map('trim', explode(',', $row['rawtags']));
            $product_data['tags'] = array_filter(array_map('sanitize_text_field', $tags_array));
        }
        
        // Store additions for addons importer
        if (!empty($row['additions'])) {
            $product_data['additions'] = sanitize_text_field($row['additions']);
        }
        
        // Determine status based on ambiguity
        if ($treat_ambiguous_as_draft && empty($row['type'])) {
            $product_data['status'] = 'draft';
        }
        
        return $product_data;
    }
    
    /**
     * Sanitize price value
     */
    private function sanitize_price($price) {
        if (empty($price)) {
            return '0.00';
        }
        
        // Remove currency symbols and ensure numeric
        $price = preg_replace('/[^0-9.]/', '', (string) $price);
        
        if (!is_numeric($price) || floatval($price) < 0) {
            return '0.00';
        }
        
        return number_format(floatval($price), 2, '.', '');
    }
    
    /**
     * Generate SKU from product name
     */
    private function generate_sku_from_name($name) {
        $sku = strtoupper(preg_replace('/[^a-zA-Z0-9]/', '', substr($name, 0, 8)));
        $sku .= '-' . strtoupper(substr(md5($name . time()), 0, 6));
        return $sku;
    }
    
    /**
     * Save single product
     */
    public function save_product() {
        check_ajax_referer('aiwpg_nonce', 'nonce');
        
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error(array('message' => __('Permission denied', 'ai-woo-product-generator')));
        }
        
        $product_data = isset($_POST['product']) ? json_decode(stripslashes($_POST['product']), true) : array();
        
        if (empty($product_data)) {
            wp_send_json_error(array('message' => __('Product data is required', 'ai-woo-product-generator')));
        }
        
        $product_id = $this->product_model->create_product($product_data);
        
        if (is_wp_error($product_id)) {
            wp_send_json_error(array('message' => $product_id->get_error_message()));
        }
        
        wp_send_json_success(array(
            'message' => __('Product saved successfully', 'ai-woo-product-generator'),
            'product_id' => $product_id,
        ));
    }
    
    /**
     * Save multiple products
     */
    public function save_products() {
        check_ajax_referer('aiwpg_nonce', 'nonce');
        
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error(array('message' => __('Permission denied', 'ai-woo-product-generator')));
        }
        
        $products_data = isset($_POST['products']) ? json_decode(stripslashes($_POST['products']), true) : array();
        
        if (empty($products_data)) {
            wp_send_json_error(array('message' => __('Products data is required', 'ai-woo-product-generator')));
        }
        
        $created = array();
        $errors = array();
        
        foreach ($products_data as $index => $product_data) {
            $product_id = $this->product_model->create_product($product_data);
            
            if (is_wp_error($product_id)) {
                $errors[] = sprintf(__('Product #%d: %s', 'ai-woo-product-generator'), $index + 1, $product_id->get_error_message());
            } else {
                $created[] = $product_id;
            }
        }
        
        wp_send_json_success(array(
            'message' => sprintf(__('%d products saved successfully', 'ai-woo-product-generator'), count($created)),
            'created' => count($created),
            'errors' => $errors,
        ));
    }
    
    /**
     * Get products with pagination
     */
    public function get_products() {
        check_ajax_referer('aiwpg_nonce', 'nonce');
        
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error(array('message' => __('Permission denied', 'ai-woo-product-generator')));
        }
        
        $page = isset($_POST['page']) ? intval($_POST['page']) : 1;
        $per_page = isset($_POST['per_page']) ? intval($_POST['per_page']) : 12;
        $search = isset($_POST['search']) ? sanitize_text_field($_POST['search']) : '';
        
        $result = $this->product_model->get_products($page, $per_page, $search);
        
        wp_send_json_success($result);
    }
    
    /**
     * Search products (autocomplete)
     */
    public function search_products() {
        check_ajax_referer('aiwpg_nonce', 'nonce');
        
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error(array('message' => __('Permission denied', 'ai-woo-product-generator')));
        }
        
        $search = isset($_POST['search']) ? sanitize_text_field($_POST['search']) : '';
        
        if (empty($search)) {
            wp_send_json_error(array('message' => __('Please enter a search term', 'ai-woo-product-generator')));
        }
        
        $products = $this->product_model->search_products($search, 4);
        
        wp_send_json_success(array('products' => $products));
    }
    
    /**
     * Get single product
     */
    public function get_product() {
        check_ajax_referer('aiwpg_nonce', 'nonce');
        
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error(array('message' => __('Permission denied', 'ai-woo-product-generator')));
        }
        
        $product_id = isset($_POST['product_id']) ? intval($_POST['product_id']) : 0;
        
        if (!$product_id) {
            wp_send_json_error(array('message' => __('Product ID is required', 'ai-woo-product-generator')));
        }
        
        $product = $this->product_model->get_product($product_id);
        
        if (is_wp_error($product)) {
            wp_send_json_error(array('message' => $product->get_error_message()));
        }
        
        wp_send_json_success(array('product' => $product));
    }
    
    /**
     * Update product
     */
    public function update_product() {
        check_ajax_referer('aiwpg_nonce', 'nonce');
        
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error(array('message' => __('Permission denied', 'ai-woo-product-generator')));
        }
        
        $product_id = isset($_POST['product_id']) ? intval($_POST['product_id']) : 0;
        $product_data = isset($_POST['product']) ? json_decode(stripslashes($_POST['product']), true) : array();
        
        if (!$product_id) {
            wp_send_json_error(array('message' => __('Product ID is required', 'ai-woo-product-generator')));
        }
        
        $result = $this->product_model->update_product($product_id, $product_data);
        
        if (is_wp_error($result)) {
            wp_send_json_error(array('message' => $result->get_error_message()));
        }
        
        wp_send_json_success(array('message' => __('Product updated successfully', 'ai-woo-product-generator')));
    }
    
    /**
     * Delete product
     */
    public function delete_product() {
        check_ajax_referer('aiwpg_nonce', 'nonce');
        
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error(array('message' => __('Permission denied', 'ai-woo-product-generator')));
        }
        
        $product_id = isset($_POST['product_id']) ? intval($_POST['product_id']) : 0;
        
        if (!$product_id) {
            wp_send_json_error(array('message' => __('Product ID is required', 'ai-woo-product-generator')));
        }
        
        $result = $this->product_model->delete_product($product_id, true);
        
        if (is_wp_error($result)) {
            wp_send_json_error(array('message' => $result->get_error_message()));
        }
        
        wp_send_json_success(array('message' => __('Product deleted successfully', 'ai-woo-product-generator')));
    }
    
    /**
     * Get statistics for dashboard
     */
    public function get_statistics() {
        check_ajax_referer('aiwpg_nonce', 'nonce');
        
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error(array('message' => __('Permission denied', 'ai-woo-product-generator')));
        }
        
        global $wpdb;
        
        // Total products count
        $total_products = wp_count_posts('product');
        $total = $total_products->publish + $total_products->draft + $total_products->pending + $total_products->private;
        
        // Published products
        $published = $total_products->publish;
        
        // Draft products
        $drafts = $total_products->draft + $total_products->pending;
        
        // Calculate stock value
        $stock_value = 0;
        $products_query = new WP_Query(array(
            'post_type' => 'product',
            'post_status' => 'publish',
            'posts_per_page' => -1,
            'fields' => 'ids',
        ));
        
        if ($products_query->have_posts()) {
            foreach ($products_query->posts as $product_id) {
                $product = wc_get_product($product_id);
                if ($product) {
                    $price = $product->get_price();
                    $stock = $product->get_stock_quantity();
                    if ($price && $stock) {
                        $stock_value += floatval($price) * intval($stock);
                    }
                }
            }
        }
        
        // Calculate out of stock products
        $out_of_stock_query = new WP_Query(array(
            'post_type' => 'product',
            'post_status' => 'publish',
            'meta_query' => array(
                array(
                    'key' => '_stock_status',
                    'value' => 'outofstock',
                    'compare' => '=',
                ),
            ),
            'fields' => 'ids',
        ));
        
        $out_of_stock = $out_of_stock_query->found_posts;
        
        wp_reset_postdata();
        
        // Format stock value
        $formatted_stock_value = wc_price($stock_value);
        
        wp_send_json_success(array(
            'total' => $total,
            'published' => $published,
            'drafts' => $drafts,
            'stock_value' => $stock_value,
            'stock_value_formatted' => $formatted_stock_value,
            'out_of_stock' => $out_of_stock,
        ));
    }
    
    /**
     * Improve prompt with AI
     */
    public function improve_prompt() {
        check_ajax_referer('aiwpg_nonce', 'nonce');
        
        if (!current_user_can('manage_woocommerce')) {
            $this->logger->log('Permission denied for improve_prompt', 'products_controller', array(), 'warning');
            wp_send_json_error(array('message' => __('Permission denied', 'ai-woo-product-generator')));
        }
        
        $prompt = isset($_POST['prompt']) ? sanitize_textarea_field($_POST['prompt']) : '';
        
        if (empty($prompt)) {
            $this->logger->log('Empty prompt for improve_prompt', 'products_controller', array(), 'warning');
            wp_send_json_error(array('message' => __('Text is required', 'ai-woo-product-generator')));
        }
        
        try {
            // Create improvement prompt with clear instructions
            $improvement_prompt = "You are a professional product description writer. Improve and enhance the following text. Return ONLY the improved text without any introduction, explanation, or additional comments. Just provide the enhanced version directly:\n\n" . $prompt;
            
            $result = $this->gemini_client->generate_text($improvement_prompt);
            
            if (is_wp_error($result)) {
                $this->logger->log(
                    'Failed to improve prompt',
                    'products_controller',
                    array('error' => $result->get_error_message(), 'prompt_length' => strlen($prompt)),
                    'error'
                );
                wp_send_json_error(array('message' => $result->get_error_message()));
            }
            
            $this->logger->log(
                'Prompt improved successfully',
                'products_controller',
                array('original_length' => strlen($prompt), 'improved_length' => strlen($result)),
                'info'
            );
            
            wp_send_json_success(array(
                'improved_prompt' => $result,
                'message' => __('Text improved successfully', 'ai-woo-product-generator'),
            ));
        } catch (Exception $e) {
            $this->logger->log(
                'Exception in improve_prompt',
                'products_controller',
                array('exception' => $e->getMessage(), 'trace' => $e->getTraceAsString()),
                'error'
            );
            wp_send_json_error(array('message' => __('An error occurred. Please try again.', 'ai-woo-product-generator')));
        }
    }
    
    /**
     * Improve specific field with AI
     */
    public function improve_field() {
        check_ajax_referer('aiwpg_nonce', 'nonce');
        
        if (!current_user_can('manage_woocommerce')) {
            $this->logger->log('Permission denied for improve_field', 'products_controller', array(), 'warning');
            wp_send_json_error(array('message' => __('Permission denied', 'ai-woo-product-generator')));
        }
        
        $text = isset($_POST['text']) ? sanitize_textarea_field($_POST['text']) : '';
        $field_name = isset($_POST['field_name']) ? sanitize_text_field($_POST['field_name']) : '';
        
        if (empty($text)) {
            $this->logger->log('Empty text for improve_field', 'products_controller', array('field' => $field_name), 'warning');
            wp_send_json_error(array('message' => __('Text is required', 'ai-woo-product-generator')));
        }
        
        try {
            // Create field-specific improvement prompt with clear instructions for single output
            $improvement_prompt = sprintf(
                "You are a professional copywriter. Improve and enhance the following %s. 

IMPORTANT: Return ONLY ONE improved version. Do NOT provide multiple options or alternatives.

Return ONLY the improved text without any introduction, explanation, numbering, bullet points, or additional comments. Just provide the single enhanced version directly:

%s",
                $field_name,
                $text
            );
            
            $result = $this->gemini_client->generate_text($improvement_prompt);
            
            if (is_wp_error($result)) {
                $this->logger->log(
                    'Failed to improve field',
                    'products_controller',
                    array('error' => $result->get_error_message(), 'field' => $field_name, 'text_length' => strlen($text)),
                    'error'
                );
                wp_send_json_error(array('message' => $result->get_error_message()));
            }
            
            // Clean up the result to ensure only one option
            $result = $this->clean_single_option($result);
            
            $this->logger->log(
                'Field improved successfully',
                'products_controller',
                array('field' => $field_name, 'original_length' => strlen($text), 'improved_length' => strlen($result)),
                'info'
            );
            
            wp_send_json_success(array(
                'improved_text' => $result,
                'message' => __('Text improved successfully', 'ai-woo-product-generator'),
            ));
        } catch (Exception $e) {
            $this->logger->log(
                'Exception in improve_field',
                'products_controller',
                array('exception' => $e->getMessage(), 'field' => $field_name, 'trace' => $e->getTraceAsString()),
                'error'
            );
            wp_send_json_error(array('message' => __('An error occurred. Please try again.', 'ai-woo-product-generator')));
        }
    }
    
    /**
     * Clean single option from AI response - remove numbering, options, etc.
     */
    private function clean_single_option($text) {
        // Remove option numbering like "1.", "Option 1:", etc.
        $text = preg_replace('/^(Option\s+)?\d+[.:)\s]+/im', '', $text);
        
        // Remove "Here is..." or "Here's..." introductions
        $text = preg_replace('/^(Here is|Here\'s|Here are)[^:]*:\s*/i', '', $text);
        
        // If there are multiple paragraphs separated by double line breaks, take only the first
        $paragraphs = preg_split('/\n\s*\n/', trim($text), 2);
        if (count($paragraphs) > 1 && strlen($paragraphs[0]) > 20) {
            // If first paragraph is substantial, use it
            $text = $paragraphs[0];
        }
        
        // Remove any lines that look like option markers
        $lines = explode("\n", $text);
        $cleaned_lines = array();
        $found_option_marker = false;
        
        foreach ($lines as $line) {
            $trimmed = trim($line);
            // Check if line starts with option marker
            if (preg_match('/^(Option\s+)?\d+[.:)\s]+/i', $trimmed) || 
                preg_match('/^(Alternative|Version)\s+\d+/i', $trimmed)) {
                $found_option_marker = true;
                break;
            }
            $cleaned_lines[] = $line;
        }
        
        if ($found_option_marker && count($cleaned_lines) > 0) {
            $text = implode("\n", $cleaned_lines);
        }
        
        return trim($text);
    }
    
    /**
     * Score prompt quality with AI
     */
    public function score_prompt_quality() {
        check_ajax_referer('aiwpg_nonce', 'nonce');
        
        if (!current_user_can('manage_woocommerce')) {
            $this->logger->log('Permission denied for score_prompt_quality', 'products_controller', array(), 'warning');
            wp_send_json_error(array('message' => __('Permission denied', 'ai-woo-product-generator')));
        }
        
        $prompt = isset($_POST['prompt']) ? sanitize_textarea_field($_POST['prompt']) : '';
        
        if (empty($prompt)) {
            $this->logger->log('Empty prompt for score_prompt_quality', 'products_controller', array(), 'warning');
            wp_send_json_error(array('message' => __('Prompt is required', 'ai-woo-product-generator')));
        }
        
        try {
            // Create quality scoring prompt
            $scoring_prompt = "You are an expert in evaluating product description prompts for AI generation.

Analyze the following product description prompt and provide:
1. A quality score from 0 to 100 (where 100 is perfect)
2. Brief feedback in Arabic (1-2 sentences)

Consider these criteria:
- Clarity and specificity
- Completeness of information (price, quantity, features)
- Structure and organization
- Use of variables and placeholders
- Professional language
- Details that would help generate a good product

Return your response in this EXACT format:
SCORE: [number]
FEEDBACK: [Arabic text]

Prompt to evaluate:
{$prompt}";
            
            $result = $this->gemini_client->generate_text($scoring_prompt);
            
            if (is_wp_error($result)) {
                $this->logger->log(
                    'Failed to score prompt quality',
                    'products_controller',
                    array('error' => $result->get_error_message(), 'prompt_length' => strlen($prompt)),
                    'error'
                );
                wp_send_json_error(array('message' => $result->get_error_message()));
            }
            
            // Parse the score and feedback
            $score = 0;
            $feedback = 'تم التقييم بنجاح';
            
            if (preg_match('/SCORE:\s*(\d+)/i', $result, $matches)) {
                $score = intval($matches[1]);
                $score = min(100, max(0, $score)); // Clamp between 0-100
            }
            
            if (preg_match('/FEEDBACK:\s*(.+?)(?:\n|$)/is', $result, $matches)) {
                $feedback = trim($matches[1]);
            }
            
            $this->logger->log(
                'Prompt quality scored successfully',
                'products_controller',
                array('score' => $score, 'prompt_length' => strlen($prompt)),
                'info'
            );
            
            wp_send_json_success(array(
                'score' => $score,
                'feedback' => $feedback,
                'message' => __('Quality scored successfully', 'ai-woo-product-generator'),
            ));
        } catch (Exception $e) {
            $this->logger->log(
                'Exception in score_prompt_quality',
                'products_controller',
                array('exception' => $e->getMessage(), 'trace' => $e->getTraceAsString()),
                'error'
            );
            wp_send_json_error(array('message' => __('An error occurred. Please try again.', 'ai-woo-product-generator')));
        }
    }
    
    /**
     * Get WooCommerce product categories
     */
    public function get_categories() {
        check_ajax_referer('aiwpg_nonce', 'nonce');
        
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error(array('message' => __('Permission denied', 'ai-woo-product-generator')));
        }
        
        $categories = get_terms(array(
            'taxonomy' => 'product_cat',
            'hide_empty' => false,
            'orderby' => 'name',
            'order' => 'ASC',
        ));
        
        if (is_wp_error($categories)) {
            wp_send_json_error(array('message' => __('Failed to load categories', 'ai-woo-product-generator')));
        }
        
        $category_list = array();
        foreach ($categories as $category) {
            $category_list[] = array(
                'id' => $category->term_id,
                'name' => $category->name,
                'slug' => $category->slug,
            );
        }
        
        wp_send_json_success(array(
            'categories' => $category_list,
        ));
    }
    
    /**
     * Update variation
     */
    public function update_variation() {
        check_ajax_referer('aiwpg_nonce', 'nonce');
        
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error(array('message' => __('Permission denied', 'ai-woo-product-generator')));
        }
        
        $variation_id = isset($_POST['variation_id']) ? intval($_POST['variation_id']) : 0;
        $variation_data = isset($_POST['variation']) ? json_decode(stripslashes($_POST['variation']), true) : array();
        
        if (!$variation_id || empty($variation_data)) {
            wp_send_json_error(array('message' => __('Invalid variation data', 'ai-woo-product-generator')));
        }
        
        try {
            // Get variation object
            $variation = wc_get_product($variation_id);
            
            if (!$variation || $variation->get_type() !== 'variation') {
                wp_send_json_error(array('message' => __('Variation not found', 'ai-woo-product-generator')));
            }
            
            // Update variation data
            if (isset($variation_data['sku'])) {
                $variation->set_sku($variation_data['sku']);
            }
            
            if (isset($variation_data['price'])) {
                $variation->set_regular_price($variation_data['price']);
            }
            
            if (isset($variation_data['stock_quantity'])) {
                $variation->set_manage_stock(true);
                $variation->set_stock_quantity($variation_data['stock_quantity']);
            }
            
            if (isset($variation_data['stock_status'])) {
                $variation->set_stock_status($variation_data['stock_status']);
            }
            
            // Update variation image
            if (isset($variation_data['image_id'])) {
                if (!empty($variation_data['image_id'])) {
                    $variation->set_image_id(intval($variation_data['image_id']));
                } else {
                    // Remove image if empty
                    $variation->set_image_id('');
                }
            }
            
            // Save variation
            $variation->save();
            
            // Sync parent product
            $parent_id = $variation->get_parent_id();
            if ($parent_id) {
                WC_Product_Variable::sync($parent_id);
                wc_delete_product_transients($parent_id);
            }
            
            // Get image URL for response
            $image_id = $variation->get_image_id();
            $image_url = $image_id ? wp_get_attachment_image_url($image_id, 'thumbnail') : '';
            
            wp_send_json_success(array(
                'message' => __('Variation updated successfully', 'ai-woo-product-generator'),
                'variation' => array(
                    'id' => $variation->get_id(),
                    'sku' => $variation->get_sku(),
                    'price' => $variation->get_regular_price(),
                    'stock_quantity' => $variation->get_stock_quantity(),
                    'stock_status' => $variation->get_stock_status(),
                    'image_id' => $image_id,
                    'image_url' => $image_url,
                )
            ));
            
        } catch (Exception $e) {
            $this->logger->log('Failed to update variation: ' . $e->getMessage(), 'products_controller', array(
                'variation_id' => $variation_id,
                'error' => $e->getMessage()
            ), 'error');
            
            wp_send_json_error(array('message' => __('Failed to update variation', 'ai-woo-product-generator')));
        }
    }
    
    /**
     * Prepare tags - handle both array and string formats
     */
    private function prepare_tags($product_data) {
        if (!isset($product_data['tags'])) {
            return array();
        }
        
        $tags = $product_data['tags'];
        
        // If already an array, return as is
        if (is_array($tags)) {
            return array_filter($tags); // Remove empty values
        }
        
        // If string, split by comma
        if (is_string($tags) && !empty($tags)) {
            return array_filter(array_map('trim', explode(',', $tags)));
        }
        
        return array();
    }
    
    /**
     * Create new product from Add Product modal
     */
    public function create_product() {
        check_ajax_referer('aiwpg_nonce', 'nonce');
        
        if (!current_user_can('manage_woocommerce')) {
            $this->logger->log('Permission denied for create_product', 'products_controller', array(), 'warning');
            wp_send_json_error(array('message' => __('Permission denied', 'ai-woo-product-generator')));
        }
        
        $product_data = isset($_POST['product']) ? json_decode(stripslashes($_POST['product']), true) : array();
        
        $this->logger->log('Create product request received', 'products_controller', array('has_data' => !empty($product_data)), 'info');
        
        if (empty($product_data) || !isset($product_data['name'])) {
            $this->logger->log('Invalid product data', 'products_controller', array('data' => $product_data), 'error');
            wp_send_json_error(array('message' => __('Product data is required', 'ai-woo-product-generator')));
        }
        
        // Transform data to match create_product format
        $formatted_data = array(
            'title' => $product_data['name'],
            'type' => isset($product_data['type']) ? $product_data['type'] : 'simple',
            'description' => isset($product_data['description']) ? $product_data['description'] : '',
            'short_description' => isset($product_data['short_description']) ? $product_data['short_description'] : '',
            'sku' => isset($product_data['sku']) ? $product_data['sku'] : '',
            'regular_price' => isset($product_data['regular_price']) ? $product_data['regular_price'] : '',
            'sale_price' => isset($product_data['sale_price']) ? $product_data['sale_price'] : '',
            'stock_quantity' => isset($product_data['stock_quantity']) ? $product_data['stock_quantity'] : '',
            'stock_status' => isset($product_data['stock_status']) ? $product_data['stock_status'] : 'instock',
            'manage_stock' => isset($product_data['manage_stock']) ? $product_data['manage_stock'] : false,
            'categories' => isset($product_data['categories']) ? $product_data['categories'] : array(),
            'tags' => $this->prepare_tags($product_data),
            'status' => isset($product_data['status']) ? $product_data['status'] : 'publish',
            'virtual' => isset($product_data['virtual']) ? $product_data['virtual'] : false,
            'downloadable' => isset($product_data['downloadable']) ? $product_data['downloadable'] : false,
            'weight' => isset($product_data['weight']) ? $product_data['weight'] : '',
            'length' => isset($product_data['length']) ? $product_data['length'] : '',
            'width' => isset($product_data['width']) ? $product_data['width'] : '',
            'height' => isset($product_data['height']) ? $product_data['height'] : '',
            'featured' => isset($product_data['featured']) ? $product_data['featured'] : false,
            'catalog_visibility' => isset($product_data['catalog_visibility']) ? $product_data['catalog_visibility'] : 'visible',
            'sold_individually' => isset($product_data['sold_individually']) ? $product_data['sold_individually'] : false,
            'reviews_allowed' => isset($product_data['reviews_allowed']) ? $product_data['reviews_allowed'] : true,
        );
        
        // External product specific fields
        if ($formatted_data['type'] === 'external') {
            $formatted_data['external_url'] = isset($product_data['external_url']) ? $product_data['external_url'] : '';
            $formatted_data['button_text'] = isset($product_data['button_text']) ? $product_data['button_text'] : 'Buy Now';
        }
        
        // Downloadable product specific fields
        if ($formatted_data['downloadable']) {
            $formatted_data['download_limit'] = isset($product_data['download_limit']) ? $product_data['download_limit'] : -1;
            $formatted_data['download_expiry'] = isset($product_data['download_expiry']) ? $product_data['download_expiry'] : -1;
            $formatted_data['downloadable_files'] = isset($product_data['downloadable_files']) ? $product_data['downloadable_files'] : array();
        }
        
        // Media (Images)
        if (isset($product_data['image_id']) && !empty($product_data['image_id'])) {
            $formatted_data['image_id'] = $product_data['image_id'];
        }
        if (isset($product_data['gallery_ids']) && !empty($product_data['gallery_ids'])) {
            $formatted_data['gallery_ids'] = $product_data['gallery_ids'];
        }
        
        $this->logger->log('Attempting to create product', 'products_controller', array('formatted_data' => $formatted_data), 'info');
        
        $product_id = $this->product_model->create_product($formatted_data);
        
        if (is_wp_error($product_id)) {
            $error_message = $product_id->get_error_message();
            $error_code = $product_id->get_error_code();
            
            $this->logger->log(
                'Product creation failed: ' . $error_message, 
                'products_controller', 
                array(
                    'error_code' => $error_code,
                    'error_message' => $error_message,
                    'product_data' => $formatted_data
                ), 
                'error'
            );
            
            wp_send_json_error(array(
                'message' => $error_message,
                'error_code' => $error_code
            ));
        }
        
        wp_send_json_success(array(
            'message' => __('Product created successfully', 'ai-woo-product-generator'),
            'product_id' => $product_id,
        ));
    }
    
    /**
     * Get gallery images by IDs
     */
    public function get_gallery_images() {
        check_ajax_referer('aiwpg_nonce', 'nonce');
        
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error(array('message' => __('Permission denied', 'ai-woo-product-generator')));
        }
        
        $image_ids = isset($_POST['image_ids']) ? $_POST['image_ids'] : array();
        
        if (empty($image_ids) || !is_array($image_ids)) {
            wp_send_json_error(array('message' => __('No image IDs provided', 'ai-woo-product-generator')));
        }
        
        $images = array();
        foreach ($image_ids as $image_id) {
            $image_url = wp_get_attachment_url($image_id);
            if ($image_url) {
                $images[] = array(
                    'id' => $image_id,
                    'url' => $image_url,
                );
            }
        }
        
        wp_send_json_success(array('images' => $images));
    }
    
    /**
     * Get all products list (for linked products selection)
     */
    public function get_all_products_list() {
        check_ajax_referer('aiwpg_nonce', 'nonce');
        
        if (!current_user_can('manage_woocommerce')) {
            $this->logger->log('Permission denied for get_all_products_list', 'products_controller', array(), 'warning');
            wp_send_json_error(array('message' => __('Permission denied', 'ai-woo-product-generator')));
        }
        
        $exclude_id = isset($_POST['exclude_id']) ? intval($_POST['exclude_id']) : 0;
        
        $this->logger->log('Getting all products list', 'products_controller', array('exclude_id' => $exclude_id), 'info');
        
        $args = array(
            'post_type' => 'product',
            'post_status' => 'publish',
            'posts_per_page' => -1,
            'orderby' => 'title',
            'order' => 'ASC',
            'fields' => 'ids',
        );
        
        if ($exclude_id > 0) {
            $args['post__not_in'] = array($exclude_id);
        }
        
        $query = new WP_Query($args);
        $products = array();
        
        $this->logger->log('WP_Query executed', 'products_controller', array('found_posts' => $query->found_posts), 'info');
        
        if ($query->have_posts()) {
            foreach ($query->posts as $product_id) {
                $product = wc_get_product($product_id);
                if ($product) {
                    $products[] = array(
                        'id' => $product->get_id(),
                        'title' => $product->get_name(),
                    );
                }
            }
        }
        
        wp_reset_postdata();
        
        $this->logger->log('Products list retrieved', 'products_controller', array('total_products' => count($products)), 'info');
        
        wp_send_json_success(array('products' => $products));
    }
    
    /**
     * Save Excel products after confirmation
     */
    public function save_excel_products() {
        check_ajax_referer('aiwpg_nonce', 'nonce');
        
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error(array('message' => __('Permission denied', 'ai-woo-product-generator')));
        }
        
        // Accept both 'products' (already converted) or 'rows' (raw Excel data)
        $rows_data = isset($_POST['rows']) ? json_decode(stripslashes($_POST['rows']), true) : null;
        $products_data = isset($_POST['products']) ? json_decode(stripslashes($_POST['products']), true) : null;
        
        $import_mode = isset($_POST['import_mode']) ? sanitize_text_field($_POST['import_mode']) : 'create-new';
        
        // Map import modes
        if ($import_mode === 'create-new') {
            $import_mode = 'create-only';
        } elseif ($import_mode === 'create-update') {
            // Keep as is
        } else {
            $import_mode = 'create-only'; // Default
        }
        
        // Convert rows to product data if needed
        if (!empty($rows_data) && is_array($rows_data)) {
            $products_data = array();
            foreach ($rows_data as $row) {
                $product_data = $this->convert_row_to_product_data($row);
                if (!isset($product_data['error'])) {
                    $products_data[] = $product_data;
                }
            }
        }
        
        if (empty($products_data)) {
            wp_send_json_error(array('message' => __('No products selected for import', 'ai-woo-product-generator')));
        }
        
        $this->logger->log(
            'Starting Excel products import',
            'products_controller',
            array(
                'products_count' => count($products_data),
                'import_mode' => $import_mode
            ),
            'info'
        );
        
        $created = array();
        $updated = array();
        $skipped = array();
        $errors = array();
        
        foreach ($products_data as $index => $product_data) {
            try {
                // Skip products with errors
                if (isset($product_data['error'])) {
                    $skipped[] = sprintf(__('Row %d: %s', 'ai-woo-product-generator'), $product_data['row_index'] ?? ($index + 1), $product_data['error']);
                    continue;
                }
                
                // Validate required fields
                if (empty($product_data['title'])) {
                    $errors[] = sprintf(__('Row %d: Product name is required', 'ai-woo-product-generator'), $index + 1);
                    continue;
                }
                
                // Check if product exists (by SKU or name)
                $existing_id = null;
                if (!empty($product_data['sku'])) {
                    $existing_id = wc_get_product_id_by_sku($product_data['sku']);
                }
                
                if (!$existing_id && !empty($product_data['title'])) {
                    // Try to find by name
                    $posts = get_posts(array(
                        'post_type' => 'product',
                        'title' => $product_data['title'],
                        'posts_per_page' => 1,
                        'post_status' => 'any',
                    ));
                    if (!empty($posts)) {
                        $existing_id = $posts[0]->ID;
                    }
                }
                
                // Handle based on import mode
                if (($import_mode === 'create-only' || $import_mode === 'create-new') && $existing_id) {
                    $skipped[] = sprintf(__('Product "%s" already exists (SKU: %s)', 'ai-woo-product-generator'), $product_data['title'], $product_data['sku'] ?? 'N/A');
                    continue;
                }
                
                // Create or update product
                if ($existing_id && $import_mode === 'create-update') {
                    // Update existing product
                    $result = $this->product_model->update_product($existing_id, $product_data);
                    if (is_wp_error($result)) {
                        $errors[] = sprintf(__('Failed to update product "%s": %s', 'ai-woo-product-generator'), $product_data['title'], $result->get_error_message());
                        
                        $this->logger->log(
                            'Failed to update product',
                            'products_controller',
                            array(
                                'product_id' => $existing_id,
                                'product_title' => $product_data['title'],
                                'error' => $result->get_error_message()
                            ),
                            'error'
                        );
                    } else {
                        $updated[] = $existing_id;
                        // Apply kitchen and add-on group settings
                        $this->apply_product_metadata($existing_id, $product_data);
                        
                        $this->logger->log(
                            'Product updated successfully',
                            'products_controller',
                            array('product_id' => $existing_id, 'product_title' => $product_data['title']),
                            'info'
                        );
                    }
                } else {
                    // Create new product
                    $product_id = $this->product_model->create_product($product_data);
                    
                    if (is_wp_error($product_id)) {
                        $error_msg = $product_id->get_error_message();
                        $errors[] = sprintf(__('Failed to create product "%s": %s', 'ai-woo-product-generator'), $product_data['title'], $error_msg);
                        
                        $this->logger->log(
                            'Failed to create product',
                            'products_controller',
                            array(
                                'product_title' => $product_data['title'],
                                'error' => $error_msg,
                                'product_data_keys' => array_keys($product_data)
                            ),
                            'error'
                        );
                    } elseif ($product_id && $product_id > 0) {
                        // Verify product was created
                        $created_product = wc_get_product($product_id);
                        if ($created_product) {
                            $created[] = $product_id;
                            // Apply kitchen and add-on group settings
                            $this->apply_product_metadata($product_id, $product_data);
                            
                            $this->logger->log(
                                'Product created successfully',
                                'products_controller',
                                array(
                                    'product_id' => $product_id,
                                    'product_title' => $product_data['title'],
                                    'product_status' => $created_product->get_status()
                                ),
                                'info'
                            );
                        } else {
                            $errors[] = sprintf(__('Product ID returned but product not found: %d', 'ai-woo-product-generator'), $product_id);
                        }
                    } else {
                        $errors[] = sprintf(__('Invalid product ID returned for "%s"', 'ai-woo-product-generator'), $product_data['title']);
                    }
                }
                
            } catch (Exception $e) {
                $errors[] = sprintf(__('Row %d: Exception - %s', 'ai-woo-product-generator'), $index + 1, $e->getMessage());
                
                $this->logger->log(
                    'Exception in save_excel_products',
                    'products_controller',
                    array(
                        'row_index' => $index + 1,
                        'exception' => $e->getMessage(),
                        'trace' => $e->getTraceAsString()
                    ),
                    'error'
                );
            }
        }
        
        $stats = array(
            'created' => count($created),
            'updated' => count($updated),
            'skipped' => count($skipped),
            'errors' => $errors,
        );
        
        $this->logger->log(
            'Excel products import completed',
            'products_controller',
            array_merge($stats, array('total_processed' => count($products_data))),
            'info'
        );
        
        wp_send_json_success(array(
            'message' => sprintf(
                __('Import completed: %d created, %d updated, %d skipped, %d errors', 'ai-woo-product-generator'),
                $stats['created'],
                $stats['updated'],
                $stats['skipped'],
                count($stats['errors'])
            ),
            'stats' => $stats,
            'created' => count($created),
            'updated' => count($updated),
            'skipped' => count($skipped),
            'errors' => $errors,
            'skipped_details' => $skipped,
        ));
    }
    
    /**
     * Apply product metadata (kitchen, add-on groups, etc.)
     */
    private function apply_product_metadata($product_id, $product_data) {
        // Save kitchen assignment
        if (isset($product_data['_ai_kitchen'])) {
            update_post_meta($product_id, '_aiwpg_kitchen', sanitize_text_field($product_data['_ai_kitchen']));
        }
        
        // Store additions in product meta for addons importer
        if (isset($product_data['additions']) && !empty($product_data['additions'])) {
            update_post_meta($product_id, '_aiwpg_additions', sanitize_text_field($product_data['additions']));
            
            // Also import add-ons directly to our add-ons table
            $addon_model = AIWPG_Addon_Model::get_instance();
            $group_name = isset($product_data['addongroup']) ? $product_data['addongroup'] : null;
            if (empty($group_name) && isset($product_data['category'])) {
                // Try to determine group from category
                $category_name = strtolower($product_data['category']);
                $category_group_mapping = array(
                    'pizza' => 'Pizza Addons',
                    'burger' => 'Burger Extras',
                    'salad' => 'Salad Toppings',
                    'drink' => 'Drink Extras',
                    'coffee' => 'Drink Extras',
                );
                foreach ($category_group_mapping as $key => $group) {
                    if (strpos($category_name, $key) !== false) {
                        $group_name = $group;
                        break;
                    }
                }
            }
            $addon_model->import_from_sheet($product_id, $product_data['additions'], $group_name);
        }
        
        // Handle add-on groups if Woo Food is active
        if (isset($product_data['_ai_isaddon']) && $product_data['_ai_isaddon'] && !empty($product_data['_ai_addongroup'])) {
            $this->assign_to_woo_food_addon_group($product_id, $product_data['_ai_addongroup']);
        }
        
        // Fire action hook for extensibility
        do_action('aiwpg_after_import_row', $product_id, $product_data);
    }
    
    /**
     * Assign product to Woo Food add-on group
     */
    private function assign_to_woo_food_addon_group($product_id, $addon_group_name) {
        // Check if Woo Food plugin is active
        if (!function_exists('exwoofood_get_option')) {
            $this->logger->log(
                'Woo Food plugin not active, skipping add-on group assignment',
                'excel_import',
                array('product_id' => $product_id, 'group_name' => $addon_group_name),
                'info'
            );
            return;
        }
        
        // Get or create add-on group
        // Woo Food stores add-ons in exwo_options meta
        // This is a simplified approach - may need adjustment based on actual Woo Food implementation
        
        $product = wc_get_product($product_id);
        if (!$product) {
            return;
        }
        
        // Get existing add-on options
        $exwo_options = get_post_meta($product_id, 'exwo_options', true);
        if (empty($exwo_options)) {
            $exwo_options = array();
        } else {
            $exwo_options = maybe_unserialize($exwo_options);
            if (!is_array($exwo_options)) {
                $exwo_options = array();
            }
        }
        
        // Check if group already exists
        $group_exists = false;
        foreach ($exwo_options as $option) {
            if (isset($option['_name']) && $option['_name'] === $addon_group_name) {
                $group_exists = true;
                break;
            }
        }
        
        // If group doesn't exist, we can't automatically create it in Woo Food structure
        // Instead, we'll store the group name in a custom meta for reference
        update_post_meta($product_id, '_aiwpg_addon_group', sanitize_text_field($addon_group_name));
        update_post_meta($product_id, '_aiwpg_is_addon', true);
        
        $this->logger->log(
            'Add-on group assigned to product',
            'excel_import',
            array('product_id' => $product_id, 'group_name' => $addon_group_name, 'group_exists' => $group_exists),
            'info'
        );
    }
    
    /**
     * Parse uploaded Excel/CSV file (supports client-side parsed data)
     */
    public function parse_excel_file() {
        check_ajax_referer('aiwpg_nonce', 'nonce');
        
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error(array('message' => __('Permission denied', 'ai-woo-product-generator')));
        }
        
        require_once AIWPG_PLUGIN_DIR . 'models/class-aiwpg-excel-parser.php';
        
        // Option 1: Client-side parsed data (from SheetJS)
        if (isset($_POST['parsed_data'])) {
            $parsed_data = json_decode(stripslashes($_POST['parsed_data']), true);
            $ai_module = isset($_POST['ai_module']) ? sanitize_text_field($_POST['ai_module']) : '';
            
            if (empty($parsed_data) || !is_array($parsed_data)) {
                wp_send_json_error(array('message' => __('Invalid parsed data', 'ai-woo-product-generator')));
            }
            
            // Normalize client-side parsed data
            $parser = new AIWPG_Excel_Parser();
            $normalized = $parser->normalize_client_parsed_data($parsed_data);
            
            // Apply AI module from form if specified (overrides Excel column)
            if (!empty($ai_module)) {
                foreach ($normalized as &$row) {
                    $row['ai_module'] = $ai_module;
                }
            }
            
            $this->logger->log(
                'Excel file parsed (client-side)',
                'products_controller',
                array('rows_count' => count($normalized), 'ai_module' => $ai_module),
                'info'
            );
            
            wp_send_json_success(array(
                'message' => sprintf(__('%d rows parsed successfully', 'ai-woo-product-generator'), count($normalized)),
                'rows' => $normalized,
            ));
        }
        
        // Option 2: Server-side file upload parsing
        if (!isset($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
            wp_send_json_error(array('message' => __('File upload failed or no file provided', 'ai-woo-product-generator')));
        }
        
        $file = $_FILES['file'];
        $upload_dir = wp_upload_dir();
        $temp_dir = $upload_dir['basedir'] . '/aiwpg-temp';
        
        // Create temp directory if it doesn't exist
        if (!file_exists($temp_dir)) {
            wp_mkdir_p($temp_dir);
        }
        
        // Generate unique filename
        $filename = sanitize_file_name(basename($file['name']));
        $temp_filepath = $temp_dir . '/' . uniqid('excel_') . '_' . $filename;
        
        // Move uploaded file
        if (!move_uploaded_file($file['tmp_name'], $temp_filepath)) {
            wp_send_json_error(array('message' => __('Failed to save uploaded file', 'ai-woo-product-generator')));
        }
        
        // Parse file
        $parser = new AIWPG_Excel_Parser();
        $result = $parser->parse($temp_filepath);
        
        // Clean up temp file
        @unlink($temp_filepath);
        
        if (is_wp_error($result)) {
            wp_send_json_error(array('message' => $result->get_error_message()));
        }
        
        $this->logger->log(
            'Excel file parsed successfully (server-side)',
            'products_controller',
            array('rows_count' => count($result)),
            'info'
        );
        
        wp_send_json_success(array(
            'message' => sprintf(__('%d rows parsed successfully', 'ai-woo-product-generator'), count($result)),
            'rows' => $result,
        ));
    }
    
    /**
     * Enrich Excel rows with AI classification
     */
    public function enrich_excel_rows() {
        check_ajax_referer('aiwpg_nonce', 'nonce');
        
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error(array('message' => __('Permission denied', 'ai-woo-product-generator')));
        }
        
        $rows_json = isset($_POST['rows']) ? stripslashes($_POST['rows']) : '[]';
        $rows = json_decode($rows_json, true);
        $ai_module = isset($_POST['ai_module']) ? sanitize_text_field($_POST['ai_module']) : '';
        
        if (empty($rows) || !is_array($rows)) {
            wp_send_json_error(array('message' => __('Invalid rows data', 'ai-woo-product-generator')));
        }
        
        // Apply AI module from form if specified (overrides Excel column)
        if (!empty($ai_module)) {
            foreach ($rows as &$row) {
                $row['ai_module'] = $ai_module;
            }
        }
        
        require_once AIWPG_PLUGIN_DIR . 'models/class-aiwpg-ai-service.php';
        
        $ai_service = new AIWPG_AI_Service();
        $enriched = $ai_service->enrich_product_rows($rows, 10, $ai_module); // Process in batches of 10
        
        $this->logger->log(
            'Rows enriched with AI',
            'products_controller',
            array('rows_count' => count($enriched)),
            'info'
        );
        
        wp_send_json_success(array(
            'message' => sprintf(__('%d rows enriched successfully', 'ai-woo-product-generator'), count($enriched)),
            'enriched' => $enriched,
        ));
    }
    
    /**
     * Import Excel products to WooCommerce
     */
    public function import_excel_products() {
        check_ajax_referer('aiwpg_nonce', 'nonce');
        
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error(array('message' => __('Permission denied', 'ai-woo-product-generator')));
        }
        
        $rows_json = isset($_POST['rows']) ? stripslashes($_POST['rows']) : '[]';
        $rows = json_decode($rows_json, true);
        $import_mode = isset($_POST['import_mode']) ? sanitize_text_field($_POST['import_mode']) : 'create-new';
        
        if (empty($rows) || !is_array($rows)) {
            wp_send_json_error(array('message' => __('Invalid rows data', 'ai-woo-product-generator')));
        }
        
        // Skip import if dry-run
        if ($import_mode === 'dry-run') {
            wp_send_json_success(array(
                'message' => __('Dry-run mode: No products were created', 'ai-woo-product-generator'),
                'stats' => array(
                    'created' => 0,
                    'updated' => 0,
                    'skipped' => count($rows),
                    'errors' => array(),
                ),
            ));
        }
        
        $stats = array(
            'created' => 0,
            'updated' => 0,
            'skipped' => 0,
            'errors' => array(),
        );
        
        // Process each row
        foreach ($rows as $row_index => $row) {
            try {
                // Convert enriched row to WooCommerce product data
                $product_data = $this->convert_row_to_product_data($row);
                
                // Skip if error in conversion
                if (isset($product_data['error'])) {
                    $stats['errors'][] = sprintf(
                        __('Row %d: %s', 'ai-woo-product-generator'),
                        $row['_row_index'] ?? ($row_index + 1),
                        $product_data['error']
                    );
                    continue;
                }
                
                // Check if product exists (by SKU or name)
                $existing_id = null;
                if (!empty($product_data['sku'])) {
                    $existing_id = wc_get_product_id_by_sku($product_data['sku']);
                }
                
                if (!$existing_id && !empty($product_data['title'])) {
                    // Try to find by title
                    $existing = get_page_by_title($product_data['title'], OBJECT, 'product');
                    if ($existing) {
                        $existing_id = $existing->ID;
                    }
                }
                
                // Handle based on import mode
                if ($existing_id && $import_mode === 'create-new') {
                    $stats['skipped']++;
                    continue;
                }
                
                if ($existing_id && $import_mode === 'create-update') {
                    // Update existing product
                    $result = $this->product_model->update_product($existing_id, $product_data);
                    if (!is_wp_error($result)) {
                        $stats['updated']++;
                        // Apply metadata
                        $this->apply_product_metadata($existing_id, $product_data);
                    } else {
                        $stats['errors'][] = sprintf(
                            __('Row %d: %s', 'ai-woo-product-generator'),
                            $row['_row_index'] ?? ($row_index + 1),
                            $result->get_error_message()
                        );
                    }
                } else {
                    // Create new product using create_product method
                    $product_id = $this->product_model->create_product($product_data);
                    
                    if (is_wp_error($product_id)) {
                        $stats['errors'][] = sprintf(
                            __('Row %d: %s', 'ai-woo-product-generator'),
                            $row['_row_index'] ?? ($row_index + 1),
                            $product_id->get_error_message()
                        );
                    } elseif ($product_id && $product_id > 0) {
                        // Verify product was created
                        $created_product = wc_get_product($product_id);
                        if ($created_product) {
                            $stats['created']++;
                            // Apply metadata (kitchen, add-ons, etc.)
                            $this->apply_product_metadata($product_id, $product_data);
                        } else {
                            $stats['errors'][] = sprintf(
                                __('Row %d: Product ID returned but product not found', 'ai-woo-product-generator'),
                                $row['_row_index'] ?? ($row_index + 1)
                            );
                        }
                    } else {
                        $stats['errors'][] = sprintf(
                            __('Row %d: Invalid product ID returned', 'ai-woo-product-generator'),
                            $row['_row_index'] ?? ($row_index + 1)
                        );
                    }
                }
                
            } catch (Exception $e) {
                $stats['errors'][] = sprintf(
                    __('Row %d: %s', 'ai-woo-product-generator'),
                    $row['_row_index'] ?? ($row_index + 1),
                    $e->getMessage()
                );
            }
        }
        
        $this->logger->log(
            'Excel products import completed',
            'products_controller',
            array_merge($stats, array('total_rows' => count($rows))),
            'info'
        );
        
        wp_send_json_success(array(
            'message' => sprintf(
                __('Import completed: %d created, %d updated, %d skipped', 'ai-woo-product-generator'),
                $stats['created'],
                $stats['updated'],
                $stats['skipped']
            ),
            'stats' => $stats,
        ));
    }
}
