<?php
/**
 * Add-ons Controller
 * Handles AJAX requests for product add-ons management
 * 
 * @package AIWPG
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

class AIWPG_Addons_Controller {
    
    /**
     * Single instance
     */
    private static $instance = null;
    
    /**
     * Add-on model
     */
    private $addon_model;
    
    /**
     * Logger
     */
    private $logger;
    
    /**
     * Get instance
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructor
     */
    private function __construct() {
        $this->addon_model = AIWPG_Addon_Model::get_instance();
        $this->logger = AIWPG_Logger::get_instance();
        
        // AJAX handlers
        add_action('wp_ajax_aiwpg_get_product_addons', array($this, 'ajax_get_product_addons'));
        add_action('wp_ajax_aiwpg_create_addon', array($this, 'ajax_create_addon'));
        add_action('wp_ajax_aiwpg_update_addon', array($this, 'ajax_update_addon'));
        add_action('wp_ajax_aiwpg_delete_addon', array($this, 'ajax_delete_addon'));
        add_action('wp_ajax_aiwpg_bulk_update_addons', array($this, 'ajax_bulk_update_addons'));
        add_action('wp_ajax_aiwpg_sync_external_addons', array($this, 'ajax_sync_external_addons'));
        add_action('wp_ajax_aiwpg_generate_ai_suggestions', array($this, 'ajax_generate_ai_suggestions'));
    }
    
    /**
     * Get product add-ons (AJAX)
     */
    public function ajax_get_product_addons() {
        check_ajax_referer('aiwpg_nonce', 'nonce');
        
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error(array('message' => __('Permission denied', 'ai-woo-product-generator')));
        }
        
        $product_id = isset($_POST['product_id']) ? intval($_POST['product_id']) : 0;
        $source = isset($_POST['source']) ? sanitize_text_field($_POST['source']) : null;
        $status = isset($_POST['status']) ? sanitize_text_field($_POST['status']) : null;
        
        if (!$product_id) {
            wp_send_json_error(array('message' => __('Product ID is required', 'ai-woo-product-generator')));
        }
        
        $addons = $this->addon_model->get_product_addons($product_id, $source, $status);
        $counts = $this->addon_model->get_addons_count_by_source($product_id);
        
        // Also sync external add-ons if needed
        $this->sync_external_addons($product_id);
        
        wp_send_json_success(array(
            'addons' => $addons,
            'counts' => $counts,
        ));
    }
    
    /**
     * Create add-on (AJAX)
     */
    public function ajax_create_addon() {
        check_ajax_referer('aiwpg_nonce', 'nonce');
        
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error(array('message' => __('Permission denied', 'ai-woo-product-generator')));
        }
        
        $data = array(
            'product_id' => isset($_POST['product_id']) ? intval($_POST['product_id']) : 0,
            'addon_name' => isset($_POST['addon_name']) ? sanitize_text_field($_POST['addon_name']) : '',
            'addon_group' => isset($_POST['addon_group']) ? sanitize_text_field($_POST['addon_group']) : null,
            'price' => isset($_POST['price']) ? floatval($_POST['price']) : 0.00,
            'price_type' => isset($_POST['price_type']) ? sanitize_text_field($_POST['price_type']) : 'flat_fee',
            'selection_type' => isset($_POST['selection_type']) ? sanitize_text_field($_POST['selection_type']) : 'multiple_choice',
            'status' => isset($_POST['status']) ? sanitize_text_field($_POST['status']) : 'suggested',
            'scope' => isset($_POST['scope']) ? sanitize_text_field($_POST['scope']) : 'this_product',
            'source' => 'manual',
        );
        
        $id = $this->addon_model->create_addon($data);
        
        if (is_wp_error($id)) {
            wp_send_json_error(array('message' => $id->get_error_message()));
        }
        
        $addon = $this->addon_model->get_addon($id);
        
        wp_send_json_success(array(
            'message' => __('Add-on created successfully', 'ai-woo-product-generator'),
            'addon' => $addon,
        ));
    }
    
    /**
     * Update add-on (AJAX)
     */
    public function ajax_update_addon() {
        check_ajax_referer('aiwpg_nonce', 'nonce');
        
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error(array('message' => __('Permission denied', 'ai-woo-product-generator')));
        }
        
        $id = isset($_POST['id']) ? intval($_POST['id']) : 0;
        
        if (!$id) {
            wp_send_json_error(array('message' => __('Add-on ID is required', 'ai-woo-product-generator')));
        }
        
        $data = array();
        
        if (isset($_POST['addon_name'])) {
            $data['addon_name'] = sanitize_text_field($_POST['addon_name']);
        }
        if (isset($_POST['addon_group'])) {
            $data['addon_group'] = sanitize_text_field($_POST['addon_group']);
        }
        if (isset($_POST['price'])) {
            $data['price'] = floatval($_POST['price']);
        }
        if (isset($_POST['price_type'])) {
            $data['price_type'] = sanitize_text_field($_POST['price_type']);
        }
        if (isset($_POST['selection_type'])) {
            $data['selection_type'] = sanitize_text_field($_POST['selection_type']);
        }
        if (isset($_POST['status'])) {
            $data['status'] = sanitize_text_field($_POST['status']);
        }
        if (isset($_POST['scope'])) {
            $data['scope'] = sanitize_text_field($_POST['scope']);
        }
        
        $result = $this->addon_model->update_addon($id, $data);
        
        if (is_wp_error($result)) {
            wp_send_json_error(array('message' => $result->get_error_message()));
        }
        
        $addon = $this->addon_model->get_addon($id);
        
        wp_send_json_success(array(
            'message' => __('Add-on updated successfully', 'ai-woo-product-generator'),
            'addon' => $addon,
        ));
    }
    
    /**
     * Delete add-on (AJAX)
     */
    public function ajax_delete_addon() {
        check_ajax_referer('aiwpg_nonce', 'nonce');
        
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error(array('message' => __('Permission denied', 'ai-woo-product-generator')));
        }
        
        $id = isset($_POST['id']) ? intval($_POST['id']) : 0;
        
        if (!$id) {
            wp_send_json_error(array('message' => __('Add-on ID is required', 'ai-woo-product-generator')));
        }
        
        $result = $this->addon_model->delete_addon($id);
        
        if (is_wp_error($result)) {
            wp_send_json_error(array('message' => $result->get_error_message()));
        }
        
        wp_send_json_success(array(
            'message' => __('Add-on deleted successfully', 'ai-woo-product-generator'),
        ));
    }
    
    /**
     * Bulk update add-ons (AJAX)
     */
    public function ajax_bulk_update_addons() {
        check_ajax_referer('aiwpg_nonce', 'nonce');
        
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error(array('message' => __('Permission denied', 'ai-woo-product-generator')));
        }
        
        $ids = isset($_POST['ids']) ? array_map('intval', $_POST['ids']) : array();
        $action = isset($_POST['action_type']) ? sanitize_text_field($_POST['action_type']) : '';
        
        if (empty($ids)) {
            wp_send_json_error(array('message' => __('No add-ons selected', 'ai-woo-product-generator')));
        }
        
        $data = array();
        
        switch ($action) {
            case 'attach':
                $data['status'] = 'attached';
                break;
            case 'detach':
                $data['status'] = 'suggested';
                break;
            case 'ignore':
                $data['status'] = 'ignored';
                break;
            default:
                wp_send_json_error(array('message' => __('Invalid action', 'ai-woo-product-generator')));
        }
        
        $updated = $this->addon_model->bulk_update_addons($ids, $data);
        
        if (is_wp_error($updated)) {
            wp_send_json_error(array('message' => $updated->get_error_message()));
        }
        
        wp_send_json_success(array(
            'message' => sprintf(__('%d add-on(s) updated successfully', 'ai-woo-product-generator'), $updated),
            'updated' => $updated,
        ));
    }
    
    /**
     * Sync external add-ons (AJAX)
     * Fetches add-ons from Woo Food, WC Product Add-ons, etc.
     */
    public function ajax_sync_external_addons() {
        check_ajax_referer('aiwpg_nonce', 'nonce');
        
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error(array('message' => __('Permission denied', 'ai-woo-product-generator')));
        }
        
        $product_id = isset($_POST['product_id']) ? intval($_POST['product_id']) : 0;
        
        if (!$product_id) {
            wp_send_json_error(array('message' => __('Product ID is required', 'ai-woo-product-generator')));
        }
        
        $synced = $this->sync_external_addons($product_id);
        
        wp_send_json_success(array(
            'message' => __('External add-ons synced successfully', 'ai-woo-product-generator'),
            'synced' => $synced,
        ));
    }
    
    /**
     * Sync external add-ons for a product
     * 
     * @param int $product_id Product ID
     * @return array Summary of synced add-ons
     */
    private function sync_external_addons($product_id) {
        $synced = array(
            'woo_food' => 0,
            'wc_addons' => 0,
        );
        
        // Sync Woo Food add-ons
        if (class_exists('Woo_Food') || function_exists('woo_food_get_product_addons')) {
            $woo_food_addons = $this->sync_woo_food_addons($product_id);
            $synced['woo_food'] = count($woo_food_addons);
        }
        
        // Sync WooCommerce Product Add-ons
        if (class_exists('WC_Product_Add_Ons')) {
            $wc_addons = $this->sync_wc_product_addons($product_id);
            $synced['wc_addons'] = count($wc_addons);
        }
        
        return $synced;
    }
    
    /**
     * Sync Woo Food add-ons
     * 
     * @param int $product_id Product ID
     * @return array Created add-on IDs
     */
    private function sync_woo_food_addons($product_id) {
        $created_ids = array();
        
        // Try to get Woo Food add-ons
        // This is a placeholder - adjust based on actual Woo Food API
        if (function_exists('woo_food_get_product_addons')) {
            $woo_food_addons = woo_food_get_product_addons($product_id);
            
            if (is_array($woo_food_addons) && !empty($woo_food_addons)) {
                foreach ($woo_food_addons as $addon) {
                    // Check if already exists
                    $existing = $this->addon_model->get_product_addons($product_id, 'woo_food');
                    $exists = false;
                    foreach ($existing as $existing_addon) {
                        if (isset($addon['id']) && $existing_addon['external_id'] == $addon['id']) {
                            $exists = true;
                            break;
                        }
                    }
                    
                    if (!$exists) {
                        $addon_data = array(
                            'product_id' => $product_id,
                            'addon_name' => isset($addon['name']) ? $addon['name'] : 'Add-on',
                            'addon_group' => isset($addon['group']) ? $addon['group'] : null,
                            'source' => 'woo_food',
                            'price' => isset($addon['price']) ? floatval($addon['price']) : 0.00,
                            'price_type' => isset($addon['price_type']) ? $addon['price_type'] : 'flat_fee',
                            'selection_type' => isset($addon['selection_type']) ? $addon['selection_type'] : 'multiple_choice',
                            'status' => 'suggested',
                            'scope' => 'this_product',
                            'external_id' => isset($addon['id']) ? $addon['id'] : null,
                            'external_data' => $addon,
                        );
                        
                        $id = $this->addon_model->create_addon($addon_data);
                        if (!is_wp_error($id)) {
                            $created_ids[] = $id;
                        }
                    }
                }
            }
        }
        
        return $created_ids;
    }
    
    /**
     * Sync WooCommerce Product Add-ons
     * 
     * @param int $product_id Product ID
     * @return array Created add-on IDs
     */
    private function sync_wc_product_addons($product_id) {
        $created_ids = array();
        
        // Get product add-ons assigned to this product
        $product_addons = get_post_meta($product_id, '_product_addons', true);
        
        if (is_array($product_addons) && !empty($product_addons)) {
            foreach ($product_addons as $group) {
                if (isset($group['fields']) && is_array($group['fields'])) {
                    foreach ($group['fields'] as $field) {
                        if (isset($field['options']) && is_array($field['options'])) {
                            foreach ($field['options'] as $option) {
                                // Check if already exists
                                $existing = $this->addon_model->get_product_addons($product_id, 'wc_addons');
                                $exists = false;
                                foreach ($existing as $existing_addon) {
                                    if (isset($option['label']) && $existing_addon['addon_name'] === $option['label']) {
                                        $exists = true;
                                        break;
                                    }
                                }
                                
                                if (!$exists && isset($option['label'])) {
                                    $addon_data = array(
                                        'product_id' => $product_id,
                                        'addon_name' => $option['label'],
                                        'addon_group' => isset($group['name']) ? $group['name'] : null,
                                        'source' => 'wc_addons',
                                        'price' => isset($option['price']) ? floatval($option['price']) : 0.00,
                                        'price_type' => isset($option['price_type']) ? $option['price_type'] : 'flat_fee',
                                        'selection_type' => isset($field['type']) ? $field['type'] : 'multiple_choice',
                                        'status' => 'attached', // Already attached in WC
                                        'scope' => 'this_product',
                                        'external_id' => isset($option['id']) ? $option['id'] : null,
                                        'external_data' => $option,
                                    );
                                    
                                    $id = $this->addon_model->create_addon($addon_data);
                                    if (!is_wp_error($id)) {
                                        $created_ids[] = $id;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        
        // Also check global add-ons that apply to this product
        // This would require checking product categories and matching global add-on restrictions
        
        return $created_ids;
    }
    
    /**
     * Generate AI suggestions (AJAX)
     */
    public function ajax_generate_ai_suggestions() {
        check_ajax_referer('aiwpg_nonce', 'nonce');
        
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error(array('message' => __('Permission denied', 'ai-woo-product-generator')));
        }
        
        $product_id = isset($_POST['product_id']) ? intval($_POST['product_id']) : 0;
        
        if (!$product_id) {
            wp_send_json_error(array('message' => __('Product ID is required', 'ai-woo-product-generator')));
        }
        
        $product = wc_get_product($product_id);
        if (!$product) {
            wp_send_json_error(array('message' => __('Product not found', 'ai-woo-product-generator')));
        }
        
        // Get product information
        $product_name = $product->get_name();
        $product_description = $product->get_description();
        $categories = wp_get_post_terms($product_id, 'product_cat', array('fields' => 'names'));
        $category_name = !empty($categories) ? implode(', ', $categories) : '';
        
        // Get kitchen info if available (from meta or custom field)
        $kitchen = get_post_meta($product_id, '_aiwpg_kitchen', true) ?: '';
        
        // Call AI service to generate suggestions
        $ai_service = new AIWPG_AI_Service();
        $suggestions = $ai_service->generate_addon_suggestions($product_name, $product_description, $category_name, $kitchen);
        
        if (is_wp_error($suggestions)) {
            wp_send_json_error(array('message' => $suggestions->get_error_message()));
        }
        
        // Create add-on records from suggestions
        $created_ids = array();
        foreach ($suggestions as $suggestion) {
            $addon_data = array(
                'product_id' => $product_id,
                'addon_name' => $suggestion['name'],
                'addon_group' => isset($suggestion['group']) ? $suggestion['group'] : null,
                'source' => 'ai',
                'price' => isset($suggestion['price']) ? floatval($suggestion['price']) : 0.00,
                'price_type' => isset($suggestion['price_type']) ? $suggestion['price_type'] : 'flat_fee',
                'selection_type' => isset($suggestion['selection_type']) ? $suggestion['selection_type'] : 'multiple_choice',
                'status' => 'suggested',
                'scope' => 'this_product',
            );
            
            $id = $this->addon_model->create_addon($addon_data);
            if (!is_wp_error($id)) {
                $created_ids[] = $id;
            }
        }
        
        wp_send_json_success(array(
            'message' => sprintf(__('%d AI suggestions generated', 'ai-woo-product-generator'), count($created_ids)),
            'suggestions' => $created_ids,
        ));
    }
}
