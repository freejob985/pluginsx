<?php
/**
 * Cron Job Controller
 * 
 * Handles cron job management and image generation endpoint
 *
 * @package AI_Woo_Product_Generator
 */

if (!defined('ABSPATH')) {
    exit;
}

class AIWPG_CronJob_Controller {
    /**
     * Single instance
     */
    private static $instance = null;
    
    /**
     * Cron job client
     */
    private $cron_client;
    
    /**
     * Batch image generator
     */
    private $batch_generator;
    
    /**
     * Logger instance
     */
    private $logger;
    
    /**
     * Get instance
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructor
     */
    private function __construct() {
        $this->cron_client = new AIWPG_CronJob_Client();
        $this->batch_generator = new AIWPG_Batch_Image_Generator();
        $this->logger = AIWPG_Logger::get_instance();
        
        // Register AJAX handlers
        add_action('wp_ajax_aiwpg_save_cron_settings', array($this, 'save_cron_settings'));
        add_action('wp_ajax_aiwpg_create_cron_job', array($this, 'create_cron_job'));
        add_action('wp_ajax_aiwpg_get_cron_progress', array($this, 'get_cron_progress'));
        add_action('wp_ajax_aiwpg_reset_cron_progress', array($this, 'reset_cron_progress'));
        
        // Register endpoint for cron-job.org to call
        add_action('init', array($this, 'register_cron_endpoint'));
        add_action('template_redirect', array($this, 'handle_cron_endpoint'));
    }
    
    /**
     * Register custom endpoint for cron job
     */
    public function register_cron_endpoint() {
        // Add rewrite rule
        add_rewrite_rule(
            '^aiwpg-cron-generate-images/?$',
            'index.php?aiwpg_cron_action=generate_images',
            'top'
        );
        
        // Add query var
        add_rewrite_tag('%aiwpg_cron_action%', '([^&]+)');
    }
    
    /**
     * Handle cron endpoint
     * This is called via template_redirect hook
     */
    public function handle_cron_endpoint() {
        // Check if this is our endpoint via query var
        $action = get_query_var('aiwpg_cron_action');
        
        // Also check direct URL parameter (fallback)
        if (empty($action) && isset($_GET['aiwpg_cron_action'])) {
            $action = sanitize_text_field($_GET['aiwpg_cron_action']);
        }
        
        if ($action === 'generate_images') {
            // Verify secret token (optional but recommended)
            $secret = isset($_GET['secret']) ? sanitize_text_field($_GET['secret']) : '';
            $saved_secret = get_option('aiwpg_cron_secret', '');
            
            // If secret is configured, verify it
            if (!empty($saved_secret) && $secret !== $saved_secret) {
                http_response_code(403);
                echo json_encode(array('error' => 'Invalid secret token'));
                exit;
            }
            
            // Process next item
            $result = $this->batch_generator->process_next_item();
            
            header('Content-Type: application/json');
            echo json_encode($result);
            exit;
        }
    }
    
    /**
     * Save cron settings
     */
    public function save_cron_settings() {
        check_ajax_referer('aiwpg_nonce', 'nonce');
        
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error(array('message' => __('Permission denied', 'ai-woo-product-generator')));
        }
        
        $api_key = isset($_POST['api_key']) ? sanitize_text_field($_POST['api_key']) : '';
        $interval = isset($_POST['interval']) ? sanitize_text_field($_POST['interval']) : 'minute';
        $timezone = isset($_POST['timezone']) ? sanitize_text_field($_POST['timezone']) : 'UTC';
        
        $settings = array(
            'api_key' => $api_key,
            'interval' => $interval,
            'timezone' => $timezone
        );
        
        update_option('aiwpg_cron_settings', $settings);
        
        // Generate and save secret token for endpoint security
        if (empty(get_option('aiwpg_cron_secret', ''))) {
            $secret = wp_generate_password(32, false);
            update_option('aiwpg_cron_secret', $secret);
        }
        
        wp_send_json_success(array(
            'message' => __('Cron settings saved successfully', 'ai-woo-product-generator')
        ));
    }
    
    /**
     * Create cron job
     */
    public function create_cron_job() {
        check_ajax_referer('aiwpg_nonce', 'nonce');
        
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error(array('message' => __('Permission denied', 'ai-woo-product-generator')));
        }
        
        // Get settings
        $settings = get_option('aiwpg_cron_settings', array());
        $api_key = isset($settings['api_key']) ? $settings['api_key'] : '';
        $interval = isset($settings['interval']) ? $settings['interval'] : 'minute';
        $timezone = isset($settings['timezone']) ? $settings['timezone'] : 'UTC';
        
        if (empty($api_key)) {
            wp_send_json_error(array('message' => __('Please configure cron-job.org API key first', 'ai-woo-product-generator')));
        }
        
        $this->cron_client->set_api_key($api_key);
        
        // Build endpoint URL
        $secret = get_option('aiwpg_cron_secret', '');
        $endpoint_url = home_url('/aiwpg-cron-generate-images');
        if (!empty($secret)) {
            $endpoint_url .= '?secret=' . urlencode($secret);
        }
        
        // Build schedule
        $schedule = $this->cron_client->build_schedule($interval, $timezone);
        
        // Initialize progress
        $this->batch_generator->init_progress();
        
        // Create cron job
        $result = $this->cron_client->create_job(
            $endpoint_url,
            $schedule,
            true,
            'AI WooCommerce Product Image Generator'
        );
        
        if ($result['success']) {
            // Save job ID
            $settings['job_id'] = $result['jobId'];
            update_option('aiwpg_cron_settings', $settings);
            
            wp_send_json_success(array(
                'message' => __('Cron job created successfully', 'ai-woo-product-generator'),
                'job_id' => $result['jobId']
            ));
        } else {
            wp_send_json_error(array(
                'message' => __('Failed to create cron job: ', 'ai-woo-product-generator') . $result['error']
            ));
        }
    }
    
    /**
     * Get cron progress
     */
    public function get_cron_progress() {
        check_ajax_referer('aiwpg_nonce', 'nonce');
        
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error(array('message' => __('Permission denied', 'ai-woo-product-generator')));
        }
        
        $progress = $this->batch_generator->get_progress();
        
        if (!$progress) {
            wp_send_json_success(array(
                'status' => 'not_started',
                'message' => __('No generation in progress', 'ai-woo-product-generator')
            ));
        }
        
        wp_send_json_success($progress);
    }
    
    /**
     * Reset cron progress
     */
    public function reset_cron_progress() {
        check_ajax_referer('aiwpg_nonce', 'nonce');
        
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error(array('message' => __('Permission denied', 'ai-woo-product-generator')));
        }
        
        $this->batch_generator->reset_progress();
        
        wp_send_json_success(array(
            'message' => __('Progress reset successfully', 'ai-woo-product-generator')
        ));
    }
}

