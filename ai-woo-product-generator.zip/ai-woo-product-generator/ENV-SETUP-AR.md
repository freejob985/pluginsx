# 🔐 دليل إعداد ملف البيئة (.env)

## 📋 نظرة عامة

تم تحديث الإضافة لتحميل مفاتيح API من ملف `.env` بدلاً من كتابتها مباشرة في الكود (لأسباب أمنية).

---

## 🚀 خطوات الإعداد السريع

### الخطوة 1️⃣: إنشاء ملف .env

في مجلد الإضافة `ai-woo-product-generator/`، أنشئ ملف جديد باسم `.env`:

```bash
cd wp-content/plugins/ai-woo-product-generator/
touch .env
```

### الخطوة 2️⃣: إضافة مفاتيح API

افتح ملف `.env` وأضف مفاتيحك:

```env
# Google Gemini API Keys (لتوليد المنتجات)
AIWPG_GEMINI_API_KEY_1=AIzaSyD7jSzV7S-XwRa8L90KVBxM08g7LSMDeGk
AIWPG_GEMINI_API_KEY_2=AIzaSyCTYH7rvcxwjemRqYO1zy6fftpXtJ7x7s
AIWPG_GEMINI_API_KEY_3=AIzaSyCwYAwZIqKE727iTqIbYWLBvrt8ebW-0k
AIWPG_GEMINI_API_KEY_4=AIzaSyC2uWuYocXExJfqQxeBaV90ZIvdx1EibCc
AIWPG_GEMINI_API_KEY_5=AIzaSyDa-Ad3iE6JwBMy5mg9me2vfXbrdI3bLQo

# Freepik API Keys (لتوليد الصور)
AIWPG_FREEPIK_API_KEY_1=FPSX92452c6f2d4fa55c28aada8cf90ca9b5
AIWPG_FREEPIK_API_KEY_2=FPSXfc69924b6277229b426ebe763a08c492
AIWPG_FREEPIK_API_KEY_3=FPSX0aeba49147ef1227332719d498be9a6d
AIWPG_FREEPIK_API_KEY_4=FPSX6067f6de3fa5753b99d144e8b39c3d5f
AIWPG_FREEPIK_API_KEY_5=FPSXfab91d35c22b8659c9c8495bfd6084dc
```

### الخطوة 3️⃣: حفظ الملف

احفظ ملف `.env` وتأكد من:
- ✅ اسم الملف: `.env` (بدون امتداد)
- ✅ الموقع: داخل مجلد `ai-woo-product-generator/`
- ✅ الصلاحيات: `644` أو `600` (للأمان)

```bash
chmod 600 .env
```

### الخطوة 4️⃣: التحقق من العمل

1. افتح لوحة تحكم WordPress
2. انتقل إلى **AI Products → Generate Products**
3. إذا اختفت رسالة الخطأ الحمراء → تم التكوين بنجاح! ✅

---

## 📝 ملاحظات مهمة

### ✅ أفضل الممارسات

1. **لا تشارك ملف .env أبداً**
   - ملف `.env` يحتوي على مفاتيح حساسة
   - لا ترفعه إلى GitHub أو Git
   - لا تشاركه عبر البريد الإلكتروني

2. **استخدم .gitignore**
   - تم إضافة `.env` تلقائياً إلى `.gitignore`
   - تحقق من أن Git يتجاهل هذا الملف

3. **نسخ احتياطي آمن**
   - احفظ نسخة من مفاتيحك في مكان آمن
   - استخدم مدير كلمات مرور (مثل 1Password، LastPass)

### 🔄 لا تحتاج لجميع المفاتيح

يمكنك استخدام مفتاح واحد فقط:

```env
# مفتاح واحد يكفي للبدء
AIWPG_GEMINI_API_KEY_1=your-key-here
AIWPG_FREEPIK_API_KEY_1=your-key-here
```

الإضافة ستستخدم المفاتيح المتاحة تلقائياً مع نظام Failover.

---

## 🔧 طرق بديلة للتكوين

### الطريقة 1: ملف wp-config.php (موصى به للإنتاج)

افتح `wp-config.php` وأضف قبل السطر `/* That's all, stop editing! */`:

```php
// AI Woo Product Generator - API Keys
define('AIWPG_GEMINI_API_KEY_1', 'your-key-here');
define('AIWPG_FREEPIK_API_KEY_1', 'your-key-here');
```

### الطريقة 2: متغيرات البيئة على مستوى السيرفر

إذا كنت تستخدم Apache، أضف إلى `.htaccess`:

```apache
SetEnv AIWPG_GEMINI_API_KEY_1 "your-key-here"
SetEnv AIWPG_FREEPIK_API_KEY_1 "your-key-here"
```

إذا كنت تستخدم Nginx، أضف إلى `nginx.conf`:

```nginx
fastcgi_param AIWPG_GEMINI_API_KEY_1 "your-key-here";
fastcgi_param AIWPG_FREEPIK_API_KEY_1 "your-key-here";
```

---

## 🐛 حل المشاكل

### ❌ الخطأ: "Freepik API keys are not configured"

**الحل:**

1. تحقق من وجود ملف `.env` في المسار الصحيح:
   ```bash
   ls -la wp-content/plugins/ai-woo-product-generator/.env
   ```

2. تحقق من محتوى الملف:
   ```bash
   cat wp-content/plugins/ai-woo-product-generator/.env
   ```

3. تحقق من أن المفاتيح ليست فارغة أو placeholder

4. أعد تحميل الصفحة (Ctrl+F5)

### ❌ الملف .env غير مقروء

تحقق من صلاحيات الملف:

```bash
chmod 644 .env
chown www-data:www-data .env  # استبدل www-data بمستخدم الويب سيرفر
```

### ❌ المفاتيح لا تعمل

1. تحقق من صحة المفاتيح في:
   - Google Gemini: https://makersuite.google.com/app/apikey
   - Freepik: https://www.freepik.com/api/

2. تحقق من أن المفاتيح نشطة ولم تنتهي صلاحيتها

3. تحقق من الحصة (Quota) المتبقية

---

## 📊 اختبار التكوين

### اختبار سريع

قم بتشغيل هذا الأمر في SSH:

```bash
cd wp-content/plugins/ai-woo-product-generator/
php -r "require 'env-loader.php'; echo getenv('AIWPG_GEMINI_API_KEY_1') ? 'OK' : 'FAIL';"
```

إذا ظهر `OK` → التكوين صحيح ✅

### اختبار من WordPress

1. افتح لوحة التحكم
2. انتقل إلى **AI Products → Generate Products**
3. جرب توليد منتج جديد
4. إذا عمل → التكوين صحيح ✅

---

## 🔒 الأمان

### ✅ تم التنفيذ تلقائياً

- ✅ ملف `.env` مضاف إلى `.gitignore`
- ✅ لا يمكن الوصول للملف عبر المتصفح
- ✅ المفاتيح لا تظهر في الكود المصدري
- ✅ الحماية من CSRF في ملفات الاختبار

### ⚠️ توصيات إضافية

1. استخدم HTTPS على موقعك
2. قم بتحديث ووردبريس والإضافات باستمرار
3. استخدم جدار حماية (Firewall) على السيرفر
4. راقب السجلات (Logs) بانتظام

---

## 📞 الدعم

إذا واجهت مشاكل:

1. تحقق من ملف السجل:
   ```bash
   tail -f wp-content/uploads/aiwpg-logs/aiwpg-*.log
   ```

2. فعّل وضع التطوير:
   ```php
   // في wp-config.php
   define('WP_DEBUG', true);
   define('WP_DEBUG_LOG', true);
   ```

3. راجع الدليل الكامل في: `/doc/README-AR.md`

---

✅ **بعد إتمام هذه الخطوات، ستكون الإضافة جاهزة للعمل بشكل آمن!**

