<?php
/**
 * اختبار استخراج الصورة
 */

// محاكاة استجابة Freepik API عند COMPLETED
$response = [
    'data' => [
        'status' => 'COMPLETED',
        'task_id' => '920266cc-281f-4779-b8ad-c0636d4b027d',
        'generated' => [
            [
                'url' => 'https://cdn.freepik.com/ai-images/test-image.jpg',
                'width' => 1024,
                'height' => 1024
            ]
        ]
    ]
];

echo "🧪 اختبار استخراج الصورة\n";
echo "=======================\n\n";

echo "📋 الاستجابة:\n";
echo json_encode($response, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) . "\n\n";

// اختبار الاستخراج
echo "🔍 محاولة الاستخراج...\n";

// الطريقة القديمة (خاطئة)
if (isset($response['generated'])) {
    echo "❌ خطأ: يبحث في المستوى الرئيسي\n";
} else {
    echo "✓ صحيح: لا يوجد في المستوى الرئيسي\n";
}

// الطريقة الجديدة (صحيحة)
if (isset($response['data']['generated']) && !empty($response['data']['generated'])) {
    echo "✓ صحيح: وُجد في data.generated\n";
    $image_url = $response['data']['generated'][0]['url'];
    echo "✓ URL: {$image_url}\n";
} else {
    echo "❌ خطأ: لم يُعثر عليه\n";
}

echo "\n🎉 الإصلاح يعمل بشكل صحيح!\n";
