<?php
/**
 * Database Management
 * Handles database table creation and updates for product add-ons
 * 
 * @package AIWPG
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

class AIWPG_Database {
    
    /**
     * Single instance
     */
    private static $instance = null;
    
    /**
     * Table name (without prefix)
     */
    private $table_name = 'aiwpg_product_addons';
    
    /**
     * Get instance
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructor
     */
    private function __construct() {
        // Table creation is handled via activation hook
    }
    
    /**
     * Get full table name with prefix
     * 
     * @return string
     */
    public function get_table_name() {
        global $wpdb;
        return $wpdb->prefix . $this->table_name;
    }
    
    /**
     * Create add-ons table
     * Called on plugin activation
     * 
     * @return bool|WP_Error
     */
    public function create_tables() {
        global $wpdb;
        
        $table_name = $this->get_table_name();
        $charset_collate = $wpdb->get_charset_collate();
        
        $sql = "CREATE TABLE IF NOT EXISTS {$table_name} (
            id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            product_id bigint(20) UNSIGNED NOT NULL,
            addon_name varchar(255) NOT NULL,
            addon_group varchar(255) DEFAULT NULL,
            source varchar(50) NOT NULL DEFAULT 'manual',
            price decimal(10,2) DEFAULT 0.00,
            price_type varchar(50) DEFAULT 'flat_fee',
            selection_type varchar(50) DEFAULT 'multiple_choice',
            status varchar(50) NOT NULL DEFAULT 'suggested',
            scope varchar(50) DEFAULT 'this_product',
            external_id varchar(255) DEFAULT NULL COMMENT 'ID from external source (WC Add-ons, Woo Food, etc.)',
            external_data longtext DEFAULT NULL COMMENT 'JSON data from external source',
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY product_id (product_id),
            KEY source (source),
            KEY status (status),
            KEY addon_group (addon_group)
        ) {$charset_collate};";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
        
        // Check if table was created successfully
        if ($wpdb->get_var("SHOW TABLES LIKE '{$table_name}'") !== $table_name) {
            return new WP_Error('table_creation_failed', __('Failed to create add-ons table', 'ai-woo-product-generator'));
        }
        
        return true;
    }
    
    /**
     * Drop add-ons table
     * Called on plugin uninstall (optional)
     * 
     * @return bool
     */
    public function drop_tables() {
        global $wpdb;
        
        $table_name = $this->get_table_name();
        $wpdb->query("DROP TABLE IF EXISTS {$table_name}");
        
        return true;
    }
    
    /**
     * Check if table exists
     * 
     * @return bool
     */
    public function table_exists() {
        global $wpdb;
        $table_name = $this->get_table_name();
        return $wpdb->get_var("SHOW TABLES LIKE '{$table_name}'") === $table_name;
    }
}
