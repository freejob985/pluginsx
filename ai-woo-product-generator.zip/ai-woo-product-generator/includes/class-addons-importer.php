<?php
/**
 * Addons Importer
 * Handles import of product add-ons from Excel sheets to WooCommerce Product Add-Ons
 * 
 * @package AIWPG
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

class AIWPG_Addons_Importer {
    
    /**
     * Single instance
     */
    private static $instance = null;
    
    /**
     * Logger instance
     */
    private $logger;
    
    /**
     * Log file path for addons import
     */
    private $addons_log_file;
    
    /**
     * Category to group name mapping
     * Can be filtered via 'aiwpg_addon_group_mapping' filter
     */
    private $category_group_mapping = array(
        'pizza' => 'Pizza Addons',
        'burger' => 'Burger Extras',
        'salad' => 'Salad Toppings',
        'drink' => 'Drink Extras',
        'coffee' => 'Drink Extras',
    );
    
    /**
     * Get instance
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructor
     */
    private function __construct() {
        $this->logger = AIWPG_Logger::get_instance();
        
        // Setup addons-specific log file
        $upload_dir = wp_upload_dir();
        $log_dir = $upload_dir['basedir'] . '/aiwpg-logs';
        if (!file_exists($log_dir)) {
            wp_mkdir_p($log_dir);
        }
        $this->addons_log_file = $log_dir . '/addons-import.log';
        
        // Allow filtering of category mapping
        $this->category_group_mapping = apply_filters('aiwpg_addon_group_mapping', $this->category_group_mapping);
        
        // Hook into product import
        add_action('aiwpg_after_import_row', array($this, 'handle_row'), 10, 2);
        
        // AJAX handler for manual import
        add_action('wp_ajax_aiwpg_import_addons', array($this, 'ajax_import_addons'));
    }
    
    /**
     * Handle row after import
     * Called via 'aiwpg_after_import_row' hook
     * 
     * @param int $product_id Product ID
     * @param array $product_data Product data array
     */
    public function handle_row($product_id, $product_data) {
        // Check if addons import is enabled
        $settings = get_option('aiwpg_settings', array());
        if (empty($settings['enable_addons_import'])) {
            return;
        }
        
        // Check if WooCommerce Product Add-Ons is active
        if (!class_exists('WC_Product_Add_Ons')) {
            $this->log_addons('WooCommerce Product Add-Ons plugin not active, skipping addons import', 'warning', array('product_id' => $product_id));
            return;
        }
        
        // Get additions from product data or product meta
        $additions = '';
        if (isset($product_data['additions']) && !empty($product_data['additions'])) {
            $additions = $product_data['additions'];
        } else {
            // Try to get from product meta (stored during import)
            $additions = get_post_meta($product_id, '_aiwpg_additions', true);
        }
        
        if (empty($additions)) {
            return; // No additions to process
        }
        
        // Parse additions
        $addons_list = $this->parse_addons($additions);
        if (empty($addons_list)) {
            return;
        }
        
        // Get product category to determine group name
        $product = wc_get_product($product_id);
        if (!$product) {
            $this->log_addons('Product not found', 'error', array('product_id' => $product_id));
            return;
        }
        
        $categories = $product->get_category_ids();
        $category_name = '';
        if (!empty($categories)) {
            $category = get_term($categories[0], 'product_cat');
            if ($category && !is_wp_error($category)) {
                $category_name = strtolower($category->name);
            }
        }
        
        // Determine group name
        $group_name = $this->determine_group_name($product->get_name(), $category_name);
        
        // Get category ID for restriction (if applicable)
        $category_id = !empty($categories) ? $categories[0] : null;
        
        // Create or update add-on group
        $group_id = $this->create_or_update_group($group_name, $addons_list, $category_id);
        
        if (is_wp_error($group_id)) {
            $this->log_addons(
                'Failed to create/update add-on group',
                'error',
                array(
                    'product_id' => $product_id,
                    'group_name' => $group_name,
                    'error' => $group_id->get_error_message()
                )
            );
            return;
        }
        
        // Link group to product
        $linked = $this->link_group_to_product($product_id, $group_id);
        
        if ($linked) {
            $this->log_addons(
                'Add-ons processed successfully',
                'info',
                array(
                    'product_id' => $product_id,
                    'product_name' => $product->get_name(),
                    'group_id' => $group_id,
                    'group_name' => $group_name,
                    'addons_count' => count($addons_list)
                )
            );
        }
    }
    
    /**
     * Parse addons from string
     * Format: "Extra Cheese; Extra Olives; Extra Sauce"
     * 
     * @param string $additions_string Additions string
     * @return array List of addon names (trimmed, unique, non-empty)
     */
    public function parse_addons($additions_string) {
        if (empty($additions_string)) {
            return array();
        }
        
        // Split by semicolon
        $addons = explode(';', $additions_string);
        
        // Trim and filter
        $addons = array_map('trim', $addons);
        $addons = array_filter($addons, function($addon) {
            return !empty($addon);
        });
        
        // Remove duplicates (case-insensitive)
        $unique_addons = array();
        $seen = array();
        foreach ($addons as $addon) {
            $key = strtolower($addon);
            if (!isset($seen[$key])) {
                $seen[$key] = true;
                $unique_addons[] = $addon;
            }
        }
        
        return $unique_addons;
    }
    
    /**
     * Determine add-on group name based on product name and category
     * 
     * @param string $product_name Product name
     * @param string $category_name Category name (lowercase)
     * @return string Group name
     */
    private function determine_group_name($product_name, $category_name = '') {
        // Check category mapping first
        if (!empty($category_name)) {
            foreach ($this->category_group_mapping as $cat_key => $group_name) {
                if (strpos($category_name, $cat_key) !== false) {
                    return $group_name;
                }
            }
        }
        
        // Check product name for keywords
        $product_lower = strtolower($product_name);
        foreach ($this->category_group_mapping as $cat_key => $group_name) {
            if (strpos($product_lower, $cat_key) !== false) {
                return $group_name;
            }
        }
        
        // Default: Use product name + "Addons"
        return $product_name . ' Addons';
    }
    
    /**
     * Create or update global add-on group
     * Uses WooCommerce Product Add-Ons REST API
     * 
     * @param string $group_name Group name
     * @param array $addons_list List of addon names
     * @param int|null $category_id Category ID for restriction
     * @return int|WP_Error Group ID or error
     */
    public function create_or_update_group($group_name, $addons_list, $category_id = null) {
        // Check if group exists
        $existing_group = $this->get_group_by_name($group_name);
        
        if ($existing_group) {
            // Update existing group
            return $this->update_group($existing_group['id'], $group_name, $addons_list, $category_id);
        } else {
            // Create new group
            return $this->create_group($group_name, $addons_list, $category_id);
        }
    }
    
    /**
     * Get global add-on group by name
     * 
     * @param string $name Group name
     * @return array|null Group data or null if not found
     */
    private function get_group_by_name($name) {
        // Use REST API to get all global add-ons
        $rest_url = rest_url('wc-product-add-ons/v2/global-add-ons');
        $response = wp_remote_get($rest_url, array(
            'headers' => array(
                'Content-Type' => 'application/json',
            ),
            'timeout' => 30,
        ));
        
        if (is_wp_error($response)) {
            $this->log_addons('Failed to fetch global add-ons', 'error', array('error' => $response->get_error_message()));
            return null;
        }
        
        $response_code = wp_remote_retrieve_response_code($response);
        if ($response_code !== 200) {
            $this->log_addons('Failed to fetch global add-ons', 'error', array('http_code' => $response_code));
            return null;
        }
        
        $body = wp_remote_retrieve_body($response);
        $groups = json_decode($body, true);
        
        if (!is_array($groups)) {
            return null;
        }
        
        // Find group by name
        foreach ($groups as $group) {
            if (isset($group['name']) && $group['name'] === $name) {
                return $group;
            }
        }
        
        return null;
    }
    
    /**
     * Create new global add-on group
     * 
     * @param string $group_name Group name
     * @param array $addons_list List of addon names
     * @param int|null $category_id Category ID for restriction
     * @return int|WP_Error Group ID or error
     */
    private function create_group($group_name, $addons_list, $category_id = null) {
        $rest_url = rest_url('wc-product-add-ons/v2/global-add-ons');
        
        // Build options array
        $options = array();
        foreach ($addons_list as $addon_name) {
            $options[] = array(
                'label' => $addon_name,
                'price' => '0',
                'price_type' => 'flat_fee',
            );
        }
        
        // Build request body
        $body = array(
            'name' => $group_name,
            'priority' => 10,
            'fields' => array(
                array(
                    'type' => 'multiple_choice',
                    'name' => 'Choose extras',
                    'required' => false,
                    'options' => $options,
                ),
            ),
        );
        
        // Add category restriction if provided
        if ($category_id) {
            $body['restrict_to_categories'] = array($category_id);
        }
        
        $response = wp_remote_post($rest_url, array(
            'headers' => array(
                'Content-Type' => 'application/json',
            ),
            'body' => wp_json_encode($body),
            'timeout' => 30,
        ));
        
        if (is_wp_error($response)) {
            $this->log_addons(
                'Failed to create add-on group via REST API',
                'error',
                array('error' => $response->get_error_message(), 'group_name' => $group_name)
            );
            return new WP_Error('rest_api_error', $response->get_error_message());
        }
        
        $response_code = wp_remote_retrieve_response_code($response);
        $response_body = wp_remote_retrieve_body($response);
        
        if ($response_code !== 201 && $response_code !== 200) {
            $this->log_addons(
                'REST API returned error when creating group',
                'error',
                array(
                    'http_code' => $response_code,
                    'response_body' => $response_body,
                    'group_name' => $group_name
                )
            );
            return new WP_Error('rest_api_error', sprintf('HTTP %d: %s', $response_code, $response_body));
        }
        
        $group_data = json_decode($response_body, true);
        $group_id = isset($group_data['id']) ? $group_data['id'] : null;
        
        if (!$group_id) {
            return new WP_Error('invalid_response', 'Group ID not found in response');
        }
        
        $this->log_addons(
            'Add-on group created successfully',
            'info',
            array('group_id' => $group_id, 'group_name' => $group_name)
        );
        
        return $group_id;
    }
    
    /**
     * Update existing global add-on group
     * Merges new options with existing ones (avoids duplicates)
     * 
     * @param int $group_id Group ID
     * @param string $group_name Group name
     * @param array $addons_list List of addon names
     * @param int|null $category_id Category ID for restriction
     * @return int|WP_Error Group ID or error
     */
    private function update_group($group_id, $group_name, $addons_list, $category_id = null) {
        // First, get existing group data
        $rest_url = rest_url('wc-product-add-ons/v2/global-add-ons/' . $group_id);
        $response = wp_remote_get($rest_url, array(
            'headers' => array(
                'Content-Type' => 'application/json',
            ),
            'timeout' => 30,
        ));
        
        if (is_wp_error($response)) {
            return new WP_Error('fetch_error', $response->get_error_message());
        }
        
        $response_code = wp_remote_retrieve_response_code($response);
        if ($response_code !== 200) {
            return new WP_Error('fetch_error', sprintf('HTTP %d', $response_code));
        }
        
        $existing_group = json_decode(wp_remote_retrieve_body($response), true);
        
        // Get existing options from first field
        $existing_options = array();
        if (isset($existing_group['fields'][0]['options']) && is_array($existing_group['fields'][0]['options'])) {
            $existing_options = $existing_group['fields'][0]['options'];
        }
        
        // Build map of existing option labels (case-insensitive)
        $existing_labels = array();
        foreach ($existing_options as $option) {
            if (isset($option['label'])) {
                $existing_labels[strtolower($option['label'])] = $option;
            }
        }
        
        // Merge new options (avoid duplicates)
        $merged_options = $existing_options;
        foreach ($addons_list as $addon_name) {
            $key = strtolower($addon_name);
            if (!isset($existing_labels[$key])) {
                $merged_options[] = array(
                    'label' => $addon_name,
                    'price' => '0',
                    'price_type' => 'flat_fee',
                );
            }
        }
        
        // Update group
        $update_body = array(
            'name' => $group_name,
            'priority' => isset($existing_group['priority']) ? $existing_group['priority'] : 10,
            'fields' => array(
                array(
                    'type' => isset($existing_group['fields'][0]['type']) ? $existing_group['fields'][0]['type'] : 'multiple_choice',
                    'name' => isset($existing_group['fields'][0]['name']) ? $existing_group['fields'][0]['name'] : 'Choose extras',
                    'required' => isset($existing_group['fields'][0]['required']) ? $existing_group['fields'][0]['required'] : false,
                    'options' => $merged_options,
                ),
            ),
        );
        
        // Preserve category restriction if exists, or add new one
        if ($category_id) {
            $update_body['restrict_to_categories'] = array($category_id);
        } elseif (isset($existing_group['restrict_to_categories'])) {
            $update_body['restrict_to_categories'] = $existing_group['restrict_to_categories'];
        }
        
        $update_url = rest_url('wc-product-add-ons/v2/global-add-ons/' . $group_id);
        $update_response = wp_remote_request($update_url, array(
            'method' => 'PUT',
            'headers' => array(
                'Content-Type' => 'application/json',
            ),
            'body' => wp_json_encode($update_body),
            'timeout' => 30,
        ));
        
        if (is_wp_error($update_response)) {
            $this->log_addons(
                'Failed to update add-on group via REST API',
                'error',
                array('error' => $update_response->get_error_message(), 'group_id' => $group_id)
            );
            return new WP_Error('rest_api_error', $update_response->get_error_message());
        }
        
        $update_code = wp_remote_retrieve_response_code($update_response);
        $update_body_response = wp_remote_retrieve_body($update_response);
        
        if ($update_code !== 200) {
            $this->log_addons(
                'REST API returned error when updating group',
                'error',
                array(
                    'http_code' => $update_code,
                    'response_body' => $update_body_response,
                    'group_id' => $group_id
                )
            );
            return new WP_Error('rest_api_error', sprintf('HTTP %d: %s', $update_code, $update_body_response));
        }
        
        $this->log_addons(
            'Add-on group updated successfully',
            'info',
            array('group_id' => $group_id, 'group_name' => $group_name, 'new_options' => count($addons_list))
        );
        
        return $group_id;
    }
    
    /**
     * Link add-on group to product
     * 
     * @param int $product_id Product ID
     * @param int $group_id Group ID
     * @return bool Success
     */
    public function link_group_to_product($product_id, $group_id) {
        // WooCommerce Product Add-Ons stores group assignments in product meta
        // The meta key format may vary, but typically it's '_product_addons' or similar
        
        // Method 1: Use REST API to update product with addons
        $rest_url = rest_url('wc/v3/products/' . $product_id);
        
        // Get current product data
        $response = wp_remote_get($rest_url, array(
            'headers' => array(
                'Content-Type' => 'application/json',
            ),
            'timeout' => 30,
        ));
        
        if (is_wp_error($response)) {
            $this->log_addons(
                'Failed to fetch product for linking group',
                'error',
                array('product_id' => $product_id, 'error' => $response->get_error_message())
            );
            return false;
        }
        
        $response_code = wp_remote_retrieve_response_code($response);
        if ($response_code !== 200) {
            $this->log_addons(
                'Product not found for linking group',
                'error',
                array('product_id' => $product_id, 'http_code' => $response_code)
            );
            return false;
        }
        
        $product_data = json_decode(wp_remote_retrieve_body($response), true);
        
        // Get existing addons
        $existing_addons = isset($product_data['addons']) ? $product_data['addons'] : array();
        
        // Check if group is already linked
        $group_linked = false;
        foreach ($existing_addons as $addon) {
            if (isset($addon['id']) && $addon['id'] == $group_id) {
                $group_linked = true;
                break;
            }
        }
        
        if (!$group_linked) {
            // Add group to addons array
            $existing_addons[] = array('id' => $group_id);
            
            // Update product
            $update_response = wp_remote_request($rest_url, array(
                'method' => 'PUT',
                'headers' => array(
                    'Content-Type' => 'application/json',
                ),
                'body' => wp_json_encode(array('addons' => $existing_addons)),
                'timeout' => 30,
            ));
            
            if (is_wp_error($update_response)) {
                $this->log_addons(
                    'Failed to link group to product via REST API',
                    'error',
                    array(
                        'product_id' => $product_id,
                        'group_id' => $group_id,
                        'error' => $update_response->get_error_message()
                    )
                );
                return false;
            }
            
            $update_code = wp_remote_retrieve_response_code($update_response);
            if ($update_code !== 200) {
                $this->log_addons(
                    'REST API returned error when linking group',
                    'error',
                    array(
                        'product_id' => $product_id,
                        'group_id' => $group_id,
                        'http_code' => $update_code
                    )
                );
                return false;
            }
        }
        
        return true;
    }
    
    /**
     * Import addons from rows (for manual import)
     * 
     * @param array $rows Array of product rows with 'additions' column
     * @return array Summary of import
     */
    public function import_from_rows($rows) {
        $summary = array(
            'groups_created' => 0,
            'groups_updated' => 0,
            'products_linked' => 0,
            'errors' => array(),
        );
        
        foreach ($rows as $row) {
            try {
                // Get product by SKU or name
                $product_id = null;
                if (!empty($row['sku'])) {
                    $product_id = wc_get_product_id_by_sku($row['sku']);
                }
                
                if (!$product_id && !empty($row['name'])) {
                    $posts = get_posts(array(
                        'post_type' => 'product',
                        'title' => $row['name'],
                        'posts_per_page' => 1,
                        'post_status' => 'any',
                    ));
                    if (!empty($posts)) {
                        $product_id = $posts[0]->ID;
                    }
                }
                
                if (!$product_id) {
                    $summary['errors'][] = sprintf(__('Product not found: %s', 'ai-woo-product-generator'), $row['name'] ?? 'N/A');
                    continue;
                }
                
                // Process addons for this product
                if (!empty($row['additions'])) {
                    $product_data = array('additions' => $row['additions']);
                    $this->handle_row($product_id, $product_data);
                    $summary['products_linked']++;
                }
                
            } catch (Exception $e) {
                $summary['errors'][] = sprintf(__('Error processing row: %s', 'ai-woo-product-generator'), $e->getMessage());
            }
        }
        
        return $summary;
    }
    
    /**
     * AJAX handler for manual addons import
     */
    public function ajax_import_addons() {
        check_ajax_referer('aiwpg_nonce', 'nonce');
        
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error(array('message' => __('Permission denied', 'ai-woo-product-generator')));
        }
        
        // Get rows from request (if provided)
        $rows = isset($_POST['rows']) ? json_decode(stripslashes($_POST['rows']), true) : array();
        
        if (empty($rows)) {
            // Try to get from all products with additions meta
            $args = array(
                'post_type' => 'product',
                'posts_per_page' => -1,
                'meta_query' => array(
                    array(
                        'key' => '_aiwpg_additions',
                        'compare' => 'EXISTS',
                    ),
                ),
            );
            
            $query = new WP_Query($args);
            $rows = array();
            
            foreach ($query->posts as $post) {
                $product = wc_get_product($post->ID);
                if ($product) {
                    $additions = get_post_meta($post->ID, '_aiwpg_additions', true);
                    if (!empty($additions)) {
                        $rows[] = array(
                            'name' => $product->get_name(),
                            'sku' => $product->get_sku(),
                            'additions' => $additions,
                        );
                    }
                }
            }
        }
        
        if (empty($rows)) {
            wp_send_json_error(array('message' => __('No products with addons found', 'ai-woo-product-generator')));
        }
        
        $summary = $this->import_from_rows($rows);
        
        wp_send_json_success(array(
            'message' => __('Addons import completed', 'ai-woo-product-generator'),
            'summary' => $summary,
        ));
    }
    
    /**
     * Log to addons-specific log file
     * 
     * @param string $message Log message
     * @param string $level Log level (info, warning, error)
     * @param array $data Additional data
     */
    private function log_addons($message, $level = 'info', $data = array()) {
        $timestamp = current_time('mysql');
        $log_line = sprintf(
            "[%s] [%s] %s",
            $timestamp,
            strtoupper($level),
            $message
        );
        
        if (!empty($data)) {
            $log_line .= ' | ' . wp_json_encode($data);
        }
        
        $log_line .= PHP_EOL;
        
        // Write to addons log file
        file_put_contents($this->addons_log_file, $log_line, FILE_APPEND);
        
        // Also use main logger
        $this->logger->log($message, 'addons_importer', $data, $level);
    }
}
