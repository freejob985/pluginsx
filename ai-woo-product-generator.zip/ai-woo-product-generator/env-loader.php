<?php
/**
 * Environment Variable Loader
 * 
 * This file loads API keys from .env file if it exists
 * Place this file in your plugin directory and it will automatically
 * load environment variables from .env file
 * 
 * @package AI_Woo_Product_Generator
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Load environment variables from .env file
 * Simple implementation without external dependencies
 */
function aiwpg_load_env_file() {
    $env_file = __DIR__ . '/.env';
    
    // Check if .env file exists
    if (!file_exists($env_file)) {
        return false;
    }
    
    // Read .env file
    $lines = file($env_file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    
    if ($lines === false) {
        return false;
    }
    
    foreach ($lines as $line) {
        // Skip comments
        if (strpos(trim($line), '#') === 0) {
            continue;
        }
        
        // Parse KEY=VALUE format
        if (strpos($line, '=') !== false) {
            list($key, $value) = explode('=', $line, 2);
            $key = trim($key);
            $value = trim($value);
            
            // Remove quotes if present
            $value = trim($value, '"\'');
            
            // Skip empty values or placeholder values
            if (empty($value) || 
                strpos($value, 'your-') === 0 || 
                strpos($value, 'placeholder') !== false) {
                continue;
            }
            
            // Set environment variable if not already set
            if (!getenv($key)) {
                putenv("$key=$value");
                $_ENV[$key] = $value;
                $_SERVER[$key] = $value;
            }
        }
    }
    
    return true;
}

// Load .env file automatically
aiwpg_load_env_file();

