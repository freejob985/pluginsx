# 🔍 دليل الاختبار السريع - Linked Products

## ⚡ اختبار سريع (5 دقائق)

### الخطوة 1: مسح Cache
```
اضغط: Ctrl + Shift + R
```
**⚠️ هذا ضروري جداً!**

---

### الخطوة 2: افتح Console
```
اضغط F12
→ اذهب لتبويب Console
```

---

### الخطوة 3: افتح Edit Product
```
1. اذهب لـ AI Woo → Products
2. اضغط "Edit" على أي منتج
3. اضغط على تبويب "Linked Products"
```

---

### الخطوة 4: ابحث عن هذه الرسائل في Console

#### ✅ رسائل النجاح (يجب أن تراها):

```javascript
✅ Linked Products module loaded successfully!
🔗 Initializing Linked Products module...
✅ aiwpgData found: {ajaxUrl: "...", nonce: "OK"}
🔄 Rebinding search events...
✅ Search input found: [object Object]
✅ Events rebound successfully
📦 Loading linked products for product: 123
✅ aiwpgData is available, sending AJAX request...
⏳ Sending AJAX request to: .../admin-ajax.php
📨 AJAX response received: {success: true, ...}
✅ Products loaded successfully: 50
   - Sample products (first 3):
     1. ID: 101, Title: Product A
     2. ID: 102, Title: Product B
     3. ID: 103, Title: Product C
🎉 البحث جاهز! جرّب كتابة أي حرف في مربع البحث
```

#### ❌ رسائل الخطأ (إذا رأيتها):

**خطأ 1: aiwpgData غير موجود**
```javascript
❌ aiwpgData is not defined!
```
**الحل:**
- امسح cache المتصفح (Ctrl+Shift+R)
- تأكد من أنك في صفحة Products الصحيحة
- تحقق من أن الـ plugin مفعّل

**خطأ 2: Search input غير موجود**
```javascript
❌ Search input not found!
```
**الحل:**
- تأكد من أنك في تبويب "Linked Products"
- أغلق Modal وافتحه مرة أخرى

**خطأ 3: لا توجد منتجات**
```javascript
⚠️ No products loaded yet!
```
**الحل:**
- انتظر 2-3 ثواني
- تحقق من Network tab → admin-ajax.php
- تأكد من وجود منتجات في المتجر

---

### الخطوة 5: اختبر البحث

#### اكتب أي حرف في مربع البحث

**يجب أن ترى:**

1. **في الـ Console:**
```javascript
🔍 handleSearch called!
   - Query: "c"
   - Query length: 1
   - All products count: 50
✅ Products are loaded, proceeding with search...
🔍 Executing search after 300ms delay...
🔍 Searching in 50 products for: "c"
  - Checking: Cable → true
  - Checking: Desk → false
✅ Matches found: 5
🎨 Rendering autocomplete: 5 results
✅ Autocomplete rendered and shown
```

2. **في الصفحة:**
- يظهر مربع أسفل حقل البحث
- يحتوي على 5 منتجات مطابقة
- كل منتج له زرين: Upsell & Cross-sell

3. **في أعلى حقل البحث:**
```
Search Products (50 منتج متاح)
```

---

## 🐛 إذا لم تظهر النتائج

### السيناريو 1: لا توجد رسائل في Console
**المشكلة:** JavaScript لم يتم تحميله
**الحل:**
1. امسح Cache (Ctrl+Shift+R)
2. تحقق من Network tab → ابحث عن `linked-products.js`
3. تأكد أن Status = 200

---

### السيناريو 2: رسالة "No products loaded"
**المشكلة:** AJAX فشل أو لا توجد منتجات
**الحل:**
1. اذهب لـ F12 → Network tab
2. ابحث عن `admin-ajax.php`
3. اضغط عليه واذهب لـ "Response"
4. يجب أن ترى:
```json
{
  "success": true,
  "data": {
    "products": [
      {"id": 101, "title": "Product A"},
      ...
    ]
  }
}
```

إذا كان Response فارغ أو يحتوي على error:
- تحقق من وجود منتجات في المتجر
- تحقق من الصلاحيات (يجب أن تكون Admin)
- تحقق من wp-content/debug.log

---

### السيناريو 3: رسائل تظهر لكن لا توجد نتائج
**المشكلة:** Event handlers لا تعمل
**الحل:**
1. في Console، اكتب:
```javascript
$('#linked-products-search').val('test').trigger('input');
```
2. يجب أن ترى رسائل في Console
3. إذا لم تظهر رسائل:
   - أغلق Modal وافتحه مرة أخرى
   - امسح Cache مرة أخرى

---

## 📊 معلومات Debug في الصفحة

يجب أن ترى مربع رمادي أسفل حقل البحث يحتوي على:
```
🔍 Debug Info:
⏰ 10:30:45 AM
📦 Products loaded: 50
🔼 Upsells: 0
🔀 Cross-sells: 0
💬 Searching for: "c"
```

---

## 🔬 اختبار متقدم

### في Console، جرّب:

```javascript
// 1. تحقق من AIWPG
console.log(window.AIWPG.LinkedProducts);

// 2. تحقق من allProducts
// (هذا لن يعمل لأن allProducts هي private variable، ولكن جرّب)

// 3. اختبر handleSearch مباشرة
window.AIWPG.LinkedProducts.handleSearch('test');

// 4. تحقق من عدد المنتجات المرتبطة
window.AIWPG.LinkedProducts.getValues();

// 5. rebind events
window.AIWPG.LinkedProducts.rebindEvents();
```

---

## 📝 نموذج تقرير المشكلة

إذا استمرت المشكلة، أرسل:

### 1. Screenshot من Console
أظهر جميع الرسائل من البداية

### 2. Screenshot من Network tab
أظهر response من `admin-ajax.php` (action: aiwpg_get_all_products_list)

### 3. معلومات البيئة
```
- WordPress Version: ?
- WooCommerce Version: ?
- PHP Version: ?
- Browser: Chrome/Firefox/Safari?
- عدد المنتجات في المتجر: ?
```

### 4. الرسائل المحددة
```
- هل ترى "✅ Products loaded successfully"? نعم/لا
- كم عدد المنتجات المحمّلة? 
- هل ترى "🔍 handleSearch called"? نعم/لا
- هل يظهر مربع Debug Info? نعم/لا
- هل يظهر "(X منتج متاح)"? نعم/لا
```

---

## ✅ علامات النجاح

يعمل كل شيء بشكل صحيح إذا:
1. ✅ ترى "50 منتج متاح" في أعلى حقل البحث
2. ✅ عند الكتابة، تظهر النتائج فوراً
3. ✅ يمكنك النقر على منتج لإضافته
4. ✅ يمكنك الضغط على Enter لإضافة أول نتيجة
5. ✅ Toggle buttons تعمل (Upsells/Cross-sells)
6. ✅ Debug info يتحدث مع كل عملية بحث

---

## 🆘 اتصل بالدعم

إذا جربت كل هذه الخطوات ولم تنجح:
1. أرسل Screenshots من Console و Network
2. أرسل معلومات البيئة
3. أرسل نص الأخطاء (إن وجدت)

---

**آخر تحديث:** الآن
**الإصدار:** 2.0 (مع Enhanced Debugging)

