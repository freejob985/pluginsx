# Product Add-Ons Import Feature | ميزة استيراد إضافات المنتجات

[English](#english) | [العربية](#arabic)

---

<a name="english"></a>
# 📦 Product Add-Ons Import Feature

## Overview

This feature automatically imports product add-ons from Excel sheets and creates/updates WooCommerce Product Add-Ons groups, then links them to the relevant products.

## Features

✅ **Automatic Import**: Reads "Addons" column from Excel during product import  
✅ **Smart Group Naming**: Automatically determines add-on group names based on product categories  
✅ **Idempotent**: Running import multiple times won't create duplicate groups  
✅ **Merge Options**: Updates existing groups by merging new options (avoids duplicates)  
✅ **Product Linking**: Automatically links add-on groups to products  
✅ **Manual Import**: Run import manually for existing products  
✅ **Error Logging**: Comprehensive logging to `/wp-content/uploads/aiwpg-logs/addons-import.log`

---

## Requirements

1. **WooCommerce** - Must be installed and activated
2. **WooCommerce Product Add-Ons** - Official extension must be installed and activated
3. **Excel Import Feature** - Must be enabled in the plugin

---

## How It Works

### 1. Excel Sheet Format

Your Excel sheet should include an **"Addons"** column with values separated by semicolons (`;`):

| Name | Price | Category | Addons |
|------|-------|----------|--------|
| Pepperoni Pizza | 15.99 | Pizza | Extra Cheese; Extra Olives; Extra Sauce |
| Burger | 12.99 | Burger | Cheese; Bacon; Double Patty |
| Caesar Salad | 8.99 | Salad | Grilled Chicken; Extra Dressing |

**Column Names Supported:**
- `Addons` (English)
- `Add-ons`
- `Addons`
- `الإضافات` (Arabic)
- `إضافات` (Arabic)

### 2. Automatic Processing

When you import products from Excel:

1. **Read Addons Column**: The plugin reads the "Addons" column value
2. **Parse Addons**: Splits by semicolon (`;`), trims spaces, removes duplicates
3. **Determine Group Name**: Based on product category or name:
   - `Pizza` → `Pizza Addons`
   - `Burger` → `Burger Extras`
   - `Salad` → `Salad Toppings`
   - `Drink`/`Coffee` → `Drink Extras`
   - Other → `{Product Name} Addons`
4. **Create/Update Group**: Creates new group or updates existing one via REST API
5. **Link to Product**: Automatically links the group to the product

### 3. Group Name Mapping

The plugin uses intelligent mapping to determine group names:

```php
'pizza' => 'Pizza Addons',
'burger' => 'Burger Extras',
'salad' => 'Salad Toppings',
'drink' => 'Drink Extras',
'coffee' => 'Drink Extras',
```

You can customize this mapping using the `aiwpg_addon_group_mapping` filter.

---

## Setup & Configuration

### Step 1: Enable the Feature

1. Go to **AI Products → Settings**
2. In the **General Settings** tab, check **"Enable Add-Ons Import"**
3. Click **"Save Settings"**

### Step 2: Import Products

1. Go to **AI Products → Generate Products**
2. Use the **Excel Import** tab
3. Upload your Excel file with the "Addons" column
4. Review and confirm import

The add-ons will be automatically processed during import.

### Step 3: Manual Import (Optional)

If you have existing products with addons data:

1. Go to **AI Products → Settings**
2. Click the **"Add-Ons Import"** tab
3. Click **"Run Add-Ons Import Now"**

This will process all products that have addons data stored.

---

## Examples

### Example 1: Pizza Product

**Excel Row:**
```
Name: Pepperoni Pizza
Price: 15.99
Category: Pizza
Addons: Extra Cheese; Extra Olives; Extra Sauce; Mushrooms
```

**Result:**
- Group Created: `Pizza Addons`
- Options Added: Extra Cheese, Extra Olives, Extra Sauce, Mushrooms
- Product Linked: ✓

### Example 2: Burger Product

**Excel Row:**
```
Name: Classic Burger
Price: 12.99
Category: Burger
Addons: Cheese; Bacon; Double Patty; Avocado
```

**Result:**
- Group Created: `Burger Extras`
- Options Added: Cheese, Bacon, Double Patty, Avocado
- Product Linked: ✓

### Example 3: Update Existing Group

If you import again with new addons:
```
Addons: Extra Cheese; Extra Olives; Extra Sauce; Pineapple
```

**Result:**
- Group Updated: `Pizza Addons` (existing)
- New Options Added: Pineapple
- Existing Options Preserved: Extra Cheese, Extra Olives, Extra Sauce
- No Duplicates: ✓

---

## Advanced Configuration

### Custom Group Name Mapping

You can customize the category-to-group-name mapping using a filter:

```php
add_filter('aiwpg_addon_group_mapping', function($mapping) {
    $mapping['dessert'] = 'Dessert Extras';
    $mapping['appetizer'] = 'Appetizer Add-ons';
    return $mapping;
});
```

### REST API Endpoints Used

The plugin uses WooCommerce Product Add-Ons REST API:

- `GET /wp-json/wc-product-add-ons/v2/global-add-ons` - List groups
- `POST /wp-json/wc-product-add-ons/v2/global-add-ons` - Create group
- `PUT /wp-json/wc-product-add-ons/v2/global-add-ons/{id}` - Update group
- `GET /wp-json/wc/v3/products/{id}` - Get product
- `PUT /wp-json/wc/v3/products/{id}` - Update product (link group)

---

## Troubleshooting

### Issue: Add-ons not being imported

**Check:**
1. ✅ WooCommerce Product Add-Ons plugin is active
2. ✅ "Enable Add-Ons Import" is checked in settings
3. ✅ Excel column is named "Addons" (or supported variant)
4. ✅ Addons value is not empty
5. ✅ Check log file: `/wp-content/uploads/aiwpg-logs/addons-import.log`

### Issue: Groups created but not linked to products

**Check:**
1. ✅ Product exists in WooCommerce
2. ✅ REST API is accessible
3. ✅ Check browser console for JavaScript errors
4. ✅ Check log file for REST API errors

### Issue: Duplicate groups created

**Solution:**
- The plugin is idempotent by design. If duplicates exist, they may have been created manually.
- Delete duplicate groups from WooCommerce → Products → Add-ons
- Re-run the import - it will use existing groups

### Issue: Wrong group name assigned

**Solution:**
- Check product category name (case-insensitive matching)
- Use the `aiwpg_addon_group_mapping` filter to customize mapping
- Group name defaults to `{Product Name} Addons` if no category match

---

## Log Files

All add-ons import activities are logged to:
```
/wp-content/uploads/aiwpg-logs/addons-import.log
```

Log entries include:
- Timestamp
- Log level (INFO, WARNING, ERROR)
- Message
- Additional data (product ID, group ID, etc.)

Example log entry:
```
[2025-01-15 10:30:45] [INFO] Add-ons processed successfully | {"product_id":123,"group_id":5,"group_name":"Pizza Addons","addons_count":4}
```

---

## Technical Details

### Class: `AIWPG_Addons_Importer`

**Location:** `/includes/class-addons-importer.php`

**Key Methods:**
- `handle_row($product_id, $product_data)` - Processes addons after product import
- `parse_addons($additions_string)` - Parses semicolon-separated addons
- `determine_group_name($product_name, $category_name)` - Determines group name
- `create_or_update_group($group_name, $addons_list, $category_id)` - Creates/updates group
- `link_group_to_product($product_id, $group_id)` - Links group to product

**Hook Used:**
- `aiwpg_after_import_row` - Fired after each product is imported

**Settings:**
- `aiwpg_settings['enable_addons_import']` - Enable/disable feature

---

## FAQ

**Q: Can I use commas instead of semicolons?**  
A: Currently, only semicolons (`;`) are supported. You can modify the `parse_addons()` method to support other separators.

**Q: Can I set prices for individual addons?**  
A: Currently, all addons are created with price `0`. You can extend the code to read prices from Excel if needed.

**Q: What if a product has multiple categories?**  
A: The plugin uses the first category to determine the group name.

**Q: Can I manually edit groups after import?**  
A: Yes! Groups are created in WooCommerce Product Add-Ons, so you can edit them normally from WooCommerce → Products → Add-ons.

**Q: Will re-importing create duplicates?**  
A: No. The plugin checks if a group exists by name and updates it instead of creating duplicates.

---

## Support

For issues or questions:
1. Check the log file: `/wp-content/uploads/aiwpg-logs/addons-import.log`
2. Enable WordPress debug mode: `define('WP_DEBUG', true);` in `wp-config.php`
3. Check browser console for JavaScript errors
4. Verify WooCommerce Product Add-Ons plugin is active and up-to-date

---

<a name="arabic"></a>
# 📦 ميزة استيراد إضافات المنتجات

## نظرة عامة

هذه الميزة تستورد تلقائياً إضافات المنتجات من ملفات Excel وتنشئ/تحدّث مجموعات WooCommerce Product Add-Ons، ثم تربطها بالمنتجات ذات الصلة.

## المميزات

✅ **استيراد تلقائي**: يقرأ عمود "Addons" من Excel أثناء استيراد المنتجات  
✅ **تسمية ذكية للمجموعات**: يحدد تلقائياً أسماء مجموعات الإضافات بناءً على فئات المنتجات  
✅ **عدم التكرار**: تشغيل الاستيراد عدة مرات لن ينشئ مجموعات مكررة  
✅ **دمج الخيارات**: يحدّث المجموعات الموجودة بدمج خيارات جديدة (يتجنب التكرار)  
✅ **ربط المنتجات**: يربط تلقائياً مجموعات الإضافات بالمنتجات  
✅ **استيراد يدوي**: تشغيل الاستيراد يدوياً للمنتجات الموجودة  
✅ **تسجيل الأخطاء**: تسجيل شامل في `/wp-content/uploads/aiwpg-logs/addons-import.log`

---

## المتطلبات

1. **WooCommerce** - يجب تثبيته وتفعيله
2. **WooCommerce Product Add-Ons** - يجب تثبيت وتفعيل الإضافة الرسمية
3. **ميزة استيراد Excel** - يجب تفعيلها في الإضافة

---

## كيفية العمل

### 1. تنسيق ملف Excel

يجب أن يتضمن ملف Excel عمود **"Addons"** بقيم مفصولة بفواصل منقوطة (`;`):

| الاسم | السعر | الفئة | الإضافات |
|------|-------|----------|--------|
| بيتزا بيبروني | 15.99 | Pizza | Extra Cheese; Extra Olives; Extra Sauce |
| برجر | 12.99 | Burger | Cheese; Bacon; Double Patty |
| سلطة قيصر | 8.99 | Salad | Grilled Chicken; Extra Dressing |

**أسماء الأعمدة المدعومة:**
- `Addons` (إنجليزي)
- `Add-ons`
- `Addons`
- `الإضافات` (عربي)
- `إضافات` (عربي)

### 2. المعالجة التلقائية

عند استيراد المنتجات من Excel:

1. **قراءة عمود الإضافات**: تقرأ الإضافة قيمة عمود "Addons"
2. **تحليل الإضافات**: تقسيم بفواصل منقوطة (`;`)، إزالة المسافات، إزالة التكرار
3. **تحديد اسم المجموعة**: بناءً على فئة المنتج أو الاسم:
   - `Pizza` → `Pizza Addons`
   - `Burger` → `Burger Extras`
   - `Salad` → `Salad Toppings`
   - `Drink`/`Coffee` → `Drink Extras`
   - أخرى → `{اسم المنتج} Addons`
4. **إنشاء/تحديث المجموعة**: ينشئ مجموعة جديدة أو يحدّث الموجودة عبر REST API
5. **ربط بالمنتج**: يربط تلقائياً المجموعة بالمنتج

### 3. تخطيط أسماء المجموعات

تستخدم الإضافة تخطيطاً ذكياً لتحديد أسماء المجموعات:

```php
'pizza' => 'Pizza Addons',
'burger' => 'Burger Extras',
'salad' => 'Salad Toppings',
'drink' => 'Drink Extras',
'coffee' => 'Drink Extras',
```

يمكنك تخصيص هذا التخطيط باستخدام فلتر `aiwpg_addon_group_mapping`.

---

## الإعداد والتكوين

### الخطوة 1: تفعيل الميزة

1. اذهب إلى **AI Products → Settings**
2. في تبويب **General Settings**، فعّل **"Enable Add-Ons Import"**
3. انقر **"Save Settings"**

### الخطوة 2: استيراد المنتجات

1. اذهب إلى **AI Products → Generate Products**
2. استخدم تبويب **Excel Import**
3. ارفع ملف Excel الذي يحتوي على عمود "Addons"
4. راجع وأكد الاستيراد

سيتم معالجة الإضافات تلقائياً أثناء الاستيراد.

### الخطوة 3: الاستيراد اليدوي (اختياري)

إذا كان لديك منتجات موجودة مع بيانات إضافات:

1. اذهب إلى **AI Products → Settings**
2. انقر تبويب **"Add-Ons Import"**
3. انقر **"Run Add-Ons Import Now"**

سيتم معالجة جميع المنتجات التي تحتوي على بيانات إضافات.

---

## أمثلة

### مثال 1: منتج بيتزا

**صف Excel:**
```
Name: Pepperoni Pizza
Price: 15.99
Category: Pizza
Addons: Extra Cheese; Extra Olives; Extra Sauce; Mushrooms
```

**النتيجة:**
- تم إنشاء المجموعة: `Pizza Addons`
- تمت إضافة الخيارات: Extra Cheese, Extra Olives, Extra Sauce, Mushrooms
- تم ربط المنتج: ✓

### مثال 2: منتج برجر

**صف Excel:**
```
Name: Classic Burger
Price: 12.99
Category: Burger
Addons: Cheese; Bacon; Double Patty; Avocado
```

**النتيجة:**
- تم إنشاء المجموعة: `Burger Extras`
- تمت إضافة الخيارات: Cheese, Bacon, Double Patty, Avocado
- تم ربط المنتج: ✓

### مثال 3: تحديث مجموعة موجودة

إذا قمت بالاستيراد مرة أخرى بإضافات جديدة:
```
Addons: Extra Cheese; Extra Olives; Extra Sauce; Pineapple
```

**النتيجة:**
- تم تحديث المجموعة: `Pizza Addons` (موجودة)
- تمت إضافة خيارات جديدة: Pineapple
- تم الحفاظ على الخيارات الموجودة: Extra Cheese, Extra Olives, Extra Sauce
- لا توجد تكرارات: ✓

---

## التكوين المتقدم

### تخصيص تخطيط أسماء المجموعات

يمكنك تخصيص تخطيط الفئة إلى اسم المجموعة باستخدام فلتر:

```php
add_filter('aiwpg_addon_group_mapping', function($mapping) {
    $mapping['dessert'] = 'Dessert Extras';
    $mapping['appetizer'] = 'Appetizer Add-ons';
    return $mapping;
});
```

### نقاط نهاية REST API المستخدمة

تستخدم الإضافة REST API لـ WooCommerce Product Add-Ons:

- `GET /wp-json/wc-product-add-ons/v2/global-add-ons` - قائمة المجموعات
- `POST /wp-json/wc-product-add-ons/v2/global-add-ons` - إنشاء مجموعة
- `PUT /wp-json/wc-product-add-ons/v2/global-add-ons/{id}` - تحديث مجموعة
- `GET /wp-json/wc/v3/products/{id}` - الحصول على منتج
- `PUT /wp-json/wc/v3/products/{id}` - تحديث منتج (ربط مجموعة)

---

## استكشاف الأخطاء

### المشكلة: الإضافات لا يتم استيرادها

**تحقق من:**
1. ✅ إضافة WooCommerce Product Add-Ons مفعّلة
2. ✅ "Enable Add-Ons Import" مفعّل في الإعدادات
3. ✅ عمود Excel اسمه "Addons" (أو متغير مدعوم)
4. ✅ قيمة الإضافات ليست فارغة
5. ✅ راجع ملف السجل: `/wp-content/uploads/aiwpg-logs/addons-import.log`

### المشكلة: تم إنشاء المجموعات لكن لم يتم ربطها بالمنتجات

**تحقق من:**
1. ✅ المنتج موجود في WooCommerce
2. ✅ REST API قابل للوصول
3. ✅ راجع console المتصفح للأخطاء JavaScript
4. ✅ راجع ملف السجل لأخطاء REST API

### المشكلة: تم إنشاء مجموعات مكررة

**الحل:**
- الإضافة مصممة لتجنب التكرار. إذا وُجدت تكرارات، قد تكون أُنشئت يدوياً.
- احذف المجموعات المكررة من WooCommerce → Products → Add-ons
- أعد تشغيل الاستيراد - سيستخدم المجموعات الموجودة

### المشكلة: تم تعيين اسم مجموعة خاطئ

**الحل:**
- تحقق من اسم فئة المنتج (مطابقة غير حساسة لحالة الأحرف)
- استخدم فلتر `aiwpg_addon_group_mapping` لتخصيص التخطيط
- اسم المجموعة الافتراضي هو `{اسم المنتج} Addons` إذا لم توجد مطابقة فئة

---

## ملفات السجل

يتم تسجيل جميع أنشطة استيراد الإضافات في:
```
/wp-content/uploads/aiwpg-logs/addons-import.log
```

تتضمن إدخالات السجل:
- الطابع الزمني
- مستوى السجل (INFO, WARNING, ERROR)
- الرسالة
- بيانات إضافية (معرف المنتج، معرف المجموعة، إلخ)

مثال على إدخال السجل:
```
[2025-01-15 10:30:45] [INFO] Add-ons processed successfully | {"product_id":123,"group_id":5,"group_name":"Pizza Addons","addons_count":4}
```

---

## التفاصيل التقنية

### الكلاس: `AIWPG_Addons_Importer`

**الموقع:** `/includes/class-addons-importer.php`

**الطرق الرئيسية:**
- `handle_row($product_id, $product_data)` - يعالج الإضافات بعد استيراد المنتج
- `parse_addons($additions_string)` - يحلل الإضافات المفصولة بفواصل منقوطة
- `determine_group_name($product_name, $category_name)` - يحدد اسم المجموعة
- `create_or_update_group($group_name, $addons_list, $category_id)` - ينشئ/يحدّث المجموعة
- `link_group_to_product($product_id, $group_id)` - يربط المجموعة بالمنتج

**الـ Hook المستخدم:**
- `aiwpg_after_import_row` - يُنفّذ بعد استيراد كل منتج

**الإعدادات:**
- `aiwpg_settings['enable_addons_import']` - تفعيل/تعطيل الميزة

---

## الأسئلة الشائعة

**س: هل يمكنني استخدام الفواصل بدلاً من الفواصل المنقوطة؟**  
ج: حالياً، الفواصل المنقوطة (`;`) فقط مدعومة. يمكنك تعديل طريقة `parse_addons()` لدعم فواصل أخرى.

**س: هل يمكنني تعيين أسعار للإضافات الفردية؟**  
ج: حالياً، جميع الإضافات تُنشأ بسعر `0`. يمكنك توسيع الكود لقراءة الأسعار من Excel إذا لزم الأمر.

**س: ماذا لو كان للمنتج عدة فئات؟**  
ج: تستخدم الإضافة الفئة الأولى لتحديد اسم المجموعة.

**س: هل يمكنني تعديل المجموعات يدوياً بعد الاستيراد؟**  
ج: نعم! المجموعات تُنشأ في WooCommerce Product Add-Ons، لذا يمكنك تعديلها بشكل طبيعي من WooCommerce → Products → Add-ons.

**س: هل إعادة الاستيراد ستنشئ تكرارات؟**  
ج: لا. تتحقق الإضافة من وجود المجموعة بالاسم وتحدّثها بدلاً من إنشاء تكرارات.

---

## الدعم

للحصول على المساعدة أو الإبلاغ عن مشاكل:
1. راجع ملف السجل: `/wp-content/uploads/aiwpg-logs/addons-import.log`
2. فعّل وضع تصحيح WordPress: `define('WP_DEBUG', true);` في `wp-config.php`
3. راجع console المتصفح لأخطاء JavaScript
4. تحقق من أن إضافة WooCommerce Product Add-Ons مفعّلة ومحدّثة

---

## Changelog

### Version 1.0.0 (2025-01-15)
- ✅ Initial release
- ✅ Automatic addons import from Excel
- ✅ Smart group naming based on categories
- ✅ Idempotent import (no duplicates)
- ✅ Manual import feature
- ✅ Comprehensive logging

---

**Developed for:** AI Woo Product Generator Plugin  
**Compatible with:** WooCommerce Product Add-Ons Extension  
**Last Updated:** January 2025
