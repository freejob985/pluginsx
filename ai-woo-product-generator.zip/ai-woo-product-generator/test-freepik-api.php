<?php
/**
 * Test Freepik API Keys
 * 
 * SECURITY: This file is for DEVELOPMENT/TESTING ONLY
 * It is disabled in production environments.
 * 
 * Usage: 
 * 1. Enable WP_DEBUG in wp-config.php
 * 2. Access via: /wp-content/plugins/ai-woo-product-generator/test-freepik-api.php?nonce=<nonce>
 * 3. Must be logged in as administrator
 */

// ============================================================================
// PRODUCTION PROTECTION - This tool is disabled unless WP_DEBUG is enabled
// ============================================================================
if (!defined('WP_DEBUG') || !WP_DEBUG) {
    header('HTTP/1.0 403 Forbidden');
    die('
        <h1>Access Denied</h1>
        <p><strong>This testing tool is disabled in production environments.</strong></p>
        <p>To use this tool:</p>
        <ol>
            <li>Enable <code>WP_DEBUG</code> in your <code>wp-config.php</code> file</li>
            <li>Ensure you are logged in as an administrator</li>
        </ol>
        <p><em>For security reasons, this file should be removed or renamed on production servers.</em></p>
    ');}

// ============================================================================
// LOAD WORDPRESS - Try multiple possible paths
// ============================================================================
$wp_load_paths = [
    __DIR__ . '/../../../wp-load.php',                    // Standard WordPress structure
    dirname(dirname(dirname(__DIR__))) . '/wp-load.php',  // Alternative
    __DIR__ . '/../../../../wp-load.php',                 // Nested plugins
];

$wp_loaded = false;
foreach ($wp_load_paths as $path) {
    if (file_exists($path)) {
        require_once($path);
        $wp_loaded = true;
        break;
    }
}

if (!$wp_loaded) {
    die('
        <h1>WordPress Not Found</h1>
        <p>Could not locate WordPress installation.</p>
        <p>Tried paths:</p>
        <ul>' . implode('', array_map(function($p) { return '<li>' . esc_html($p) . '</li>'; }, $wp_load_paths)) . '</ul>
    ');
}

// ============================================================================
// AUTHENTICATION & AUTHORIZATION CHECKS
// ============================================================================

// Check if user is logged in
if (!is_user_logged_in()) {
    wp_die('You must be logged in to access this testing tool.', 'Authentication Required', ['response' => 401]);
}

// Check if user has admin capabilities
if (!current_user_can('manage_options')) {
    wp_die('Access denied. Administrator privileges required.', 'Access Denied', ['response' => 403]);
}

// Verify nonce for CSRF protection
$nonce = isset($_GET['nonce']) ? sanitize_text_field($_GET['nonce']) : '';
if (empty($nonce) || !wp_verify_nonce($nonce, 'aiwpg_test_api_' . get_current_user_id())) {
    // Generate a fresh nonce for the user
    $fresh_nonce = wp_create_nonce('aiwpg_test_api_' . get_current_user_id());
    $current_url = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
    $url_parts = parse_url($current_url);
    $base_url = $url_parts['scheme'] . '://' . $url_parts['host'] . $url_parts['path'];
    
    wp_die(
        'Invalid or missing security token.<br><br>' .
        '<strong>Click here to access with valid token:</strong><br>' .
        '<a href="' . esc_url($base_url . '?nonce=' . $fresh_nonce) . '">' . 
        esc_html($base_url . '?nonce=' . $fresh_nonce) . '</a>',
        'Security Check Failed',
        ['response' => 403]
    );
}

// ============================================================================
// LOAD API KEYS FROM CONFIGURATION (NOT HARDCODED)
// ============================================================================
$api_keys = [];
for ($i = 1; $i <= 5; $i++) {
    $constant = 'AIWPG_FREEPIK_API_KEY_' . $i;
    if (defined($constant) && !empty(constant($constant))) {
        $api_keys[] = constant($constant);
    }
}

// Check if any keys are configured
if (empty($api_keys)) {
    die('
        <div style="font-family: Arial, sans-serif; margin: 40px; background: #fff3cd; padding: 20px; border-left: 4px solid #ffc107;">
            <h2>⚠️ No API Keys Configured</h2>
            <p>No Freepik API keys found in configuration.</p>
            <p>Please add your API keys to <code>wp-config.php</code>:</p>
            <pre>define(\'AIWPG_FREEPIK_API_KEY_1\', \'your-key-here\');
define(\'AIWPG_FREEPIK_API_KEY_2\', \'your-key-here\');
// ... etc</pre>
        </div>
    ');
}

$api_endpoint = 'https://api.freepik.com/v1/ai/gemini-2-5-flash-image-preview';
$test_prompt = 'A simple red apple on white background';

echo '<!DOCTYPE html>
<html>
<head>
    <title>Freepik API Test</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; background: #f5f5f5; }
        .container { max-width: 1200px; margin: 0 auto; background: white; padding: 30px; border-radius: 8px; }
        h1 { color: #333; border-bottom: 3px solid #2271b1; padding-bottom: 10px; }
        .test-info { background: #e7f3ff; padding: 15px; border-left: 4px solid #2271b1; margin-bottom: 30px; }
        .key-test { margin: 20px 0; padding: 20px; border: 1px solid #ddd; border-radius: 5px; }
        .key-test h3 { margin-top: 0; color: #2271b1; }
        .success { background: #d4edda; border-color: #28a745; }
        .error { background: #f8d7da; border-color: #dc3545; }
        .warning { background: #fff3cd; border-color: #ffc107; }
        pre { background: #f5f5f5; padding: 15px; border-radius: 4px; overflow-x: auto; }
        .status { font-weight: bold; font-size: 18px; margin: 10px 0; }
        .status.ok { color: #28a745; }
        .status.fail { color: #dc3545; }
        .loading { color: #666; font-style: italic; }
    </style>
</head>
<body>
    <div class="container">
        <h1>🔍 Freepik API Keys Test</h1>
        
        <div class="test-info">
            <strong>Test Configuration:</strong><br>
            <strong>Endpoint:</strong> ' . htmlspecialchars($api_endpoint) . '<br>
            <strong>Test Prompt:</strong> ' . htmlspecialchars($test_prompt) . '<br>
            <strong>Keys to Test:</strong> ' . count($api_keys) . '<br>
            <strong>Time:</strong> ' . date('Y-m-d H:i:s') . '
        </div>';

foreach ($api_keys as $index => $api_key) {
    $key_number = $index + 1;
    // Mask the key for security - only show first 8 and last 4 characters
    $key_length = strlen($api_key);
    if ($key_length > 12) {
        $masked_key = substr($api_key, 0, 8) . '...' . substr($api_key, -4);
    } else {
        $masked_key = substr($api_key, 0, 4) . '...';
    }
    
    echo '<div class="key-test">';
    echo '<h3>Testing API Key #' . $key_number . ': ' . htmlspecialchars($masked_key) . '</h3>';
    echo '<p class="loading">⏳ Sending request...</p>';
    
    flush();
    ob_flush();
    
    $start_time = microtime(true);
    
    // Prepare request
    $body = ['prompt' => $test_prompt];
    
    $args = [
        'headers' => [
            'Content-Type' => 'application/json',
            'x-freepik-api-key' => $api_key
        ],
        'body' => json_encode($body),
        'timeout' => 60,
        'method' => 'POST'
    ];
    
    // Send request
    $response = wp_remote_post($api_endpoint, $args);
    
    $end_time = microtime(true);
    $duration = round($end_time - $start_time, 2);
    
    echo '<script>document.querySelectorAll(".loading")[' . $index . '].remove();</script>';
    
    // Check for errors
    if (is_wp_error($response)) {
        $error_message = $response->get_error_message();
        echo '<div class="status fail">❌ FAILED</div>';
        echo '<p><strong>Error Type:</strong> WordPress HTTP Error</p>';
        echo '<p><strong>Error Message:</strong> ' . htmlspecialchars($error_message) . '</p>';
        echo '<p><strong>Duration:</strong> ' . $duration . ' seconds</p>';
    } else {
        $status_code = wp_remote_retrieve_response_code($response);
        $response_body = wp_remote_retrieve_body($response);
        $decoded = json_decode($response_body, true);
        
        if ($status_code === 200) {
            echo '<div class="status ok">✅ SUCCESS</div>';
            echo '<p><strong>HTTP Status:</strong> ' . $status_code . '</p>';
            echo '<p><strong>Duration:</strong> ' . $duration . ' seconds</p>';
            
            // Check response structure
            if (isset($decoded['data'])) {
                echo '<p><strong>Response Structure:</strong> Contains "data" field ✓</p>';
                
                if (isset($decoded['data']['image'])) {
                    echo '<p><strong>Image Data:</strong> Present ✓</p>';
                    $image_preview = substr($decoded['data']['image'], 0, 100);
                    echo '<p><strong>Image Data Preview:</strong> ' . htmlspecialchars($image_preview) . '...</p>';
                } else {
                    echo '<p><strong>Image Data:</strong> Missing ⚠️</p>';
                }
            } elseif (isset($decoded['image_url'])) {
                echo '<p><strong>Image URL:</strong> ' . htmlspecialchars($decoded['image_url']) . '</p>';
            }
            
            echo '<details><summary><strong>Full Response (click to expand)</strong></summary>';
            echo '<pre>' . htmlspecialchars(json_encode($decoded, JSON_PRETTY_PRINT)) . '</pre>';
            echo '</details>';
            
        } else {
            echo '<div class="status fail">❌ FAILED</div>';
            echo '<p><strong>HTTP Status:</strong> ' . $status_code . '</p>';
            echo '<p><strong>Duration:</strong> ' . $duration . ' seconds</p>';
            
            if (isset($decoded['message'])) {
                echo '<p><strong>Error Message:</strong> ' . htmlspecialchars($decoded['message']) . '</p>';
            }
            
            if (isset($decoded['error'])) {
                echo '<p><strong>Error Details:</strong> ' . htmlspecialchars($decoded['error']) . '</p>';
            }
            
            echo '<details><summary><strong>Full Response (click to expand)</strong></summary>';
            echo '<pre>' . htmlspecialchars($response_body) . '</pre>';
            echo '</details>';
        }
    }
    
    echo '</div>';
    flush();
    ob_flush();
}

echo '
        <div class="test-info" style="margin-top: 30px;">
            <strong>💡 Next Steps:</strong><br>
            • If all keys failed with 401/403: Keys are invalid or expired<br>
            • If keys failed with 429: Rate limit exceeded, wait and try again<br>
            • If keys show "quota exceeded": You need to upgrade your Freepik plan<br>
            • If successful but no image data: Check API response structure above<br>
            • Check the full response details to understand the API format
        </div>
    </div>
</body>
</html>';
