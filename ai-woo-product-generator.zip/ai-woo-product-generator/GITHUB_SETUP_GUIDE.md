# خطوات رفع المشروع إلى GitHub

## ✅ تم بالفعل

1. ✔️ تهيئة Git في المشروع
2. ✔️ إعداد ملف .gitignore
3. ✔️ إضافة جميع الملفات (108 ملف)
4. ✔️ عمل Commit أولي
5. ✔️ إنشاء ملفات README.md و CHANGELOG.md

## 📋 الخطوات المتبقية

### 1. إنشاء Repository على GitHub

1. افتح متصفح الويب واذهب إلى: https://github.com/new
2. أدخل المعلومات التالية:
   - **Repository name**: `ai-woo-product-generator`
   - **Description**: `WordPress plugin for generating WooCommerce products using AI (Google Gemini & Freepik)`
   - **Visibility**: اختر Public أو Private حسب رغبتك
   - **لا تختر**: Initialize with README (لأننا لدينا README بالفعل)
3. انقر على "Create repository"

### 2. ربط المشروع المحلي بـ GitHub

بعد إنشاء الـ Repository، قم بتشغيل الأوامر التالية في Terminal:

```powershell
# إضافة GitHub كـ remote origin
git remote add origin https://github.com/freejob985/ai-woo-product-generator.git

# رفع الملفات إلى GitHub
git push -u origin main
```

### 3. التحقق من الرفع

بعد تنفيذ الأمر السابق:
1. افتح https://github.com/freejob985/ai-woo-product-generator
2. تحقق من ظهور جميع الملفات والمجلدات

## 🔍 عرض الملفات المتغيرة في المستقبل

بعد رفع المشروع لـ GitHub، يمكنك استخدام:

### عرض التغييرات المحلية
```powershell
git status
```

### عرض الفروقات في الملفات
```powershell
git diff
```

### عرض سجل التغييرات
```powershell
git log --oneline --graph --all
```

### عرض التغييرات في ملف معين
```powershell
git diff filename.php
```

## 📊 إحصائيات المشروع الحالي

- **عدد الملفات**: 108 ملف
- **عدد الأسطر**: 41,092+ سطر
- **المجلدات الرئيسية**:
  - controllers/ (4 ملفات)
  - models/ (6 ملفات)
  - views/ (3 ملفات)
  - assets/js/ (25+ ملف)
  - doc/ (8 ملفات توثيق)

## 🔄 للتحديثات المستقبلية

عند إجراء تغييرات على الملفات:

```powershell
# إضافة الملفات المعدلة
git add .

# حفظ التغييرات مع رسالة وصفية
git commit -m "وصف التغييرات هنا"

# رفع التغييرات إلى GitHub
git push
```

## 🌿 العمل مع الفروع (Branches)

### إنشاء فرع جديد للتطوير
```powershell
git checkout -b feature/new-feature
```

### الرجوع للفرع الرئيسي
```powershell
git checkout main
```

### دمج الفرع مع الفرع الرئيسي
```powershell
git checkout main
git merge feature/new-feature
git push
```

## 🔐 ملاحظات الأمان

⚠️ **مهم جداً**:
- ملف `.env` **لن يتم** رفعه لـ GitHub (محمي بواسطة .gitignore)
- مفاتيح API آمنة ولن تُرفع
- الملفات الحساسة محمية

## 📞 في حالة المشاكل

### مشكلة: ظهور خطأ عند Push
```powershell
# جلب آخر التغييرات أولاً
git pull origin main --rebase

# ثم رفع التغييرات
git push
```

### مشكلة: عدم ظهور بعض الملفات
```powershell
# التحقق من .gitignore
cat .gitignore

# إجبار إضافة ملف معين
git add -f filename.php
```

## ✨ الميزات المتاحة على GitHub

بعد رفع المشروع:
- ✅ تتبع جميع التغييرات
- ✅ سجل كامل للإصدارات
- ✅ إمكانية التعاون مع مطورين آخرين
- ✅ Issues & Pull Requests
- ✅ GitHub Actions للـ CI/CD
- ✅ Wiki للتوثيق الإضافي

---

**جاهز للرفع! 🚀**

فقط قم بإنشاء Repository على GitHub واتبع الأوامر في القسم رقم 2.
