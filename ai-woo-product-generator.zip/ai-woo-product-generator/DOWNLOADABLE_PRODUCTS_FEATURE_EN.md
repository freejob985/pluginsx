# Downloadable Products Feature

## Complete Implementation

The downloadable products feature has been fully implemented in the "Add New Product" modal.

### ✅ Completed Tasks

#### 1. User Interface (UI)
- ✅ Added "Downloadable" checkbox
- ✅ When checked, the following additional fields are displayed:

##### Downloadable Files Fields
- **Downloadable files**: Table containing:
  - "Name" column: File name
  - "File URL" column: File link
  - Delete button for each row
- **"Add File" button**: To add a new file

##### Download Control Fields
- **Download Limit**: Download limit (Unlimited by default)
  - Description: "Leave blank for unlimited re-downloads."
- **Download Expiry**: Download expiration (Never by default)
  - Description: "Enter the number of days before a download link expires, or leave blank."

---

## Modified Files

### 1. views/admin-products-list-page.php
**Location**: Step 3 - Inventory & Shipping
- Added downloadable files table
- Added "Add File" button
- Updated Download Limit and Download Expiry field descriptions

### 2. assets/js/products_list/add-product-modal.js
**Added Functions**:
- `addDownloadableFileRow()`: Add a new file row
- `getDownloadableFiles()`: Collect file data
- Handle "Add File" button click events
- Handle file deletion events
- Clear file list when resetting the form

### 3. assets/css/aiwpg-admin.css
**Added Styles**:
- File table styles `.downloadable-files-table`
- "Add File" button styles `.add-downloadable-file`
- Delete button styles `.remove-downloadable-file`
- Hover and focus effects

### 4. controllers/class-aiwpg-products-controller.php
**Updates**:
- Added `downloadable_files` handling in `create_product()` function
- Pass data to product model

### 5. models/class-aiwpg-product-model.php
**Updates**:
- Added downloadable files array processing
- Use `set_downloads()` to save files in WooCommerce
- Generate unique ID for each file using `md5()`

---

## How to Use

### Steps:
1. Open "Add New Product" modal
2. In **Step 1**: Select product type (Simple or Variable)
3. Enable "Downloadable" checkbox
4. In **Step 3**: "Downloadable Options" fields will appear
5. Click **"Add File"** button to add a file:
   - Enter file name in "Name" field
   - Enter file URL in "File URL" field
6. You can add multiple files by clicking "Add File" multiple times
7. You can delete any file by clicking the trash icon
8. Set **Download Limit** (leave blank for unlimited downloads)
9. Set **Download Expiry** (leave blank for no expiration)
10. Complete the remaining steps and save the product

---

## Example Data Sent

```json
{
  "name": "eBook - Learn WordPress",
  "type": "simple",
  "downloadable": true,
  "downloadable_files": [
    {
      "name": "WordPress Guide.pdf",
      "file": "https://example.com/files/wordpress-guide.pdf"
    },
    {
      "name": "Bonus Resources.zip",
      "file": "https://example.com/files/bonus-resources.zip"
    }
  ],
  "download_limit": "-1",
  "download_expiry": "-1"
}
```

---

## Features

✅ Easy and intuitive user interface
✅ Ability to add multiple files
✅ Ability to delete files
✅ Automatic data cleanup when closing/reopening the form
✅ Full integration with WooCommerce
✅ Support for all file types (PDF, ZIP, MP3, etc.)
✅ Data validation at frontend and backend levels
✅ Attractive styling consistent with WordPress interface

---

## Testing

### To verify the feature works:
1. Open Products List page
2. Click "Add Product"
3. Enable "Downloadable" checkbox
4. Verify the files table and "Add File" button appear
5. Add one or more files
6. Save the product
7. Open the product in WooCommerce to verify files are saved

---

## Technical Notes

### File Handling in WooCommerce
- Files are saved using `WC_Product::set_downloads()`
- Each file requires a unique ID (generated using `md5()`)
- Required data for each file:
  - `name`: File name
  - `file`: File URL

### Default Values
- **Download Limit**: `-1` (unlimited)
- **Download Expiry**: `-1` (no expiration)

### Security
- `sanitize_text_field()` is used to sanitize file names
- `esc_url_raw()` is used to sanitize file URLs

---

## Support

If you encounter any issues:
1. Check browser console for errors
2. Check WordPress error logs
3. Ensure WooCommerce is activated
4. Verify permissions (`manage_woocommerce`)

---

Implementation Date: November 25, 2025
Status: ✅ Complete and Tested

