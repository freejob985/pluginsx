# حل مشكلة Git - الملفات لا تظهر في Git

## المشكلة
التغييرات في البلاجن `ai-woo-product-generator` لا تظهر في Git.

## الحلول الممكنة

### الحل 1: التحقق من حالة Git

افتح PowerShell في مجلد `e:\plugins` وقم بتنفيذ:

```powershell
# التحقق من وجود مستودع Git
cd e:\plugins
git status

# إضافة الملفات المعدلة
git add ai-woo-product-generator/

# عرض الملفات المضافة
git status --short ai-woo-product-generator/
```

### الحل 2: إضافة الملفات بالقوة (Force Add)

إذا كانت الملفات في `.gitignore`:

```powershell
cd e:\plugins
git add -f ai-woo-product-generator/models/class-aiwpg-ai-service.php
git add -f ai-woo-product-generator/controllers/class-aiwpg-products-controller.php
git add -f ai-woo-product-generator/views/admin-ai-generator-page.php
git add -f ai-woo-product-generator/assets/js/generate_products/excel-import.js
git add -f ai-woo-product-generator/models/class-aiwpg-product-model.php
```

### الحل 3: التحقق من .gitignore

تحقق من ملف `.gitignore` في `e:\plugins\.gitignore`:

```powershell
cd e:\plugins
Get-Content .gitignore
```

إذا كان `ai-woo-product-generator` موجود في `.gitignore`، قم بإزالته أو استخدم `git add -f`.

### الحل 4: إضافة جميع الملفات المعدلة

```powershell
cd e:\plugins

# إضافة جميع الملفات المعدلة
git add ai-woo-product-generator/

# أو إضافة ملفات محددة
git add ai-woo-product-generator/models/class-aiwpg-ai-service.php
git add ai-woo-product-generator/controllers/class-aiwpg-products-controller.php
git add ai-woo-product-generator/views/admin-ai-generator-page.php
git add ai-woo-product-generator/assets/js/generate_products/excel-import.js
git add ai-woo-product-generator/models/class-aiwpg-product-model.php
git add ai-woo-product-generator/EXCEL_AI_INTEGRATION.md

# عرض حالة Git
git status
```

### الحل 5: إنشاء commit

بعد إضافة الملفات:

```powershell
cd e:\plugins
git commit -m "Update Excel AI Integration feature"
```

### الحل 6: إذا كان المجلد ليس في Git

إذا كان المجلد `ai-woo-product-generator` غير متتبع في Git:

```powershell
cd e:\plugins

# إضافة المجلد بالكامل
git add ai-woo-product-generator/

# أو إضافة ملفات محددة
git add ai-woo-product-generator/*.php
git add ai-woo-product-generator/*.js
git add ai-woo-product-generator/*.md
```

## الملفات المعدلة التي يجب إضافتها

1. `models/class-aiwpg-ai-service.php` - تحديث AI Service
2. `controllers/class-aiwpg-products-controller.php` - تحديث Controller
3. `views/admin-ai-generator-page.php` - تحديث الواجهة
4. `assets/js/generate_products/excel-import.js` - تحديث JavaScript
5. `models/class-aiwpg-product-model.php` - تحديث Product Model
6. `EXCEL_AI_INTEGRATION.md` - ملف التوثيق الجديد

## أمر سريع لإضافة كل شيء

```powershell
cd e:\plugins
git add ai-woo-product-generator/models/class-aiwpg-ai-service.php
git add ai-woo-product-generator/controllers/class-aiwpg-products-controller.php
git add ai-woo-product-generator/views/admin-ai-generator-page.php
git add ai-woo-product-generator/assets/js/generate_products/excel-import.js
git add ai-woo-product-generator/models/class-aiwpg-product-model.php
git add ai-woo-product-generator/EXCEL_AI_INTEGRATION.md
git add ai-woo-product-generator/GIT_FIX.md
git status
```

## ملاحظات

- إذا كان المستودع في `e:\plugins` وليس في `e:\plugins\ai-woo-product-generator`، استخدم المسارات النسبية
- استخدم `git add -f` لإضافة الملفات حتى لو كانت في `.gitignore`
- تأكد من أنك في المجلد الصحيح قبل تنفيذ الأوامر




