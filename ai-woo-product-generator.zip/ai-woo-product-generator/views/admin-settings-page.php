<?php
/**
 * Settings Admin Page
 * Plugin settings and delete operations
 */

if (!defined('ABSPATH')) {
    exit;
}

$settings = get_option('aiwpg_settings', array(
    'products_per_page' => 12,
    'default_stock_status' => 'instock',
    'auto_publish' => false,
));

// Get API keys from database
$api_keys = get_option('aiwpg_api_keys', array());
?>

<div class="wrap aiwpg-wrap">
    <h1><?php _e('AI Product Generator Settings', 'ai-woo-product-generator'); ?></h1>
    
    <!-- Tabs Navigation -->
    <nav class="nav-tab-wrapper">
        <a href="#general" class="nav-tab nav-tab-active" data-tab="general">
            <span class="dashicons dashicons-admin-generic"></span>
            <?php _e('General Settings', 'ai-woo-product-generator'); ?>
        </a>
        <a href="#api-keys" class="nav-tab" data-tab="api-keys">
            <span class="dashicons dashicons-admin-network"></span>
            <?php _e('API Keys', 'ai-woo-product-generator'); ?>
        </a>
        <a href="#cron-job" class="nav-tab" data-tab="cron-job">
            <span class="dashicons dashicons-clock"></span>
            <?php _e('Cron Job', 'ai-woo-product-generator'); ?>
        </a>
        <a href="#addons-import" class="nav-tab" data-tab="addons-import">
            <span class="dashicons dashicons-plus-alt"></span>
            <?php _e('Add-Ons Import', 'ai-woo-product-generator'); ?>
        </a>
        <a href="#danger-zone" class="nav-tab" data-tab="danger-zone">
            <span class="dashicons dashicons-warning"></span>
            <?php _e('Danger Zone', 'ai-woo-product-generator'); ?>
        </a>
    </nav>
    
    <div class="aiwpg-settings-container">
        <!-- General Settings Tab -->
        <div class="tab-content" id="general-tab" style="display: block;">
        <div class="aiwpg-card">
            <h2><?php _e('General Settings', 'ai-woo-product-generator'); ?></h2>
            
            <form id="settings-form" class="aiwpg-form">
                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="products_per_page"><?php _e('Products Per Page', 'ai-woo-product-generator'); ?></label>
                        </th>
                        <td>
                            <input 
                                type="number" 
                                id="products_per_page" 
                                name="products_per_page" 
                                value="<?php echo esc_attr($settings['products_per_page']); ?>" 
                                min="1" 
                                max="100"
                                class="small-text"
                            >
                            <p class="description">
                                <?php _e('Number of products to display per page in the products list.', 'ai-woo-product-generator'); ?>
                            </p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">
                            <label for="default_stock_status"><?php _e('Default Stock Status', 'ai-woo-product-generator'); ?></label>
                        </th>
                        <td>
                            <select id="default_stock_status" name="default_stock_status">
                                <option value="instock" <?php selected($settings['default_stock_status'], 'instock'); ?>>
                                    <?php _e('In Stock', 'ai-woo-product-generator'); ?>
                                </option>
                                <option value="outofstock" <?php selected($settings['default_stock_status'], 'outofstock'); ?>>
                                    <?php _e('Out of Stock', 'ai-woo-product-generator'); ?>
                                </option>
                            </select>
                            <p class="description">
                                <?php _e('Default stock status for new AI-generated products.', 'ai-woo-product-generator'); ?>
                            </p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">
                            <?php _e('Auto-Publish Products', 'ai-woo-product-generator'); ?>
                        </th>
                        <td>
                            <label>
                                <input 
                                    type="checkbox" 
                                    id="auto_publish" 
                                    name="auto_publish" 
                                    value="1" 
                                    <?php checked($settings['auto_publish'], true); ?>
                                >
                                <?php _e('Automatically publish AI-generated products (otherwise saved as drafts)', 'ai-woo-product-generator'); ?>
                            </label>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">
                            <?php _e('Enable Add-Ons Import', 'ai-woo-product-generator'); ?>
                        </th>
                        <td>
                            <label>
                                <input 
                                    type="checkbox" 
                                    id="enable_addons_import" 
                                    name="enable_addons_import" 
                                    value="1" 
                                    <?php checked(!empty($settings['enable_addons_import']), true); ?>
                                >
                                <?php _e('Automatically import product add-ons from Excel "Addons" column to WooCommerce Product Add-Ons', 'ai-woo-product-generator'); ?>
                            </label>
                            <p class="description">
                                <?php _e('When enabled, the plugin will automatically create/update add-on groups and link them to products during Excel import.', 'ai-woo-product-generator'); ?>
                                <?php if (!class_exists('WC_Product_Add_Ons')): ?>
                                    <br><strong style="color: #d63638;">
                                        <?php _e('⚠️ WooCommerce Product Add-Ons plugin is not active. Please install and activate it to use this feature.', 'ai-woo-product-generator'); ?>
                                    </strong>
                                <?php endif; ?>
                            </p>
                        </td>
                    </tr>
                </table>
                
                <p class="submit">
                    <button type="submit" class="button button-primary">
                        <?php _e('Save Settings', 'ai-woo-product-generator'); ?>
                    </button>
                </p>
            </form>
        </div>
        </div>
        <!-- End General Settings Tab -->
        
        <!-- API Keys Tab -->
        <div class="tab-content" id="api-keys-tab" style="display: none;">
            
            <!-- Google Gemini API Keys -->
            <div class="aiwpg-card">
                <h2>
                    <span class="dashicons dashicons-cloud"></span>
                    <?php _e('Google Gemini API Keys', 'ai-woo-product-generator'); ?>
                </h2>
                <p class="description">
                    <?php _e('Configure up to 5 Google Gemini API keys for product generation. The plugin will automatically use failover if one key reaches its quota.', 'ai-woo-product-generator'); ?>
                    <br>
                    <a href="https://makersuite.google.com/app/apikey" target="_blank">
                        <?php _e('Get your API keys here', 'ai-woo-product-generator'); ?> →
                    </a>
                </p>
                
                <form id="gemini-keys-form" class="aiwpg-form api-keys-form">
                    <table class="form-table">
                        <?php for ($i = 1; $i <= 5; $i++): 
                            $key_value = isset($api_keys['gemini_' . $i]) ? $api_keys['gemini_' . $i] : '';
                        ?>
                        <tr>
                            <th scope="row">
                                <label for="gemini_key_<?php echo $i; ?>">
                                    <?php printf(__('API Key %d', 'ai-woo-product-generator'), $i); ?>
                                </label>
                            </th>
                            <td>
                                <div class="api-key-input-group">
                                    <input 
                                        type="password" 
                                        id="gemini_key_<?php echo $i; ?>" 
                                        name="gemini_key_<?php echo $i; ?>" 
                                        value="<?php echo esc_attr($key_value); ?>" 
                                        class="regular-text api-key-input"
                                        placeholder="AIzaSy..."
                                        autocomplete="off"
                                    >
                                    <button type="button" class="button toggle-password" data-target="gemini_key_<?php echo $i; ?>">
                                        <span class="dashicons dashicons-visibility"></span>
                                    </button>
                                    <button type="button" class="button test-api-key" data-key-type="gemini" data-key-index="<?php echo $i; ?>">
                                        <span class="dashicons dashicons-yes-alt"></span>
                                        <?php _e('Test', 'ai-woo-product-generator'); ?>
                                    </button>
                                    <span class="key-status" id="gemini_status_<?php echo $i; ?>"></span>
                                </div>
                            </td>
                        </tr>
                        <?php endfor; ?>
                    </table>
                    
                    <p class="submit">
                        <button type="submit" class="button button-primary">
                            <span class="dashicons dashicons-saved"></span>
                            <?php _e('Save Gemini Keys', 'ai-woo-product-generator'); ?>
                        </button>
                    </p>
                </form>
            </div>
            
            <!-- Freepik API Keys -->
            <div class="aiwpg-card">
                <h2>
                    <span class="dashicons dashicons-format-image"></span>
                    <?php _e('Freepik API Keys', 'ai-woo-product-generator'); ?>
                </h2>
                <p class="description">
                    <?php _e('Configure up to 5 Freepik API keys for image generation. The plugin will automatically use failover if one key reaches its quota.', 'ai-woo-product-generator'); ?>
                    <br>
                    <a href="https://www.freepik.com/api/" target="_blank">
                        <?php _e('Get your API keys here', 'ai-woo-product-generator'); ?> →
                    </a>
                </p>
                
                <form id="freepik-keys-form" class="aiwpg-form api-keys-form">
                    <table class="form-table">
                        <?php for ($i = 1; $i <= 5; $i++): 
                            $key_value = isset($api_keys['freepik_' . $i]) ? $api_keys['freepik_' . $i] : '';
                        ?>
                        <tr>
                            <th scope="row">
                                <label for="freepik_key_<?php echo $i; ?>">
                                    <?php printf(__('API Key %d', 'ai-woo-product-generator'), $i); ?>
                                </label>
                            </th>
                            <td>
                                <div class="api-key-input-group">
                                    <input 
                                        type="password" 
                                        id="freepik_key_<?php echo $i; ?>" 
                                        name="freepik_key_<?php echo $i; ?>" 
                                        value="<?php echo esc_attr($key_value); ?>" 
                                        class="regular-text api-key-input"
                                        placeholder="FPSX..."
                                        autocomplete="off"
                                    >
                                    <button type="button" class="button toggle-password" data-target="freepik_key_<?php echo $i; ?>">
                                        <span class="dashicons dashicons-visibility"></span>
                                    </button>
                                    <button type="button" class="button test-api-key" data-key-type="freepik" data-key-index="<?php echo $i; ?>">
                                        <span class="dashicons dashicons-yes-alt"></span>
                                        <?php _e('Test', 'ai-woo-product-generator'); ?>
                                    </button>
                                    <span class="key-status" id="freepik_status_<?php echo $i; ?>"></span>
                                </div>
                            </td>
                        </tr>
                        <?php endfor; ?>
                    </table>
                    
                    <p class="submit">
                        <button type="submit" class="button button-primary">
                            <span class="dashicons dashicons-saved"></span>
                            <?php _e('Save Freepik Keys', 'ai-woo-product-generator'); ?>
                        </button>
                    </p>
                </form>
            </div>
            
        </div>
        <!-- End API Keys Tab -->
        
        <!-- Cron Job Tab -->
        <div class="tab-content" id="cron-job-tab" style="display: none;">
            <?php
            $cron_settings = get_option('aiwpg_cron_settings', array());
            $cron_api_key = isset($cron_settings['api_key']) ? $cron_settings['api_key'] : '';
            $cron_interval = isset($cron_settings['interval']) ? $cron_settings['interval'] : 'minute';
            $cron_timezone = isset($cron_settings['timezone']) ? $cron_settings['timezone'] : 'UTC';
            $cron_job_id = isset($cron_settings['job_id']) ? $cron_settings['job_id'] : '';
            ?>
            
            <div class="aiwpg-card">
                <h2>
                    <span class="dashicons dashicons-clock"></span>
                    <?php _e('Cron Job Settings', 'ai-woo-product-generator'); ?>
                </h2>
                <p class="description">
                    <?php _e('Configure automatic image generation for all products and variations using cron-job.org.', 'ai-woo-product-generator'); ?>
                    <br>
                    <a href="https://cron-job.org/" target="_blank">
                        <?php _e('Get your API key from cron-job.org', 'ai-woo-product-generator'); ?> →
                    </a>
                </p>
                
                <form id="cron-settings-form" class="aiwpg-form">
                    <table class="form-table">
                        <tr>
                            <th scope="row">
                                <label for="cron_api_key">
                                    <?php _e('Cron-Job.org API Key', 'ai-woo-product-generator'); ?>
                                </label>
                            </th>
                            <td>
                                <input 
                                    type="password" 
                                    id="cron_api_key" 
                                    name="cron_api_key" 
                                    value="<?php echo esc_attr($cron_api_key); ?>" 
                                    class="regular-text"
                                    placeholder="zaX78aqKJuIH4l4RX6njoqADn77MQNJJ"
                                >
                                <p class="description">
                                    <?php _e('Your cron-job.org API key. Get it from Settings → API Keys in your cron-job.org account.', 'ai-woo-product-generator'); ?>
                                </p>
                            </td>
                        </tr>
                        
                        <tr>
                            <th scope="row">
                                <label for="cron_interval">
                                    <?php _e('Execution Interval', 'ai-woo-product-generator'); ?>
                                </label>
                            </th>
                            <td>
                                <select id="cron_interval" name="cron_interval">
                                    <option value="minute" <?php selected($cron_interval, 'minute'); ?>>
                                        <?php _e('Every Minute', 'ai-woo-product-generator'); ?>
                                    </option>
                                    <option value="hour" <?php selected($cron_interval, 'hour'); ?>>
                                        <?php _e('Every Hour', 'ai-woo-product-generator'); ?>
                                    </option>
                                </select>
                                <p class="description">
                                    <?php _e('How often the cron job should run. Each execution processes one product/variation image.', 'ai-woo-product-generator'); ?>
                                </p>
                            </td>
                        </tr>
                        
                        <tr>
                            <th scope="row">
                                <label for="cron_timezone">
                                    <?php _e('Timezone', 'ai-woo-product-generator'); ?>
                                </label>
                            </th>
                            <td>
                                <select id="cron_timezone" name="cron_timezone">
                                    <option value="UTC" <?php selected($cron_timezone, 'UTC'); ?>>UTC</option>
                                    <option value="Europe/Berlin" <?php selected($cron_timezone, 'Europe/Berlin'); ?>>Europe/Berlin</option>
                                    <option value="America/New_York" <?php selected($cron_timezone, 'America/New_York'); ?>>America/New_York</option>
                                    <option value="Asia/Dubai" <?php selected($cron_timezone, 'Asia/Dubai'); ?>>Asia/Dubai</option>
                                </select>
                                <p class="description">
                                    <?php _e('Timezone for cron job scheduling.', 'ai-woo-product-generator'); ?>
                                </p>
                            </td>
                        </tr>
                        
                        <tr>
                            <th scope="row">
                                <?php _e('Endpoint URL', 'ai-woo-product-generator'); ?>
                            </th>
                            <td>
                                <?php
                                $secret = get_option('aiwpg_cron_secret', '');
                                $endpoint_url = home_url('/aiwpg-cron-generate-images');
                                if (!empty($secret)) {
                                    $endpoint_url .= '?secret=' . urlencode($secret);
                                }
                                ?>
                                <code style="display: block; padding: 8px; background: #f0f0f0; border: 1px solid #ddd; border-radius: 4px; margin: 5px 0;">
                                    <?php echo esc_html($endpoint_url); ?>
                                </code>
                                <p class="description">
                                    <?php _e('This URL will be called by cron-job.org to generate images. The secret token is automatically generated for security.', 'ai-woo-product-generator'); ?>
                                </p>
                            </td>
                        </tr>
                    </table>
                    
                    <p class="submit">
                        <button type="submit" class="button button-primary">
                            <span class="dashicons dashicons-saved"></span>
                            <?php _e('Save Cron Settings', 'ai-woo-product-generator'); ?>
                        </button>
                    </p>
                </form>
            </div>
            
            <div class="aiwpg-card" style="margin-top: 20px;">
                <h2>
                    <span class="dashicons dashicons-controls-play"></span>
                    <?php _e('Cron Job Management', 'ai-woo-product-generator'); ?>
                </h2>
                
                <?php if (!empty($cron_job_id)): ?>
                    <p class="description">
                        <?php printf(__('Current Job ID: %s', 'ai-woo-product-generator'), '<strong>' . esc_html($cron_job_id) . '</strong>'); ?>
                    </p>
                <?php endif; ?>
                
                <p>
                    <button type="button" id="create-cron-job" class="button button-primary">
                        <span class="dashicons dashicons-plus-alt"></span>
                        <?php _e('Create/Update Cron Job', 'ai-woo-product-generator'); ?>
                    </button>
                    <button type="button" id="reset-progress" class="button button-secondary">
                        <span class="dashicons dashicons-update"></span>
                        <?php _e('Reset Progress', 'ai-woo-product-generator'); ?>
                    </button>
                </p>
                
                <div id="cron-progress-container" style="margin-top: 20px; display: none;">
                    <h3><?php _e('Generation Progress', 'ai-woo-product-generator'); ?></h3>
                    <div id="cron-progress-bar" style="width: 100%; height: 30px; background: #f0f0f0; border-radius: 4px; overflow: hidden; margin: 10px 0;">
                        <div id="cron-progress-fill" style="height: 100%; background: #2271b1; width: 0%; transition: width 0.3s; display: flex; align-items: center; justify-content: center; color: white; font-weight: bold;">
                            <span id="cron-progress-text">0%</span>
                        </div>
                    </div>
                    <div id="cron-progress-details" style="margin-top: 10px;">
                        <p>
                            <strong><?php _e('Status:', 'ai-woo-product-generator'); ?></strong>
                            <span id="cron-status-text">-</span>
                        </p>
                        <p>
                            <strong><?php _e('Completed:', 'ai-woo-product-generator'); ?></strong>
                            <span id="cron-completed">0</span> / 
                            <span id="cron-total">0</span>
                        </p>
                        <p>
                            <strong><?php _e('Failed:', 'ai-woo-product-generator'); ?></strong>
                            <span id="cron-failed">0</span>
                        </p>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Cron Job Tab -->
        
        <!-- Add-Ons Import Tab -->
        <div class="tab-content" id="addons-import-tab" style="display: none;">
            <div class="aiwpg-card">
                <h2>
                    <span class="dashicons dashicons-plus-alt"></span>
                    <?php _e('Product Add-Ons Import', 'ai-woo-product-generator'); ?>
                </h2>
                <p class="description">
                    <?php _e('Import product add-ons from Excel sheets and automatically create/update WooCommerce Product Add-Ons groups.', 'ai-woo-product-generator'); ?>
                </p>
                
                <?php if (!class_exists('WC_Product_Add_Ons')): ?>
                    <div class="notice notice-error inline">
                        <p>
                            <strong><?php _e('WooCommerce Product Add-Ons Required', 'ai-woo-product-generator'); ?></strong><br>
                            <?php _e('Please install and activate the WooCommerce Product Add-Ons plugin to use this feature.', 'ai-woo-product-generator'); ?>
                        </p>
                    </div>
                <?php else: ?>
                    <div class="addons-import-section">
                        <h3><?php _e('Manual Import', 'ai-woo-product-generator'); ?></h3>
                        <p>
                            <?php _e('Run add-ons import for all products that have addons data stored from previous Excel imports.', 'ai-woo-product-generator'); ?>
                        </p>
                        <p>
                            <button type="button" id="run-addons-import" class="button button-primary">
                                <span class="dashicons dashicons-update"></span>
                                <?php _e('Run Add-Ons Import Now', 'ai-woo-product-generator'); ?>
                            </button>
                        </p>
                        <div id="addons-import-results" style="display: none; margin-top: 20px;">
                            <div class="addons-import-summary"></div>
                        </div>
                    </div>
                    
                    <div class="addons-import-info" style="margin-top: 30px; padding: 15px; background: #f0f6fc; border-left: 4px solid #2271b1;">
                        <h3 style="margin-top: 0;"><?php _e('How It Works', 'ai-woo-product-generator'); ?></h3>
                        <ol>
                            <li><?php _e('Read "Addons" column from Excel sheet (format: "Extra Cheese; Extra Olives; Extra Sauce")', 'ai-woo-product-generator'); ?></li>
                            <li><?php _e('Determine add-on group name based on product category or name', 'ai-woo-product-generator'); ?></li>
                            <li><?php _e('Create or update global add-on groups in WooCommerce Product Add-Ons', 'ai-woo-product-generator'); ?></li>
                            <li><?php _e('Automatically link add-on groups to relevant products', 'ai-woo-product-generator'); ?></li>
                        </ol>
                        
                        <h4 style="margin-top: 20px;"><?php _e('Group Name Mapping', 'ai-woo-product-generator'); ?></h4>
                        <ul>
                            <li><strong>Pizza</strong> → Pizza Addons</li>
                            <li><strong>Burger</strong> → Burger Extras</li>
                            <li><strong>Salad</strong> → Salad Toppings</li>
                            <li><strong>Drink/Coffee</strong> → Drink Extras</li>
                            <li><strong>Other</strong> → {Product Name} Addons</li>
                        </ul>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        <!-- End Add-Ons Import Tab -->
        
        <!-- Danger Zone Tab -->
        <div class="tab-content" id="danger-zone-tab" style="display: none;">
        <!-- Danger Zone -->
        <div class="aiwpg-card aiwpg-danger-zone">
            <h2><?php _e('Danger Zone', 'ai-woo-product-generator'); ?></h2>
            
            <div class="danger-action">
                <div>
                    <h3><?php _e('Delete AI-Generated Products', 'ai-woo-product-generator'); ?></h3>
                    <p><?php _e('Delete all products that were generated by this plugin. This action cannot be undone.', 'ai-woo-product-generator'); ?></p>
                </div>
                <button type="button" id="delete-ai-products" class="button button-secondary">
                    <span class="dashicons dashicons-trash"></span>
                    <?php _e('Delete AI Products', 'ai-woo-product-generator'); ?>
                </button>
            </div>
            
            <hr>
            
            <div class="danger-action">
                <div>
                    <h3><?php _e('Delete ALL WooCommerce Products', 'ai-woo-product-generator'); ?></h3>
                    <p><?php _e('Delete ALL products in your WooCommerce store. This includes products not created by this plugin. This action cannot be undone!', 'ai-woo-product-generator'); ?></p>
                </div>
                <button type="button" id="delete-all-products" class="button button-danger">
                    <span class="dashicons dashicons-warning"></span>
                    <?php _e('Delete ALL Products', 'ai-woo-product-generator'); ?>
                </button>
            </div>
        </div>
        </div>
        <!-- End Danger Zone Tab -->
        
    </div>
</div>

<!-- Global Context Menu -->
<div id="global-context-menu" class="context-menu" style="display: none;">
    <div class="context-menu-item" data-action="generate-products">
        <span class="dashicons dashicons-admin-generic"></span>
        <span><?php _e('Generate Products', 'ai-woo-product-generator'); ?></span>
    </div>
    <div class="context-menu-item" data-action="products-list">
        <span class="dashicons dashicons-products"></span>
        <span><?php _e('Products List', 'ai-woo-product-generator'); ?></span>
    </div>
    <div class="context-menu-item" data-action="settings">
        <span class="dashicons dashicons-admin-settings"></span>
        <span><?php _e('Settings', 'ai-woo-product-generator'); ?></span>
    </div>
    <div class="context-menu-divider"></div>
    <div class="context-menu-item" data-action="add-product">
        <span class="dashicons dashicons-plus-alt"></span>
        <span><?php _e('Add Product', 'ai-woo-product-generator'); ?></span>
    </div>
    <div class="context-menu-divider"></div>
    <div class="context-menu-item" data-action="refresh">
        <span class="dashicons dashicons-update"></span>
        <span><?php _e('Refresh Page', 'ai-woo-product-generator'); ?></span>
    </div>
</div>