<?php
/**
 * Settings Admin Page
 * Plugin settings and delete operations
 */

if (!defined('ABSPATH')) {
    exit;
}

$settings = get_option('aiwpg_settings', array(
    'products_per_page' => 12,
    'default_stock_status' => 'instock',
    'auto_publish' => false,
));

// Get API keys from database
$api_keys = get_option('aiwpg_api_keys', array());
?>

<div class="wrap aiwpg-wrap">
    <h1><?php _e('AI Product Generator Settings', 'ai-woo-product-generator'); ?></h1>
    
    <!-- Tabs Navigation -->
    <nav class="nav-tab-wrapper">
        <a href="#general" class="nav-tab nav-tab-active" data-tab="general">
            <span class="dashicons dashicons-admin-generic"></span>
            <?php _e('General Settings', 'ai-woo-product-generator'); ?>
        </a>
        <a href="#api-keys" class="nav-tab" data-tab="api-keys">
            <span class="dashicons dashicons-admin-network"></span>
            <?php _e('API Keys', 'ai-woo-product-generator'); ?>
        </a>
        <a href="#danger-zone" class="nav-tab" data-tab="danger-zone">
            <span class="dashicons dashicons-warning"></span>
            <?php _e('Danger Zone', 'ai-woo-product-generator'); ?>
        </a>
    </nav>
    
    <div class="aiwpg-settings-container">
        <!-- General Settings Tab -->
        <div class="tab-content" id="general-tab" style="display: block;">
        <div class="aiwpg-card">
            <h2><?php _e('General Settings', 'ai-woo-product-generator'); ?></h2>
            
            <form id="settings-form" class="aiwpg-form">
                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="products_per_page"><?php _e('Products Per Page', 'ai-woo-product-generator'); ?></label>
                        </th>
                        <td>
                            <input 
                                type="number" 
                                id="products_per_page" 
                                name="products_per_page" 
                                value="<?php echo esc_attr($settings['products_per_page']); ?>" 
                                min="1" 
                                max="100"
                                class="small-text"
                            >
                            <p class="description">
                                <?php _e('Number of products to display per page in the products list.', 'ai-woo-product-generator'); ?>
                            </p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">
                            <label for="default_stock_status"><?php _e('Default Stock Status', 'ai-woo-product-generator'); ?></label>
                        </th>
                        <td>
                            <select id="default_stock_status" name="default_stock_status">
                                <option value="instock" <?php selected($settings['default_stock_status'], 'instock'); ?>>
                                    <?php _e('In Stock', 'ai-woo-product-generator'); ?>
                                </option>
                                <option value="outofstock" <?php selected($settings['default_stock_status'], 'outofstock'); ?>>
                                    <?php _e('Out of Stock', 'ai-woo-product-generator'); ?>
                                </option>
                            </select>
                            <p class="description">
                                <?php _e('Default stock status for new AI-generated products.', 'ai-woo-product-generator'); ?>
                            </p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">
                            <?php _e('Auto-Publish Products', 'ai-woo-product-generator'); ?>
                        </th>
                        <td>
                            <label>
                                <input 
                                    type="checkbox" 
                                    id="auto_publish" 
                                    name="auto_publish" 
                                    value="1" 
                                    <?php checked($settings['auto_publish'], true); ?>
                                >
                                <?php _e('Automatically publish AI-generated products (otherwise saved as drafts)', 'ai-woo-product-generator'); ?>
                            </label>
                        </td>
                    </tr>
                </table>
                
                <p class="submit">
                    <button type="submit" class="button button-primary">
                        <?php _e('Save Settings', 'ai-woo-product-generator'); ?>
                    </button>
                </p>
            </form>
        </div>
        </div>
        <!-- End General Settings Tab -->
        
        <!-- API Keys Tab -->
        <div class="tab-content" id="api-keys-tab" style="display: none;">
            
            <!-- Google Gemini API Keys -->
            <div class="aiwpg-card">
                <h2>
                    <span class="dashicons dashicons-cloud"></span>
                    <?php _e('Google Gemini API Keys', 'ai-woo-product-generator'); ?>
                </h2>
                <p class="description">
                    <?php _e('Configure up to 5 Google Gemini API keys for product generation. The plugin will automatically use failover if one key reaches its quota.', 'ai-woo-product-generator'); ?>
                    <br>
                    <a href="https://makersuite.google.com/app/apikey" target="_blank">
                        <?php _e('Get your API keys here', 'ai-woo-product-generator'); ?> →
                    </a>
                </p>
                
                <form id="gemini-keys-form" class="aiwpg-form api-keys-form">
                    <table class="form-table">
                        <?php for ($i = 1; $i <= 5; $i++): 
                            $key_value = isset($api_keys['gemini_' . $i]) ? $api_keys['gemini_' . $i] : '';
                        ?>
                        <tr>
                            <th scope="row">
                                <label for="gemini_key_<?php echo $i; ?>">
                                    <?php printf(__('API Key %d', 'ai-woo-product-generator'), $i); ?>
                                </label>
                            </th>
                            <td>
                                <div class="api-key-input-group">
                                    <input 
                                        type="password" 
                                        id="gemini_key_<?php echo $i; ?>" 
                                        name="gemini_key_<?php echo $i; ?>" 
                                        value="<?php echo esc_attr($key_value); ?>" 
                                        class="regular-text api-key-input"
                                        placeholder="AIzaSy..."
                                        autocomplete="off"
                                    >
                                    <button type="button" class="button toggle-password" data-target="gemini_key_<?php echo $i; ?>">
                                        <span class="dashicons dashicons-visibility"></span>
                                    </button>
                                    <button type="button" class="button test-api-key" data-key-type="gemini" data-key-index="<?php echo $i; ?>">
                                        <span class="dashicons dashicons-yes-alt"></span>
                                        <?php _e('Test', 'ai-woo-product-generator'); ?>
                                    </button>
                                    <span class="key-status" id="gemini_status_<?php echo $i; ?>"></span>
                                </div>
                            </td>
                        </tr>
                        <?php endfor; ?>
                    </table>
                    
                    <p class="submit">
                        <button type="submit" class="button button-primary">
                            <span class="dashicons dashicons-saved"></span>
                            <?php _e('Save Gemini Keys', 'ai-woo-product-generator'); ?>
                        </button>
                    </p>
                </form>
            </div>
            
            <!-- Freepik API Keys -->
            <div class="aiwpg-card">
                <h2>
                    <span class="dashicons dashicons-format-image"></span>
                    <?php _e('Freepik API Keys', 'ai-woo-product-generator'); ?>
                </h2>
                <p class="description">
                    <?php _e('Configure up to 5 Freepik API keys for image generation. The plugin will automatically use failover if one key reaches its quota.', 'ai-woo-product-generator'); ?>
                    <br>
                    <a href="https://www.freepik.com/api/" target="_blank">
                        <?php _e('Get your API keys here', 'ai-woo-product-generator'); ?> →
                    </a>
                </p>
                
                <form id="freepik-keys-form" class="aiwpg-form api-keys-form">
                    <table class="form-table">
                        <?php for ($i = 1; $i <= 5; $i++): 
                            $key_value = isset($api_keys['freepik_' . $i]) ? $api_keys['freepik_' . $i] : '';
                        ?>
                        <tr>
                            <th scope="row">
                                <label for="freepik_key_<?php echo $i; ?>">
                                    <?php printf(__('API Key %d', 'ai-woo-product-generator'), $i); ?>
                                </label>
                            </th>
                            <td>
                                <div class="api-key-input-group">
                                    <input 
                                        type="password" 
                                        id="freepik_key_<?php echo $i; ?>" 
                                        name="freepik_key_<?php echo $i; ?>" 
                                        value="<?php echo esc_attr($key_value); ?>" 
                                        class="regular-text api-key-input"
                                        placeholder="FPSX..."
                                        autocomplete="off"
                                    >
                                    <button type="button" class="button toggle-password" data-target="freepik_key_<?php echo $i; ?>">
                                        <span class="dashicons dashicons-visibility"></span>
                                    </button>
                                    <button type="button" class="button test-api-key" data-key-type="freepik" data-key-index="<?php echo $i; ?>">
                                        <span class="dashicons dashicons-yes-alt"></span>
                                        <?php _e('Test', 'ai-woo-product-generator'); ?>
                                    </button>
                                    <span class="key-status" id="freepik_status_<?php echo $i; ?>"></span>
                                </div>
                            </td>
                        </tr>
                        <?php endfor; ?>
                    </table>
                    
                    <p class="submit">
                        <button type="submit" class="button button-primary">
                            <span class="dashicons dashicons-saved"></span>
                            <?php _e('Save Freepik Keys', 'ai-woo-product-generator'); ?>
                        </button>
                    </p>
                </form>
            </div>
            
        </div>
        <!-- End API Keys Tab -->
        
        <!-- Danger Zone Tab -->
        <div class="tab-content" id="danger-zone-tab" style="display: none;">
        <!-- Danger Zone -->
        <div class="aiwpg-card aiwpg-danger-zone">
            <h2><?php _e('Danger Zone', 'ai-woo-product-generator'); ?></h2>
            
            <div class="danger-action">
                <div>
                    <h3><?php _e('Delete AI-Generated Products', 'ai-woo-product-generator'); ?></h3>
                    <p><?php _e('Delete all products that were generated by this plugin. This action cannot be undone.', 'ai-woo-product-generator'); ?></p>
                </div>
                <button type="button" id="delete-ai-products" class="button button-secondary">
                    <span class="dashicons dashicons-trash"></span>
                    <?php _e('Delete AI Products', 'ai-woo-product-generator'); ?>
                </button>
            </div>
            
            <hr>
            
            <div class="danger-action">
                <div>
                    <h3><?php _e('Delete ALL WooCommerce Products', 'ai-woo-product-generator'); ?></h3>
                    <p><?php _e('Delete ALL products in your WooCommerce store. This includes products not created by this plugin. This action cannot be undone!', 'ai-woo-product-generator'); ?></p>
                </div>
                <button type="button" id="delete-all-products" class="button button-danger">
                    <span class="dashicons dashicons-warning"></span>
                    <?php _e('Delete ALL Products', 'ai-woo-product-generator'); ?>
                </button>
            </div>
        </div>
        </div>
        <!-- End Danger Zone Tab -->
        
    </div>
</div>
