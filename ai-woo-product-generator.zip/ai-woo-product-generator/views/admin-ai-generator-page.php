<?php
/**
 * AI Generator Admin Page
 * Three modes: Single product, Multiple textarea, Multiple Excel
 */

if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="wrap aiwpg-wrap">
    <h1><?php _e('AI Product Generator', 'ai-woo-product-generator'); ?></h1>
    
    <div class="aiwpg-tabs">
        <nav class="nav-tab-wrapper">
            <a href="#tab-single" class="nav-tab nav-tab-active" data-tab="single">
                <?php _e('Single Product', 'ai-woo-product-generator'); ?>
            </a>
            <a href="#tab-multiple" class="nav-tab" data-tab="multiple">
                <?php _e('Multiple Products (Textarea)', 'ai-woo-product-generator'); ?>
            </a>
            <a href="#tab-excel" class="nav-tab" data-tab="excel">
                <?php _e('Multiple Products (Excel)', 'ai-woo-product-generator'); ?>
            </a>
        </nav>
        
        
        <!-- Tab: Single Product -->
        <div id="tab-single" class="aiwpg-tab-content active">
            <div class="aiwpg-card">
                <h2><?php _e('Generate Single Product', 'ai-woo-product-generator'); ?></h2>
                <p class="description">
                    <?php _e('Enter a description of the product you want to create. AI will generate title, descriptions, categories, tags, and SKU.', 'ai-woo-product-generator'); ?>
                </p>
                
                <form id="single-product-form" class="aiwpg-form">
                    <div class="form-group">
                        <label><?php _e('Product Type', 'ai-woo-product-generator'); ?></label>
                        <div class="product-type-toggle">
                            <button type="button" class="type-toggle-btn active" data-type="automatic">
                                <span class="dashicons dashicons-admin-generic"></span>
                                <span class="btn-text"><?php _e('Automatic', 'ai-woo-product-generator'); ?></span>
                            </button>
                            <button type="button" class="type-toggle-btn" data-type="simple">
                                <span class="dashicons dashicons-products"></span>
                                <span class="btn-text"><?php _e('Simple', 'ai-woo-product-generator'); ?></span>
                            </button>
                            <button type="button" class="type-toggle-btn" data-type="variable">
                                <span class="dashicons dashicons-networking"></span>
                                <span class="btn-text"><?php _e('Variable', 'ai-woo-product-generator'); ?></span>
                            </button>
                        </div>
                        <p class="description product-type-description">
                            <span data-type="automatic" style="display:inline;"><?php _e('AI will automatically decide the product type based on the description', 'ai-woo-product-generator'); ?></span>
                            <span data-type="simple" style="display:none;"><?php _e('Create a simple product without variations', 'ai-woo-product-generator'); ?></span>
                            <span data-type="variable" style="display:none;"><?php _e('Create a variable product with attributes and variations', 'ai-woo-product-generator'); ?></span>
                        </p>
                    </div>
                    
                    <div class="form-group">
                        <label for="single-prompt"><?php _e('Product Description', 'ai-woo-product-generator'); ?></label>
                        <textarea 
                            id="single-prompt" 
                            name="prompt" 
                            rows="6" 
                            class="large-text" 
                            placeholder="<?php _e('e.g., A premium wireless Bluetooth headphone with noise cancellation, 40-hour battery life, and premium sound quality...', 'ai-woo-product-generator'); ?>"
                            required
                        ></textarea>
                        <div class="form-button-group">
                            <button type="button" id="single-example" class="button button-secondary">
                                <span class="dashicons dashicons-lightbulb"></span>
                                <?php _e('Load Example', 'ai-woo-product-generator'); ?>
                            </button>
                            <button type="submit" class="button button-primary button-large">
                                <span class="dashicons dashicons-download"></span>
                                <?php _e('Generate Product', 'ai-woo-product-generator'); ?>
                            </button>
                            <button type="button" id="improve-single-prompt" class="button button-secondary">
                                <span class="dashicons dashicons-admin-tools"></span>
                                <?php _e('Improve Description', 'ai-woo-product-generator'); ?>
                            </button>
                            <button type="button" id="insert-single-template" class="button button-secondary">
                                <span class="dashicons dashicons-media-document"></span>
                                <?php _e('Insert Template', 'ai-woo-product-generator'); ?>
                            </button>
                            <button type="button" id="score-single-quality" class="button button-secondary">
                                <span class="dashicons dashicons-chart-bar"></span>
                                <?php _e('Score Quality', 'ai-woo-product-generator'); ?>
                            </button>
                            <button type="button" class="button button-secondary mic-button" data-target="single-prompt" title="<?php _e('Voice Input', 'ai-woo-product-generator'); ?>">
                                <span class="dashicons dashicons-microphone"></span>
                            </button>
                        </div>
                        <div id="single-quality-score" class="quality-score-container" style="display:none;">
                            <div class="quality-score-header">
                                <span class="quality-label"><?php _e('Prompt Quality Score:', 'ai-woo-product-generator'); ?></span>
                                <span class="quality-percentage">0%</span>
                            </div>
                            <div class="quality-progress-bar">
                                <div class="quality-progress-fill" style="width: 0%"></div>
                            </div>
                            <p class="quality-feedback"></p>
                        </div>
                    </div>
                </form>
                
                <!-- Preview Area -->
                <div id="single-preview" class="aiwpg-preview" style="display: none;">
                    <h3><?php _e('Product Preview', 'ai-woo-product-generator'); ?></h3>
                    <div id="single-preview-content" class="preview-content"></div>
                    <div class="form-actions">
                        <button type="button" id="save-single-product" class="button button-primary button-large">
                            <span class="dashicons dashicons-yes"></span>
                            <?php _e('Save Product', 'ai-woo-product-generator'); ?>
                        </button>
                        <button type="button" id="cancel-single" class="button button-secondary">
                            <?php _e('Cancel', 'ai-woo-product-generator'); ?>
                        </button>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Tab: Multiple Products (Textarea) -->
        <div id="tab-multiple" class="aiwpg-tab-content">
            <div class="aiwpg-card">
                <h2><?php _e('Generate Multiple Products', 'ai-woo-product-generator'); ?></h2>
                <p class="description">
                    <?php _e('Enter one product per line. You can optionally add quantity using pipe separator (|).', 'ai-woo-product-generator'); ?><br>
                    <strong><?php _e('Format:', 'ai-woo-product-generator'); ?></strong> 
                    <?php _e('Product description | Quantity (optional)', 'ai-woo-product-generator'); ?>
                </p>
                
                <div class="aiwpg-example">
                    <strong><?php _e('Example:', 'ai-woo-product-generator'); ?></strong><br>
                    <code>Wireless mouse with ergonomic design | 25</code><br>
                    <code>USB-C charging cable 2 meters | 50</code><br>
                    <code>Gaming keyboard with RGB lighting</code>
                </div>
                

                
                <form id="multiple-products-form" class="aiwpg-form">
                    <div class="form-group">
                        <label><?php _e('Product Type', 'ai-woo-product-generator'); ?></label>
                        <div class="product-type-toggle">
                            <button type="button" class="type-toggle-btn active" data-type="automatic">
                                <span class="dashicons dashicons-admin-generic"></span>
                                <span class="btn-text"><?php _e('Automatic', 'ai-woo-product-generator'); ?></span>
                            </button>
                            <button type="button" class="type-toggle-btn" data-type="simple">
                                <span class="dashicons dashicons-products"></span>
                                <span class="btn-text"><?php _e('Simple', 'ai-woo-product-generator'); ?></span>
                            </button>
                            <button type="button" class="type-toggle-btn" data-type="variable">
                                <span class="dashicons dashicons-networking"></span>
                                <span class="btn-text"><?php _e('Variable', 'ai-woo-product-generator'); ?></span>
                            </button>
                        </div>
                        <p class="description product-type-description">
                            <span data-type="automatic" style="display:inline;"><?php _e('AI will automatically decide the product type based on the description', 'ai-woo-product-generator'); ?></span>
                            <span data-type="simple" style="display:none;"><?php _e('Create simple products without variations', 'ai-woo-product-generator'); ?></span>
                            <span data-type="variable" style="display:none;"><?php _e('Create variable products with attributes and variations', 'ai-woo-product-generator'); ?></span>
                        </p>
                    </div>
                    
                    <div class="form-group">
                        <label for="multiple-prompts"><?php _e('Product Descriptions (one per line)', 'ai-woo-product-generator'); ?></label>
                        <textarea 
                            id="multiple-prompts" 
                            name="prompts" 
                            rows="10" 
                            class="large-text" 
                            placeholder="<?php _e('Wireless Bluetooth speaker | 30' . "\n" . 'Smartphone protective case | 100' . "\n" . 'Screen protector tempered glass', 'ai-woo-product-generator'); ?>"
                            required
                        ></textarea>
                        <div class="form-button-group">
                            <button type="button" id="multiple-example" class="button button-secondary">
                                <span class="dashicons dashicons-lightbulb"></span>
                                <?php _e('Load Example', 'ai-woo-product-generator'); ?>
                            </button>
                            <button type="submit" class="button button-primary button-large">
                                <span class="dashicons dashicons-download"></span>
                                <?php _e('Generate Products', 'ai-woo-product-generator'); ?>
                            </button>
                            <button type="button" id="improve-multiple-prompts" class="button button-secondary">
                                <span class="dashicons dashicons-admin-tools"></span>
                                <?php _e('Improve Descriptions', 'ai-woo-product-generator'); ?>
                            </button>
                            <button type="button" id="insert-multiple-template" class="button button-secondary">
                                <span class="dashicons dashicons-media-document"></span>
                                <?php _e('Insert Template', 'ai-woo-product-generator'); ?>
                            </button>
                            <button type="button" id="score-multiple-quality" class="button button-secondary">
                                <span class="dashicons dashicons-chart-bar"></span>
                                <?php _e('Score Quality', 'ai-woo-product-generator'); ?>
                            </button>
                            <button type="button" class="button button-secondary mic-button" data-target="multiple-prompts" title="<?php _e('Voice Input', 'ai-woo-product-generator'); ?>">
                                <span class="dashicons dashicons-microphone"></span>
                            </button>
                        </div>
                        <div id="multiple-quality-score" class="quality-score-container" style="display:none;">
                            <div class="quality-score-header">
                                <span class="quality-label"><?php _e('Prompt Quality Score:', 'ai-woo-product-generator'); ?></span>
                                <span class="quality-percentage">0%</span>
                            </div>
                            <div class="quality-progress-bar">
                                <div class="quality-progress-fill" style="width: 0%"></div>
                            </div>
                            <p class="quality-feedback"></p>
                        </div>
                    </div>
                </form>
                
                
                <!-- Preview Table -->
                <div id="multiple-preview" class="aiwpg-preview" style="display: none;">
                    <h3><?php _e('Products Preview', 'ai-woo-product-generator'); ?></h3>
                    <div class="table-responsive">
                        <table id="multiple-preview-table" class="wp-list-table widefat fixed striped">
                            <thead>
                                <tr>
                                    <th class="check-column">
                                        <input type="checkbox" id="select-all-multiple" checked>
                                    </th>
                                    <th><?php _e('Title', 'ai-woo-product-generator'); ?></th>
                                    <th><?php _e('Short Description', 'ai-woo-product-generator'); ?></th>
                                    <th><?php _e('SKU', 'ai-woo-product-generator'); ?></th>
                                    <th><?php _e('Price', 'ai-woo-product-generator'); ?></th>
                                    <th><?php _e('Quantity', 'ai-woo-product-generator'); ?></th>
                                    <th><?php _e('Categories', 'ai-woo-product-generator'); ?></th>
                                </tr>
                            </thead>
                            <tbody id="multiple-preview-body"></tbody>
                        </table>
                    </div>
                    <div class="form-actions">
                        <button type="button" id="save-multiple-products" class="button button-primary button-large">
                            <span class="dashicons dashicons-yes"></span>
                            <?php _e('Save Selected Products', 'ai-woo-product-generator'); ?>
                        </button>
                        <button type="button" id="cancel-multiple" class="button button-secondary">
                            <?php _e('Cancel', 'ai-woo-product-generator'); ?>
                        </button>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Tab: Multiple Products (Excel) -->
        <div id="tab-excel" class="aiwpg-tab-content">
            <div class="aiwpg-card">
                <h2><?php _e('Generate Products from Excel', 'ai-woo-product-generator'); ?></h2>
                <p class="description">
                    <?php _e('Upload an Excel file with product data. AI will automatically classify products, assign kitchens, categories, and detect add-ons. Download the template below to see the required format.', 'ai-woo-product-generator'); ?>
                </p>
                
                <div class="aiwpg-template-download">
                    <a href="#" id="download-template" class="button button-secondary">
                        <span class="dashicons dashicons-media-spreadsheet"></span>
                        <?php _e('Download Excel Template', 'ai-woo-product-generator'); ?>
                    </a>
                </div>
                
                <form id="excel-products-form" class="aiwpg-form">
                    <div class="form-group">
                        <label for="excel-file"><?php _e('Upload Excel File', 'ai-woo-product-generator'); ?></label>
                        <input 
                            type="file" 
                            id="excel-file" 
                            name="excel_file" 
                            accept=".xlsx,.xls,.csv" 
                            class="aiwpg-file-input"
                            required
                        >
                        <p class="description">
                            <?php _e('Accepted formats: .xlsx, .xls, .csv', 'ai-woo-product-generator'); ?>
                        </p>
                    </div>
                    
                    <div class="form-group">
                        <label for="excel-import-mode"><?php _e('Import Mode', 'ai-woo-product-generator'); ?></label>
                        <select id="excel-import-mode" name="import_mode" class="regular-text">
                            <option value="dry-run"><?php _e('Dry-run (Preview only)', 'ai-woo-product-generator'); ?></option>
                            <option value="create-only"><?php _e('Create only new products', 'ai-woo-product-generator'); ?></option>
                            <option value="create-update"><?php _e('Create & update existing products', 'ai-woo-product-generator'); ?></option>
                        </select>
                        <p class="description">
                            <?php _e('Dry-run mode shows preview without creating products. Use it to review AI classifications before importing.', 'ai-woo-product-generator'); ?>
                        </p>
                    </div>
                    
                    <div class="form-group">
                        <label>
                            <input type="checkbox" id="excel-use-ai" name="use_ai" checked>
                            <?php _e('Use AI to auto-assign type, category, kitchen, and add-on groups', 'ai-woo-product-generator'); ?>
                        </label>
                        <p class="description">
                            <?php _e('When enabled, AI will automatically classify products (Food/Beverage), assign kitchen stations, categories, tags, and detect add-ons.', 'ai-woo-product-generator'); ?>
                        </p>
                    </div>
                    
                    <div class="form-group" id="excel-ai-module-group" style="display: none;">
                        <label for="excel-ai-module"><?php _e('AI Module', 'ai-woo-product-generator'); ?></label>
                        <select id="excel-ai-module" name="ai_module" class="regular-text">
                            <option value=""><?php _e('Auto (Let AI decide)', 'ai-woo-product-generator'); ?></option>
                            <option value="kitchen">👨‍🍳 <?php _e('Kitchen', 'ai-woo-product-generator'); ?></option>
                            <option value="food">🍕 <?php _e('Food', 'ai-woo-product-generator'); ?></option>
                            <option value="beverages">🥤 <?php _e('Beverages', 'ai-woo-product-generator'); ?></option>
                            <option value="mixed">🍽 <?php _e('Mixed Only', 'ai-woo-product-generator'); ?></option>
                        </select>
                        <p class="description">
                            <?php _e('Select the AI module to use for classification. This will override the module specified in Excel file.', 'ai-woo-product-generator'); ?>
                        </p>
                    </div>
                    
                    <div class="form-group">
                        <label>
                            <input type="checkbox" id="excel-treat-ambiguous-as-draft" name="treat_ambiguous_as_draft">
                            <?php _e('Treat ambiguous rows as draft products', 'ai-woo-product-generator'); ?>
                        </label>
                        <p class="description">
                            <?php _e('Products that AI cannot clearly classify will be saved as drafts for manual review.', 'ai-woo-product-generator'); ?>
                        </p>
                    </div>
                    
                    <div class="form-actions">
                        <button type="submit" class="button button-primary button-large">
                            <span class="dashicons dashicons-upload"></span>
                            <span class="button-text"><?php _e('Upload and Process', 'ai-woo-product-generator'); ?></span>
                        </button>
                    </div>
                </form>
                
                <!-- Preview Table -->
                <div id="excel-preview" class="aiwpg-preview" style="display: none;">
                    <h3><?php _e('Products Preview from Excel', 'ai-woo-product-generator'); ?></h3>
                    
                    <!-- Summary Statistics -->
                    <div id="excel-summary" class="aiwpg-summary" style="margin-bottom: 20px; padding: 15px; background: #f5f5f5; border-radius: 4px;">
                        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 15px;">
                            <div>
                                <strong><?php _e('Total Rows:', 'ai-woo-product-generator'); ?></strong>
                                <span id="excel-total-rows">0</span>
                            </div>
                            <div>
                                <strong><?php _e('Successfully Processed:', 'ai-woo-product-generator'); ?></strong>
                                <span id="excel-success-count" style="color: #46b450;">0</span>
                            </div>
                            <div>
                                <strong><?php _e('Errors:', 'ai-woo-product-generator'); ?></strong>
                                <span id="excel-error-count" style="color: #dc3232;">0</span>
                            </div>
                            <div>
                                <strong><?php _e('AI Calls:', 'ai-woo-product-generator'); ?></strong>
                                <span id="excel-ai-calls">0</span>
                            </div>
                        </div>
                    </div>
                    
                    <div class="table-responsive">
                        <table id="excel-preview-table" class="wp-list-table widefat fixed striped">
                            <thead>
                                <tr>
                                    <th class="check-column">
                                        <input type="checkbox" id="select-all-excel" checked>
                                    </th>
                                    <th><?php _e('Original Name', 'ai-woo-product-generator'); ?></th>
                                    <th><?php _e('AI Type', 'ai-woo-product-generator'); ?></th>
                                    <th><?php _e('AI Category', 'ai-woo-product-generator'); ?></th>
                                    <th><?php _e('Kitchen', 'ai-woo-product-generator'); ?></th>
                                    <th><?php _e('Price', 'ai-woo-product-generator'); ?></th>
                                    <th><?php _e('Is Add-on', 'ai-woo-product-generator'); ?></th>
                                    <th><?php _e('Add-on Group', 'ai-woo-product-generator'); ?></th>
                                    <th><?php _e('Additions', 'ai-woo-product-generator'); ?></th>
                                    <th><?php _e('AI Module', 'ai-woo-product-generator'); ?></th>
                                    <th><?php _e('Status', 'ai-woo-product-generator'); ?></th>
                                </tr>
                            </thead>
                            <tbody id="excel-preview-body"></tbody>
                        </table>
                    </div>
                    <div class="form-actions">
                        <button type="button" id="confirm-excel-import" class="button button-primary button-large">
                            <span class="dashicons dashicons-yes"></span>
                            <span class="button-text"><?php _e('Confirm Import', 'ai-woo-product-generator'); ?></span>
                        </button>
                        <button type="button" id="cancel-excel" class="button button-secondary">
                            <?php _e('Cancel', 'ai-woo-product-generator'); ?>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Global Context Menu -->
<div id="global-context-menu" class="context-menu" style="display: none;">
    <div class="context-menu-item" data-action="generate-products">
        <span class="dashicons dashicons-admin-generic"></span>
        <span><?php _e('Generate Products', 'ai-woo-product-generator'); ?></span>
    </div>
    <div class="context-menu-item" data-action="products-list">
        <span class="dashicons dashicons-products"></span>
        <span><?php _e('Products List', 'ai-woo-product-generator'); ?></span>
    </div>
    <div class="context-menu-item" data-action="settings">
        <span class="dashicons dashicons-admin-settings"></span>
        <span><?php _e('Settings', 'ai-woo-product-generator'); ?></span>
    </div>
    <div class="context-menu-divider"></div>
    <div class="context-menu-item" data-action="add-product">
        <span class="dashicons dashicons-plus-alt"></span>
        <span><?php _e('Add Product', 'ai-woo-product-generator'); ?></span>
    </div>
    <div class="context-menu-divider"></div>
    <div class="context-menu-item" data-action="refresh">
        <span class="dashicons dashicons-update"></span>
        <span><?php _e('Refresh Page', 'ai-woo-product-generator'); ?></span>
    </div>
</div>