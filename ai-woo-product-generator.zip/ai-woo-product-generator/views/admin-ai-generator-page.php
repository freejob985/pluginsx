<?php
/**
 * AI Generator Admin Page
 * Three modes: Single product, Multiple textarea, Multiple Excel
 */

if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="wrap aiwpg-wrap">
    <h1><?php _e('AI Product Generator', 'ai-woo-product-generator'); ?></h1>
    
    <div class="aiwpg-tabs">
        <nav class="nav-tab-wrapper">
            <a href="#tab-single" class="nav-tab nav-tab-active" data-tab="single">
                <?php _e('Single Product', 'ai-woo-product-generator'); ?>
            </a>
            <a href="#tab-multiple" class="nav-tab" data-tab="multiple">
                <?php _e('Multiple Products (Textarea)', 'ai-woo-product-generator'); ?>
            </a>
            <a href="#tab-excel" class="nav-tab" data-tab="excel">
                <?php _e('Multiple Products (Excel)', 'ai-woo-product-generator'); ?>
            </a>
        </nav>
        
        
        <!-- Tab: Single Product -->
        <div id="tab-single" class="aiwpg-tab-content active">
            <div class="aiwpg-card">
                <h2><?php _e('Generate Single Product', 'ai-woo-product-generator'); ?></h2>
                <p class="description">
                    <?php _e('Enter a description of the product you want to create. AI will generate title, descriptions, categories, tags, and SKU.', 'ai-woo-product-generator'); ?>
                </p>
                
                <form id="single-product-form" class="aiwpg-form">
                    <div class="form-group">
                        <label><?php _e('Product Type', 'ai-woo-product-generator'); ?></label>
                        <div class="product-type-toggle">
                            <button type="button" class="type-toggle-btn active" data-type="automatic">
                                <span class="dashicons dashicons-admin-generic"></span>
                                <span class="btn-text"><?php _e('Automatic', 'ai-woo-product-generator'); ?></span>
                            </button>
                            <button type="button" class="type-toggle-btn" data-type="simple">
                                <span class="dashicons dashicons-products"></span>
                                <span class="btn-text"><?php _e('Simple', 'ai-woo-product-generator'); ?></span>
                            </button>
                            <button type="button" class="type-toggle-btn" data-type="variable">
                                <span class="dashicons dashicons-networking"></span>
                                <span class="btn-text"><?php _e('Variable', 'ai-woo-product-generator'); ?></span>
                            </button>
                        </div>
                        <p class="description product-type-description">
                            <span data-type="automatic" style="display:inline;"><?php _e('AI will automatically decide the product type based on the description', 'ai-woo-product-generator'); ?></span>
                            <span data-type="simple" style="display:none;"><?php _e('Create a simple product without variations', 'ai-woo-product-generator'); ?></span>
                            <span data-type="variable" style="display:none;"><?php _e('Create a variable product with attributes and variations', 'ai-woo-product-generator'); ?></span>
                        </p>
                    </div>
                    
                    <div class="form-group">
                        <label for="single-prompt"><?php _e('Product Description', 'ai-woo-product-generator'); ?></label>
                        <textarea 
                            id="single-prompt" 
                            name="prompt" 
                            rows="6" 
                            class="large-text" 
                            placeholder="<?php _e('e.g., A premium wireless Bluetooth headphone with noise cancellation, 40-hour battery life, and premium sound quality...', 'ai-woo-product-generator'); ?>"
                            required
                        ></textarea>
                        <div class="form-button-group">
                            <button type="button" id="single-example" class="button button-secondary">
                                <span class="dashicons dashicons-lightbulb"></span>
                                <?php _e('Load Example', 'ai-woo-product-generator'); ?>
                            </button>
                            <button type="submit" class="button button-primary button-large">
                                <span class="dashicons dashicons-download"></span>
                                <?php _e('Generate Product', 'ai-woo-product-generator'); ?>
                            </button>
                            <button type="button" id="improve-single-prompt" class="button button-secondary">
                                <span class="dashicons dashicons-admin-tools"></span>
                                <?php _e('Improve Description', 'ai-woo-product-generator'); ?>
                            </button>
                            <button type="button" class="button button-secondary mic-button" data-target="single-prompt" title="<?php _e('Voice Input', 'ai-woo-product-generator'); ?>">
                                <span class="dashicons dashicons-microphone"></span>
                            </button>
                        </div>
                    </div>
                </form>
                
                <!-- Preview Area -->
                <div id="single-preview" class="aiwpg-preview" style="display: none;">
                    <h3><?php _e('Product Preview', 'ai-woo-product-generator'); ?></h3>
                    <div id="single-preview-content" class="preview-content"></div>
                    <div class="form-actions">
                        <button type="button" id="save-single-product" class="button button-primary button-large">
                            <span class="dashicons dashicons-yes"></span>
                            <?php _e('Save Product', 'ai-woo-product-generator'); ?>
                        </button>
                        <button type="button" id="cancel-single" class="button button-secondary">
                            <?php _e('Cancel', 'ai-woo-product-generator'); ?>
                        </button>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Tab: Multiple Products (Textarea) -->
        <div id="tab-multiple" class="aiwpg-tab-content">
            <div class="aiwpg-card">
                <h2><?php _e('Generate Multiple Products', 'ai-woo-product-generator'); ?></h2>
                <p class="description">
                    <?php _e('Enter one product per line. You can optionally add quantity using pipe separator (|).', 'ai-woo-product-generator'); ?><br>
                    <strong><?php _e('Format:', 'ai-woo-product-generator'); ?></strong> 
                    <?php _e('Product description | Quantity (optional)', 'ai-woo-product-generator'); ?>
                </p>
                
                <div class="aiwpg-example">
                    <strong><?php _e('Example:', 'ai-woo-product-generator'); ?></strong><br>
                    <code>Wireless mouse with ergonomic design | 25</code><br>
                    <code>USB-C charging cable 2 meters | 50</code><br>
                    <code>Gaming keyboard with RGB lighting</code>
                </div>
                

                
                <form id="multiple-products-form" class="aiwpg-form">
                    <div class="form-group">
                        <label><?php _e('Product Type', 'ai-woo-product-generator'); ?></label>
                        <div class="product-type-toggle">
                            <button type="button" class="type-toggle-btn active" data-type="automatic">
                                <span class="dashicons dashicons-admin-generic"></span>
                                <span class="btn-text"><?php _e('Automatic', 'ai-woo-product-generator'); ?></span>
                            </button>
                            <button type="button" class="type-toggle-btn" data-type="simple">
                                <span class="dashicons dashicons-products"></span>
                                <span class="btn-text"><?php _e('Simple', 'ai-woo-product-generator'); ?></span>
                            </button>
                            <button type="button" class="type-toggle-btn" data-type="variable">
                                <span class="dashicons dashicons-networking"></span>
                                <span class="btn-text"><?php _e('Variable', 'ai-woo-product-generator'); ?></span>
                            </button>
                        </div>
                        <p class="description product-type-description">
                            <span data-type="automatic" style="display:inline;"><?php _e('AI will automatically decide the product type based on the description', 'ai-woo-product-generator'); ?></span>
                            <span data-type="simple" style="display:none;"><?php _e('Create simple products without variations', 'ai-woo-product-generator'); ?></span>
                            <span data-type="variable" style="display:none;"><?php _e('Create variable products with attributes and variations', 'ai-woo-product-generator'); ?></span>
                        </p>
                    </div>
                    
                    <div class="form-group">
                        <label for="multiple-prompts"><?php _e('Product Descriptions (one per line)', 'ai-woo-product-generator'); ?></label>
                        <textarea 
                            id="multiple-prompts" 
                            name="prompts" 
                            rows="10" 
                            class="large-text" 
                            placeholder="<?php _e('Wireless Bluetooth speaker | 30' . "\n" . 'Smartphone protective case | 100' . "\n" . 'Screen protector tempered glass', 'ai-woo-product-generator'); ?>"
                            required
                        ></textarea>
                        <div class="form-button-group">
                            <button type="button" id="multiple-example" class="button button-secondary">
                                <span class="dashicons dashicons-lightbulb"></span>
                                <?php _e('Load Example', 'ai-woo-product-generator'); ?>
                            </button>
                            <button type="submit" class="button button-primary button-large">
                                <span class="dashicons dashicons-download"></span>
                                <?php _e('Generate Products', 'ai-woo-product-generator'); ?>
                            </button>
                            <button type="button" id="improve-multiple-prompts" class="button button-secondary">
                                <span class="dashicons dashicons-admin-tools"></span>
                                <?php _e('Improve Descriptions', 'ai-woo-product-generator'); ?>
                            </button>
                            <button type="button" class="button button-secondary mic-button" data-target="multiple-prompts" title="<?php _e('Voice Input', 'ai-woo-product-generator'); ?>">
                                <span class="dashicons dashicons-microphone"></span>
                            </button>
                        </div>
                    </div>
                </form>
                
                <!-- Preview Table -->
                <div id="multiple-preview" class="aiwpg-preview" style="display: none;">
                    <h3><?php _e('Products Preview', 'ai-woo-product-generator'); ?></h3>
                    <div class="table-responsive">
                        <table id="multiple-preview-table" class="wp-list-table widefat fixed striped">
                            <thead>
                                <tr>
                                    <th class="check-column">
                                        <input type="checkbox" id="select-all-multiple" checked>
                                    </th>
                                    <th><?php _e('Title', 'ai-woo-product-generator'); ?></th>
                                    <th><?php _e('Short Description', 'ai-woo-product-generator'); ?></th>
                                    <th><?php _e('SKU', 'ai-woo-product-generator'); ?></th>
                                    <th><?php _e('Price', 'ai-woo-product-generator'); ?></th>
                                    <th><?php _e('Quantity', 'ai-woo-product-generator'); ?></th>
                                    <th><?php _e('Categories', 'ai-woo-product-generator'); ?></th>
                                </tr>
                            </thead>
                            <tbody id="multiple-preview-body"></tbody>
                        </table>
                    </div>
                    <div class="form-actions">
                        <button type="button" id="save-multiple-products" class="button button-primary button-large">
                            <span class="dashicons dashicons-yes"></span>
                            <?php _e('Save Selected Products', 'ai-woo-product-generator'); ?>
                        </button>
                        <button type="button" id="cancel-multiple" class="button button-secondary">
                            <?php _e('Cancel', 'ai-woo-product-generator'); ?>
                        </button>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Tab: Multiple Products (Excel) -->
        <div id="tab-excel" class="aiwpg-tab-content">
            <div class="aiwpg-card">
                <h2><?php _e('Generate Products from Excel', 'ai-woo-product-generator'); ?></h2>
                <p class="description">
                    <?php _e('Upload an Excel file with product descriptions. Download the template below to see the required format.', 'ai-woo-product-generator'); ?>
                </p>
                
                <div class="aiwpg-template-download">
                    <a href="#" id="download-template" class="button button-secondary">
                        <span class="dashicons dashicons-media-spreadsheet"></span>
                        <?php _e('Download Excel Template', 'ai-woo-product-generator'); ?>
                    </a>
                </div>
                
                <form id="excel-products-form" class="aiwpg-form">
                    <div class="form-group">
                        <label for="excel-file"><?php _e('Upload Excel File', 'ai-woo-product-generator'); ?></label>
                        <input 
                            type="file" 
                            id="excel-file" 
                            name="excel_file" 
                            accept=".xlsx,.xls" 
                            class="aiwpg-file-input"
                            required
                        >
                        <p class="description">
                            <?php _e('Accepted formats: .xlsx, .xls', 'ai-woo-product-generator'); ?>
                        </p>
                    </div>
                    
                    <div class="form-actions">
                        <button type="submit" class="button button-primary button-large">
                            <span class="dashicons dashicons-upload"></span>
                            <?php _e('Upload and Generate Products', 'ai-woo-product-generator'); ?>
                        </button>
                    </div>
                </form>
                
                <!-- Preview Table -->
                <div id="excel-preview" class="aiwpg-preview" style="display: none;">
                    <h3><?php _e('Products Preview from Excel', 'ai-woo-product-generator'); ?></h3>
                    <div class="table-responsive">
                        <table id="excel-preview-table" class="wp-list-table widefat fixed striped">
                            <thead>
                                <tr>
                                    <th class="check-column">
                                        <input type="checkbox" id="select-all-excel" checked>
                                    </th>
                                    <th><?php _e('Title', 'ai-woo-product-generator'); ?></th>
                                    <th><?php _e('Short Description', 'ai-woo-product-generator'); ?></th>
                                    <th><?php _e('SKU', 'ai-woo-product-generator'); ?></th>
                                    <th><?php _e('Price', 'ai-woo-product-generator'); ?></th>
                                    <th><?php _e('Quantity', 'ai-woo-product-generator'); ?></th>
                                    <th><?php _e('Categories', 'ai-woo-product-generator'); ?></th>
                                </tr>
                            </thead>
                            <tbody id="excel-preview-body"></tbody>
                        </table>
                    </div>
                    <div class="form-actions">
                        <button type="button" id="save-excel-products" class="button button-primary button-large">
                            <span class="dashicons dashicons-yes"></span>
                            <?php _e('Save Selected Products', 'ai-woo-product-generator'); ?>
                        </button>
                        <button type="button" id="cancel-excel" class="button button-secondary">
                            <?php _e('Cancel', 'ai-woo-product-generator'); ?>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
