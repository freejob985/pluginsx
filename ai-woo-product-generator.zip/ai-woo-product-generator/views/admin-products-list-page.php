<?php
/**
 * Products List Admin Page
 * Display products in card grid with search, autocomplete, and modals
 */

if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="wrap aiwpg-wrap">
    <h1><?php _e('WooCommerce Products', 'ai-woo-product-generator'); ?></h1>
    
    <!-- Statistics Dashboard -->
    <div class="aiwpg-stats-dashboard" id="stats-dashboard">
        <div class="stat-card stat-total">
            <div class="stat-header">
                <div>
                    <div class="stat-label"><?php _e('Total Products', 'ai-woo-product-generator'); ?></div>
                    <div class="stat-value" id="stat-total-value">
                        <span class="spinner is-active" style="float: none; margin: 0;"></span>
                    </div>
                </div>
                <div class="stat-icon">
                    <span class="dashicons dashicons-products"></span>
                </div>
            </div>
        </div>
        
        <div class="stat-card stat-published">
            <div class="stat-header">
                <div>
                    <div class="stat-label"><?php _e('Published', 'ai-woo-product-generator'); ?></div>
                    <div class="stat-value" id="stat-published-value">
                        <span class="spinner is-active" style="float: none; margin: 0;"></span>
                    </div>
                </div>
                <div class="stat-icon">
                    <span class="dashicons dashicons-yes-alt"></span>
                </div>
            </div>
        </div>
        
        <div class="stat-card stat-draft">
            <div class="stat-header">
                <div>
                    <div class="stat-label"><?php _e('Drafts', 'ai-woo-product-generator'); ?></div>
                    <div class="stat-value" id="stat-draft-value">
                        <span class="spinner is-active" style="float: none; margin: 0;"></span>
                    </div>
                </div>
                <div class="stat-icon">
                    <span class="dashicons dashicons-edit"></span>
                </div>
            </div>
        </div>
        
        <div class="stat-card stat-value">
            <div class="stat-header">
                <div>
                    <div class="stat-label"><?php _e('Stock Value', 'ai-woo-product-generator'); ?></div>
                    <div class="stat-value" id="stat-value-value">
                        <span class="spinner is-active" style="float: none; margin: 0;"></span>
                    </div>
                </div>
                <div class="stat-icon">
                    <span class="dashicons dashicons-money-alt"></span>
                </div>
            </div>
        </div>
        
        <div class="stat-card stat-out-of-stock">
            <div class="stat-header">
                <div>
                    <div class="stat-label"><?php _e('Out of Stock', 'ai-woo-product-generator'); ?></div>
                    <div class="stat-value" id="stat-out-of-stock-value">
                        <span class="spinner is-active" style="float: none; margin: 0;"></span>
                    </div>
                </div>
                <div class="stat-icon">
                    <span class="dashicons dashicons-dismiss"></span>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Search Bar -->
    <div class="aiwpg-search-bar">
        <div class="search-wrapper">
            <input 
                type="text" 
                id="product-search" 
                class="aiwpg-search-input" 
                placeholder="<?php _e('Search products...', 'ai-woo-product-generator'); ?>"
                autocomplete="off"
            >
            <span class="dashicons dashicons-search search-icon"></span>
            
            <!-- Autocomplete Results -->
            <div id="autocomplete-results" class="autocomplete-results"></div>
        </div>
        
        <button type="button" id="refresh-products" class="button">
            <span class="dashicons dashicons-update"></span>
            <?php _e('Refresh', 'ai-woo-product-generator'); ?>
        </button>
    </div>
    
    <!-- Products Grid -->
    <div id="products-container" class="aiwpg-products-grid">
        <!-- Products will be loaded here via AJAX -->
        <div class="aiwpg-loading">
            <span class="spinner is-active"></span>
            <p><?php _e('Loading products...', 'ai-woo-product-generator'); ?></p>
        </div>
    </div>
    
    <!-- Pagination -->
    <div id="products-pagination" class="aiwpg-pagination">
        <!-- Pagination will be loaded here -->
    </div>
</div>

<!-- Context Menu for Edit Product Modal -->
<div id="edit-product-context-menu" class="context-menu" style="display: none;">
    <div class="context-menu-item" data-tab="general">
        <span class="dashicons dashicons-admin-generic"></span>
        <span><?php _e('General', 'ai-woo-product-generator'); ?></span>
    </div>
    <div class="context-menu-item" data-tab="inventory">
        <span class="dashicons dashicons-archive"></span>
        <span><?php _e('Inventory', 'ai-woo-product-generator'); ?></span>
    </div>
    <div class="context-menu-item" data-tab="shipping">
        <span class="dashicons dashicons-admin-site"></span>
        <span><?php _e('Shipping', 'ai-woo-product-generator'); ?></span>
    </div>
    <div class="context-menu-item" data-tab="linked">
        <span class="dashicons dashicons-admin-links"></span>
        <span><?php _e('Linked', 'ai-woo-product-generator'); ?></span>
    </div>
    <div class="context-menu-item" data-tab="media">
        <span class="dashicons dashicons-format-image"></span>
        <span><?php _e('Media', 'ai-woo-product-generator'); ?></span>
    </div>
    <div class="context-menu-item" data-tab="variations">
        <span class="dashicons dashicons-screenoptions"></span>
        <span><?php _e('Variations', 'ai-woo-product-generator'); ?></span>
    </div>
    <div class="context-menu-item" data-tab="settings">
        <span class="dashicons dashicons-admin-settings"></span>
        <span><?php _e('Settings', 'ai-woo-product-generator'); ?></span>
    </div>
</div>

<!-- View Product Modal -->
<div id="view-product-modal" class="aiwpg-modal">
    <div class="modal-overlay"></div>
    <div class="modal-content">
        <div class="modal-header">
            <h2 id="view-modal-title"><?php _e('Product Details', 'ai-woo-product-generator'); ?></h2>
            <button type="button" class="modal-close">
                <span class="dashicons dashicons-no"></span>
            </button>
        </div>
        <div class="modal-body" id="view-modal-body">
            <!-- Product details will be loaded here -->
        </div>
        <div class="modal-footer">
            <button type="button" class="button button-secondary close-modal">
                <?php _e('Close', 'ai-woo-product-generator'); ?>
            </button>
        </div>
    </div>
</div>

<!-- Edit Product Modal -->
<div id="edit-product-modal" class="aiwpg-modal">
    <div class="modal-overlay"></div>
    <div class="modal-content modal-content-wide">
        <div class="modal-header">
            <div class="modal-header-left">
                <button type="button" class="button button-secondary nav-product-btn" id="prev-product-btn" title="<?php _e('Previous Product', 'ai-woo-product-generator'); ?>">
                    <span class="dashicons dashicons-arrow-left-alt2"></span>
                </button>
                <h2><?php _e('Edit Product', 'ai-woo-product-generator'); ?></h2>
                <button type="button" class="button button-secondary nav-product-btn" id="next-product-btn" title="<?php _e('Next Product', 'ai-woo-product-generator'); ?>">
                    <span class="dashicons dashicons-arrow-right-alt2"></span>
                </button>
            </div>
            <div class="modal-header-right">
                <button type="button" class="button button-secondary modal-fullscreen-btn" id="toggle-fullscreen-btn" title="<?php _e('Toggle Fullscreen', 'ai-woo-product-generator'); ?>">
                    <span class="dashicons dashicons-fullscreen-alt"></span>
                </button>
                <button type="button" class="modal-close">
                    <span class="dashicons dashicons-no"></span>
                </button>
            </div>
        </div>
        <div class="modal-body">
            <!-- Tab Navigation -->
            <div class="product-tabs-nav">
                <button type="button" class="tab-btn active" data-tab="general">
                    <span class="dashicons dashicons-admin-generic"></span>
                    <span><?php _e('General', 'ai-woo-product-generator'); ?></span>
                </button>
                <button type="button" class="tab-btn" data-tab="inventory">
                    <span class="dashicons dashicons-archive"></span>
                    <span><?php _e('Inventory', 'ai-woo-product-generator'); ?></span>
                </button>
                <button type="button" class="tab-btn" data-tab="shipping">
                    <span class="dashicons dashicons-admin-site"></span>
                    <span><?php _e('Shipping', 'ai-woo-product-generator'); ?></span>
                </button>
                <button type="button" class="tab-btn" data-tab="linked">
                    <span class="dashicons dashicons-admin-links"></span>
                    <span><?php _e('Linked', 'ai-woo-product-generator'); ?></span>
                </button>
                <button type="button" class="tab-btn" data-tab="media">
                    <span class="dashicons dashicons-format-gallery"></span>
                    <span><?php _e('Media', 'ai-woo-product-generator'); ?></span>
                </button>
                <button type="button" class="tab-btn" data-tab="variations">
                    <span class="dashicons dashicons-image-filter"></span>
                    <span><?php _e('Variations', 'ai-woo-product-generator'); ?></span>
                </button>
                <button type="button" class="tab-btn" data-tab="settings">
                    <span class="dashicons dashicons-admin-settings"></span>
                    <span><?php _e('Settings', 'ai-woo-product-generator'); ?></span>
                </button>
                <button type="button" class="tab-btn" data-tab="addons_ai">
                    <span class="dashicons dashicons-plus-alt"></span>
                    <span><?php _e('Add-ons & AI', 'ai-woo-product-generator'); ?></span>
                </button>
            </div>

            <form id="edit-product-form">
                <input type="hidden" id="edit-product-id" name="product_id">
                
                <!-- General Tab -->
                <div class="tab-content active" data-tab="general">
                    <div class="form-group">
                        <label for="edit-title"><?php _e('Product Name', 'ai-woo-product-generator'); ?></label>
                        <div class="input-with-ai">
                            <input type="text" id="edit-title" name="title" class="widefat" required>
                            <button type="button" class="button button-secondary improve-field-btn" data-field="edit-title" title="<?php _e('Improve with AI', 'ai-woo-product-generator'); ?>">
                                <span class="dashicons dashicons-admin-tools"></span>
                            </button>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="edit-long-description"><?php _e('Description', 'ai-woo-product-generator'); ?></label>
                        <div class="input-with-ai">
                            <textarea id="edit-long-description" name="long_description" rows="6" class="widefat"></textarea>
                            <button type="button" class="button button-secondary improve-field-btn" data-field="edit-long-description" title="<?php _e('Improve with AI', 'ai-woo-product-generator'); ?>">
                                <span class="dashicons dashicons-admin-tools"></span>
                            </button>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="edit-short-description"><?php _e('Short Description', 'ai-woo-product-generator'); ?></label>
                        <div class="input-with-ai">
                            <textarea id="edit-short-description" name="short_description" rows="3" class="widefat"></textarea>
                            <button type="button" class="button button-secondary improve-field-btn" data-field="edit-short-description" title="<?php _e('Improve with AI', 'ai-woo-product-generator'); ?>">
                                <span class="dashicons dashicons-admin-tools"></span>
                            </button>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="edit-sku"><?php _e('SKU', 'ai-woo-product-generator'); ?></label>
                        <input type="text" id="edit-sku" name="sku" class="widefat">
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="edit-regular-price"><?php _e('Regular Price', 'ai-woo-product-generator'); ?></label>
                            <input type="number" id="edit-regular-price" name="regular_price" class="widefat" step="0.01" min="0">
                        </div>
                        
                        <div class="form-group">
                            <label for="edit-sale-price"><?php _e('Sale Price', 'ai-woo-product-generator'); ?></label>
                            <input type="number" id="edit-sale-price" name="sale_price" class="widefat" step="0.01" min="0">
                        </div>
                    </div>
                </div>
                
                <!-- Inventory Tab -->
                <div class="tab-content" data-tab="inventory">
                    <div class="form-group">
                        <label class="switch-label">
                            <input type="checkbox" id="edit-manage-stock" name="manage_stock" class="switch-input">
                            <span class="switch-slider"></span>
                            <span class="switch-text"><?php _e('Manage Stock', 'ai-woo-product-generator'); ?></span>
                        </label>
                        <p class="description"><?php _e('Enable stock management at product level', 'ai-woo-product-generator'); ?></p>
                    </div>
                    
                    <div class="form-group stock-quantity-group">
                        <label for="edit-stock-quantity"><?php _e('Stock Quantity', 'ai-woo-product-generator'); ?></label>
                        <input type="number" id="edit-stock-quantity" name="stock_quantity" class="widefat" min="0">
                    </div>
                    
                    <div class="form-group">
                        <label for="edit-stock-status"><?php _e('Stock Status', 'ai-woo-product-generator'); ?></label>
                        <select id="edit-stock-status" name="stock_status" class="widefat">
                            <option value="instock"><?php _e('In Stock', 'ai-woo-product-generator'); ?></option>
                            <option value="outofstock"><?php _e('Out of Stock', 'ai-woo-product-generator'); ?></option>
                            <option value="onbackorder"><?php _e('On Backorder', 'ai-woo-product-generator'); ?></option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="edit-low-stock-threshold"><?php _e('Low Stock Threshold', 'ai-woo-product-generator'); ?></label>
                        <input type="number" id="edit-low-stock-threshold" name="low_stock_threshold" class="widefat" min="0">
                        <p class="description"><?php _e('Set a low stock threshold to receive notifications', 'ai-woo-product-generator'); ?></p>
                    </div>
                    
                    <div class="form-group">
                        <label class="switch-label">
                            <input type="checkbox" id="edit-sold-individually" name="sold_individually" class="switch-input">
                            <span class="switch-slider"></span>
                            <span class="switch-text"><?php _e('Sold Individually', 'ai-woo-product-generator'); ?></span>
                        </label>
                        <p class="description"><?php _e('Enable this to only allow one of this item to be bought in a single order', 'ai-woo-product-generator'); ?></p>
                    </div>
                </div>
                
                <!-- Shipping Tab -->
                <div class="tab-content" data-tab="shipping">
                    <div class="form-group">
                        <label for="edit-weight"><?php _e('Weight (kg)', 'ai-woo-product-generator'); ?></label>
                        <input type="number" id="edit-weight" name="weight" class="widefat" step="0.01" min="0">
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="edit-length"><?php _e('Length (cm)', 'ai-woo-product-generator'); ?></label>
                            <input type="number" id="edit-length" name="length" class="widefat" step="0.01" min="0">
                        </div>
                        
                        <div class="form-group">
                            <label for="edit-width"><?php _e('Width (cm)', 'ai-woo-product-generator'); ?></label>
                            <input type="number" id="edit-width" name="width" class="widefat" step="0.01" min="0">
                        </div>
                        
                        <div class="form-group">
                            <label for="edit-height"><?php _e('Height (cm)', 'ai-woo-product-generator'); ?></label>
                            <input type="number" id="edit-height" name="height" class="widefat" step="0.01" min="0">
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="edit-shipping-class"><?php _e('Shipping Class', 'ai-woo-product-generator'); ?></label>
                        <select id="edit-shipping-class" name="shipping_class" class="widefat">
                            <option value=""><?php _e('No shipping class', 'ai-woo-product-generator'); ?></option>
                            <!-- Shipping classes will be loaded via AJAX -->
                        </select>
                    </div>
                </div>
                
                <!-- Linked Products Tab -->
                <div class="tab-content" data-tab="linked">
                    <div class="linked-products-section">
                        <!-- Info Banner -->
                        <div class="linked-products-info">
                            <p class="description">
                                <span class="dashicons dashicons-info"></span>
                                <?php _e('Link related products to increase sales and improve customer experience.', 'ai-woo-product-generator'); ?>
                            </p>
                        </div>
                        
                        <!-- Search Box -->
                        <div class="linked-products-search-wrapper">
                            <label>
                                <span class="dashicons dashicons-search"></span>
                                <?php _e('Search Products', 'ai-woo-product-generator'); ?>
                            </label>
                            
                            <!-- Toggle Buttons -->
                            <div class="linked-products-toggle-buttons">
                                <button type="button" class="toggle-btn active" data-target="upsell">
                                    <span class="dashicons dashicons-arrow-up-alt"></span>
                                    <?php _e('Upsells', 'ai-woo-product-generator'); ?>
                                </button>
                                <button type="button" class="toggle-btn" data-target="cross-sell">
                                    <span class="dashicons dashicons-randomize"></span>
                                    <?php _e('Cross-sells', 'ai-woo-product-generator'); ?>
                                </button>
                            </div>
                            
                            <div class="search-box-container">
                                <input 
                                    type="text" 
                                    id="linked-products-search" 
                                    class="widefat linked-products-search-input" 
                                    placeholder="<?php _e('Type to search and press Enter...', 'ai-woo-product-generator'); ?>"
                                    autocomplete="off"
                                >
                                <span class="search-spinner" style="display:none;">
                                    <span class="spinner is-active"></span>
                                </span>
                            </div>
                        </div>
                        
                        <!-- Autocomplete Results (Search Suggestions) -->
                        <div id="linked-products-autocomplete" class="linked-products-autocomplete" style="display:none;">
                            <!-- Results will be populated here -->
                        </div>
                        
                        <!-- Upsells Section -->
                        <div class="form-group linked-products-list-section">
                            <label for="edit-upsell-ids">
                                <span class="dashicons dashicons-arrow-up-alt"></span>
                                <?php _e('Upsells', 'ai-woo-product-generator'); ?>
                                <span class="products-count" id="upsells-count">(0)</span>
                            </label>
                            <div class="linked-products-list" id="upsells-list" data-type="upsell">
                                <div class="empty-state">
                                    <span class="dashicons dashicons-cart"></span>
                                    <p><?php _e('No upsell products added yet. Search and add products above.', 'ai-woo-product-generator'); ?></p>
                                </div>
                            </div>
                            <input type="hidden" id="edit-upsell-ids" name="upsell_ids" value="">
                            <p class="description">
                                <span class="dashicons dashicons-lightbulb"></span>
                                <?php _e('Upsells are products which you recommend instead of the currently viewed product.', 'ai-woo-product-generator'); ?>
                            </p>
                        </div>
                        
                        <!-- Cross-sells Section -->
                        <div class="form-group linked-products-list-section">
                            <label for="edit-cross-sell-ids">
                                <span class="dashicons dashicons-randomize"></span>
                                <?php _e('Cross-sells', 'ai-woo-product-generator'); ?>
                                <span class="products-count" id="cross-sells-count">(0)</span>
                            </label>
                            <div class="linked-products-list" id="cross-sells-list" data-type="cross-sell">
                                <div class="empty-state">
                                    <span class="dashicons dashicons-cart"></span>
                                    <p><?php _e('No cross-sell products added yet. Search and add products above.', 'ai-woo-product-generator'); ?></p>
                                </div>
                            </div>
                            <input type="hidden" id="edit-cross-sell-ids" name="cross_sell_ids" value="">
                            <p class="description">
                                <span class="dashicons dashicons-lightbulb"></span>
                                <?php _e('Cross-sells are products which you promote in the cart based on the current product.', 'ai-woo-product-generator'); ?>
                            </p>
                        </div>
                    </div>
                </div>
                
                <!-- Media Tab -->
                <div class="tab-content" data-tab="media">
                    <div class="form-group">
                        <label><?php _e('Product Image', 'ai-woo-product-generator'); ?></label>
                        <div class="media-upload-area">
                            <div id="edit-product-image-preview" class="image-preview">
                                <img src="" alt="" style="display:none;">
                                <button type="button" class="button button-secondary remove-image" style="display:none;">
                                    <span class="dashicons dashicons-no"></span>
                                </button>
                            </div>
                            <button type="button" class="button button-secondary upload-image-btn" data-target="product-image">
                                <span class="dashicons dashicons-upload"></span>
                                <?php _e('Upload Image', 'ai-woo-product-generator'); ?>
                            </button>
                            <input type="hidden" id="edit-product-image-id" name="image_id">
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label><?php _e('Product Gallery', 'ai-woo-product-generator'); ?></label>
                        <div class="media-upload-area">
                            <div id="edit-gallery-preview" class="gallery-preview"></div>
                            <button type="button" class="button button-secondary upload-gallery-btn">
                                <span class="dashicons dashicons-images-alt2"></span>
                                <?php _e('Add Gallery Images', 'ai-woo-product-generator'); ?>
                            </button>
                            <input type="hidden" id="edit-gallery-ids" name="gallery_ids">
                        </div>
                    </div>
                </div>
                
                <!-- Variations Tab -->
                <div class="tab-content" data-tab="variations">
                    <div class="variations-info">
                        <p class="description">
                            <span class="dashicons dashicons-info"></span>
                            <?php _e('Product variations are displayed here for reference. To edit variations, please use the WooCommerce product editor.', 'ai-woo-product-generator'); ?>
                        </p>
                    </div>
                    <div id="edit-variations-list" class="variations-list">
                        <!-- Variations will be loaded here -->
                    </div>
                </div>
                
                <!-- Settings Tab -->
                <div class="tab-content" data-tab="settings">
                    <div class="form-group">
                        <label for="edit-status"><?php _e('Status', 'ai-woo-product-generator'); ?></label>
                        <select id="edit-status" name="status" class="widefat">
                            <option value="publish"><?php _e('Published', 'ai-woo-product-generator'); ?></option>
                            <option value="draft"><?php _e('Draft', 'ai-woo-product-generator'); ?></option>
                            <option value="pending"><?php _e('Pending Review', 'ai-woo-product-generator'); ?></option>
                            <option value="private"><?php _e('Private', 'ai-woo-product-generator'); ?></option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="edit-catalog-visibility"><?php _e('Catalog Visibility', 'ai-woo-product-generator'); ?></label>
                        <select id="edit-catalog-visibility" name="catalog_visibility" class="widefat">
                            <option value="visible"><?php _e('Shop and search results', 'ai-woo-product-generator'); ?></option>
                            <option value="catalog"><?php _e('Shop only', 'ai-woo-product-generator'); ?></option>
                            <option value="search"><?php _e('Search results only', 'ai-woo-product-generator'); ?></option>
                            <option value="hidden"><?php _e('Hidden', 'ai-woo-product-generator'); ?></option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label class="switch-label">
                            <input type="checkbox" id="edit-featured" name="featured" class="switch-input">
                            <span class="switch-slider"></span>
                            <span class="switch-text"><?php _e('Featured Product', 'ai-woo-product-generator'); ?></span>
                        </label>
                        <p class="description"><?php _e('Enable this option to feature this product', 'ai-woo-product-generator'); ?></p>
                    </div>
                    
                    <div class="form-group">
                        <label for="edit-categories"><?php _e('Categories', 'ai-woo-product-generator'); ?></label>
                        <select id="edit-categories" name="categories" class="widefat" multiple size="5">
                            <!-- Categories will be loaded via AJAX -->
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="edit-tags"><?php _e('Tags', 'ai-woo-product-generator'); ?></label>
                        <input type="text" id="edit-tags" name="tags" class="widefat" placeholder="<?php _e('Add tags...', 'ai-woo-product-generator'); ?>">
                    </div>
                    
                    <div class="form-group">
                        <label for="edit-menu-order"><?php _e('Menu Order', 'ai-woo-product-generator'); ?></label>
                        <input type="number" id="edit-menu-order" name="menu_order" class="widefat" min="0">
                        <p class="description"><?php _e('Custom ordering position', 'ai-woo-product-generator'); ?></p>
                    </div>
                    
                    <div class="form-group">
                        <label class="switch-label">
                            <input type="checkbox" id="edit-reviews-allowed" name="reviews_allowed" class="switch-input">
                            <span class="switch-slider"></span>
                            <span class="switch-text"><?php _e('Enable Reviews', 'ai-woo-product-generator'); ?></span>
                        </label>
                    </div>
                </div>
                
                <!-- Add-ons & AI Suggestions Tab -->
                <div class="tab-content" data-tab="addons_ai">
                    <?php include AIWPG_PLUGIN_DIR . 'views/admin-product-addons-tab.php'; ?>
                </div>
            </form>
        </div>
        <div class="modal-footer">
            <button type="button" class="button button-primary" id="save-product-edit">
                <span class="dashicons dashicons-yes"></span>
                <?php _e('Save Changes', 'ai-woo-product-generator'); ?>
            </button>
            <button type="button" class="button button-secondary close-modal">
                <?php _e('Cancel', 'ai-woo-product-generator'); ?>
            </button>
        </div>
    </div>
</div>

<!-- Add Product Modal -->
<div id="add-product-modal" class="aiwpg-modal">
    <div class="modal-overlay"></div>
    <div class="modal-content modal-content-wide">
        <div class="modal-header">
            <h2><?php _e('Add New Product', 'ai-woo-product-generator'); ?></h2>
            <button type="button" class="modal-close">
                <span class="dashicons dashicons-no"></span>
            </button>
        </div>
        
        <!-- Step Progress -->
        <div class="step-progress">
            <div class="step-indicator active" data-step="1">
                <div class="step-number">1</div>
                <div class="step-label"><?php _e('Product Type', 'ai-woo-product-generator'); ?></div>
            </div>
            <div class="step-indicator" data-step="2">
                <div class="step-number">2</div>
                <div class="step-label"><?php _e('Pricing', 'ai-woo-product-generator'); ?></div>
            </div>
            <div class="step-indicator" data-step="3">
                <div class="step-number">3</div>
                <div class="step-label"><?php _e('Inventory', 'ai-woo-product-generator'); ?></div>
            </div>
            <div class="step-indicator" data-step="4">
                <div class="step-number">4</div>
                <div class="step-label"><?php _e('Media', 'ai-woo-product-generator'); ?></div>
            </div>
            <div class="step-indicator" data-step="5">
                <div class="step-number">5</div>
                <div class="step-label"><?php _e('Settings', 'ai-woo-product-generator'); ?></div>
            </div>
        </div>
        
        <div class="modal-body">
            <form id="add-product-form">
                
                <!-- Step 1: Product Type & Basic Info -->
                <div class="add-step-content active" data-step="1">
                    <h3><?php _e('Product Type & Basic Information', 'ai-woo-product-generator'); ?></h3>
                    <p class="description"><?php _e('Select the product type and enter basic information', 'ai-woo-product-generator'); ?></p>
                    
                    <div class="form-group">
                        <label><?php _e('Product Type', 'ai-woo-product-generator'); ?></label>
                        <div class="product-type-selector">
                            <div class="type-option selected" data-type="simple">
                                <span class="dashicons dashicons-products"></span>
                                <span class="type-name"><?php _e('Simple', 'ai-woo-product-generator'); ?></span>
                                <p><?php _e('Standard product without variations', 'ai-woo-product-generator'); ?></p>
                            </div>
                            <div class="type-option" data-type="grouped">
                                <span class="dashicons dashicons-category"></span>
                                <span class="type-name"><?php _e('Grouped', 'ai-woo-product-generator'); ?></span>
                                <p><?php _e('Collection of related products', 'ai-woo-product-generator'); ?></p>
                            </div>
                            <div class="type-option" data-type="external">
                                <span class="dashicons dashicons-admin-links"></span>
                                <span class="type-name"><?php _e('External/Affiliate', 'ai-woo-product-generator'); ?></span>
                                <p><?php _e('Product sold on external website', 'ai-woo-product-generator'); ?></p>
                            </div>
                            <div class="type-option" data-type="variable">
                                <span class="dashicons dashicons-networking"></span>
                                <span class="type-name"><?php _e('Variable', 'ai-woo-product-generator'); ?></span>
                                <p><?php _e('Product with variations (size, color, etc)', 'ai-woo-product-generator'); ?></p>
                            </div>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="add-product-name"><?php _e('Product Name', 'ai-woo-product-generator'); ?> <span class="required">*</span></label>
                        <input type="text" id="add-product-name" class="widefat" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="add-product-description"><?php _e('Description', 'ai-woo-product-generator'); ?></label>
                        <textarea id="add-product-description" rows="4" class="widefat"></textarea>
                    </div>
                    
                    <div class="form-group">
                        <label for="add-product-short-description"><?php _e('Short Description', 'ai-woo-product-generator'); ?></label>
                        <textarea id="add-product-short-description" rows="2" class="widefat"></textarea>
                    </div>
                    
                    <div class="form-group">
                        <label for="add-product-sku"><?php _e('SKU', 'ai-woo-product-generator'); ?></label>
                        <input type="text" id="add-product-sku" class="widefat">
                    </div>
                    
                    <!-- External Product Fields -->
                    <div class="field-external" style="display:none;">
                        <div class="form-group">
                            <label for="add-external-url"><?php _e('Product URL', 'ai-woo-product-generator'); ?></label>
                            <input type="url" id="add-external-url" class="widefat" placeholder="https://...">
                        </div>
                        
                        <div class="form-group">
                            <label for="add-button-text"><?php _e('Button Text', 'ai-woo-product-generator'); ?></label>
                            <input type="text" id="add-button-text" class="widefat" placeholder="Buy Now">
                        </div>
                    </div>
                    
                    <!-- Virtual & Downloadable Options -->
                    <div class="virtual-downloadable-options">
                        <div class="form-group">
                            <label class="switch-label">
                                <input type="checkbox" id="add-virtual" class="switch-input">
                                <span class="switch-slider"></span>
                                <span class="switch-text"><?php _e('Virtual', 'ai-woo-product-generator'); ?></span>
                            </label>
                            <p class="description"><?php _e('Virtual products don\'t require shipping', 'ai-woo-product-generator'); ?></p>
                        </div>
                        
                        <div class="form-group">
                            <label class="switch-label">
                                <input type="checkbox" id="add-downloadable" class="switch-input">
                                <span class="switch-slider"></span>
                                <span class="switch-text"><?php _e('Downloadable', 'ai-woo-product-generator'); ?></span>
                            </label>
                            <p class="description"><?php _e('Downloadable products give access to a file upon purchase', 'ai-woo-product-generator'); ?></p>
                        </div>
                        
                        <!-- Downloadable Fields (shown if downloadable) -->
                        <div class="downloadable-fields" style="display:none;">
                            <h4><?php _e('Downloadable Options', 'ai-woo-product-generator'); ?></h4>
                            
                            <!-- Downloadable Files Table -->
                            <div class="form-group">
                                <label><?php _e('Downloadable files', 'ai-woo-product-generator'); ?></label>
                                <div class="downloadable-files-wrapper">
                                    <table class="downloadable-files-table">
                                        <thead>
                                            <tr>
                                                <th><?php _e('Name', 'ai-woo-product-generator'); ?></th>
                                                <th><?php _e('File URL', 'ai-woo-product-generator'); ?></th>
                                                <th width="50"></th>
                                                <th width="80"></th>
                                            </tr>
                                        </thead>
                                        <tbody id="downloadable-files-list">
                                            <!-- Files will be added here -->
                                        </tbody>
                                    </table>
                                    <button type="button" class="button add-downloadable-file">
                                        <span class="dashicons dashicons-plus-alt2"></span>
                                        <?php _e('Add File', 'ai-woo-product-generator'); ?>
                                    </button>
                                </div>
                            </div>
                            
                            <div class="form-row">
                                <div class="form-group">
                                    <label for="add-download-limit"><?php _e('Download Limit', 'ai-woo-product-generator'); ?></label>
                                    <input type="number" id="add-download-limit" class="widefat" min="-1" value="-1" placeholder="<?php _e('Unlimited', 'ai-woo-product-generator'); ?>">
                                    <p class="description"><?php _e('Leave blank for unlimited re-downloads.', 'ai-woo-product-generator'); ?></p>
                                </div>
                                
                                <div class="form-group">
                                    <label for="add-download-expiry"><?php _e('Download Expiry', 'ai-woo-product-generator'); ?></label>
                                    <input type="number" id="add-download-expiry" class="widefat" min="-1" value="-1" placeholder="<?php _e('Never', 'ai-woo-product-generator'); ?>">
                                    <p class="description"><?php _e('Enter the number of days before a download link expires, or leave blank.', 'ai-woo-product-generator'); ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Step 2: Pricing -->
                <div class="add-step-content" data-step="2">
                    <h3><?php _e('Pricing', 'ai-woo-product-generator'); ?></h3>
                    <p class="description"><?php _e('Set product pricing and tax information', 'ai-woo-product-generator'); ?></p>
                    
                    <div class="field-simple field-external field-variable">
                        <div class="form-row">
                            <div class="form-group">
                                <label for="add-regular-price"><?php _e('Regular Price', 'ai-woo-product-generator'); ?> <span class="required">*</span></label>
                                <input type="number" id="add-regular-price" class="widefat" step="0.01" min="0">
                            </div>
                            
                            <div class="form-group">
                                <label for="add-sale-price"><?php _e('Sale Price', 'ai-woo-product-generator'); ?></label>
                                <input type="number" id="add-sale-price" class="widefat" step="0.01" min="0">
                            </div>
                        </div>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label for="add-tax-status"><?php _e('Tax Status', 'ai-woo-product-generator'); ?></label>
                                <select id="add-tax-status" class="widefat">
                                    <option value="taxable"><?php _e('Taxable', 'ai-woo-product-generator'); ?></option>
                                    <option value="shipping"><?php _e('Shipping only', 'ai-woo-product-generator'); ?></option>
                                    <option value="none"><?php _e('None', 'ai-woo-product-generator'); ?></option>
                                </select>
                            </div>
                            
                            <div class="form-group">
                                <label for="add-tax-class"><?php _e('Tax Class', 'ai-woo-product-generator'); ?></label>
                                <select id="add-tax-class" class="widefat">
                                    <option value=""><?php _e('Standard', 'ai-woo-product-generator'); ?></option>
                                    <option value="reduced-rate"><?php _e('Reduced rate', 'ai-woo-product-generator'); ?></option>
                                    <option value="zero-rate"><?php _e('Zero rate', 'ai-woo-product-generator'); ?></option>
                                </select>
                            </div>
                        </div>
                    </div>
                    
                    <div class="field-grouped">
                        <p class="description"><?php _e('Grouped products don\'t have their own price. The price is determined by the grouped products.', 'ai-woo-product-generator'); ?></p>
                    </div>
                </div>
                
                <!-- Step 3: Inventory & Shipping -->
                <div class="add-step-content" data-step="3">
                    <h3><?php _e('Inventory & Shipping', 'ai-woo-product-generator'); ?></h3>
                    <p class="description"><?php _e('Manage stock and shipping information', 'ai-woo-product-generator'); ?></p>
                    
                    <div class="field-simple field-variable">
                        <div class="form-group">
                            <label class="switch-label">
                                <input type="checkbox" id="add-manage-stock" class="switch-input">
                                <span class="switch-slider"></span>
                                <span class="switch-text"><?php _e('Manage Stock', 'ai-woo-product-generator'); ?></span>
                            </label>
                        </div>
                        
                        <div class="form-group stock-quantity-group" style="display:none;">
                            <label for="add-stock-quantity"><?php _e('Stock Quantity', 'ai-woo-product-generator'); ?></label>
                            <input type="number" id="add-stock-quantity" class="widefat" min="0" value="0">
                        </div>
                        
                        <div class="form-group">
                            <label for="add-stock-status"><?php _e('Stock Status', 'ai-woo-product-generator'); ?></label>
                            <select id="add-stock-status" class="widefat">
                                <option value="instock"><?php _e('In Stock', 'ai-woo-product-generator'); ?></option>
                                <option value="outofstock"><?php _e('Out of Stock', 'ai-woo-product-generator'); ?></option>
                                <option value="onbackorder"><?php _e('On Backorder', 'ai-woo-product-generator'); ?></option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label class="switch-label">
                                <input type="checkbox" id="add-sold-individually-add" class="switch-input">
                                <span class="switch-slider"></span>
                                <span class="switch-text"><?php _e('Sold Individually', 'ai-woo-product-generator'); ?></span>
                            </label>
                        </div>
                    </div>
                    
                    <!-- Shipping Fields (hidden if virtual) -->
                    <div class="shipping-fields">
                        <h4><?php _e('Shipping', 'ai-woo-product-generator'); ?></h4>
                        
                        <div class="form-group">
                            <label for="add-weight"><?php _e('Weight (kg)', 'ai-woo-product-generator'); ?></label>
                            <input type="number" id="add-weight" class="widefat" step="0.01" min="0">
                        </div>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label for="add-length"><?php _e('Length (cm)', 'ai-woo-product-generator'); ?></label>
                                <input type="number" id="add-length" class="widefat" step="0.01" min="0">
                            </div>
                            
                            <div class="form-group">
                                <label for="add-width"><?php _e('Width (cm)', 'ai-woo-product-generator'); ?></label>
                                <input type="number" id="add-width" class="widefat" step="0.01" min="0">
                            </div>
                            
                            <div class="form-group">
                                <label for="add-height"><?php _e('Height (cm)', 'ai-woo-product-generator'); ?></label>
                                <input type="number" id="add-height" class="widefat" step="0.01" min="0">
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Step 4: Media (Images) -->
                <div class="add-step-content" data-step="4">
                    <h3><?php _e('Product Images', 'ai-woo-product-generator'); ?></h3>
                    <p class="description"><?php _e('Upload product images from WordPress media library', 'ai-woo-product-generator'); ?></p>
                    
                    <!-- Product Image -->
                    <div class="form-group">
                        <label><?php _e('Product Image', 'ai-woo-product-generator'); ?></label>
                        <div class="media-upload-wrapper">
                            <div id="add-product-image-preview" class="media-preview">
                                <div class="media-placeholder">
                                    <span class="dashicons dashicons-format-image"></span>
                                    <p><?php _e('No image selected', 'ai-woo-product-generator'); ?></p>
                                </div>
                            </div>
                            <div class="media-buttons">
                                <button type="button" id="add-product-image-btn" class="button button-primary">
                                    <span class="dashicons dashicons-admin-media"></span>
                                    <?php _e('Select Image', 'ai-woo-product-generator'); ?>
                                </button>
                                <button type="button" id="remove-product-image-btn" class="button button-secondary" style="display:none;">
                                    <span class="dashicons dashicons-trash"></span>
                                    <?php _e('Remove Image', 'ai-woo-product-generator'); ?>
                                </button>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Product Gallery -->
                    <div class="form-group">
                        <label><?php _e('Product Gallery', 'ai-woo-product-generator'); ?></label>
                        <div class="media-upload-wrapper">
                            <div id="add-product-gallery-preview" class="media-gallery-preview">
                                <!-- Gallery images will be added here -->
                            </div>
                            <div class="media-buttons">
                                <button type="button" id="add-product-gallery-btn" class="button button-primary">
                                    <span class="dashicons dashicons-admin-media"></span>
                                    <?php _e('Add to Gallery', 'ai-woo-product-generator'); ?>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Step 5: Categories & Settings -->
                <div class="add-step-content" data-step="5">
                    <h3><?php _e('Categories & Settings', 'ai-woo-product-generator'); ?></h3>
                    <p class="description"><?php _e('Organize your product and configure visibility settings', 'ai-woo-product-generator'); ?></p>
                    
                    <div class="form-group">
                        <label for="add-categories"><?php _e('Categories', 'ai-woo-product-generator'); ?></label>
                        <select id="add-categories" class="widefat" multiple size="5">
                            <!-- Will be loaded via AJAX -->
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="add-tags-input"><?php _e('Tags', 'ai-woo-product-generator'); ?></label>
                        <div class="tags-input-wrapper">
                            <div class="tags-container" id="add-tags-container">
                                <!-- Tags will be added here -->
                            </div>
                            <input type="text" id="add-tags-input" class="widefat tags-input-field" placeholder="<?php _e('Type and press Enter to add tags...', 'ai-woo-product-generator'); ?>">
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="add-status"><?php _e('Status', 'ai-woo-product-generator'); ?></label>
                        <select id="add-status" class="widefat">
                            <option value="publish"><?php _e('Published', 'ai-woo-product-generator'); ?></option>
                            <option value="draft"><?php _e('Draft', 'ai-woo-product-generator'); ?></option>
                            <option value="pending"><?php _e('Pending Review', 'ai-woo-product-generator'); ?></option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="add-catalog-visibility"><?php _e('Catalog Visibility', 'ai-woo-product-generator'); ?></label>
                        <select id="add-catalog-visibility" class="widefat">
                            <option value="visible"><?php _e('Shop and search results', 'ai-woo-product-generator'); ?></option>
                            <option value="catalog"><?php _e('Shop only', 'ai-woo-product-generator'); ?></option>
                            <option value="search"><?php _e('Search results only', 'ai-woo-product-generator'); ?></option>
                            <option value="hidden"><?php _e('Hidden', 'ai-woo-product-generator'); ?></option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label class="switch-label">
                            <input type="checkbox" id="add-featured" class="switch-input">
                            <span class="switch-slider"></span>
                            <span class="switch-text"><?php _e('Featured Product', 'ai-woo-product-generator'); ?></span>
                        </label>
                    </div>
                    
                    <div class="form-group">
                        <label class="switch-label">
                            <input type="checkbox" id="add-reviews-allowed" class="switch-input" checked>
                            <span class="switch-slider"></span>
                            <span class="switch-text"><?php _e('Enable Reviews', 'ai-woo-product-generator'); ?></span>
                        </label>
                    </div>
                </div>
                
            </form>
        </div>
        
        <div class="modal-footer">
            <button type="button" class="button button-secondary" id="add-product-prev">
                <span class="dashicons dashicons-arrow-left-alt2"></span>
                <?php _e('Previous', 'ai-woo-product-generator'); ?>
            </button>
            <button type="button" class="button button-primary" id="add-product-next">
                <?php _e('Next', 'ai-woo-product-generator'); ?>
                <span class="dashicons dashicons-arrow-right-alt2"></span>
            </button>
            <button type="button" class="button button-primary" id="add-product-save" style="display:none;">
                <span class="dashicons dashicons-yes"></span>
                <?php _e('Create Product', 'ai-woo-product-generator'); ?>
            </button>
            <button type="button" class="button button-secondary close-modal">
                <?php _e('Cancel', 'ai-woo-product-generator'); ?>
            </button>
        </div>
    </div>
</div>

<!-- Global Context Menu -->
<div id="global-context-menu" class="context-menu" style="display: none;">
    <div class="context-menu-item" data-action="generate-products">
        <span class="dashicons dashicons-admin-generic"></span>
        <span><?php _e('Generate Products', 'ai-woo-product-generator'); ?></span>
    </div>
    <div class="context-menu-item" data-action="products-list">
        <span class="dashicons dashicons-products"></span>
        <span><?php _e('Products List', 'ai-woo-product-generator'); ?></span>
    </div>
    <div class="context-menu-item" data-action="settings">
        <span class="dashicons dashicons-admin-settings"></span>
        <span><?php _e('Settings', 'ai-woo-product-generator'); ?></span>
    </div>
    <div class="context-menu-divider"></div>
    <div class="context-menu-item" data-action="add-product">
        <span class="dashicons dashicons-plus-alt"></span>
        <span><?php _e('Add Product', 'ai-woo-product-generator'); ?></span>
    </div>
    <div class="context-menu-divider"></div>
    <div class="context-menu-item" data-action="refresh">
        <span class="dashicons dashicons-update"></span>
        <span><?php _e('Refresh Page', 'ai-woo-product-generator'); ?></span>
    </div>
</div>