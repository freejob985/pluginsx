<?php
/**
 * Products List Admin Page
 * Display products in card grid with search, autocomplete, and modals
 */

if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="wrap aiwpg-wrap">
    <h1><?php _e('WooCommerce Products', 'ai-woo-product-generator'); ?></h1>
    
    <!-- Statistics Dashboard -->
    <div class="aiwpg-stats-dashboard" id="stats-dashboard">
        <div class="stat-card stat-total">
            <div class="stat-header">
                <div>
                    <div class="stat-label"><?php _e('Total Products', 'ai-woo-product-generator'); ?></div>
                    <div class="stat-value" id="stat-total-value">
                        <span class="spinner is-active" style="float: none; margin: 0;"></span>
                    </div>
                </div>
                <div class="stat-icon">
                    <span class="dashicons dashicons-products"></span>
                </div>
            </div>
        </div>
        
        <div class="stat-card stat-published">
            <div class="stat-header">
                <div>
                    <div class="stat-label"><?php _e('Published', 'ai-woo-product-generator'); ?></div>
                    <div class="stat-value" id="stat-published-value">
                        <span class="spinner is-active" style="float: none; margin: 0;"></span>
                    </div>
                </div>
                <div class="stat-icon">
                    <span class="dashicons dashicons-yes-alt"></span>
                </div>
            </div>
        </div>
        
        <div class="stat-card stat-draft">
            <div class="stat-header">
                <div>
                    <div class="stat-label"><?php _e('Drafts', 'ai-woo-product-generator'); ?></div>
                    <div class="stat-value" id="stat-draft-value">
                        <span class="spinner is-active" style="float: none; margin: 0;"></span>
                    </div>
                </div>
                <div class="stat-icon">
                    <span class="dashicons dashicons-edit"></span>
                </div>
            </div>
        </div>
        
        <div class="stat-card stat-value">
            <div class="stat-header">
                <div>
                    <div class="stat-label"><?php _e('Stock Value', 'ai-woo-product-generator'); ?></div>
                    <div class="stat-value" id="stat-value-value">
                        <span class="spinner is-active" style="float: none; margin: 0;"></span>
                    </div>
                </div>
                <div class="stat-icon">
                    <span class="dashicons dashicons-money-alt"></span>
                </div>
            </div>
        </div>
        
        <div class="stat-card stat-out-of-stock">
            <div class="stat-header">
                <div>
                    <div class="stat-label"><?php _e('Out of Stock', 'ai-woo-product-generator'); ?></div>
                    <div class="stat-value" id="stat-out-of-stock-value">
                        <span class="spinner is-active" style="float: none; margin: 0;"></span>
                    </div>
                </div>
                <div class="stat-icon">
                    <span class="dashicons dashicons-dismiss"></span>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Search Bar -->
    <div class="aiwpg-search-bar">
        <div class="search-wrapper">
            <input 
                type="text" 
                id="product-search" 
                class="aiwpg-search-input" 
                placeholder="<?php _e('Search products...', 'ai-woo-product-generator'); ?>"
                autocomplete="off"
            >
            <span class="dashicons dashicons-search search-icon"></span>
            
            <!-- Autocomplete Results -->
            <div id="autocomplete-results" class="autocomplete-results"></div>
        </div>
        
        <button type="button" id="refresh-products" class="button">
            <span class="dashicons dashicons-update"></span>
            <?php _e('Refresh', 'ai-woo-product-generator'); ?>
        </button>
    </div>
    
    <!-- Products Grid -->
    <div id="products-container" class="aiwpg-products-grid">
        <!-- Products will be loaded here via AJAX -->
        <div class="aiwpg-loading">
            <span class="spinner is-active"></span>
            <p><?php _e('Loading products...', 'ai-woo-product-generator'); ?></p>
        </div>
    </div>
    
    <!-- Pagination -->
    <div id="products-pagination" class="aiwpg-pagination">
        <!-- Pagination will be loaded here -->
    </div>
</div>

<!-- Context Menu for Edit Product Modal -->
<div id="edit-product-context-menu" class="context-menu" style="display: none;">
    <div class="context-menu-item" data-tab="general">
        <span class="dashicons dashicons-admin-generic"></span>
        <span><?php _e('General', 'ai-woo-product-generator'); ?></span>
    </div>
    <div class="context-menu-item" data-tab="inventory">
        <span class="dashicons dashicons-archive"></span>
        <span><?php _e('Inventory', 'ai-woo-product-generator'); ?></span>
    </div>
    <div class="context-menu-item" data-tab="shipping">
        <span class="dashicons dashicons-admin-site"></span>
        <span><?php _e('Shipping', 'ai-woo-product-generator'); ?></span>
    </div>
    <div class="context-menu-item" data-tab="linked">
        <span class="dashicons dashicons-admin-links"></span>
        <span><?php _e('Linked', 'ai-woo-product-generator'); ?></span>
    </div>
    <div class="context-menu-item" data-tab="media">
        <span class="dashicons dashicons-format-image"></span>
        <span><?php _e('Media', 'ai-woo-product-generator'); ?></span>
    </div>
    <div class="context-menu-item" data-tab="variations">
        <span class="dashicons dashicons-screenoptions"></span>
        <span><?php _e('Variations', 'ai-woo-product-generator'); ?></span>
    </div>
    <div class="context-menu-item" data-tab="settings">
        <span class="dashicons dashicons-admin-settings"></span>
        <span><?php _e('Settings', 'ai-woo-product-generator'); ?></span>
    </div>
</div>

<!-- View Product Modal -->
<div id="view-product-modal" class="aiwpg-modal">
    <div class="modal-overlay"></div>
    <div class="modal-content">
        <div class="modal-header">
            <h2 id="view-modal-title"><?php _e('Product Details', 'ai-woo-product-generator'); ?></h2>
            <button type="button" class="modal-close">
                <span class="dashicons dashicons-no"></span>
            </button>
        </div>
        <div class="modal-body" id="view-modal-body">
            <!-- Product details will be loaded here -->
        </div>
        <div class="modal-footer">
            <button type="button" class="button button-secondary close-modal">
                <?php _e('Close', 'ai-woo-product-generator'); ?>
            </button>
        </div>
    </div>
</div>

<!-- Edit Product Modal -->
<div id="edit-product-modal" class="aiwpg-modal">
    <div class="modal-overlay"></div>
    <div class="modal-content modal-content-wide">
        <div class="modal-header">
            <div class="modal-header-left">
                <button type="button" class="button button-secondary nav-product-btn" id="prev-product-btn" title="<?php _e('Previous Product', 'ai-woo-product-generator'); ?>">
                    <span class="dashicons dashicons-arrow-left-alt2"></span>
                </button>
                <h2><?php _e('Edit Product', 'ai-woo-product-generator'); ?></h2>
                <button type="button" class="button button-secondary nav-product-btn" id="next-product-btn" title="<?php _e('Next Product', 'ai-woo-product-generator'); ?>">
                    <span class="dashicons dashicons-arrow-right-alt2"></span>
                </button>
            </div>
            <div class="modal-header-right">
                <button type="button" class="button button-secondary modal-fullscreen-btn" id="toggle-fullscreen-btn" title="<?php _e('Toggle Fullscreen', 'ai-woo-product-generator'); ?>">
                    <span class="dashicons dashicons-fullscreen-alt"></span>
                </button>
                <button type="button" class="modal-close">
                    <span class="dashicons dashicons-no"></span>
                </button>
            </div>
        </div>
        <div class="modal-body">
            <!-- Tab Navigation -->
            <div class="product-tabs-nav">
                <button type="button" class="tab-btn active" data-tab="general">
                    <span class="dashicons dashicons-admin-generic"></span>
                    <span><?php _e('General', 'ai-woo-product-generator'); ?></span>
                </button>
                <button type="button" class="tab-btn" data-tab="inventory">
                    <span class="dashicons dashicons-archive"></span>
                    <span><?php _e('Inventory', 'ai-woo-product-generator'); ?></span>
                </button>
                <button type="button" class="tab-btn" data-tab="shipping">
                    <span class="dashicons dashicons-admin-site"></span>
                    <span><?php _e('Shipping', 'ai-woo-product-generator'); ?></span>
                </button>
                <button type="button" class="tab-btn" data-tab="linked">
                    <span class="dashicons dashicons-admin-links"></span>
                    <span><?php _e('Linked', 'ai-woo-product-generator'); ?></span>
                </button>
                <button type="button" class="tab-btn" data-tab="media">
                    <span class="dashicons dashicons-format-gallery"></span>
                    <span><?php _e('Media', 'ai-woo-product-generator'); ?></span>
                </button>
                <button type="button" class="tab-btn" data-tab="variations">
                    <span class="dashicons dashicons-image-filter"></span>
                    <span><?php _e('Variations', 'ai-woo-product-generator'); ?></span>
                </button>
                <button type="button" class="tab-btn" data-tab="settings">
                    <span class="dashicons dashicons-admin-settings"></span>
                    <span><?php _e('Settings', 'ai-woo-product-generator'); ?></span>
                </button>
            </div>

            <form id="edit-product-form">
                <input type="hidden" id="edit-product-id" name="product_id">
                
                <!-- General Tab -->
                <div class="tab-content active" data-tab="general">
                    <div class="form-group">
                        <label for="edit-title"><?php _e('Product Name', 'ai-woo-product-generator'); ?></label>
                        <div class="input-with-ai">
                            <input type="text" id="edit-title" name="title" class="widefat" required>
                            <button type="button" class="button button-secondary improve-field-btn" data-field="edit-title" title="<?php _e('Improve with AI', 'ai-woo-product-generator'); ?>">
                                <span class="dashicons dashicons-admin-tools"></span>
                            </button>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="edit-long-description"><?php _e('Description', 'ai-woo-product-generator'); ?></label>
                        <div class="input-with-ai">
                            <textarea id="edit-long-description" name="long_description" rows="6" class="widefat"></textarea>
                            <button type="button" class="button button-secondary improve-field-btn" data-field="edit-long-description" title="<?php _e('Improve with AI', 'ai-woo-product-generator'); ?>">
                                <span class="dashicons dashicons-admin-tools"></span>
                            </button>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="edit-short-description"><?php _e('Short Description', 'ai-woo-product-generator'); ?></label>
                        <div class="input-with-ai">
                            <textarea id="edit-short-description" name="short_description" rows="3" class="widefat"></textarea>
                            <button type="button" class="button button-secondary improve-field-btn" data-field="edit-short-description" title="<?php _e('Improve with AI', 'ai-woo-product-generator'); ?>">
                                <span class="dashicons dashicons-admin-tools"></span>
                            </button>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="edit-sku"><?php _e('SKU', 'ai-woo-product-generator'); ?></label>
                        <input type="text" id="edit-sku" name="sku" class="widefat">
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="edit-regular-price"><?php _e('Regular Price', 'ai-woo-product-generator'); ?></label>
                            <input type="number" id="edit-regular-price" name="regular_price" class="widefat" step="0.01" min="0">
                        </div>
                        
                        <div class="form-group">
                            <label for="edit-sale-price"><?php _e('Sale Price', 'ai-woo-product-generator'); ?></label>
                            <input type="number" id="edit-sale-price" name="sale_price" class="widefat" step="0.01" min="0">
                        </div>
                    </div>
                </div>
                
                <!-- Inventory Tab -->
                <div class="tab-content" data-tab="inventory">
                    <div class="form-group">
                        <label class="switch-label">
                            <input type="checkbox" id="edit-manage-stock" name="manage_stock" class="switch-input">
                            <span class="switch-slider"></span>
                            <span class="switch-text"><?php _e('Manage Stock', 'ai-woo-product-generator'); ?></span>
                        </label>
                        <p class="description"><?php _e('Enable stock management at product level', 'ai-woo-product-generator'); ?></p>
                    </div>
                    
                    <div class="form-group stock-quantity-group">
                        <label for="edit-stock-quantity"><?php _e('Stock Quantity', 'ai-woo-product-generator'); ?></label>
                        <input type="number" id="edit-stock-quantity" name="stock_quantity" class="widefat" min="0">
                    </div>
                    
                    <div class="form-group">
                        <label for="edit-stock-status"><?php _e('Stock Status', 'ai-woo-product-generator'); ?></label>
                        <select id="edit-stock-status" name="stock_status" class="widefat">
                            <option value="instock"><?php _e('In Stock', 'ai-woo-product-generator'); ?></option>
                            <option value="outofstock"><?php _e('Out of Stock', 'ai-woo-product-generator'); ?></option>
                            <option value="onbackorder"><?php _e('On Backorder', 'ai-woo-product-generator'); ?></option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="edit-low-stock-threshold"><?php _e('Low Stock Threshold', 'ai-woo-product-generator'); ?></label>
                        <input type="number" id="edit-low-stock-threshold" name="low_stock_threshold" class="widefat" min="0">
                        <p class="description"><?php _e('Set a low stock threshold to receive notifications', 'ai-woo-product-generator'); ?></p>
                    </div>
                    
                    <div class="form-group">
                        <label class="switch-label">
                            <input type="checkbox" id="edit-sold-individually" name="sold_individually" class="switch-input">
                            <span class="switch-slider"></span>
                            <span class="switch-text"><?php _e('Sold Individually', 'ai-woo-product-generator'); ?></span>
                        </label>
                        <p class="description"><?php _e('Enable this to only allow one of this item to be bought in a single order', 'ai-woo-product-generator'); ?></p>
                    </div>
                </div>
                
                <!-- Shipping Tab -->
                <div class="tab-content" data-tab="shipping">
                    <div class="form-group">
                        <label for="edit-weight"><?php _e('Weight (kg)', 'ai-woo-product-generator'); ?></label>
                        <input type="number" id="edit-weight" name="weight" class="widefat" step="0.01" min="0">
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="edit-length"><?php _e('Length (cm)', 'ai-woo-product-generator'); ?></label>
                            <input type="number" id="edit-length" name="length" class="widefat" step="0.01" min="0">
                        </div>
                        
                        <div class="form-group">
                            <label for="edit-width"><?php _e('Width (cm)', 'ai-woo-product-generator'); ?></label>
                            <input type="number" id="edit-width" name="width" class="widefat" step="0.01" min="0">
                        </div>
                        
                        <div class="form-group">
                            <label for="edit-height"><?php _e('Height (cm)', 'ai-woo-product-generator'); ?></label>
                            <input type="number" id="edit-height" name="height" class="widefat" step="0.01" min="0">
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="edit-shipping-class"><?php _e('Shipping Class', 'ai-woo-product-generator'); ?></label>
                        <select id="edit-shipping-class" name="shipping_class" class="widefat">
                            <option value=""><?php _e('No shipping class', 'ai-woo-product-generator'); ?></option>
                            <!-- Shipping classes will be loaded via AJAX -->
                        </select>
                    </div>
                </div>
                
                <!-- Linked Products Tab -->
                <div class="tab-content" data-tab="linked">
                    <div class="form-group">
                        <label for="edit-upsell-ids"><?php _e('Upsells', 'ai-woo-product-generator'); ?></label>
                        <select id="edit-upsell-ids" name="upsell_ids" class="widefat" multiple>
                            <!-- Products will be loaded via AJAX -->
                        </select>
                        <p class="description"><?php _e('Upsells are products which you recommend instead of the currently viewed product', 'ai-woo-product-generator'); ?></p>
                    </div>
                    
                    <div class="form-group">
                        <label for="edit-cross-sell-ids"><?php _e('Cross-sells', 'ai-woo-product-generator'); ?></label>
                        <select id="edit-cross-sell-ids" name="cross_sell_ids" class="widefat" multiple>
                            <!-- Products will be loaded via AJAX -->
                        </select>
                        <p class="description"><?php _e('Cross-sells are products which you promote in the cart, based on the current product', 'ai-woo-product-generator'); ?></p>
                    </div>
                </div>
                
                <!-- Media Tab -->
                <div class="tab-content" data-tab="media">
                    <div class="form-group">
                        <label><?php _e('Product Image', 'ai-woo-product-generator'); ?></label>
                        <div class="media-upload-area">
                            <div id="edit-product-image-preview" class="image-preview">
                                <img src="" alt="" style="display:none;">
                                <button type="button" class="button button-secondary remove-image" style="display:none;">
                                    <span class="dashicons dashicons-no"></span>
                                </button>
                            </div>
                            <button type="button" class="button button-secondary upload-image-btn" data-target="product-image">
                                <span class="dashicons dashicons-upload"></span>
                                <?php _e('Upload Image', 'ai-woo-product-generator'); ?>
                            </button>
                            <input type="hidden" id="edit-product-image-id" name="image_id">
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label><?php _e('Product Gallery', 'ai-woo-product-generator'); ?></label>
                        <div class="media-upload-area">
                            <div id="edit-gallery-preview" class="gallery-preview"></div>
                            <button type="button" class="button button-secondary upload-gallery-btn">
                                <span class="dashicons dashicons-images-alt2"></span>
                                <?php _e('Add Gallery Images', 'ai-woo-product-generator'); ?>
                            </button>
                            <input type="hidden" id="edit-gallery-ids" name="gallery_ids">
                        </div>
                    </div>
                </div>
                
                <!-- Variations Tab -->
                <div class="tab-content" data-tab="variations">
                    <div class="variations-info">
                        <p class="description">
                            <span class="dashicons dashicons-info"></span>
                            <?php _e('Product variations are displayed here for reference. To edit variations, please use the WooCommerce product editor.', 'ai-woo-product-generator'); ?>
                        </p>
                    </div>
                    <div id="edit-variations-list" class="variations-list">
                        <!-- Variations will be loaded here -->
                    </div>
                </div>
                
                <!-- Settings Tab -->
                <div class="tab-content" data-tab="settings">
                    <div class="form-group">
                        <label for="edit-status"><?php _e('Status', 'ai-woo-product-generator'); ?></label>
                        <select id="edit-status" name="status" class="widefat">
                            <option value="publish"><?php _e('Published', 'ai-woo-product-generator'); ?></option>
                            <option value="draft"><?php _e('Draft', 'ai-woo-product-generator'); ?></option>
                            <option value="pending"><?php _e('Pending Review', 'ai-woo-product-generator'); ?></option>
                            <option value="private"><?php _e('Private', 'ai-woo-product-generator'); ?></option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="edit-catalog-visibility"><?php _e('Catalog Visibility', 'ai-woo-product-generator'); ?></label>
                        <select id="edit-catalog-visibility" name="catalog_visibility" class="widefat">
                            <option value="visible"><?php _e('Shop and search results', 'ai-woo-product-generator'); ?></option>
                            <option value="catalog"><?php _e('Shop only', 'ai-woo-product-generator'); ?></option>
                            <option value="search"><?php _e('Search results only', 'ai-woo-product-generator'); ?></option>
                            <option value="hidden"><?php _e('Hidden', 'ai-woo-product-generator'); ?></option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label class="switch-label">
                            <input type="checkbox" id="edit-featured" name="featured" class="switch-input">
                            <span class="switch-slider"></span>
                            <span class="switch-text"><?php _e('Featured Product', 'ai-woo-product-generator'); ?></span>
                        </label>
                        <p class="description"><?php _e('Enable this option to feature this product', 'ai-woo-product-generator'); ?></p>
                    </div>
                    
                    <div class="form-group">
                        <label for="edit-categories"><?php _e('Categories', 'ai-woo-product-generator'); ?></label>
                        <select id="edit-categories" name="categories" class="widefat" multiple size="5">
                            <!-- Categories will be loaded via AJAX -->
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="edit-tags"><?php _e('Tags', 'ai-woo-product-generator'); ?></label>
                        <input type="text" id="edit-tags" name="tags" class="widefat" placeholder="<?php _e('Add tags...', 'ai-woo-product-generator'); ?>">
                    </div>
                    
                    <div class="form-group">
                        <label for="edit-menu-order"><?php _e('Menu Order', 'ai-woo-product-generator'); ?></label>
                        <input type="number" id="edit-menu-order" name="menu_order" class="widefat" min="0">
                        <p class="description"><?php _e('Custom ordering position', 'ai-woo-product-generator'); ?></p>
                    </div>
                    
                    <div class="form-group">
                        <label class="switch-label">
                            <input type="checkbox" id="edit-reviews-allowed" name="reviews_allowed" class="switch-input">
                            <span class="switch-slider"></span>
                            <span class="switch-text"><?php _e('Enable Reviews', 'ai-woo-product-generator'); ?></span>
                        </label>
                    </div>
                </div>
            </form>
        </div>
        <div class="modal-footer">
            <button type="button" class="button button-primary" id="save-product-edit">
                <span class="dashicons dashicons-yes"></span>
                <?php _e('Save Changes', 'ai-woo-product-generator'); ?>
            </button>
            <button type="button" class="button button-secondary close-modal">
                <?php _e('Cancel', 'ai-woo-product-generator'); ?>
            </button>
        </div>
    </div>
</div>
