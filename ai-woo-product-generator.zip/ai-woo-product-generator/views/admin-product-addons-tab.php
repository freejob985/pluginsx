<?php
/**
 * Product Add-ons & AI Suggestions Tab
 * 
 * @package AIWPG
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="addons-ai-tab">
    <!-- Header -->
    <div class="addons-header">
        <div class="addons-info">
            <p class="description">
                <span class="dashicons dashicons-info"></span>
                <?php _e('Manage add-ons for this product from all available sources (Sheet, Woo Food, WC Add-ons, Manual). Approve or edit suggested add-ons and attach them to this product.', 'ai-woo-product-generator'); ?>
            </p>
        </div>
    </div>
    
    <!-- Source Filter Bar -->
    <div class="addons-filter-bar">
        <div class="filter-buttons">
            <button type="button" class="filter-btn active" data-source="all">
                <?php _e('All', 'ai-woo-product-generator'); ?>
            </button>
            <button type="button" class="filter-btn" data-source="sheet">
                <?php _e('Sheet', 'ai-woo-product-generator'); ?>
            </button>
            <button type="button" class="filter-btn" data-source="woo_food">
                <?php _e('Woo Food', 'ai-woo-product-generator'); ?>
            </button>
            <button type="button" class="filter-btn" data-source="wc_addons">
                <?php _e('WC Add-ons', 'ai-woo-product-generator'); ?>
            </button>
            <button type="button" class="filter-btn" data-source="manual">
                <?php _e('Manual', 'ai-woo-product-generator'); ?>
            </button>
            <button type="button" class="filter-btn" data-source="ai">
                <?php _e('AI', 'ai-woo-product-generator'); ?>
            </button>
        </div>
    </div>
    
    <!-- Manual Add-on Form -->
    <div class="addons-manual-form">
        <h3><?php _e('Add Manual Add-on', 'ai-woo-product-generator'); ?></h3>
        <div class="form-row">
            <div class="form-group">
                <label for="manual-addon-name"><?php _e('Add-on Name', 'ai-woo-product-generator'); ?> <span class="required">*</span></label>
                <input type="text" id="manual-addon-name" class="widefat" placeholder="<?php _e('e.g., Extra Cheese', 'ai-woo-product-generator'); ?>">
            </div>
            <div class="form-group">
                <label for="manual-addon-group"><?php _e('Group Name', 'ai-woo-product-generator'); ?></label>
                <input type="text" id="manual-addon-group" class="widefat" placeholder="<?php _e('e.g., Pizza Addons', 'ai-woo-product-generator'); ?>">
            </div>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label for="manual-addon-price"><?php _e('Price', 'ai-woo-product-generator'); ?></label>
                <input type="number" id="manual-addon-price" class="widefat" step="0.01" min="0" value="0.00">
            </div>
            <div class="form-group">
                <label for="manual-addon-price-type"><?php _e('Price Type', 'ai-woo-product-generator'); ?></label>
                <select id="manual-addon-price-type" class="widefat">
                    <option value="flat_fee"><?php _e('Flat Fee', 'ai-woo-product-generator'); ?></option>
                    <option value="per_quantity"><?php _e('Per Quantity', 'ai-woo-product-generator'); ?></option>
                </select>
            </div>
            <div class="form-group">
                <label for="manual-addon-selection-type"><?php _e('Selection Type', 'ai-woo-product-generator'); ?></label>
                <select id="manual-addon-selection-type" class="widefat">
                    <option value="single_choice"><?php _e('Single Choice', 'ai-woo-product-generator'); ?></option>
                    <option value="multiple_choice" selected><?php _e('Multiple Choice', 'ai-woo-product-generator'); ?></option>
                    <option value="checkbox"><?php _e('Checkbox', 'ai-woo-product-generator'); ?></option>
                </select>
            </div>
            <div class="form-group">
                <label for="manual-addon-scope"><?php _e('Scope', 'ai-woo-product-generator'); ?></label>
                <select id="manual-addon-scope" class="widefat">
                    <option value="this_product" selected><?php _e('This Product', 'ai-woo-product-generator'); ?></option>
                    <option value="category"><?php _e('Category', 'ai-woo-product-generator'); ?></option>
                    <option value="kitchen"><?php _e('Kitchen', 'ai-woo-product-generator'); ?></option>
                </select>
            </div>
        </div>
        <div class="form-group">
            <button type="button" class="button button-primary" id="add-manual-addon">
                <span class="dashicons dashicons-plus"></span>
                <?php _e('Add Add-on', 'ai-woo-product-generator'); ?>
            </button>
        </div>
    </div>
    
    <!-- AI Suggestions Section -->
    <div class="addons-ai-section">
        <div class="ai-suggestions-header">
            <h3><?php _e('AI Suggestions', 'ai-woo-product-generator'); ?></h3>
            <button type="button" class="button button-secondary" id="generate-ai-suggestions">
                <span class="dashicons dashicons-admin-tools"></span>
                <?php _e('Regenerate AI Suggestions', 'ai-woo-product-generator'); ?>
            </button>
        </div>
        <p class="description">
            <?php _e('AI suggestions are not saved until you mark them as Attached.', 'ai-woo-product-generator'); ?>
        </p>
    </div>
    
    <!-- Bulk Actions -->
    <div class="addons-bulk-actions">
        <div class="bulk-actions-left">
            <select id="bulk-action-select" class="widefat">
                <option value=""><?php _e('Bulk Actions', 'ai-woo-product-generator'); ?></option>
                <option value="attach"><?php _e('Attach to this product', 'ai-woo-product-generator'); ?></option>
                <option value="detach"><?php _e('Detach from this product', 'ai-woo-product-generator'); ?></option>
                <option value="ignore"><?php _e('Mark as ignored', 'ai-woo-product-generator'); ?></option>
            </select>
            <button type="button" class="button" id="apply-bulk-action">
                <?php _e('Apply', 'ai-woo-product-generator'); ?>
            </button>
        </div>
        <div class="bulk-actions-right">
            <button type="button" class="button button-secondary" id="sync-external-addons">
                <span class="dashicons dashicons-update"></span>
                <?php _e('Sync External Add-ons', 'ai-woo-product-generator'); ?>
            </button>
        </div>
    </div>
    
    <!-- Add-ons Table -->
    <div class="addons-table-wrapper">
        <table class="wp-list-table widefat fixed striped" id="addons-table">
            <thead>
                <tr>
                    <th class="check-column">
                        <input type="checkbox" id="select-all-addons">
                    </th>
                    <th><?php _e('Add-on Name', 'ai-woo-product-generator'); ?></th>
                    <th><?php _e('Group', 'ai-woo-product-generator'); ?></th>
                    <th><?php _e('Source', 'ai-woo-product-generator'); ?></th>
                    <th><?php _e('Status', 'ai-woo-product-generator'); ?></th>
                    <th><?php _e('Price', 'ai-woo-product-generator'); ?></th>
                    <th><?php _e('Selection Type', 'ai-woo-product-generator'); ?></th>
                    <th><?php _e('Scope', 'ai-woo-product-generator'); ?></th>
                    <th><?php _e('Actions', 'ai-woo-product-generator'); ?></th>
                </tr>
            </thead>
            <tbody id="addons-table-body">
                <tr class="no-items">
                    <td colspan="9">
                        <p><?php _e('Loading add-ons...', 'ai-woo-product-generator'); ?></p>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</div>
