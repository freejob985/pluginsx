<?php
/**
 * Freepik AI Image Client
 * 
 * Handles communication with Freepik AI API for image generation
 *
 * @package AI_Woo_Product_Generator
 */

if (!defined('ABSPATH')) {
    exit;
}

class AIWPG_Image_Client {
    /**
     * API Keys pool (loaded from constants)
     */
    private $api_keys = [];

    /**
     * API Endpoint
     */
    private $api_endpoint = 'https://api.freepik.com/v1/ai/gemini-2-5-flash-image-preview';
    
    /**
     * Max retry attempts for polling
     * REDUCED from 60 to 10 to prevent long blocking (max 30 seconds)
     */
    private $max_poll_attempts = 10;
    
    /**
     * Poll interval in seconds
     */
    private $poll_interval = 3;
    
    /**
     * Maximum total polling time in seconds (hard timeout limit)
     * This prevents blocking for more than 30 seconds total
     */
    private $max_polling_time = 30;

    /**
     * Logger instance
     */
    private $logger;

    /**
     * Constructor
     */
    public function __construct() {
        $this->logger = AIWPG_Logger::get_instance();
        
        // PRIORITY 1: Load from wp_options (settings page)
        $saved_keys = get_option('aiwpg_api_keys', array());
        $keys_from_db = array();
        for ($i = 1; $i <= 5; $i++) {
            if (isset($saved_keys['freepik_' . $i]) && !empty($saved_keys['freepik_' . $i])) {
                $keys_from_db[] = $saved_keys['freepik_' . $i];
            }
        }
        
        // PRIORITY 2: Load from constants (wp-config.php or environment variables)
        $keys_from_constants = array();
        for ($i = 1; $i <= 5; $i++) {
            $constant = 'AIWPG_FREEPIK_API_KEY_' . $i;
            if (defined($constant) && !empty(constant($constant))) {
                $keys_from_constants[] = constant($constant);
            }
        }
        
        // Use database keys if available, otherwise fall back to constants
        $this->api_keys = !empty($keys_from_db) ? $keys_from_db : $keys_from_constants;
        
        // Remove empty keys
        $this->api_keys = array_filter($this->api_keys, function($key) {
            return !empty($key);
        });
        
        // Re-index array
        $this->api_keys = array_values($this->api_keys);
    }


    
    /**
     * Generate image from text prompt
     *
     * @param string $prompt The text prompt for image generation
     * @param array $reference_images Optional reference images (URLs or base64)
     * @param int $width Optional image width (default: 300)
     * @param int $height Optional image height (default: 300)
     * @return array Response with image URL or error
     */
    public function generate_image($prompt, $reference_images = [], $width = 300, $height = 300) {
        $this->logger->log("Starting image generation with prompt: {$prompt}, size: {$width}x{$height}", 'info');

        // Check if any API keys are configured
        if (empty($this->api_keys)) {
            $error_message = 'Freepik API keys are not configured. Please add them to wp-config.php. See plugin documentation for details.';
            $this->logger->log($error_message, 'error');
            return [
                'success' => false,
                'error' => $error_message,
                'detailed_errors' => ['No API keys configured']
            ];
        }

        $all_errors = [];
        
        // Try each API key until one works
        foreach ($this->api_keys as $index => $api_key) {
            $key_number = $index + 1;
            $this->logger->log("Trying API key #{$key_number}", 'debug');

            $result = $this->try_generate_with_key($api_key, $prompt, $reference_images, $width, $height);

            if ($result['success']) {
                $this->logger->log("Successfully generated image with API key #{$key_number}", 'info');
                return $result;
            }

            $error_detail = $result['error'];
            if (isset($result['status_code'])) {
                $error_detail .= " (HTTP {$result['status_code']})";
            }
            
            $all_errors[] = "Key #{$key_number}: {$error_detail}";
            $this->logger->log("API key #{$key_number} failed: " . $error_detail, 'error');
        }

        // All keys failed
        $error_message = 'All API keys failed to generate image. Details: ' . implode(' | ', $all_errors);
        $this->logger->log($error_message, 'error');
        return [
            'success' => false,
            'error' => $error_message,
            'detailed_errors' => $all_errors
        ];
    }

    /**
     * Try to generate image with specific API key
     *
     * TIMEOUT PROTECTION: This method includes polling with a hard 30-second timeout
     * to prevent long blocking operations that could cause PHP timeouts.
     *
     * @param string $api_key The API key to use
     * @param string $prompt The text prompt
     * @param array $reference_images Reference images
     * @param int $width Image width (default: 300)
     * @param int $height Image height (default: 300)
     * @return array Result of the attempt (includes timeout flag and can_retry if timeout occurred)
     */
    private function try_generate_with_key($api_key, $prompt, $reference_images = [], $width = 300, $height = 300) {
        $body = [
            'prompt' => $prompt
        ];

        if (!empty($reference_images)) {
            $body['reference_images'] = $reference_images;
        }
        
        // Add image size parameters if API supports it
        // Some APIs use 'width' and 'height', others use 'size' or 'dimensions'
        if ($width > 0 && $height > 0) {
            $body['width'] = $width;
            $body['height'] = $height;
            // Also try alternative size parameter format
            $body['size'] = "{$width}x{$height}";
        }

        $args = [
            'headers' => [
                'Content-Type' => 'application/json',
                'x-freepik-api-key' => $api_key
            ],
            'body' => json_encode($body),
            'timeout' => 60,
            'method' => 'POST'
        ];

        $this->logger->log("Sending request to Freepik API: " . $this->api_endpoint, 'debug');
        $this->logger->log("Request body: " . json_encode($body), 'debug');

        $response = wp_remote_post($this->api_endpoint, $args);

        if (is_wp_error($response)) {
            $error_msg = $response->get_error_message();
            $this->logger->log("WP Error: " . $error_msg, 'error');
            return [
                'success' => false,
                'error' => $error_msg
            ];
        }

        $status_code = wp_remote_retrieve_response_code($response);
        $response_body = wp_remote_retrieve_body($response);
        $decoded_response = json_decode($response_body, true);

        $this->logger->log("API Response Status: " . $status_code, 'debug');
        $this->logger->log("API Response Body: " . substr($response_body, 0, 500), 'debug');

        if ($status_code !== 200) {
            $error_message = isset($decoded_response['message']) 
                ? $decoded_response['message'] 
                : "HTTP Error: {$status_code}";
            
            $this->logger->log("API returned non-200 status: " . $error_message, 'error');
            
            return [
                'success' => false,
                'error' => $error_message,
                'status_code' => $status_code,
                'response_body' => $response_body
            ];
        }

        // Check if response indicates async generation (CREATED status)
        // Case 1: status at root level
        if (isset($decoded_response['status']) && $decoded_response['status'] === 'CREATED') {
            $this->logger->log("تم إنشاء مهمة توليد الصورة (async)، بدء الانتظار...", 'info');
            
            // If we have a task ID - this is the main path
            if (isset($decoded_response['id']) || isset($decoded_response['task_id'])) {
                $task_id = $decoded_response['id'] ?? $decoded_response['task_id'];
                $this->logger->log("Task ID: {$task_id}", 'info');
                
                $poll_result = $this->poll_for_image($api_key, $task_id);
                
                if ($poll_result['success']) {
                    return $poll_result;
                }
                
                $this->logger->log("فشل الانتظار: " . $poll_result['error'], 'error');
                return $poll_result;
            }
            
            // Check if we have task_id in data object
            if (isset($decoded_response['data']['id']) || isset($decoded_response['data']['task_id'])) {
                $task_id = $decoded_response['data']['id'] ?? $decoded_response['data']['task_id'];
                $this->logger->log("Task ID found in data object: {$task_id}", 'info');
                
                $poll_result = $this->poll_for_image($api_key, $task_id);
                
                if ($poll_result['success']) {
                    return $poll_result;
                }
                
                $this->logger->log("فشل الانتظار: " . $poll_result['error'], 'error');
                return $poll_result;
            }
            
            // No task ID but status is CREATED - wait and check if images appear
            $this->logger->log("No task ID in CREATED response, checking for generated images...", 'info');
            
            if (isset($decoded_response['generated']) && !empty($decoded_response['generated'])) {
                $this->logger->log("Images found in generated array", 'info');
                return $this->extract_image_from_response($decoded_response);
            }
            
            return [
                'success' => false,
                'error' => 'Image generation initiated but no task ID provided for polling',
                'response' => $decoded_response
            ];
        }
        
        // Case 2: status inside data object - according to API example
        if (isset($decoded_response['data']['status']) && $decoded_response['data']['status'] === 'CREATED') {
            $this->logger->log("تم إنشاء مهمة توليد الصورة (data.status = CREATED)، بدء الانتظار...", 'info');
            
            // Extract task_id from data object
            if (isset($decoded_response['data']['task_id']) || isset($decoded_response['data']['id'])) {
                $task_id = $decoded_response['data']['task_id'] ?? $decoded_response['data']['id'];
                $this->logger->log("Task ID from data: {$task_id}", 'info');
                
                $poll_result = $this->poll_for_image($api_key, $task_id);
                
                if ($poll_result['success']) {
                    return $poll_result;
                }
                
                $this->logger->log("فشل الانتظار: " . $poll_result['error'], 'error');
                return $poll_result;
            }
            
            return [
                'success' => false,
                'error' => 'Image generation initiated in data but no task_id found',
                'response' => $decoded_response
            ];
        }

        // Check if we have image data in response
        if (isset($decoded_response['data']) && isset($decoded_response['data']['image'])) {
            $this->logger->log("Image data found in response", 'info');
            return [
                'success' => true,
                'image_data' => $decoded_response['data']['image'],
                'full_response' => $decoded_response
            ];
        }

        // Check if we have a direct image URL
        if (isset($decoded_response['image_url'])) {
            $this->logger->log("Image URL found in response", 'info');
            return [
                'success' => true,
                'image_url' => $decoded_response['image_url'],
                'full_response' => $decoded_response
            ];
        }
        
        // Check for images in 'generated' array
        if (isset($decoded_response['generated']) && !empty($decoded_response['generated'])) {
            $this->logger->log("Images found in 'generated' array", 'info');
            return $this->extract_image_from_response($decoded_response);
        }

        $this->logger->log("No image data or URL in successful response", 'error');
        $this->logger->log("Full response structure: " . json_encode($decoded_response), 'debug');

        return [
            'success' => false,
            'error' => 'No image data in response',
            'response' => $decoded_response
        ];
    }
    
    /**
     * Check task status from Freepik API
     *
     * @param string $task_id Task ID
     * @param string $api_key API key
     * @return array Status information
     */
    private function check_task_status($task_id, $api_key) {
        $url = "https://api.freepik.com/v1/ai/gemini-2-5-flash-image-preview/" . $task_id;

        $response = wp_remote_get($url, [
            'headers' => [
                'x-freepik-api-key' => $api_key,
                'Content-Type'      => 'application/json',
            ],
            'timeout' => 30,
        ]);

        if (is_wp_error($response)) {
            return ['error' => $response->get_error_message()];
        }

        $body = json_decode(wp_remote_retrieve_body($response), true);

        $this->logger->log("📥 استجابة فحص الحالة: " . json_encode($body), 'debug');

        // الصورة جاهزة
        if (!empty($body['data']['generated'])) {
            $this->logger->log("✓ وُجدت بيانات صورة في data.generated", 'debug');
            $this->logger->log("عدد الصور: " . count($body['data']['generated']), 'debug');
            $this->logger->log("بيانات الصورة الأولى: " . json_encode($body['data']['generated'][0]), 'debug');
            
            return [
                'status'   => $body['data']['status'],
                'image'    => $body['data']['generated'][0],
                'task_id'  => $task_id,
                'full_body' => $body  // إضافة الاستجابة الكاملة
            ];
        }

        // لم تجهز بعد
        $this->logger->log("⏳ لا توجد صور في data.generated بعد", 'debug');
        return [
            'status'  => isset($body['data']['status']) ? $body['data']['status'] : 'UNKNOWN',
            'task_id' => $task_id,
            'full_body' => $body
        ];
    }

    /**
     * Poll for image generation completion
     *
     * @param string $api_key API key
     * @param string $task_id Task ID to poll
     * @return array Result
     */
    private function poll_for_image($api_key, $task_id) {
        $attempts = 0;
        $start_time = time();
        
        $this->logger->log("Starting image polling... Task ID: {$task_id}, Max time: {$this->max_polling_time}s", 'info');
        
        while ($attempts < $this->max_poll_attempts) {
            $attempts++;
            $elapsed_time = time() - $start_time;
            
            // HARD TIMEOUT: Check if we've exceeded maximum polling time
            if ($elapsed_time >= $this->max_polling_time) {
                $this->logger->log(
                    "TIMEOUT: Image polling exceeded {$this->max_polling_time} seconds limit",
                    'warning'
                );
                
                return [
                    'success' => false,
                    'error' => 'Image generation is taking longer than expected. The task is still processing.',
                    'timeout' => true,
                    'task_id' => $task_id,
                    'can_retry' => true,
                    'elapsed_time' => $elapsed_time,
                    'message' => sprintf(
                        'Image generation timed out after %d seconds. Please try checking the status again in 30-60 seconds.',
                        $elapsed_time
                    )
                ];
            }
            
            $this->logger->log(
                "Poll attempt {$attempts}/{$this->max_poll_attempts} (elapsed: {$elapsed_time}s) - checking task status...",
                'info'
            );
            
            // Wait before checking (except first attempt)
            if ($attempts > 1) {
                sleep($this->poll_interval);
            }
            
            // فحص حالة المهمة
            $status_result = $this->check_task_status($task_id, $api_key);
            
            // في حالة وجود خطأ في الاتصال
            if (isset($status_result['error'])) {
                $this->logger->log("خطأ في الاتصال: " . $status_result['error'], 'warning');
                continue;
            }
            
            $current_status = isset($status_result['status']) ? $status_result['status'] : 'UNKNOWN';
            $this->logger->log("حالة المهمة: {$current_status}", 'info');
            
            // الصورة جاهزة! (من check_task_status مباشرة)
            if (isset($status_result['image'])) {
                $this->logger->log("✓ الصورة جاهزة! تم الحصول عليها في المحاولة {$attempts}", 'info');
                
                // Try to extract using extract_image_from_response
                $extract_result = $this->extract_image_from_response($status_result);
                
                if ($extract_result['success']) {
                    $this->logger->log("✓ تم استخراج الصورة بنجاح من status_result['image']", 'info');
                    return $extract_result;
                }
                
                // Fallback to manual extraction
                $image_data = $status_result['image'];
                
                // استخراج رابط الصورة
                if (is_array($image_data)) {
                    if (isset($image_data['url'])) {
                        $this->logger->log("✓ توقف الفحص - تم الحصول على URL الصورة", 'info');
                        return [
                            'success' => true,
                            'image_url' => $image_data['url'],
                            'full_response' => $status_result
                        ];
                    }
                    
                    if (isset($image_data['base64'])) {
                        $this->logger->log("✓ توقف الفحص - تم الحصول على Base64 الصورة", 'info');
                        return [
                            'success' => true,
                            'image_data' => $image_data['base64'],
                            'full_response' => $status_result
                        ];
                    }
                    
                } elseif (is_string($image_data)) {
                    // Image is a direct URL string
                    $this->logger->log("✓ توقف الفحص - تم الحصول على URL الصورة مباشرة", 'info');
                    return [
                        'success' => true,
                        'image_url' => $image_data,
                        'full_response' => $status_result
                    ];
                }
            }
            
            // فحص إذا كانت المهمة اكتملت (حتى بدون صورة في الاستجابة)
            if ($current_status === 'COMPLETED') {
                $this->logger->log("✓ المهمة اكتملت - محاولة استخراج الصورة", 'info');
                
                // محاولة استخراج الصورة مع إعادة المحاولة
                for ($extract_attempt = 1; $extract_attempt <= 3; $extract_attempt++) {
                    $this->logger->log("محاولة استخراج #{$extract_attempt}/3", 'debug');
                    $this->logger->log("status_result keys: " . implode(', ', array_keys($status_result)), 'debug');
                    
                    // Pass full_body if available, otherwise pass status_result
                    $extract_input = isset($status_result['full_body']) ? $status_result['full_body'] : $status_result;
                    $extract_result = $this->extract_image_from_response($extract_input);
                    
                    if ($extract_result['success']) {
                        $this->logger->log("✓ نجح استخراج الصورة في المحاولة #{$extract_attempt}", 'info');
                        return $extract_result;
                    }
                    
                    // إذا فشل الاستخراج، أعد فحص الحالة بعد ثانيتين
                    if ($extract_attempt < 3) {
                        $this->logger->log("⏳ فشل الاستخراج، إعادة فحص الحالة بعد 2 ثانية...", 'warning');
                        $this->logger->log("سبب الفشل: " . ($extract_result['error'] ?? 'unknown'), 'warning');
                        sleep(2);
                        $status_result = $this->check_task_status($task_id, $api_key);
                        
                        // Check if we got an error this time
                        if (isset($status_result['error'])) {
                            $this->logger->log("خطأ في إعادة فحص الحالة: " . $status_result['error'], 'warning');
                            continue;
                        }
                    }
                }
                
                // فشلت كل محاولات الاستخراج - return detailed error
                $this->logger->log("❌ فشلت جميع محاولات استخراج الصورة (3 محاولات)", 'error');
                $this->logger->log("آخر استجابة: " . json_encode($status_result, JSON_UNESCAPED_UNICODE), 'error');
                
                return [
                    'success' => false,
                    'error' => 'المهمة اكتملت لكن فشل استخراج الصورة بعد 3 محاولات',
                    'last_status_result' => $status_result
                ];
            }
            
            // فحص إذا كانت المهمة فشلت
            if ($current_status === 'FAILED') {
                $this->logger->log("✗ فشلت مهمة توليد الصورة", 'error');
                return [
                    'success' => false,
                    'error' => 'فشلت مهمة توليد الصورة من Freepik API'
                ];
            }
            
            // المهمة لا تزال قيد المعالجة
            if (in_array($current_status, ['CREATED', 'PROCESSING', 'PENDING'])) {
                $this->logger->log("⏳ المهمة قيد المعالجة... الانتظار {$this->poll_interval} ثانية", 'info');
                continue;
            }
        }
        
        // Polling completed without success
        $elapsed_time = time() - $start_time;
        $this->logger->log(
            "Polling completed after {$attempts} attempts and {$elapsed_time} seconds - image not yet ready",
            'warning'
        );
        
        return [
            'success' => false,
            'error' => 'Image generation is taking longer than expected. The task is still processing.',
            'timeout' => true,
            'task_id' => $task_id,
            'can_retry' => true,
            'attempts' => $attempts,
            'elapsed_time' => $elapsed_time,
            'message' => sprintf(
                'Image generation did not complete within %d seconds (%d attempts). The task may still be processing. Please try again in 30-60 seconds or check the task status manually.',
                $elapsed_time,
                $attempts
            )
        ];
    }
    
    /**
     * Extract image from response
     *
     * @param array $response API response (can be status_result or direct API response)
     * @return array Result
     */
    private function extract_image_from_response($response) {
        $this->logger->log("محاولة استخراج الصورة من الاستجابة...", 'debug');
        $this->logger->log("Response structure: " . json_encode($response, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT), 'debug');
        
        // First, check if we have 'full_body' (from check_task_status result)
        // This contains the actual API response
        if (isset($response['full_body'])) {
            $this->logger->log("وُجد full_body في الاستجابة، البحث داخله...", 'debug');
            $response = $response['full_body'];
        }
        
        // Also check if we have 'image' directly (from check_task_status when image is ready)
        if (isset($response['image']) && is_array($response['image'])) {
            $this->logger->log("وُجدت صورة مباشرة في response['image']", 'debug');
            $image_data = $response['image'];
            
            if (isset($image_data['url'])) {
                $this->logger->log("✓ تم استخراج URL الصورة من response['image']['url']", 'info');
                return [
                    'success' => true,
                    'image_url' => $image_data['url'],
                    'full_response' => $response
                ];
            }
            
            if (isset($image_data['base64'])) {
                $this->logger->log("✓ تم استخراج Base64 الصورة من response['image']['base64']", 'info');
                return [
                    'success' => true,
                    'image_data' => $image_data['base64'],
                    'full_response' => $response
                ];
            }
            
            // Check if image is a string URL directly
            if (is_string($image_data)) {
                $this->logger->log("✓ تم استخراج URL الصورة مباشرة من response['image']", 'info');
                return [
                    'success' => true,
                    'image_url' => $image_data,
                    'full_response' => $response
                ];
            }
        }
        
        // Check 'data.generated' array (Freepik API format) - Primary location
        if (isset($response['data']['generated']) && is_array($response['data']['generated']) && !empty($response['data']['generated'])) {
            $this->logger->log("وُجدت صورة في data.generated[0]", 'debug');
            $first_image = $response['data']['generated'][0];
            
            // If first_image is a string (direct URL)
            if (is_string($first_image)) {
                $this->logger->log("✓ تم استخراج URL الصورة مباشرة من data.generated[0]", 'info');
                return [
                    'success' => true,
                    'image_url' => $first_image,
                    'full_response' => $response
                ];
            }
            
            // If first_image is an array with url or base64
            if (is_array($first_image)) {
                if (isset($first_image['url'])) {
                    $this->logger->log("✓ تم استخراج URL الصورة من data.generated[0]['url']", 'info');
                    return [
                        'success' => true,
                        'image_url' => $first_image['url'],
                        'full_response' => $response
                    ];
                }
                
                if (isset($first_image['base64'])) {
                    $this->logger->log("✓ تم استخراج Base64 الصورة من data.generated[0]['base64']", 'info');
                    return [
                        'success' => true,
                        'image_data' => $first_image['base64'],
                        'full_response' => $response
                    ];
                }
                
                if (isset($first_image['image_url'])) {
                    $this->logger->log("✓ تم استخراج URL الصورة من data.generated[0]['image_url']", 'info');
                    return [
                        'success' => true,
                        'image_url' => $first_image['image_url'],
                        'full_response' => $response
                    ];
                }
            }
        }
        
        // Check 'generated' array (alternative format at root level)
        if (isset($response['generated']) && is_array($response['generated']) && !empty($response['generated'])) {
            $this->logger->log("وُجدت صورة في generated[0]", 'debug');
            $first_image = $response['generated'][0];
            
            if (is_string($first_image)) {
                $this->logger->log("✓ تم استخراج URL الصورة مباشرة من generated[0]", 'info');
                return [
                    'success' => true,
                    'image_url' => $first_image,
                    'full_response' => $response
                ];
            }
            
            if (is_array($first_image)) {
                if (isset($first_image['url'])) {
                    $this->logger->log("✓ تم استخراج URL الصورة من generated[0]['url']", 'info');
                    return [
                        'success' => true,
                        'image_url' => $first_image['url'],
                        'full_response' => $response
                    ];
                }
                
                if (isset($first_image['base64'])) {
                    $this->logger->log("✓ تم استخراج Base64 الصورة من generated[0]['base64']", 'info');
                    return [
                        'success' => true,
                        'image_data' => $first_image['base64'],
                        'full_response' => $response
                    ];
                }
            }
        }
        
        // Check direct image fields
        if (isset($response['data']['image'])) {
            $image_field = $response['data']['image'];
            
            if (is_string($image_field)) {
                $this->logger->log("✓ تم استخراج URL الصورة من data.image", 'info');
                return [
                    'success' => true,
                    'image_url' => $image_field,
                    'full_response' => $response
                ];
            }
            
            if (is_array($image_field) && isset($image_field['url'])) {
                $this->logger->log("✓ تم استخراج URL الصورة من data.image.url", 'info');
                return [
                    'success' => true,
                    'image_url' => $image_field['url'],
                    'full_response' => $response
                ];
            }
        }
        
        // Check root level image_url
        if (isset($response['image_url'])) {
            $this->logger->log("✓ تم استخراج URL الصورة من image_url", 'info');
            return [
                'success' => true,
                'image_url' => $response['image_url'],
                'full_response' => $response
            ];
        }
        
        $this->logger->log("❌ فشل استخراج الصورة - لا توجد بيانات صورة في الاستجابة", 'error');
        $this->logger->log("مفاتيح المستوى الأول: " . implode(', ', array_keys($response)), 'error');
        if (isset($response['data'])) {
            $this->logger->log("مفاتيح data: " . implode(', ', array_keys($response['data'])), 'error');
        }
        
        return [
            'success' => false,
            'error' => 'Could not extract image from response',
            'response' => $response
        ];
    }

    /**
     * Generate product image from product name
     *
     * @param string $product_name The product name
     * @param string $product_description Optional product description for better prompt
     * @param array $product_data Optional full product data (title, description, categories, etc.)
     * @return array Result with image information
     */
    public function generate_product_image($product_name, $product_description = '', $product_data = []) {
        // Create a descriptive prompt for product image
        $prompt = $this->create_product_prompt($product_name, $product_description, $product_data);
        
        // Generate image with 300x300 size requirement
        $result = $this->generate_image($prompt, [], 300, 300);

        if (!$result['success']) {
            return $result;
        }

        // Upload image to WordPress media library with thumbnail generation
        $upload_result = $this->upload_to_media_library($result, $product_name, 300, 300);

        return $upload_result;
    }

    /**
     * Create a descriptive prompt for product image generation
     *
     * @param string $product_name Product name
     * @param string $product_description Optional product description
     * @param array $product_data Optional full product data (categories, tags, etc.)
     * @return string The generated prompt
     */
    private function create_product_prompt($product_name, $product_description = '', $product_data = []) {
        // Build comprehensive prompt based on available product information
        $prompt = "High-quality professional product photography thumbnail of {$product_name}";
        
        // Add description details if available
        if (!empty($product_description)) {
            // Use short description or first 100 chars of long description
            $desc = strlen($product_description) > 100 ? substr($product_description, 0, 100) . '...' : $product_description;
            $prompt .= ", showing {$desc}";
        }
        
        // Add category context if available
        if (!empty($product_data['categories']) && is_array($product_data['categories'])) {
            $categories = implode(', ', array_slice($product_data['categories'], 0, 2));
            $prompt .= ", category: {$categories}";
        }
        
        // Add style requirements for e-commerce product thumbnail
        $prompt .= ", clean white or transparent background, well-lit, commercial product shot, ";
        $prompt .= "centered composition, square format suitable for thumbnail, ";
        $prompt .= "detailed and sharp, studio lighting, photorealistic, ";
        $prompt .= "product-focused, minimal distractions, professional e-commerce style, ";
        $prompt .= "optimized for 300x300 pixels thumbnail display";

        return $prompt;
    }

    /**
     * Upload generated image to WordPress media library
     *
     * @param array $image_result Image generation result
     * @param string $product_name Product name for filename
     * @param int $target_width Target width for thumbnail (default: 300)
     * @param int $target_height Target height for thumbnail (default: 300)
     * @return array Upload result
     */
    private function upload_to_media_library($image_result, $product_name, $target_width = 300, $target_height = 300) {
        require_once(ABSPATH . 'wp-admin/includes/file.php');
        require_once(ABSPATH . 'wp-admin/includes/media.php');
        require_once(ABSPATH . 'wp-admin/includes/image.php');

        try {
            // Get image data
            $image_data = null;
            
            if (isset($image_result['image_data'])) {
                // If we have base64 or direct image data
                $image_data = $image_result['image_data'];
                
                // Check if it's base64 encoded
                if (base64_encode(base64_decode($image_data, true)) === $image_data) {
                    $image_data = base64_decode($image_data);
                }
            } elseif (isset($image_result['image_url'])) {
                // Download from URL
                $response = wp_remote_get($image_result['image_url'], ['timeout' => 60]);
                
                if (is_wp_error($response)) {
                    throw new Exception($response->get_error_message());
                }
                
                $image_data = wp_remote_retrieve_body($response);
            }

            if (empty($image_data)) {
                throw new Exception('No image data available');
            }

            // Create filename
            $filename = $this->sanitize_filename($product_name) . '-' . time() . '.jpg';

            // Upload directory
            $upload_dir = wp_upload_dir();
            $upload_path = $upload_dir['path'] . '/' . $filename;
            $upload_url = $upload_dir['url'] . '/' . $filename;

            // Save file
            $saved = file_put_contents($upload_path, $image_data);

            if ($saved === false) {
                throw new Exception('Failed to save image file');
            }

            // Create attachment
            $file_type = wp_check_filetype($filename, null);
            $attachment = [
                'post_mime_type' => $file_type['type'],
                'post_title' => sanitize_text_field($product_name),
                'post_content' => '',
                'post_status' => 'inherit'
            ];

            $attach_id = wp_insert_attachment($attachment, $upload_path);

            if (is_wp_error($attach_id)) {
                throw new Exception($attach_id->get_error_message());
            }

            // Generate metadata (this will create thumbnails automatically)
            $attach_data = wp_generate_attachment_metadata($attach_id, $upload_path);
            wp_update_attachment_metadata($attach_id, $attach_data);
            
            // Ensure 300x300 thumbnail exists
            $this->create_custom_thumbnail($attach_id, $upload_path, $target_width, $target_height);

            $this->logger->log("Image uploaded successfully. Attachment ID: {$attach_id}");

            // Get thumbnail URL (300x300) - use custom size first
            $thumbnail_url = wp_get_attachment_image_url($attach_id, 'aiwpg_product_thumbnail');
            if (!$thumbnail_url) {
                // Fallback to thumbnail size
                $thumbnail_url = wp_get_attachment_image_url($attach_id, 'thumbnail');
                if (!$thumbnail_url) {
                    // Last fallback to original
                    $thumbnail_url = $upload_url;
                }
            }

            return [
                'success' => true,
                'attachment_id' => $attach_id,
                'url' => $upload_url,
                'thumbnail_url' => $thumbnail_url,
                'path' => $upload_path
            ];

        } catch (Exception $e) {
            $this->logger->log("Image upload failed: " . $e->getMessage(), 'error');
            return [
                'success' => false,
                'error' => $e->getMessage()
            ];
        }
    }

    /**
     * Create custom thumbnail size (300x300)
     *
     * @param int $attachment_id Attachment ID
     * @param string $file_path Original file path
     * @param int $width Target width
     * @param int $height Target height
     * @return bool Success status
     */
    private function create_custom_thumbnail($attachment_id, $file_path, $width = 300, $height = 300) {
        require_once(ABSPATH . 'wp-admin/includes/image.php');
        
        // Register custom image size (always register to ensure it's available)
        add_image_size('aiwpg_product_thumbnail', $width, $height, true); // true = hard crop
        
        // Also register in theme support if needed
        if (function_exists('add_theme_support')) {
            add_theme_support('post-thumbnails');
        }
        
        // Get image editor
        $image_editor = wp_get_image_editor($file_path);
        
        if (is_wp_error($image_editor)) {
            $this->logger->log("Failed to create image editor: " . $image_editor->get_error_message(), 'warning');
            return false;
        }
        
        // Resize image to exact dimensions with cropping
        $resize_result = $image_editor->resize($width, $height, true);
        
        if (is_wp_error($resize_result)) {
            $this->logger->log("Failed to resize image: " . $resize_result->get_error_message(), 'warning');
            return false;
        }
        
        // Get upload directory
        $upload_dir = wp_upload_dir();
        $file_info = pathinfo($file_path);
        $thumbnail_filename = $file_info['filename'] . '-' . $width . 'x' . $height . '.' . $file_info['extension'];
        $thumbnail_path = $upload_dir['path'] . '/' . $thumbnail_filename;
        
        // Save resized image
        $save_result = $image_editor->save($thumbnail_path);
        
        if (is_wp_error($save_result)) {
            $this->logger->log("Failed to save thumbnail: " . $save_result->get_error_message(), 'warning');
            return false;
        }
        
        // Update attachment metadata to include the custom thumbnail
        $attach_data = wp_get_attachment_metadata($attach_id);
        if (!$attach_data) {
            $attach_data = [];
        }
        
        if (!isset($attach_data['sizes'])) {
            $attach_data['sizes'] = [];
        }
        
        $attach_data['sizes']['aiwpg_product_thumbnail'] = [
            'file' => $thumbnail_filename,
            'width' => $width,
            'height' => $height,
            'mime-type' => $save_result['mime-type'] ?? 'image/jpeg'
        ];
        
        wp_update_attachment_metadata($attachment_id, $attach_data);
        
        $this->logger->log("Created custom thumbnail {$width}x{$height} for attachment {$attachment_id}", 'info');
        
        return true;
    }

    /**
     * Sanitize filename
     *
     * @param string $filename Filename to sanitize
     * @return string Sanitized filename
     */
    private function sanitize_filename($filename) {
        // Remove special characters and spaces
        $filename = preg_replace('/[^a-zA-Z0-9\s-]/', '', $filename);
        $filename = preg_replace('/\s+/', '-', $filename);
        $filename = strtolower($filename);
        $filename = substr($filename, 0, 50); // Limit length
        
        return $filename ?: 'product-image';
    }
}
