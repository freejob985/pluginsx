<?php
/**
 * Add-on Model
 * Handles CRUD operations for product add-ons
 * 
 * @package AIWPG
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

class AIWPG_Addon_Model {
    
    /**
     * Single instance
     */
    private static $instance = null;
    
    /**
     * Database instance
     */
    private $database;
    
    /**
     * Get instance
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructor
     */
    private function __construct() {
        $this->database = AIWPG_Database::get_instance();
    }
    
    /**
     * Get add-on by ID
     * 
     * @param int $id Add-on ID
     * @return array|null
     */
    public function get_addon($id) {
        global $wpdb;
        $table_name = $this->database->get_table_name();
        
        $addon = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM {$table_name} WHERE id = %d",
                $id
            ),
            ARRAY_A
        );
        
        if ($addon && isset($addon['external_data'])) {
            $addon['external_data'] = json_decode($addon['external_data'], true);
        }
        
        return $addon;
    }
    
    /**
     * Get all add-ons for a product
     * 
     * @param int $product_id Product ID
     * @param string|null $source Filter by source (optional)
     * @param string|null $status Filter by status (optional)
     * @return array
     */
    public function get_product_addons($product_id, $source = null, $status = null) {
        global $wpdb;
        $table_name = $this->database->get_table_name();
        
        $where = array('product_id = %d');
        $values = array($product_id);
        
        if ($source) {
            $where[] = 'source = %s';
            $values[] = $source;
        }
        
        if ($status) {
            $where[] = 'status = %s';
            $values[] = $status;
        }
        
        $query = "SELECT * FROM {$table_name} WHERE " . implode(' AND ', $where) . " ORDER BY addon_group, addon_name";
        
        $addons = $wpdb->get_results(
            $wpdb->prepare($query, $values),
            ARRAY_A
        );
        
        // Decode external_data for each addon
        foreach ($addons as &$addon) {
            if (isset($addon['external_data'])) {
                $addon['external_data'] = json_decode($addon['external_data'], true);
            }
        }
        
        return $addons;
    }
    
    /**
     * Create add-on
     * 
     * @param array $data Add-on data
     * @return int|WP_Error Add-on ID or error
     */
    public function create_addon($data) {
        global $wpdb;
        $table_name = $this->database->get_table_name();
        
        // Validate required fields
        if (empty($data['product_id']) || empty($data['addon_name'])) {
            return new WP_Error('invalid_data', __('Product ID and add-on name are required', 'ai-woo-product-generator'));
        }
        
        // Prepare data
        $insert_data = array(
            'product_id' => intval($data['product_id']),
            'addon_name' => sanitize_text_field($data['addon_name']),
            'addon_group' => isset($data['addon_group']) ? sanitize_text_field($data['addon_group']) : null,
            'source' => isset($data['source']) ? sanitize_text_field($data['source']) : 'manual',
            'price' => isset($data['price']) ? floatval($data['price']) : 0.00,
            'price_type' => isset($data['price_type']) ? sanitize_text_field($data['price_type']) : 'flat_fee',
            'selection_type' => isset($data['selection_type']) ? sanitize_text_field($data['selection_type']) : 'multiple_choice',
            'status' => isset($data['status']) ? sanitize_text_field($data['status']) : 'suggested',
            'scope' => isset($data['scope']) ? sanitize_text_field($data['scope']) : 'this_product',
            'external_id' => isset($data['external_id']) ? sanitize_text_field($data['external_id']) : null,
            'external_data' => isset($data['external_data']) ? wp_json_encode($data['external_data']) : null,
        );
        
        $result = $wpdb->insert($table_name, $insert_data);
        
        if ($result === false) {
            return new WP_Error('insert_failed', __('Failed to create add-on', 'ai-woo-product-generator'));
        }
        
        return $wpdb->insert_id;
    }
    
    /**
     * Update add-on
     * 
     * @param int $id Add-on ID
     * @param array $data Update data
     * @return bool|WP_Error
     */
    public function update_addon($id, $data) {
        global $wpdb;
        $table_name = $this->database->get_table_name();
        
        // Prepare update data
        $update_data = array();
        
        if (isset($data['addon_name'])) {
            $update_data['addon_name'] = sanitize_text_field($data['addon_name']);
        }
        if (isset($data['addon_group'])) {
            $update_data['addon_group'] = sanitize_text_field($data['addon_group']);
        }
        if (isset($data['price'])) {
            $update_data['price'] = floatval($data['price']);
        }
        if (isset($data['price_type'])) {
            $update_data['price_type'] = sanitize_text_field($data['price_type']);
        }
        if (isset($data['selection_type'])) {
            $update_data['selection_type'] = sanitize_text_field($data['selection_type']);
        }
        if (isset($data['status'])) {
            $update_data['status'] = sanitize_text_field($data['status']);
        }
        if (isset($data['scope'])) {
            $update_data['scope'] = sanitize_text_field($data['scope']);
        }
        if (isset($data['external_data'])) {
            $update_data['external_data'] = wp_json_encode($data['external_data']);
        }
        
        if (empty($update_data)) {
            return true; // Nothing to update
        }
        
        $result = $wpdb->update(
            $table_name,
            $update_data,
            array('id' => $id),
            null,
            array('%d')
        );
        
        if ($result === false) {
            return new WP_Error('update_failed', __('Failed to update add-on', 'ai-woo-product-generator'));
        }
        
        return true;
    }
    
    /**
     * Delete add-on
     * 
     * @param int $id Add-on ID
     * @return bool|WP_Error
     */
    public function delete_addon($id) {
        global $wpdb;
        $table_name = $this->database->get_table_name();
        
        // Only allow deletion of manual add-ons
        $addon = $this->get_addon($id);
        if (!$addon) {
            return new WP_Error('not_found', __('Add-on not found', 'ai-woo-product-generator'));
        }
        
        if ($addon['source'] !== 'manual') {
            return new WP_Error('delete_not_allowed', __('Only manual add-ons can be deleted', 'ai-woo-product-generator'));
        }
        
        $result = $wpdb->delete(
            $table_name,
            array('id' => $id),
            array('%d')
        );
        
        if ($result === false) {
            return new WP_Error('delete_failed', __('Failed to delete add-on', 'ai-woo-product-generator'));
        }
        
        return true;
    }
    
    /**
     * Bulk update add-ons
     * 
     * @param array $ids Array of add-on IDs
     * @param array $data Update data
     * @return int|WP_Error Number of updated rows or error
     */
    public function bulk_update_addons($ids, $data) {
        if (empty($ids) || !is_array($ids)) {
            return new WP_Error('invalid_ids', __('Invalid add-on IDs', 'ai-woo-product-generator'));
        }
        
        $updated = 0;
        foreach ($ids as $id) {
            $result = $this->update_addon($id, $data);
            if (!is_wp_error($result)) {
                $updated++;
            }
        }
        
        return $updated;
    }
    
    /**
     * Import add-ons from Excel sheet
     * Parses "Addons" column and creates add-on records
     * 
     * @param int $product_id Product ID
     * @param string $addons_string Addons string (semicolon-separated)
     * @param string|null $group_name Optional group name
     * @return array Array of created add-on IDs
     */
    public function import_from_sheet($product_id, $addons_string, $group_name = null) {
        if (empty($addons_string)) {
            return array();
        }
        
        // Parse addons by semicolon
        $addons_list = array_map('trim', explode(';', $addons_string));
        $addons_list = array_filter($addons_list, function($addon) {
            return !empty($addon);
        });
        
        if (empty($addons_list)) {
            return array();
        }
        
        $created_ids = array();
        
        foreach ($addons_list as $addon_name) {
            // Check if addon already exists for this product with same name and source
            $existing = $this->get_product_addons($product_id, 'sheet');
            $exists = false;
            foreach ($existing as $existing_addon) {
                if (strtolower($existing_addon['addon_name']) === strtolower($addon_name)) {
                    $exists = true;
                    break;
                }
            }
            
            if (!$exists) {
                $addon_data = array(
                    'product_id' => $product_id,
                    'addon_name' => $addon_name,
                    'addon_group' => $group_name,
                    'source' => 'sheet',
                    'status' => 'suggested',
                    'scope' => 'this_product',
                );
                
                $id = $this->create_addon($addon_data);
                if (!is_wp_error($id)) {
                    $created_ids[] = $id;
                }
            }
        }
        
        return $created_ids;
    }
    
    /**
     * Get add-ons count by source
     * 
     * @param int $product_id Product ID
     * @return array
     */
    public function get_addons_count_by_source($product_id) {
        global $wpdb;
        $table_name = $this->database->get_table_name();
        
        $results = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT source, COUNT(*) as count FROM {$table_name} WHERE product_id = %d GROUP BY source",
                $product_id
            ),
            ARRAY_A
        );
        
        $counts = array();
        foreach ($results as $result) {
            $counts[$result['source']] = intval($result['count']);
        }
        
        return $counts;
    }
}
