<?php
/**
 * Batch Image Generator
 * 
 * Handles batch image generation for products and variations
 * with progress tracking
 *
 * @package AI_Woo_Product_Generator
 */

if (!defined('ABSPATH')) {
    exit;
}

class AIWPG_Batch_Image_Generator {
    /**
     * Image client instance
     */
    private $image_client;
    
    /**
     * Logger instance
     */
    private $logger;
    
    /**
     * Progress option name
     */
    private $progress_option = 'aiwpg_image_generation_progress';
    
    /**
     * Constructor
     */
    public function __construct() {
        $this->image_client = new AIWPG_Image_Client();
        $this->logger = AIWPG_Logger::get_instance();
    }
    
    /**
     * Initialize progress tracking
     */
    public function init_progress() {
        // Get all products and variations
        $products = $this->get_all_products();
        $variations = $this->get_all_variations();
        
        $total_items = count($products) + count($variations);
        
        $progress = array(
            'status' => 'running',
            'started_at' => current_time('mysql'),
            'total' => $total_items,
            'completed' => 0,
            'failed' => 0,
            'products' => array(),
            'variations' => array()
        );
        
        // Initialize product progress
        foreach ($products as $product_id) {
            $progress['products'][$product_id] = array(
                'status' => 'pending',
                'type' => 'product'
            );
        }
        
        // Initialize variation progress
        foreach ($variations as $variation_id) {
            $progress['variations'][$variation_id] = array(
                'status' => 'pending',
                'type' => 'variation'
            );
        }
        
        update_option($this->progress_option, $progress);
        
        return $progress;
    }
    
    /**
     * Process one item (product or variation)
     * This is called by the cron job endpoint
     *
     * @return array Result
     */
    public function process_next_item() {
        $progress = $this->get_progress();
        
        if (!$progress || $progress['status'] === 'completed') {
            return array(
                'success' => false,
                'message' => 'No items to process or already completed'
            );
        }
        
        // Find next pending product
        $next_item = null;
        $item_type = null;
        
        foreach ($progress['products'] as $product_id => $item) {
            if ($item['status'] === 'pending') {
                $next_item = $product_id;
                $item_type = 'product';
                break;
            }
        }
        
        // If no pending product, check variations
        if (!$next_item) {
            foreach ($progress['variations'] as $variation_id => $item) {
                if ($item['status'] === 'pending') {
                    $next_item = $variation_id;
                    $item_type = 'variation';
                    break;
                }
            }
        }
        
        if (!$next_item) {
            // All items processed
            $progress['status'] = 'completed';
            update_option($this->progress_option, $progress);
            
            return array(
                'success' => true,
                'message' => 'All items processed',
                'completed' => true
            );
        }
        
        // Mark as processing
        if ($item_type === 'product') {
            $progress['products'][$next_item]['status'] = 'processing';
        } else {
            $progress['variations'][$next_item]['status'] = 'processing';
        }
        update_option($this->progress_option, $progress);
        
        // Generate image
        $result = $this->generate_image_for_item($next_item, $item_type);
        
        // Update progress
        if ($result['success']) {
            if ($item_type === 'product') {
                $progress['products'][$next_item]['status'] = 'completed';
                $progress['products'][$next_item]['attachment_id'] = $result['attachment_id'];
            } else {
                $progress['variations'][$next_item]['status'] = 'completed';
                $progress['variations'][$next_item]['attachment_id'] = $result['attachment_id'];
            }
            $progress['completed']++;
        } else {
            if ($item_type === 'product') {
                $progress['products'][$next_item]['status'] = 'failed';
                $progress['products'][$next_item]['error'] = $result['error'];
            } else {
                $progress['variations'][$next_item]['status'] = 'failed';
                $progress['variations'][$next_item]['error'] = $result['error'];
            }
            $progress['failed']++;
        }
        
        // Check if all done
        if ($progress['completed'] + $progress['failed'] >= $progress['total']) {
            $progress['status'] = 'completed';
        }
        
        update_option($this->progress_option, $progress);
        
        return array(
            'success' => $result['success'],
            'item_id' => $next_item,
            'item_type' => $item_type,
            'progress' => array(
                'completed' => $progress['completed'],
                'failed' => $progress['failed'],
                'total' => $progress['total'],
                'percentage' => round(($progress['completed'] + $progress['failed']) / $progress['total'] * 100, 2)
            )
        );
    }
    
    /**
     * Generate image for a product or variation
     *
     * @param int $item_id Product or variation ID
     * @param string $type 'product' or 'variation'
     * @return array Result
     */
    private function generate_image_for_item($item_id, $type) {
        if ($type === 'product') {
            $product = wc_get_product($item_id);
        } else {
            $product = wc_get_product($item_id);
        }
        
        if (!$product) {
            return array(
                'success' => false,
                'error' => 'Product not found'
            );
        }
        
        $product_name = $product->get_name();
        $product_description = $product->get_short_description();
        
        if (empty($product_description)) {
            $product_description = wp_strip_all_tags($product->get_description());
            if (strlen($product_description) > 200) {
                $product_description = substr($product_description, 0, 200) . '...';
            }
        }
        
        // Get categories
        $categories = wp_get_post_terms($item_id, 'product_cat', array('fields' => 'names'));
        
        $product_data = array(
            'categories' => is_array($categories) ? $categories : array(),
            'tags' => wp_get_post_terms($item_id, 'product_tag', array('fields' => 'names'))
        );
        
        // Generate image
        $result = $this->image_client->generate_product_image($product_name, $product_description, $product_data);
        
        if ($result['success']) {
            // Set as featured image
            set_post_thumbnail($item_id, $result['attachment_id']);
            
            // Mark as generated
            $this->mark_as_generated($item_id);
            
            return array(
                'success' => true,
                'attachment_id' => $result['attachment_id']
            );
        }
        
        return $result;
    }
    
    /**
     * Get all products that need images
     *
     * @return array Product IDs
     */
    private function get_all_products() {
        $args = array(
            'post_type' => 'product',
            'post_status' => 'any',
            'posts_per_page' => -1,
            'fields' => 'ids',
            'meta_query' => array(
                array(
                    'key' => '_aiwpg_image_generated',
                    'compare' => 'NOT EXISTS'
                )
            )
        );
        
        $query = new WP_Query($args);
        return $query->posts;
    }
    
    /**
     * Get all variations that need images
     *
     * @return array Variation IDs
     */
    private function get_all_variations() {
        $args = array(
            'post_type' => 'product_variation',
            'post_status' => 'any',
            'posts_per_page' => -1,
            'fields' => 'ids',
            'meta_query' => array(
                array(
                    'key' => '_aiwpg_image_generated',
                    'compare' => 'NOT EXISTS'
                )
            )
        );
        
        $query = new WP_Query($args);
        return $query->posts;
    }
    
    /**
     * Get current progress
     *
     * @return array|null Progress data
     */
    public function get_progress() {
        return get_option($this->progress_option, null);
    }
    
    /**
     * Reset progress
     */
    public function reset_progress() {
        delete_option($this->progress_option);
    }
    
    /**
     * Mark item as generated (for filtering)
     *
     * @param int $item_id Product or variation ID
     */
    public function mark_as_generated($item_id) {
        update_post_meta($item_id, '_aiwpg_image_generated', current_time('mysql'));
    }
}

