<?php
/**
 * Logger Model
 * Comprehensive error tracking and logging system
 * 
 * Logs errors to file and WordPress debug log
 */

if (!defined('ABSPATH')) {
    exit;
}

class AIWPG_Logger {
    
    /**
     * Single instance
     */
    private static $instance = null;
    
    /**
     * Log file path
     */
    private $log_file;
    
    /**
     * Log directory
     */
    private $log_dir;
    
    /**
     * Maximum log file size (5MB)
     */
    private $max_file_size = 5242880;
    
    /**
     * Get instance
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructor
     */



     
    private function __construct() {
        $upload_dir = wp_upload_dir();
        $this->log_dir = $upload_dir['basedir'] . '/aiwpg-logs';
        $this->log_file = $this->log_dir . '/aiwpg-' . date('Y-m-d') . '.log';
        
        // Create log directory if it doesn't exist
        if (!file_exists($this->log_dir)) {
            wp_mkdir_p($this->log_dir);
            // Add .htaccess to protect logs
            file_put_contents($this->log_dir . '/.htaccess', 'deny from all');
        }
    }
    
    /**
     * Log error
     * 
     * @param string $message Error message
     * @param string $context Context (controller, model, view, etc.)
     * @param array $data Additional data
     * @param string $level Log level (error, warning, info, debug)
     */
    public function log($message, $context = 'general', $data = array(), $level = 'error') {
        $timestamp = current_time('mysql');
        $user_id = get_current_user_id();
        $user_info = $user_id ? get_userdata($user_id) : null;
        $user_name = $user_info ? $user_info->user_login : 'guest';
        
        // Build log entry
        $log_entry = array(
            'timestamp' => $timestamp,
            'level' => strtoupper($level),
            'context' => $context,
            'user' => $user_name,
            'user_id' => $user_id,
            'message' => $message,
        );
        
        // Add additional data if provided
        if (!empty($data)) {
            $log_entry['data'] = $data;
        }
        
        // Add stack trace for errors
        if ($level === 'error') {
            $trace = debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS, 5);
            $log_entry['trace'] = $this->format_trace($trace);
        }
        
        // Format log line
        $log_line = $this->format_log_entry($log_entry);
        
        // Write to file
        $this->write_to_file($log_line);
        
        // Also write to WordPress debug log if enabled
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('[AIWPG ' . strtoupper($level) . '] [' . $context . '] ' . $message);
        }
        
        // If critical error, also send email notification (optional)
        if ($level === 'error' && defined('AIWPG_LOG_EMAIL') && AIWPG_LOG_EMAIL) {
            $this->send_email_notification($log_entry);
        }
    }
    
    /**
     * Format log entry
     * 
     * @param array $entry Log entry
     * @return string Formatted log line
     */
    private function format_log_entry($entry) {
        $line = sprintf(
            "[%s] [%s] [%s] [%s] [ID:%d] %s",
            $entry['timestamp'],
            $entry['level'],
            $entry['context'],
            $entry['user'],
            $entry['user_id'],
            $entry['message']
        );
        
        if (!empty($entry['data'])) {
            $line .= ' | Data: ' . wp_json_encode($entry['data']);
        }
        
        if (!empty($entry['trace'])) {
            $line .= ' | Trace: ' . $entry['trace'];
        }
        
        $line .= PHP_EOL;
        
        return $line;
    }
    
    /**
     * Format stack trace
     * 
     * @param array $trace Stack trace
     * @return string Formatted trace
     */
    private function format_trace($trace) {
        $formatted = array();
        
        foreach ($trace as $index => $frame) {
            if ($index === 0) continue; // Skip logger itself
            
            $file = isset($frame['file']) ? basename($frame['file']) : 'unknown';
            $line = isset($frame['line']) ? $frame['line'] : '?';
            $function = isset($frame['function']) ? $frame['function'] : 'unknown';
            $class = isset($frame['class']) ? $frame['class'] . '::' : '';
            
            $formatted[] = sprintf('%s%s() in %s:%s', $class, $function, $file, $line);
        }
        
        return implode(' -> ', $formatted);
    }
    
    /**
     * Write to log file
     * 
     * @param string $log_line Log line to write
     */
    private function write_to_file($log_line) {
        // Check file size and rotate if needed
        if (file_exists($this->log_file) && filesize($this->log_file) > $this->max_file_size) {
            $this->rotate_log_file();
        }
        
        // Write to file
        $file_handle = fopen($this->log_file, 'a');
        if ($file_handle) {
            fwrite($file_handle, $log_line);
            fclose($file_handle);
        }
    }
    
    /**
     * Rotate log file when it gets too large
     */
    private function rotate_log_file() {
        $backup_file = $this->log_file . '.' . time() . '.bak';
        if (copy($this->log_file, $backup_file)) {
            file_put_contents($this->log_file, '');
            
            // Keep only last 10 backup files
            $backup_files = glob($this->log_dir . '/aiwpg-*.log.*.bak');
            if (count($backup_files) > 10) {
                usort($backup_files, function($a, $b) {
                    return filemtime($a) - filemtime($b);
                });
                
                $files_to_delete = array_slice($backup_files, 0, count($backup_files) - 10);
                foreach ($files_to_delete as $file) {
                    @unlink($file);
                }
            }
        }
    }
    
    /**
     * Send email notification for critical errors
     * 
     * @param array $entry Log entry
     */
    private function send_email_notification($entry) {
        $to = AIWPG_LOG_EMAIL;
        $subject = sprintf('[AIWPG Error] %s - %s', $entry['context'], $entry['message']);
        $message = sprintf(
            "AIWPG Error Report\n\nTimestamp: %s\nLevel: %s\nContext: %s\nUser: %s (ID: %d)\nMessage: %s\n\n",
            $entry['timestamp'],
            $entry['level'],
            $entry['context'],
            $entry['user'],
            $entry['user_id'],
            $entry['message']
        );
        
        if (!empty($entry['data'])) {
            $message .= "Additional Data:\n" . print_r($entry['data'], true) . "\n\n";
        }
        
        if (!empty($entry['trace'])) {
            $message .= "Stack Trace:\n" . $entry['trace'] . "\n";
        }
        
        wp_mail($to, $subject, $message);
    }
    
    /**
     * Get recent log entries
     * 
     * @param int $lines Number of lines to retrieve
     * @return array Log entries
     */
    public function get_recent_logs($lines = 100) {
        if (!file_exists($this->log_file)) {
            return array();
        }
        
        $file_lines = file($this->log_file);
        if ($file_lines === false) {
            return array();
        }
        
        return array_slice($file_lines, -$lines);
    }
    
    /**
     * Clear log file
     */
    public function clear_logs() {
        if (file_exists($this->log_file)) {
            file_put_contents($this->log_file, '');
        }
    }
    
    /**
     * Get log file path
     * 
     * @return string Log file path
     */
    public function get_log_file_path() {
        return $this->log_file;
    }
    
    /**
     * Get log directory path
     * 
     * @return string Log directory path
     */
    public function get_log_dir_path() {
        return $this->log_dir;
    }
}

