<?php
/**
 * Product Model
 * Handles WooCommerce product CRUD operations
 */

if (!defined('ABSPATH')) {
    exit;
}

class AIWPG_Product_Model {
    
    /**
     * Meta key to identify AI-generated products
     */
    private const META_KEY = '_aiwpg_generated';
    
    
    /**
     * Create WooCommerce product
     * 
     * @param array $product_data Product data from Gemini
     * @return int|WP_Error Product ID or error
     */
    public function create_product($product_data) {
        try {
            // Determine product type
            $product_type = isset($product_data['product_type']) ? $product_data['product_type'] : 'simple';
            $is_variable = ($product_type === 'variable' && !empty($product_data['attributes']));
            
            // Create appropriate product type
            if ($is_variable) {
                $product = new WC_Product_Variable();
            } else {
                $product = new WC_Product_Simple();
            }
            
            // Set basic data
            $product->set_name($product_data['title']);
            $product->set_description($product_data['long_description']);
            $product->set_short_description($product_data['short_description']);
            $product->set_sku($product_data['sku']);
            
            // Set prices and stock based on product type
            if (!$is_variable) {
                // === SIMPLE PRODUCT ===
                
                // Validate and set regular price
                $regular_price = null;
                if (isset($product_data['regular_price']) && !empty($product_data['regular_price'])) {
                    $regular_price = $product_data['regular_price'];
                } elseif (isset($product_data['price']) && !empty($product_data['price'])) {
                    // Backward compatibility
                    $regular_price = $product_data['price'];
                }
                
                if ($regular_price !== null) {
                    // Validate price is numeric and positive
                    if (!is_numeric($regular_price) || floatval($regular_price) < 0) {
                        return new WP_Error('invalid_price', 'Regular price must be a positive number');
                    }
                    $product->set_regular_price($regular_price);
                } else {
                    // Simple products should have a price
                    error_log('AIWPG: Warning - Simple product created without regular price');
                }
                
                // Validate and set sale price if provided
                if (isset($product_data['sale_price']) && !empty($product_data['sale_price'])) {
                    $sale_price = $product_data['sale_price'];
                    
                    // Validate sale price is numeric and positive
                    if (!is_numeric($sale_price) || floatval($sale_price) < 0) {
                        return new WP_Error('invalid_sale_price', 'Sale price must be a positive number');
                    }
                    
                    // Validate sale price is less than regular price
                    if ($regular_price !== null && floatval($sale_price) >= floatval($regular_price)) {
                        error_log('AIWPG: Invalid sale price (' . $sale_price . ') - must be less than regular price (' . $regular_price . ')');
                        // Don't set sale price if it's invalid
                    } else {
                        $product->set_sale_price($sale_price);
                    }
                }
                
                // Set stock (only for simple products)
                $product->set_manage_stock(true);
                $product->set_stock_quantity($product_data['stock_quantity']);
                $product->set_stock_status('instock');
                
            } else {
                // === VARIABLE PRODUCT ===
                // IMPORTANT: Variable products should NOT have prices on parent product
                // Prices must be defined on individual variations
                
                // Explicitly clear any prices that may have been set
                $product->set_regular_price('');
                $product->set_sale_price('');
                
                // For variable products, stock is managed at variation level
                $product->set_manage_stock(false);
                $product->set_stock_status('instock');
                
                // Validate that variations exist and have prices
                if (empty($product_data['variations'])) {
                    return new WP_Error(
                        'missing_variations',
                        'Variable product must have at least one variation. Please provide variations data.'
                    );
                }
                
                // Validate each variation has required data
                foreach ($product_data['variations'] as $index => $variation) {
                    if (empty($variation['regular_price'])) {
                        return new WP_Error(
                            'missing_variation_price',
                            sprintf(
                                'Variation #%d is missing regular_price. All variations must have prices.',
                                $index + 1
                            )
                        );
                    }
                    
                    // Validate variation price is numeric
                    if (!is_numeric($variation['regular_price']) || floatval($variation['regular_price']) < 0) {
                        return new WP_Error(
                            'invalid_variation_price',
                            sprintf(
                                'Variation #%d has invalid price. Price must be a positive number.',
                                $index + 1
                            )
                        );
                    }
                    
                    // Validate variation sale price if provided
                    if (!empty($variation['sale_price'])) {
                        if (!is_numeric($variation['sale_price']) || floatval($variation['sale_price']) < 0) {
                            return new WP_Error(
                                'invalid_variation_sale_price',
                                sprintf(
                                    'Variation #%d has invalid sale price. Price must be a positive number.',
                                    $index + 1
                                )
                            );
                        }
                        
                        if (floatval($variation['sale_price']) >= floatval($variation['regular_price'])) {
                            error_log(sprintf(
                                'AIWPG: Variation #%d invalid sale price - must be less than regular price',
                                $index + 1
                            ));
                        }
                    }
                }
            }
            
            // Set status
            $product->set_status('draft'); // Default to draft for review
            
            // Save product first to get ID
            $product_id = $product->save();
            
            if (!$product_id) {
                return new WP_Error('create_failed', 'Failed to create product');
            }
            
            // Set categories
            if (!empty($product_data['categories'])) {
                $this->set_categories($product_id, $product_data['categories']);
            }
            
            // Set tags
            if (!empty($product_data['tags'])) {
                $this->set_tags($product_id, $product_data['tags']);
            }
            
            // Set brand
            if (!empty($product_data['brand'])) {
                $this->set_brand($product_id, $product_data['brand']);
            }
            
            // Handle variable product attributes and variations
            if ($is_variable) {
                error_log('AIWPG: Product is variable, creating attributes and variations');
                error_log('AIWPG: Attributes: ' . print_r($product_data['attributes'], true));
                error_log('AIWPG: Variations: ' . print_r($product_data['variations'], true));
                
                // Create attributes first
                $this->create_product_attributes($product_id, $product_data['attributes']);
                
                // Create variations with error handling
                if (!empty($product_data['variations'])) {
                    $variations_result = $this->create_product_variations($product_id, $product_data['variations'], $product_data['attributes']);
                    
                    // Check if variations creation failed
                    if (is_wp_error($variations_result)) {
                        // Delete the parent product since variations failed
                        $product->delete(true);
                        error_log('AIWPG: Deleted parent product ' . $product_id . ' due to variation creation failure');
                        return $variations_result; // Return the error
                    }
                } else {
                    error_log('AIWPG: No variations data provided!');
                    // This should have been caught in validation above, but as a safety check
                    $product->delete(true);
                    return new WP_Error('no_variations', 'Variable product created but no variations provided');
                }
            } else {
                error_log('AIWPG: Product is simple, skipping attributes and variations');
            }
            
            // Mark as AI-generated
            update_post_meta($product_id, self::META_KEY, time());
            
            return $product_id;
            
        } catch (Exception $e) {
            error_log('AIWPG Create Product Error: ' . $e->getMessage());
            error_log('Stack trace: ' . $e->getTraceAsString());
            return new WP_Error('exception', $e->getMessage());
        }
    }
    
    /**
     * Update WooCommerce product
     * 
     * @param int $product_id Product ID
     * @param array $product_data Updated product data
     * @return bool|WP_Error True on success or error
     */
    public function update_product($product_id, $product_data) {
        try {
            $product = wc_get_product($product_id);
            
            if (!$product) {
                return new WP_Error('not_found', 'Product not found');
            }
            
            // General Tab
            if (isset($product_data['title'])) {
                $product->set_name($product_data['title']);
            }
            
            if (isset($product_data['short_description'])) {
                $product->set_short_description($product_data['short_description']);
            }
            
            if (isset($product_data['long_description'])) {
                $product->set_description($product_data['long_description']);
            }
            
            if (isset($product_data['sku'])) {
                $product->set_sku($product_data['sku']);
            }
            
            if (isset($product_data['regular_price'])) {
                $product->set_regular_price($product_data['regular_price']);
            }
            
            if (isset($product_data['sale_price'])) {
                $product->set_sale_price($product_data['sale_price']);
            }
            
            // Backward compatibility
            if (isset($product_data['price']) && !isset($product_data['regular_price'])) {
                $product->set_regular_price($product_data['price']);
            }
            
            // Inventory Tab
            if (isset($product_data['manage_stock'])) {
                $product->set_manage_stock($product_data['manage_stock']);
            }
            
            if (isset($product_data['stock_quantity'])) {
                $product->set_stock_quantity($product_data['stock_quantity']);
            }
            
            if (isset($product_data['stock_status'])) {
                $product->set_stock_status($product_data['stock_status']);
            }
            
            if (isset($product_data['low_stock_threshold'])) {
                $product->set_low_stock_amount($product_data['low_stock_threshold']);
            }
            
            if (isset($product_data['sold_individually'])) {
                $product->set_sold_individually($product_data['sold_individually']);
            }
            
            // Shipping Tab
            if (isset($product_data['weight'])) {
                $product->set_weight($product_data['weight']);
            }
            
            if (isset($product_data['length'])) {
                $product->set_length($product_data['length']);
            }
            
            if (isset($product_data['width'])) {
                $product->set_width($product_data['width']);
            }
            
            if (isset($product_data['height'])) {
                $product->set_height($product_data['height']);
            }
            
            if (isset($product_data['shipping_class']) && !empty($product_data['shipping_class'])) {
                // Get shipping class term ID from slug
                $shipping_class_term = get_term_by('slug', $product_data['shipping_class'], 'product_shipping_class');
                if ($shipping_class_term && !is_wp_error($shipping_class_term)) {
                    $product->set_shipping_class_id($shipping_class_term->term_id);
                }
            }
            
            // Linked Products Tab
            if (isset($product_data['upsell_ids']) && is_array($product_data['upsell_ids'])) {
                $product->set_upsell_ids(array_map('intval', $product_data['upsell_ids']));
            }
            
            if (isset($product_data['cross_sell_ids']) && is_array($product_data['cross_sell_ids'])) {
                $product->set_cross_sell_ids(array_map('intval', $product_data['cross_sell_ids']));
            }
            
            // Media Tab
            if (isset($product_data['image_id']) && !empty($product_data['image_id'])) {
                $product->set_image_id(intval($product_data['image_id']));
            }
            
            if (isset($product_data['gallery_ids']) && is_array($product_data['gallery_ids'])) {
                $product->set_gallery_image_ids(array_map('intval', array_filter($product_data['gallery_ids'])));
            }
            
            // Settings Tab
            if (isset($product_data['status'])) {
                $product->set_status($product_data['status']);
            }
            
            if (isset($product_data['catalog_visibility'])) {
                $product->set_catalog_visibility($product_data['catalog_visibility']);
            }
            
            if (isset($product_data['featured'])) {
                $product->set_featured($product_data['featured']);
            }
            
            if (isset($product_data['menu_order'])) {
                $product->set_menu_order($product_data['menu_order']);
            }
            
            if (isset($product_data['reviews_allowed'])) {
                $product->set_reviews_allowed($product_data['reviews_allowed']);
            }
            
            // Save product
            $product->save();
            
            // Update categories
            if (isset($product_data['categories'])) {
                $this->set_categories($product_id, $product_data['categories']);
            }
            
            // Update tags
            if (isset($product_data['tags'])) {
                $this->set_tags($product_id, $product_data['tags']);
            }
            
            // Update brand
            if (isset($product_data['brand'])) {
                $this->set_brand($product_id, $product_data['brand']);
            }
            
            return true;
            
        } catch (Exception $e) {
            // Log the error for debugging
            error_log('AIWPG Update Product Error: ' . $e->getMessage());
            error_log('Product ID: ' . $product_id);
            error_log('Stack trace: ' . $e->getTraceAsString());
            
            return new WP_Error('exception', 'Failed to update product: ' . $e->getMessage());
        }
    }
    
    /**
     * Get product data
     * 
     * @param int $product_id Product ID
     * @return array|WP_Error Product data or error
     */
    public function get_product($product_id) {
        $product = wc_get_product($product_id);
        
        if (!$product) {
            return new WP_Error('not_found', 'Product not found');
        }
        
        return array(
            // General
            'id' => $product->get_id(),
            'title' => $product->get_name(),
            'short_description' => $product->get_short_description(),
            'long_description' => $product->get_description(),
            'sku' => $product->get_sku(),
            'regular_price' => $product->get_regular_price(),
            'sale_price' => $product->get_sale_price(),
            'price' => $product->get_price(), // Backward compatibility
            
            // Inventory
            'manage_stock' => $product->get_manage_stock(),
            'stock_quantity' => $product->get_stock_quantity(),
            'stock_status' => $product->get_stock_status(),
            'low_stock_threshold' => $product->get_low_stock_amount(),
            'sold_individually' => $product->get_sold_individually(),
            
            // Shipping
            'weight' => $product->get_weight(),
            'length' => $product->get_length(),
            'width' => $product->get_width(),
            'height' => $product->get_height(),
            'shipping_class' => $product->get_shipping_class(), // Returns slug
            'shipping_class_id' => $product->get_shipping_class_id(), // Returns ID
            
            // Linked Products
            'upsell_ids' => $product->get_upsell_ids(),
            'cross_sell_ids' => $product->get_cross_sell_ids(),
            
            // Media
            'image_id' => $product->get_image_id(),
            'image_url' => wp_get_attachment_url($product->get_image_id()),
            'gallery_ids' => $product->get_gallery_image_ids(),
            
            // Variations
            'variations' => $this->get_product_variations($product_id),
            
            // Settings
            'status' => $product->get_status(),
            'catalog_visibility' => $product->get_catalog_visibility(),
            'featured' => $product->get_featured(),
            'menu_order' => $product->get_menu_order(),
            'reviews_allowed' => $product->get_reviews_allowed(),
            'categories' => $this->get_product_categories($product_id),
            'tags' => $this->get_product_tags($product_id),
            'brand' => $this->get_product_brand($product_id),
        );
    }
    
    /**
     * Get product variations
     */
    private function get_product_variations($product_id) {
        $product = wc_get_product($product_id);
        
        if (!$product || $product->get_type() !== 'variable') {
            return array();
        }
        
        $variations = array();
        $variation_ids = $product->get_children();
        
        foreach ($variation_ids as $variation_id) {
            $variation = wc_get_product($variation_id);
            if ($variation) {
                $variations[] = array(
                    'id' => $variation->get_id(),
                    'name' => $variation->get_name(),
                    'sku' => $variation->get_sku(),
                    'price' => $variation->get_price(),
                    'stock_quantity' => $variation->get_stock_quantity(),
                    'stock_status' => $variation->get_stock_status(),
                );
            }
        }
        
        return $variations;
    }
    
    /**
     * Get products with pagination
     * 
     * @param int $page Page number
     * @param int $per_page Products per page
     * @param string $search Search term
     * @return array Products data
     */
    public function get_products($page = 1, $per_page = 12, $search = '') {
        $args = array(
            'post_type' => 'product',
            'posts_per_page' => $per_page,
            'paged' => $page,
            'post_status' => array('publish', 'draft', 'pending'),
        );
        
        if (!empty($search)) {
            $args['s'] = $search;
        }
        
        $query = new WP_Query($args);
        $products = array();
        
        foreach ($query->posts as $post) {
            $product = wc_get_product($post->ID);
            if ($product) {
                $products[] = array(
                    'id' => $product->get_id(),
                    'title' => $product->get_name(),
                    'short_description' => $product->get_short_description(),
                    'price' => $product->get_regular_price(),
                    'stock_quantity' => $product->get_stock_quantity(),
                    'stock_status' => $product->get_stock_status(),
                    'image_url' => wp_get_attachment_url($product->get_image_id()),
                    'categories' => $this->get_product_categories($product->get_id()),
                );
            }
        }
        
        return array(
            'products' => $products,
            'total' => $query->found_posts,
            'pages' => $query->max_num_pages,
            'current_page' => $page,
        );
    }
    
    /**
     * Search products for autocomplete
     * 
     * @param string $search Search term
     * @param int $limit Results limit
     * @return array Products
     */
    public function search_products($search, $limit = 4) {
        $args = array(
            'post_type' => 'product',
            'posts_per_page' => $limit,
            's' => $search,
            'post_status' => array('publish', 'draft', 'pending'),
        );
        
        $query = new WP_Query($args);
        $products = array();
        
        foreach ($query->posts as $post) {
            $product = wc_get_product($post->ID);
            if ($product) {
                $products[] = array(
                    'id' => $product->get_id(),
                    'title' => $product->get_name(),
                    'short_description' => wp_trim_words($product->get_short_description(), 10),
                    'image_url' => wp_get_attachment_url($product->get_image_id()),
                    'price' => $product->get_regular_price(),
                );
            }
        }
        
        return $products;
    }
    
    /**
     * Delete product
     * 
     * @param int $product_id Product ID
     * @param bool $force Force delete
     * @return bool|WP_Error True on success or error
     */
    public function delete_product($product_id, $force = false) {
        $product = wc_get_product($product_id);
        
        if (!$product) {
            return new WP_Error('not_found', 'Product not found');
        }
        
        $result = $product->delete($force);
        
        return $result ? true : new WP_Error('delete_failed', 'Failed to delete product');
    }
    
    /**
     * Delete all AI-generated products
     * 
     * @return int|WP_Error Number of deleted products or error
     */
    public function delete_all_ai_products() {
        $args = array(
            'post_type' => 'product',
            'posts_per_page' => -1,
            'meta_key' => self::META_KEY,
            'fields' => 'ids',
        );
        
        $product_ids = get_posts($args);
        $deleted = 0;
        
        foreach ($product_ids as $product_id) {
            $result = $this->delete_product($product_id, true);
            if (!is_wp_error($result)) {
                $deleted++;
            }
        }
        
        return $deleted;
    }
    
    /**
     * Delete all WooCommerce products
     * 
     * @return int|WP_Error Number of deleted products or error
     */
    public function delete_all_products() {
        $args = array(
            'post_type' => 'product',
            'posts_per_page' => -1,
            'fields' => 'ids',
        );
        
        $product_ids = get_posts($args);
        $deleted = 0;
        
        foreach ($product_ids as $product_id) {
            $result = $this->delete_product($product_id, true);
            if (!is_wp_error($result)) {
                $deleted++;
            }
        }
        
        return $deleted;
    }
    
    /**
     * Set product categories
     * 
     * @param int $product_id Product ID
     * @param array $categories Category names
     */
    private function set_categories($product_id, $categories) {
        $term_ids = array();
        
        foreach ($categories as $category_name) {
            $term = get_term_by('name', $category_name, 'product_cat');
            
            if (!$term) {
                $result = wp_insert_term($category_name, 'product_cat');
                if (!is_wp_error($result)) {
                    $term_ids[] = $result['term_id'];
                }
            } else {
                $term_ids[] = $term->term_id;
            }
        }
        
        if (!empty($term_ids)) {
            wp_set_object_terms($product_id, $term_ids, 'product_cat');
        }
    }
    
    /**
     * Set product tags
     * 
     * @param int $product_id Product ID
     * @param array $tags Tag names
     */
    private function set_tags($product_id, $tags) {
        $term_ids = array();
        
        foreach ($tags as $tag_name) {
            $term = get_term_by('name', $tag_name, 'product_tag');
            
            if (!$term) {
                $result = wp_insert_term($tag_name, 'product_tag');
                if (!is_wp_error($result)) {
                    $term_ids[] = $result['term_id'];
                }
            } else {
                $term_ids[] = $term->term_id;
            }
        }
        
        if (!empty($term_ids)) {
            wp_set_object_terms($product_id, $term_ids, 'product_tag');
        }
    }
    
    /**
     * Get product categories
     * 
     * @param int $product_id Product ID
     * @return array Category names
     */
    private function get_product_categories($product_id) {
        $terms = get_the_terms($product_id, 'product_cat');
        
        if (!$terms || is_wp_error($terms)) {
            return array();
        }
        
        return array_map(function($term) {
            return $term->name;
        }, $terms);
    }
    
    /**
     * Get product tags
     * 
     * @param int $product_id Product ID
     * @return array Tag names
     */
    private function get_product_tags($product_id) {
        $terms = get_the_terms($product_id, 'product_tag');
        
        if (!$terms || is_wp_error($terms)) {
            return array();
        }
        
        return array_map(function($term) {
            return $term->name;
        }, $terms);
    }
    
    /**
     * Set product brand
     * 
     * @param int $product_id Product ID
     * @param string $brand_name Brand name
     */
    private function set_brand($product_id, $brand_name) {
        $brand_taxonomy = $this->get_brand_taxonomy();
        
        if (!$brand_taxonomy) {
            // No brand taxonomy exists, skip
            return;
        }
        
        $term = get_term_by('name', $brand_name, $brand_taxonomy);
        
        if (!$term) {
            $result = wp_insert_term($brand_name, $brand_taxonomy);
            if (!is_wp_error($result)) {
                wp_set_object_terms($product_id, $result['term_id'], $brand_taxonomy);
            }
        } else {
            wp_set_object_terms($product_id, $term->term_id, $brand_taxonomy);
        }
    }
    
    /**
     * Get product brand
     * 
     * @param int $product_id Product ID
     * @return string|null Brand name or null
     */
    private function get_product_brand($product_id) {
        $brand_taxonomy = $this->get_brand_taxonomy();
        
        if (!$brand_taxonomy) {
            return null;
        }
        
        $terms = get_the_terms($product_id, $brand_taxonomy);
        
        if (!$terms || is_wp_error($terms)) {
            return null;
        }
        
        return $terms[0]->name ?? null;
    }
    
    /**
     * Get active brand taxonomy
     * 
     * @return string|null Active brand taxonomy or null
     */
    private function get_brand_taxonomy() {
        $brand_taxonomies = array('pa_brand', 'product_brand', 'pwb-brand');
        
        foreach ($brand_taxonomies as $taxonomy) {
            if (taxonomy_exists($taxonomy)) {
                return $taxonomy;
            }
        }
        
        return null;
    }
    
    /**
     * Create product attributes for variable products
     * 
     * @param int $product_id Product ID
     * @param array $attributes Attributes data
     */
    private function create_product_attributes($product_id, $attributes) {
        if (empty($attributes)) {
            error_log('AIWPG: No attributes provided for product ' . $product_id);
            return;
        }
        
        error_log('AIWPG: Creating attributes for product ' . $product_id);
        error_log('AIWPG: Attributes data: ' . print_r($attributes, true));
        
        $product_attributes = array();
        
        foreach ($attributes as $index => $attribute_data) {
            $attribute_name = $attribute_data['name'];
            $attribute_options = $attribute_data['options'];
            $is_visible = isset($attribute_data['visible']) ? $attribute_data['visible'] : true;
            $is_variation = isset($attribute_data['variation']) ? $attribute_data['variation'] : true;
            
            error_log('AIWPG: Processing attribute: ' . $attribute_name);
            
            // Create taxonomy name (pa_attributename)
            $taxonomy = 'pa_' . wc_sanitize_taxonomy_name($attribute_name);
            
            error_log('AIWPG: Taxonomy name: ' . $taxonomy);
            
            // Check if attribute taxonomy exists, if not create it
            if (!taxonomy_exists($taxonomy)) {
                error_log('AIWPG: Taxonomy does not exist, creating...');
                
                $attribute_id = wc_create_attribute(array(
                    'name' => $attribute_name,
                    'slug' => wc_sanitize_taxonomy_name($attribute_name),
                    'type' => 'select',
                    'order_by' => 'menu_order',
                    'has_archives' => false,
                ));
                
                if (is_wp_error($attribute_id)) {
                    error_log('AIWPG: Failed to create attribute: ' . $attribute_name . ' - ' . $attribute_id->get_error_message());
                    continue;
                }
                
                error_log('AIWPG: Attribute created with ID: ' . $attribute_id);
                
                // Register the taxonomy
                register_taxonomy($taxonomy, array('product'), array(
                    'hierarchical' => false,
                    'label' => $attribute_name,
                    'query_var' => true,
                    'rewrite' => array('slug' => $taxonomy),
                ));
                
                // Flush rewrite rules
                flush_rewrite_rules();
            } else {
                error_log('AIWPG: Taxonomy already exists: ' . $taxonomy);
            }
            
            // Add terms to the attribute
            $term_ids = array();
            foreach ($attribute_options as $option) {
                error_log('AIWPG: Adding term: ' . $option . ' to ' . $taxonomy);
                
                $term = term_exists($option, $taxonomy);
                
                if (!$term) {
                    $term = wp_insert_term($option, $taxonomy);
                    error_log('AIWPG: Term created: ' . print_r($term, true));
                } else {
                    error_log('AIWPG: Term already exists: ' . print_r($term, true));
                }
                
                if (!is_wp_error($term)) {
                    $term_ids[] = $term['term_id'];
                }
            }
            
            error_log('AIWPG: Term IDs for ' . $attribute_name . ': ' . implode(', ', $term_ids));
            
            // Set terms for the product
            if (!empty($term_ids)) {
                $result = wp_set_object_terms($product_id, $term_ids, $taxonomy);
                error_log('AIWPG: Set object terms result: ' . print_r($result, true));
            }
            
            // Add to product attributes array
            $product_attributes[$taxonomy] = array(
                'name' => $taxonomy,
                'value' => '',
                'position' => $index,
                'is_visible' => $is_visible ? 1 : 0,
                'is_variation' => $is_variation ? 1 : 0,
                'is_taxonomy' => 1,
            );
        }
        
        error_log('AIWPG: Product attributes array: ' . print_r($product_attributes, true));
        
        // Update product attributes
        $result = update_post_meta($product_id, '_product_attributes', $product_attributes);
        error_log('AIWPG: Update post meta result: ' . ($result ? 'Success' : 'Failed'));
    }
    
    /**
     * Create product variations
     * 
     * @param int $product_id Parent product ID
     * @param array $variations Variations data
     * @param array $attributes Attributes data for reference
     */
    private function create_product_variations($product_id, $variations, $attributes) {
        if (empty($variations)) {
            error_log('AIWPG: No variations provided for product ' . $product_id);
            return new WP_Error('no_variations', 'No variations data provided');
        }
        
        error_log('AIWPG: Creating ' . count($variations) . ' variations for product ' . $product_id);
        
        // Track created variation IDs for rollback if needed
        $created_variation_ids = [];
        
        try {
            foreach ($variations as $index => $variation_data) {
            error_log('AIWPG: Creating variation ' . ($index + 1) . ': ' . print_r($variation_data, true));
            
            $variation = new WC_Product_Variation();
            $variation->set_parent_id($product_id);
            
            // Set variation attributes
            $variation_attributes = array();
            if (!empty($variation_data['attributes'])) {
                foreach ($variation_data['attributes'] as $attr_name => $attr_value) {
                    $taxonomy = 'pa_' . wc_sanitize_taxonomy_name($attr_name);
                    $term = get_term_by('name', $attr_value, $taxonomy);
                    
                    if ($term) {
                        $variation_attributes[$taxonomy] = $term->slug;
                        error_log('AIWPG: Set attribute ' . $taxonomy . ' = ' . $term->slug);
                    } else {
                        error_log('AIWPG: Term not found: ' . $attr_value . ' in ' . $taxonomy);
                    }
                }
            }
            $variation->set_attributes($variation_attributes);
            
            // Set variation SKU
            if (!empty($variation_data['sku'])) {
                $variation->set_sku($variation_data['sku']);
                error_log('AIWPG: Set SKU: ' . $variation_data['sku']);
            }
            
            // Set variation prices
            if (isset($variation_data['regular_price']) && !empty($variation_data['regular_price'])) {
                $variation->set_regular_price($variation_data['regular_price']);
                error_log('AIWPG: Set regular price: ' . $variation_data['regular_price']);
            }
            
            if (isset($variation_data['sale_price']) && !empty($variation_data['sale_price'])) {
                $variation->set_sale_price($variation_data['sale_price']);
                error_log('AIWPG: Set sale price: ' . $variation_data['sale_price']);
            }
            
            // Set variation stock
            if (isset($variation_data['stock_quantity'])) {
                $variation->set_manage_stock(true);
                $variation->set_stock_quantity($variation_data['stock_quantity']);
                $variation->set_stock_status('instock');
                error_log('AIWPG: Set stock quantity: ' . $variation_data['stock_quantity']);
            }
            
            // Set variation status
            $variation->set_status('publish');
            
            // Save variation
            $variation_id = $variation->save();
            
            if (!$variation_id) {
                error_log('AIWPG: Failed to create variation ' . ($index + 1) . ' for product ' . $product_id);
                throw new Exception('Failed to create variation ' . ($index + 1));
            }
            
            // Track created variation for potential rollback
            $created_variation_ids[] = $variation_id;
            error_log('AIWPG: Variation created successfully with ID: ' . $variation_id);
        }
        
        error_log('AIWPG: Syncing parent product ' . $product_id);
        
        // Sync parent product
        WC_Product_Variable::sync($product_id);
        
        // Clear cache
        wc_delete_product_transients($product_id);
        
        error_log('AIWPG: All ' . count($created_variation_ids) . ' variations created successfully for product ' . $product_id);
        return true;
        
        } catch (Exception $e) {
            // ROLLBACK: Delete all created variations to maintain data integrity
            error_log('AIWPG: ERROR - Rolling back ' . count($created_variation_ids) . ' variations for product ' . $product_id);
            error_log('AIWPG: Error details: ' . $e->getMessage());
            
            foreach ($created_variation_ids as $vid) {
                $var = wc_get_product($vid);
                if ($var) {
                    $var->delete(true); // Force delete
                    error_log('AIWPG: Rolled back variation ID: ' . $vid);
                }
            }
            
            return new WP_Error(
                'variation_creation_failed',
                'Failed to create all variations. Error: ' . $e->getMessage() . '. All variations have been rolled back to maintain data integrity.'
            );
        }
    }
}
