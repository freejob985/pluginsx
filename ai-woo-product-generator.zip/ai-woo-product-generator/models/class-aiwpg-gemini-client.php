<?php
/**
 * Gemini Client Model
 * Handles communication with Google Gemini 2.0 Flash API
 * Implements 5-key failover system and single/multi-product prompt patterns
 */

if (!defined('ABSPATH')) {
    exit;
}

class AIWPG_Gemini_Client {
    
    /**
     * Gemini API endpoint
     */
    private const API_ENDPOINT = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent';
    
    /**
     * API keys array
     */
    private $api_keys = array();
    
    /**
     * Current key index
     */
    private $current_key_index = 0;
    
    /**
     * Logger
     */
    private $logger;
    
    /**
     * Rate limiting - max requests per minute per key
     */
    private $rate_limit_per_minute = 10;
    
    /**
     * Request timestamps for rate limiting
     */
    private $request_timestamps = array();
    
    /**
     * Max retry attempts with exponential backoff
     */
    private $max_retry_attempts = 3;
    
    /**
     * Constructor
     */
    public function __construct() {
        $this->logger = AIWPG_Logger::get_instance();
        
        // PRIORITY 1: Load from wp_options (settings page)
        $saved_keys = get_option('aiwpg_api_keys', array());
        $keys_from_db = array();
        for ($i = 1; $i <= 5; $i++) {
            if (isset($saved_keys['gemini_' . $i]) && !empty($saved_keys['gemini_' . $i])) {
                $keys_from_db[] = $saved_keys['gemini_' . $i];
            }
        }
        
        // PRIORITY 2: Load from constants (wp-config.php or environment)
        $keys_from_constants = array();
        for ($i = 1; $i <= 5; $i++) {
            $constant = 'AIWPG_GEMINI_API_KEY_' . $i;
            if (defined($constant) && !empty(constant($constant))) {
                $keys_from_constants[] = constant($constant);
            }
        }
        
        // Use database keys if available, otherwise fall back to constants
        $this->api_keys = !empty($keys_from_db) ? $keys_from_db : $keys_from_constants;
        
        // Filter out empty keys
        $this->api_keys = array_filter($this->api_keys, function($key) {
            return !empty($key);
        });
        
        // Re-index array
        $this->api_keys = array_values($this->api_keys);
        
        // Initialize timestamps array for each key
        foreach ($this->api_keys as $index => $key) {
            $this->request_timestamps[$index] = array();
        }
    }
    
    /**
     * Get existing categories from WooCommerce
     * 
     * @return array Category names
     */
    private function get_existing_categories() {
        $categories = get_terms(array(
            'taxonomy' => 'product_cat',
            'hide_empty' => false,
        ));
        
        if (is_wp_error($categories) || empty($categories)) {
            return array();
        }
        
        return array_map(function($cat) {
            return $cat->name;
        }, $categories);
    }
    
    /**
     * Get existing brands from WooCommerce
     * Supports multiple brand taxonomies: pa_brand, product_brand, pwb-brand
     * 
     * @return array Brand names
     */
    private function get_existing_brands() {
        $brand_taxonomies = array('pa_brand', 'product_brand', 'pwb-brand');
        $brands = array();
        
        foreach ($brand_taxonomies as $taxonomy) {
            if (taxonomy_exists($taxonomy)) {
                $terms = get_terms(array(
                    'taxonomy' => $taxonomy,
                    'hide_empty' => false,
                ));
                
                if (!is_wp_error($terms) && !empty($terms)) {
                    $brands = array_merge($brands, array_map(function($term) {
                        return $term->name;
                    }, $terms));
                }
            }
        }
        
        return array_unique($brands);
    }
    
    /**
     * Get existing product attributes
     * 
     * @return array Array of attribute names
     */
    private function get_existing_attributes() {
        $attributes = array();
        
        // Get all product attributes
        $attribute_taxonomies = wc_get_attribute_taxonomies();
        
        if (!empty($attribute_taxonomies)) {
            foreach ($attribute_taxonomies as $attribute) {
                $attributes[] = $attribute->attribute_label;
            }
        }
        
        return $attributes;
    }
    
    /**
     * Get active brand taxonomy
     * 
     * @return string|null Active brand taxonomy or null
     */
    private function get_brand_taxonomy() {
        $brand_taxonomies = array('pa_brand', 'product_brand', 'pwb-brand');
        
        foreach ($brand_taxonomies as $taxonomy) {
            if (taxonomy_exists($taxonomy)) {
                return $taxonomy;
            }
        }
        
        return null;
    }
    
    /**
     * Generate single product
     * 
     * @param string $prompt User's product description
     * @return array|WP_Error Product data or error
     */
    public function generate_single_product($prompt, $product_type = 'automatic') {
        $system_prompt = $this->build_single_product_prompt($prompt, $product_type);
        $response = $this->call_api($system_prompt);
        
        if (is_wp_error($response)) {
            return $response;
        }
        
        return $this->parse_single_product_response($response, $product_type);
    }
    
    /**
     * Generate multiple products
     * 
     * @param array $prompts Array of product descriptions
     * @return array|WP_Error Array of products or error
     */
    public function generate_multiple_products($prompts, $product_type = 'automatic') {
        $system_prompt = $this->build_multi_product_prompt($prompts, $product_type);
        $response = $this->call_api($system_prompt);
        
        if (is_wp_error($response)) {
            return $response;
        }
        
        return $this->parse_multi_product_response($response, $product_type);
    }
    
    /**
     * Build single product prompt
     * 
     * @param string $user_prompt User's product description
     * @return string Complete prompt for Gemini
     */
    private function build_single_product_prompt($user_prompt, $product_type = 'automatic') {
        $existing_categories = $this->get_existing_categories();
        $existing_brands = $this->get_existing_brands();
        $existing_attributes = $this->get_existing_attributes();
        
        $categories_list = !empty($existing_categories) ? 
            "\nEXISTING CATEGORIES (prefer these if relevant): " . implode(', ', $existing_categories) : 
            "";
            
        $brands_list = !empty($existing_brands) ? 
            "\nEXISTING BRANDS (prefer these if relevant): " . implode(', ', $existing_brands) : 
            "";
        
        $attributes_list = !empty($existing_attributes) ? 
            "\nEXISTING ATTRIBUTES (use these if relevant for variable products): " . implode(', ', $existing_attributes) : 
            "";
        


            
        // Determine product type instruction
        $product_type_instruction = '';
        $product_structure = '';
        
        if ($product_type === 'simple') {
            $product_type_instruction = "\n**PRODUCT TYPE**: Create a SIMPLE product (no variations).";
            $product_structure = '{
  "product_type": "simple",
  "title": "Product title (clear, SEO-friendly, under 100 characters)",
  "short_description": "Brief product summary (2-3 sentences, under 200 characters)",
  "long_description": "Detailed product description (multiple paragraphs, features, benefits, use cases)",
  "categories": ["Category1", "Category2"],
  "brand": "Brand name (if applicable, prefer from existing brands list, or create new if product clearly belongs to a specific brand)",
  "tags": ["tag1", "tag2", "tag3"],
  "sku": "Unique SKU code (alphanumeric, 6-12 characters)",
  "regular_price": "99.99",
  "sale_price": "79.99",
  "stock_quantity": 10
}';
        } else if ($product_type === 'variable') {
            $product_type_instruction = "\n**PRODUCT TYPE**: Create a VARIABLE product with attributes and variations.

**IMPORTANT FOR VARIABLE PRODUCTS**:
- If the description mentions specific attributes (colors, sizes, etc.), use those
- If NO attributes are mentioned in the description, YOU MUST intelligently create appropriate attributes based on the product type:
  * For clothing/apparel: Create Color and Size attributes
  * For electronics: Create Color and Storage/Memory attributes
  * For shoes: Create Color and Size attributes
  * For accessories: Create Color and Style attributes
  * For general products: Create at least 2 relevant attributes (Color is usually applicable to most products)
- ALWAYS create at least 2 attributes for variable products
- Create realistic and appropriate options for each attribute
- Generate ALL possible variations (combinations of attributes)

**PRICING FOR VARIABLE PRODUCTS**:
- NEVER add regular_price or sale_price to the main product (parent product)
- ALWAYS add prices to EACH variation individually
- Each variation MUST have its own regular_price
- Each variation can optionally have sale_price (if there's a discount)
- If no price is mentioned in description, estimate realistic prices for each variation
- Variations with premium attributes (larger size, more storage) should have higher prices";
            
            $product_structure = '{
  "product_type": "variable",
  "title": "Product title (clear, SEO-friendly, under 100 characters)",
  "short_description": "Brief product summary (2-3 sentences, under 200 characters)",
  "long_description": "Detailed product description (multiple paragraphs, features, benefits, use cases)",
  "categories": ["Category1", "Category2"],
  "brand": "Brand name (if applicable)",
  "tags": ["tag1", "tag2", "tag3"],
  "sku": "Unique SKU code (alphanumeric, 6-12 characters)",
  "attributes": [
    {
      "name": "Color",
      "options": ["Black", "White", "Blue", "Red"],
      "visible": true,
      "variation": true
    },
    {
      "name": "Size",
      "options": ["S", "M", "L", "XL"],
      "visible": true,
      "variation": true
    }
  ],
  "variations": [
    {
      "attributes": {"Color": "Black", "Size": "S"},
      "sku": "SKU-BLACK-S",
      "regular_price": "99.99",
      "sale_price": "79.99",
      "stock_quantity": 10
    },
    {
      "attributes": {"Color": "Black", "Size": "M"},
      "sku": "SKU-BLACK-M",
      "regular_price": "99.99",
      "sale_price": "79.99",
      "stock_quantity": 10
    }
  ]
}';
        } else {
            $product_type_instruction = "\n**PRODUCT TYPE**: AUTOMATIC - Analyze the description and decide if this should be a SIMPLE or VARIABLE product. If the description mentions variations (colors, sizes, etc.), create a VARIABLE product. Otherwise, create a SIMPLE product.";
            $product_structure = '{
  "product_type": "simple" or "variable",
  "title": "Product title",
  "short_description": "Brief summary",
  "long_description": "Detailed description",
  "categories": ["Category1", "Category2"],
  "brand": "Brand name",
  "tags": ["tag1", "tag2", "tag3"],
  "sku": "Unique SKU",
  "regular_price": "99.99",
  "sale_price": "79.99",
  "stock_quantity": 10,
  "attributes": [...] (only if product_type is "variable"),
  "variations": [...] (only if product_type is "variable")
}';
        }
        
        return "You are a professional e-commerce product content generator. Based on the following product description, generate complete product information.

Product Description:
{$user_prompt}
{$categories_list}
{$brands_list}
{$attributes_list}
{$product_type_instruction}

IMPORTANT INSTRUCTIONS:
1. Generate ONLY valid JSON with NO explanations, NO comments, NO markdown formatting.
2. Use this exact structure:
{$product_structure}

3. Make the content professional, engaging, and suitable for an online store.
4. For categories: FIRST check if any EXISTING CATEGORIES match the product. If yes, use those exact names. If no match, create new appropriate category names.
5. For brand: FIRST check if any EXISTING BRANDS match the product. If yes, use that exact name. If the product clearly belongs to a brand not in the list, create it. If no brand is relevant, you can omit the brand field.
6. For attributes (VARIABLE products only): FIRST check if any EXISTING ATTRIBUTES match what you need. If yes, use those exact names. If no match, create new appropriate attributes.
7. Set a reasonable stock_quantity (default: 10).
8. **PRICING RULES (VERY IMPORTANT)**:
   - If the product description mentions a specific price, use that exact price as regular_price
   - If a sale/discount price is mentioned, set it as sale_price (must be lower than regular_price)
   - If NO price is mentioned in the description, intelligently estimate a realistic market price based on:
     * Product type and category
     * Product quality indicators (premium, budget, standard)
     * Typical market prices for similar products
     * Product features and specifications
   - regular_price should be a number without currency symbols (e.g., \"99.99\" not \"$99.99\")
   - sale_price is optional - only include if there's a discount mentioned or if you want to suggest a promotional price
   - sale_price must always be lower than regular_price
   - Prices should be realistic and appropriate for the product value
9. For VARIABLE products: Create all possible variations based on the attributes. Each variation should have unique SKU, price, and stock.
10. Output ONLY the JSON object, nothing else.";
    }
    
    /**
     * Build multi-product prompt
     * 
     * @param array $user_prompts Array of product descriptions
     * @return string Complete prompt for Gemini
     */
    private function build_multi_product_prompt($user_prompts, $product_type = 'automatic') {
        $existing_categories = $this->get_existing_categories();
        $existing_brands = $this->get_existing_brands();
        $existing_attributes = $this->get_existing_attributes();
        
        $categories_list = !empty($existing_categories) ? 
            "\nEXISTING CATEGORIES (prefer these if relevant): " . implode(', ', $existing_categories) : 
            "";
            
        $brands_list = !empty($existing_brands) ? 
            "\nEXISTING BRANDS (prefer these if relevant): " . implode(', ', $existing_brands) : 
            "";
        
        $attributes_list = !empty($existing_attributes) ? 
            "\nEXISTING ATTRIBUTES (use these if relevant for variable products): " . implode(', ', $existing_attributes) : 
            "";
        
        $products_list = '';
        foreach ($user_prompts as $index => $prompt_data) {
            $num = $index + 1;
            if (is_array($prompt_data)) {
                $desc = $prompt_data['description'] ?? $prompt_data['prompt'] ?? '';
                $qty = $prompt_data['quantity'] ?? 10;
                $products_list .= "{$num}. Description: {$desc} | Quantity: {$qty}\n";
            } else {
                $products_list .= "{$num}. Description: {$prompt_data}\n";
            }
        }
        
        // Product type instruction
        $product_type_instruction = '';
        if ($product_type === 'simple') {
            $product_type_instruction = "\n**PRODUCT TYPE**: Create SIMPLE products (no variations) for ALL products in the list.";
        } else if ($product_type === 'variable') {
            $product_type_instruction = "\n**PRODUCT TYPE**: Create VARIABLE products with attributes and variations for ALL products in the list.

**IMPORTANT FOR VARIABLE PRODUCTS**:
- For EACH product, if the description mentions specific attributes (colors, sizes, etc.), use those
- If NO attributes are mentioned, YOU MUST intelligently create appropriate attributes based on the product type:
  * For clothing/apparel: Create Color and Size attributes
  * For electronics: Create Color and Storage/Memory attributes
  * For shoes: Create Color and Size attributes
  * For accessories: Create Color and Style attributes
  * For general products: Create at least 2 relevant attributes (Color is usually applicable)
- ALWAYS create at least 2 attributes for each variable product
- Create realistic and appropriate options for each attribute
- Generate ALL possible variations (combinations of attributes)";
        } else {
            $product_type_instruction = "\n**PRODUCT TYPE**: AUTOMATIC - For EACH product, analyze its description and decide if it should be SIMPLE or VARIABLE.";
        }
        
        return "You are a professional e-commerce product content generator. Based on the following list of product descriptions, generate complete product information for EACH product.

Product List:
{$products_list}
{$categories_list}
{$brands_list}
{$attributes_list}
{$product_type_instruction}

IMPORTANT INSTRUCTIONS:
1. Generate ONLY valid JSON with NO explanations, NO comments, NO markdown formatting.
2. Use this exact structure:
{
  \"products\": [
    {
      \"product_type\": \"simple\" or \"variable\",
      \"title\": \"Product title (clear, SEO-friendly, under 100 characters)\",
      \"short_description\": \"Brief product summary (2-3 sentences, under 200 characters)\",
      \"long_description\": \"Detailed product description (multiple paragraphs, features, benefits, use cases)\",
      \"categories\": [\"Category1\", \"Category2\"],
      \"brand\": \"Brand name (if applicable, prefer from existing brands list, or create new if product clearly belongs to a specific brand)\",
      \"tags\": [\"tag1\", \"tag2\", \"tag3\"],
      \"sku\": \"Unique SKU code (alphanumeric, 6-12 characters)\",
      \"regular_price\": \"99.99\",
      \"sale_price\": \"79.99\",
      \"stock_quantity\": 10,
      \"attributes\": [...] (only if product_type is \"variable\"),
      \"variations\": [...] (only if product_type is \"variable\")
    }
  ]
}

3. Create one product object for EACH item in the list above.
4. Make each product's content unique, professional, engaging, and suitable for an online store.
5. For categories: FIRST check if any EXISTING CATEGORIES match each product. If yes, use those exact names. If no match, create new appropriate category names.
6. For brand: FIRST check if any EXISTING BRANDS match each product. If yes, use that exact name. If the product clearly belongs to a brand not in the list, create it. If no brand is relevant, you can omit the brand field.
7. Use the specified quantity if provided, otherwise default to 10.
8. Ensure each SKU is unique.
9. **PRICING RULES (VERY IMPORTANT)**:
   - If the product description mentions a specific price, use that exact price as regular_price
   - If a sale/discount price is mentioned, set it as sale_price (must be lower than regular_price)
   - If NO price is mentioned in the description, intelligently estimate a realistic market price based on:
     * Product type and category
     * Product quality indicators (premium, budget, standard)
     * Typical market prices for similar products
     * Product features and specifications
   - regular_price should be a number without currency symbols (e.g., \"99.99\" not \"$99.99\")
   - sale_price is optional - only include if there's a discount mentioned or if you want to suggest a promotional price
   - sale_price must always be lower than regular_price
   - Prices should be realistic and appropriate for the product value
10. Output ONLY the JSON object with the products array, nothing else.";
    }
    
    /**
     * Call Gemini API with failover
     * 
     * @param string $prompt The prompt to send
     * @return string|WP_Error Response text or error
     */
    private function call_api($prompt) {
        // Check if any API keys are configured
        if (empty($this->api_keys)) {
            $this->logger->log(
                'No Gemini API keys configured',
                'gemini_client',
                array('action' => 'Add keys to wp-config.php or environment variables'),
                'error'
            );
            return new WP_Error(
                'no_api_keys',
                'Google Gemini API keys are not configured. Please add them to wp-config.php. See plugin documentation for details.'
            );
        }
        
        $errors = array();
        
        // Try each API key
        for ($i = 0; $i < count($this->api_keys); $i++) {
            $key = $this->api_keys[$i];
            
            // Skip placeholder keys
            if (strpos($key, 'PLACEHOLDER') !== false) {
                $errors[] = "Key " . ($i + 1) . ": Placeholder key (not configured)";
                continue;
            }
            
            // Check rate limiting for this key
            if (!$this->check_rate_limit($i)) {
                $this->logger->log("Rate limit reached for key " . ($i + 1) . ", trying next key", 'info');
                $errors[] = "Key " . ($i + 1) . ": Rate limit exceeded";
                continue;
            }
            
            // Try with exponential backoff
            $response = $this->make_request_with_retry($key, $prompt, $i);
            
            if (!is_wp_error($response)) {
                // Record successful request timestamp
                $this->record_request($i);
                return $response;
            }
            
            $error_msg = $response->get_error_message();
            $errors[] = "Key " . ($i + 1) . ": " . $error_msg;
            
            // If it's a 429 error, skip to next key immediately
            if (strpos($error_msg, '429') !== false || strpos($error_msg, 'Resource exhausted') !== false) {
                $this->logger->log("Key " . ($i + 1) . " exhausted, moving to next key", 'warning');
                continue;
            }
        }
        
        // All keys failed
        return new WP_Error(
            'all_keys_failed',
            'All Gemini API keys failed. Errors: ' . implode(' | ', $errors)
        );
    }
    
    /**
     * Check rate limit for a specific key
     *
     * @param int $key_index Key index
     * @return bool True if within limit
     */
    private function check_rate_limit($key_index) {
        $now = time();
        $one_minute_ago = $now - 60;
        
        // Clean old timestamps
        $this->request_timestamps[$key_index] = array_filter(
            $this->request_timestamps[$key_index],
            function($timestamp) use ($one_minute_ago) {
                return $timestamp > $one_minute_ago;
            }
        );
        
        // Check if we're within limit
        return count($this->request_timestamps[$key_index]) < $this->rate_limit_per_minute;
    }
    
    /**
     * Record request timestamp
     *
     * @param int $key_index Key index
     */
    private function record_request($key_index) {
        $this->request_timestamps[$key_index][] = time();
    }
    
    /**
     * Make request with retry and exponential backoff
     *
     * @param string $api_key API key
     * @param string $prompt Prompt
     * @param int $key_index Key index for logging
     * @return string|WP_Error Response or error
     */
    private function make_request_with_retry($api_key, $prompt, $key_index) {
        $attempt = 0;
        $last_error = null;
        
        while ($attempt < $this->max_retry_attempts) {
            $attempt++;
            
            if ($attempt > 1) {
                // Exponential backoff: 2^attempt seconds
                $wait_time = pow(2, $attempt - 1);
                $this->logger->log("Retry attempt {$attempt} for key " . ($key_index + 1) . " after {$wait_time}s wait", 'info');
                sleep($wait_time);
            }
            
            $response = $this->make_request($api_key, $prompt);
            
            if (!is_wp_error($response)) {
                if ($attempt > 1) {
                    $this->logger->log("Request succeeded on attempt {$attempt} for key " . ($key_index + 1), 'info');
                }
                return $response;
            }
            
            $last_error = $response;
            $error_msg = $response->get_error_message();
            
            // Don't retry on certain errors
            if (strpos($error_msg, '400') !== false || 
                strpos($error_msg, 'Invalid') !== false ||
                strpos($error_msg, 'API key not valid') !== false) {
                $this->logger->log("Non-retryable error for key " . ($key_index + 1) . ": " . $error_msg, 'error');
                break;
            }
            
            // Don't retry 429 errors - just move to next key
            if (strpos($error_msg, '429') !== false || strpos($error_msg, 'Resource exhausted') !== false) {
                $this->logger->log("Resource exhausted for key " . ($key_index + 1) . ", won't retry", 'warning');
                break;
            }
            
            $this->logger->log("Attempt {$attempt} failed for key " . ($key_index + 1) . ": " . $error_msg, 'warning');
        }
        
        return $last_error;
    }
    
    /**
     * Make HTTP request to Gemini API
     * 
     * @param string $api_key API key to use
     * @param string $prompt The prompt
     * @return string|WP_Error Response or error
     */
    private function make_request($api_key, $prompt) {
        $url = self::API_ENDPOINT;
        
        $body = array(
            'contents' => array(
                array(
                    'parts' => array(
                        array(
                            'text' => $prompt
                        )
                    )
                )
            )
        );
        
        $args = array(
            'headers' => array(
                'Content-Type' => 'application/json',
                'X-goog-api-key' => $api_key,
            ),
            'body' => wp_json_encode($body),
            'method' => 'POST',
            'timeout' => 60,
            'data_format' => 'body',
        );
        
        $response = wp_remote_post($url, $args);
        
        if (is_wp_error($response)) {
            $this->logger->log(
                'Gemini API request failed',
                'gemini_client',
                array('error' => $response->get_error_message(), 'key_index' => $this->current_key_index + 1),
                'error'
            );
            return $response;
        }
        
        $response_code = wp_remote_retrieve_response_code($response);
        $response_body = wp_remote_retrieve_body($response);
        
        if ($response_code !== 200) {
            $this->logger->log(
                'Gemini API returned error status',
                'gemini_client',
                array('status_code' => $response_code, 'response' => substr($response_body, 0, 500), 'key_index' => $this->current_key_index + 1),
                'error'
            );
            return new WP_Error(
                'api_error',
                "API returned status {$response_code}: {$response_body}"
            );
        }
        
        $data = json_decode($response_body, true);
        
        if (json_last_error() !== JSON_ERROR_NONE) {
            $this->logger->log(
                'Failed to parse Gemini API response',
                'gemini_client',
                array('json_error' => json_last_error_msg(), 'response_preview' => substr($response_body, 0, 200)),
                'error'
            );
            return new WP_Error('json_error', 'Failed to parse API response');
        }
        
        if (!isset($data['candidates'][0]['content']['parts'][0]['text'])) {
            $this->logger->log(
                'Invalid Gemini API response structure',
                'gemini_client',
                array('response_keys' => array_keys($data)),
                'error'
            );
            return new WP_Error('invalid_response', 'Invalid API response structure');
        }
        
        $this->logger->log(
            'Gemini API request successful',
            'gemini_client',
            array('key_index' => $this->current_key_index + 1, 'response_length' => strlen($data['candidates'][0]['content']['parts'][0]['text'])),
            'info'
        );
        
        return $data['candidates'][0]['content']['parts'][0]['text'];
    }
    
    /**
     * Parse single product response
     * 
     * @param string $response JSON response from Gemini
     * @return array|WP_Error Product data or error
     */
    private function parse_single_product_response($response, $product_type = 'automatic') {
        // Clean the response (remove markdown code blocks if present)
        $response = $this->clean_json_response($response);
        
        $data = json_decode($response, true);
        
        if (json_last_error() !== JSON_ERROR_NONE) {
            return new WP_Error(
                'parse_error',
                'Failed to parse product JSON: ' . json_last_error_msg() . '. Response: ' . substr($response, 0, 500)
            );
        }
        
        // Validate required fields
        $required = array('title', 'short_description', 'long_description');
        foreach ($required as $field) {
            if (empty($data[$field])) {
                return new WP_Error('missing_field', "Missing required field: {$field}");
            }
        }
        
        // Set defaults
        $data['categories'] = $data['categories'] ?? array();
        $data['tags'] = $data['tags'] ?? array();
        $data['sku'] = $data['sku'] ?? $this->generate_sku();
        $data['stock_quantity'] = $data['stock_quantity'] ?? 10;
        $data['product_type'] = $data['product_type'] ?? 'simple';
        
        // Ensure product_type is set correctly
        if ($product_type !== 'automatic') {
            $data['product_type'] = $product_type;
        }
        
        return $data;
    }
    
    /**
     * Parse multi-product response
     * 
     * @param string $response JSON response from Gemini
     * @return array|WP_Error Array of products or error
     */
    private function parse_multi_product_response($response, $product_type = 'automatic') {
        // Clean the response
        $response = $this->clean_json_response($response);
        
        $data = json_decode($response, true);
        
        if (json_last_error() !== JSON_ERROR_NONE) {
            return new WP_Error(
                'parse_error',
                'Failed to parse products JSON: ' . json_last_error_msg()
            );
        }
        
        if (!isset($data['products']) || !is_array($data['products'])) {
            return new WP_Error('invalid_format', 'Response must contain "products" array');
        }
        
        $products = array();
        foreach ($data['products'] as $index => $product) {
            // Validate required fields
            $required = array('title', 'short_description', 'long_description');
            foreach ($required as $field) {
                if (empty($product[$field])) {
                    return new WP_Error(
                        'missing_field',
                        "Product #{$index}: Missing required field: {$field}"
                    );
                }
            }
            
            // Set defaults
            $product['categories'] = $product['categories'] ?? array();
            $product['tags'] = $product['tags'] ?? array();
            $product['sku'] = $product['sku'] ?? $this->generate_sku();
            $product['stock_quantity'] = $product['stock_quantity'] ?? 10;
            $product['product_type'] = $product['product_type'] ?? 'simple';
            
            // Ensure product_type is set correctly
            if ($product_type !== 'automatic') {
                $product['product_type'] = $product_type;
            }
            
            $products[] = $product;
        }
        
        return $products;
    }
    
    /**
     * Clean JSON response (remove markdown code blocks, extra text)
     * 
     * @param string $response Raw response
     * @return string Cleaned JSON
     */
    private function clean_json_response($response) {
        // Remove markdown code blocks
        $response = preg_replace('/^```json\s*/i', '', $response);
        $response = preg_replace('/\s*```$/', '', $response);
        $response = trim($response);
        
        // Try to extract JSON if there's extra text
        if (preg_match('/\{.*\}/s', $response, $matches)) {
            $response = $matches[0];
        }
        
        return $response;
    }
    

    
    /**
     * Generate unique SKU
     * 
     * @return string Generated SKU
     */
    private function generate_sku() {
        return 'AIWPG-' . strtoupper(substr(md5(uniqid(rand(), true)), 0, 8));
    }
    
    /**
     * Generate simple text with Gemini API
     * 
     * @param string $prompt User prompt
     * @return string|WP_Error Generated text or error
     */
    public function generate_text($prompt) {
        // Use call_api method which handles failover
        $response = $this->call_api($prompt);
        
        if (is_wp_error($response)) {
            return $response;
        }
        
        return trim($response);
    }
    
    /**
     * Make API request with body array (for internal use with generation config)
     * 
     * @param array $body Request body
     * @return array|WP_Error Response data or error
     */

     private function make_api_request($body) {
        $errors = array();
        
        // Try each API key
        for ($i = 0; $i < count($this->api_keys); $i++) {
            $key = $this->api_keys[$i];
            
            // Skip placeholder keys
            if (strpos($key, 'PLACEHOLDER') !== false) {
                $errors[] = "Key " . ($i + 1) . ": Placeholder key (not configured)";
                continue;
            }
            
            $url = self::API_ENDPOINT . '?key=' . $key;
            
            $args = array(
                'headers' => array(
                    'Content-Type' => 'application/json',
                ),
                'body' => wp_json_encode($body),
                'method' => 'POST',
                'timeout' => 60,
                'data_format' => 'body',
            );
            
            $response = wp_remote_post($url, $args);
            
            if (is_wp_error($response)) {
                $errors[] = "Key " . ($i + 1) . ": " . $response->get_error_message();
                continue;
            }
            
            $response_code = wp_remote_retrieve_response_code($response);
            $response_body = wp_remote_retrieve_body($response);
            
            if ($response_code !== 200) {
                $errors[] = "Key " . ($i + 1) . ": API returned status {$response_code}";
                continue;
            }
            
            $data = json_decode($response_body, true);
            
            if (json_last_error() !== JSON_ERROR_NONE) {
                $errors[] = "Key " . ($i + 1) . ": Failed to parse JSON response";
                continue;
            }
            
            return $data;
        }
        
        // All keys failed
        return new WP_Error(
            'all_keys_failed',
            'All Gemini API keys failed. Errors: ' . implode(' | ', $errors)
        );
    }
}
