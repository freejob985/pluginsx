<?php
/**
 * Cron-Job.org API Client
 * 
 * Handles communication with cron-job.org API for managing cron jobs
 *
 * @package AI_Woo_Product_Generator
 */

if (!defined('ABSPATH')) {
    exit;
}

class AIWPG_CronJob_Client {
    /**
     * API Endpoint
     */
    private $api_endpoint = 'https://api.cron-job.org';
    
    /**
     * API Key
     */
    private $api_key;
    
    /**
     * Logger instance
     */
    private $logger;
    
    /**
     * Constructor
     */
    public function __construct() {
        $this->logger = AIWPG_Logger::get_instance();
        
        // Get API key from settings
        $cron_settings = get_option('aiwpg_cron_settings', array());
        $this->api_key = isset($cron_settings['api_key']) ? $cron_settings['api_key'] : '';
    }
    
    /**
     * Set API key
     */
    public function set_api_key($api_key) {
        $this->api_key = $api_key;
    }
    
    /**
     * Create a new cron job
     *
     * @param string $url The URL to call
     * @param array $schedule Schedule configuration
     * @param bool $enabled Whether the job is enabled
     * @param string $title Job title
     * @return array Result with jobId or error
     */
    public function create_job($url, $schedule = array(), $enabled = true, $title = 'AI Product Image Generator') {
        if (empty($this->api_key)) {
            return array(
                'success' => false,
                'error' => 'Cron-job.org API key is not configured'
            );
        }
        
        // Default schedule: every minute
        $default_schedule = array(
            'timezone' => 'UTC',
            'expiresAt' => 0,
            'hours' => array(-1),
            'mdays' => array(-1),
            'minutes' => array(-1),
            'months' => array(-1),
            'wdays' => array(-1)
        );
        
        $schedule = wp_parse_args($schedule, $default_schedule);
        
        $body = array(
            'job' => array(
                'url' => $url,
                'enabled' => $enabled,
                'saveResponses' => true,
                'title' => $title,
                'schedule' => $schedule
            )
        );
        
        $args = array(
            'headers' => array(
                'Content-Type' => 'application/json',
                'Authorization' => 'Bearer ' . $this->api_key
            ),
            'body' => wp_json_encode($body),
            'method' => 'PUT',
            'timeout' => 30
        );
        
        $response = wp_remote_request($this->api_endpoint . '/jobs', $args);
        
        if (is_wp_error($response)) {
            $this->logger->log('Cron-job.org API error: ' . $response->get_error_message(), 'error');
            return array(
                'success' => false,
                'error' => $response->get_error_message()
            );
        }
        
        $status_code = wp_remote_retrieve_response_code($response);
        $response_body = wp_remote_retrieve_body($response);
        $decoded = json_decode($response_body, true);
        
        if ($status_code === 200 && isset($decoded['jobId'])) {
            $this->logger->log('Cron job created successfully. Job ID: ' . $decoded['jobId'], 'info');
            return array(
                'success' => true,
                'jobId' => $decoded['jobId']
            );
        }
        
        $error_message = isset($decoded['message']) ? $decoded['message'] : 'Unknown error';
        $this->logger->log('Failed to create cron job. Status: ' . $status_code . ', Error: ' . $error_message, 'error');
        
        return array(
            'success' => false,
            'error' => $error_message,
            'status_code' => $status_code
        );
    }
    
    /**
     * Update an existing cron job
     *
     * @param int $job_id Job ID
     * @param array $updates Updates to apply
     * @return array Result
     */
    public function update_job($job_id, $updates = array()) {
        if (empty($this->api_key)) {
            return array(
                'success' => false,
                'error' => 'Cron-job.org API key is not configured'
            );
        }
        
        $body = array(
            'job' => $updates
        );
        
        $args = array(
            'headers' => array(
                'Content-Type' => 'application/json',
                'Authorization' => 'Bearer ' . $this->api_key
            ),
            'body' => wp_json_encode($body),
            'method' => 'PATCH',
            'timeout' => 30
        );
        
        $response = wp_remote_request($this->api_endpoint . '/jobs/' . $job_id, $args);
        
        if (is_wp_error($response)) {
            return array(
                'success' => false,
                'error' => $response->get_error_message()
            );
        }
        
        $status_code = wp_remote_retrieve_response_code($response);
        
        if ($status_code === 200) {
            return array(
                'success' => true
            );
        }
        
        $response_body = wp_remote_retrieve_body($response);
        $decoded = json_decode($response_body, true);
        $error_message = isset($decoded['message']) ? $decoded['message'] : 'Unknown error';
        
        return array(
            'success' => false,
            'error' => $error_message,
            'status_code' => $status_code
        );
    }
    
    /**
     * Delete a cron job
     *
     * @param int $job_id Job ID
     * @return array Result
     */
    public function delete_job($job_id) {
        if (empty($this->api_key)) {
            return array(
                'success' => false,
                'error' => 'Cron-job.org API key is not configured'
            );
        }
        
        $args = array(
            'headers' => array(
                'Content-Type' => 'application/json',
                'Authorization' => 'Bearer ' . $this->api_key
            ),
            'method' => 'DELETE',
            'timeout' => 30
        );
        
        $response = wp_remote_request($this->api_endpoint . '/jobs/' . $job_id, $args);
        
        if (is_wp_error($response)) {
            return array(
                'success' => false,
                'error' => $response->get_error_message()
            );
        }
        
        $status_code = wp_remote_retrieve_response_code($response);
        
        if ($status_code === 200) {
            return array(
                'success' => true
            );
        }
        
        return array(
            'success' => false,
            'error' => 'Failed to delete job',
            'status_code' => $status_code
        );
    }
    
    /**
     * Get job details
     *
     * @param int $job_id Job ID
     * @return array Job details or error
     */
    public function get_job($job_id) {
        if (empty($this->api_key)) {
            return array(
                'success' => false,
                'error' => 'Cron-job.org API key is not configured'
            );
        }
        
        $args = array(
            'headers' => array(
                'Content-Type' => 'application/json',
                'Authorization' => 'Bearer ' . $this->api_key
            ),
            'timeout' => 30
        );
        
        $response = wp_remote_get($this->api_endpoint . '/jobs/' . $job_id, $args);
        
        if (is_wp_error($response)) {
            return array(
                'success' => false,
                'error' => $response->get_error_message()
            );
        }
        
        $status_code = wp_remote_retrieve_response_code($response);
        $response_body = wp_remote_retrieve_body($response);
        $decoded = json_decode($response_body, true);
        
        if ($status_code === 200 && isset($decoded['jobDetails'])) {
            return array(
                'success' => true,
                'job' => $decoded['jobDetails']
            );
        }
        
        return array(
            'success' => false,
            'error' => 'Failed to get job details',
            'status_code' => $status_code
        );
    }
    
    /**
     * List all jobs
     *
     * @return array List of jobs or error
     */
    public function list_jobs() {
        if (empty($this->api_key)) {
            return array(
                'success' => false,
                'error' => 'Cron-job.org API key is not configured'
            );
        }
        
        $args = array(
            'headers' => array(
                'Content-Type' => 'application/json',
                'Authorization' => 'Bearer ' . $this->api_key
            ),
            'timeout' => 30
        );
        
        $response = wp_remote_get($this->api_endpoint . '/jobs', $args);
        
        if (is_wp_error($response)) {
            return array(
                'success' => false,
                'error' => $response->get_error_message()
            );
        }
        
        $status_code = wp_remote_retrieve_response_code($response);
        $response_body = wp_remote_retrieve_body($response);
        $decoded = json_decode($response_body, true);
        
        if ($status_code === 200 && isset($decoded['jobs'])) {
            return array(
                'success' => true,
                'jobs' => $decoded['jobs']
            );
        }
        
        return array(
            'success' => false,
            'error' => 'Failed to list jobs',
            'status_code' => $status_code
        );
    }
    
    /**
     * Build schedule array based on interval
     *
     * @param string $interval 'minute' or 'hour'
     * @param string $timezone Timezone (default: UTC)
     * @return array Schedule configuration
     */
    public function build_schedule($interval = 'minute', $timezone = 'UTC') {
        $schedule = array(
            'timezone' => $timezone,
            'expiresAt' => 0,
            'hours' => array(-1),
            'mdays' => array(-1),
            'minutes' => array(-1),
            'months' => array(-1),
            'wdays' => array(-1)
        );
        
        if ($interval === 'minute') {
            // Every minute
            $schedule['minutes'] = array(-1);
        } elseif ($interval === 'hour') {
            // Every hour at minute 0
            $schedule['minutes'] = array(0);
        }
        
        return $schedule;
    }
}

