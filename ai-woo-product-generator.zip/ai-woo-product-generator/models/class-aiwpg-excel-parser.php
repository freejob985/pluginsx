<?php
/**
 * Excel Parser Model
 * Handles parsing of Excel (.xlsx, .csv) files into normalized product data
 */

if (!defined('ABSPATH')) {
    exit;
}

class AIWPG_Excel_Parser {
    
    /**
     * Logger instance
     */
    private $logger;
    
    /**
     * Constructor
     */
    public function __construct() {
        $this->logger = AIWPG_Logger::get_instance();
    }
    
    /**
     * Parse Excel file
     * 
     * @param string $filepath Path to uploaded file
     * @return array|WP_Error Normalized array of product rows or error
     */
    public function parse($filepath) {
        if (!file_exists($filepath)) {
            return new WP_Error('file_not_found', __('File not found', 'ai-woo-product-generator'));
        }
        
        $extension = strtolower(pathinfo($filepath, PATHINFO_EXTENSION));
        
        switch ($extension) {
            case 'xlsx':
            case 'xls':
                return $this->parse_excel($filepath);
            case 'csv':
                return $this->parse_csv($filepath);
            default:
                return new WP_Error('invalid_format', __('Unsupported file format. Please use .xlsx, .xls, or .csv', 'ai-woo-product-generator'));
        }
    }
    
    /**
     * Parse Excel file using PhpSpreadsheet (if available) or fallback method
     * 
     * @param string $filepath Path to Excel file
     * @return array|WP_Error
     */
    private function parse_excel($filepath) {
        // Try PhpSpreadsheet first (if installed)
        if (class_exists('PhpOffice\PhpSpreadsheet\IOFactory')) {
            return $this->parse_with_phpspreadsheet($filepath);
        }
        
        // Fallback: Try SimpleXLSX
        if (class_exists('SimpleXLSX')) {
            return $this->parse_with_simplexlsx($filepath);
        }
        
        // Last resort: Return error (but client-side parsing should be used instead)
        return new WP_Error(
            'library_missing',
            __('Server-side Excel parsing requires PhpSpreadsheet library. The plugin will automatically use client-side parsing with SheetJS (no library needed).', 'ai-woo-product-generator')
        );
    }
    
    /**
     * Parse with PhpSpreadsheet
     */
    private function parse_with_phpspreadsheet($filepath) {
        try {
            $spreadsheet = \PhpOffice\PhpSpreadsheet\IOFactory::load($filepath);
            $worksheet = $spreadsheet->getActiveSheet();
            $rows = $worksheet->toArray();
            
            if (empty($rows) || count($rows) < 2) {
                return new WP_Error('empty_file', __('Excel file is empty or has no data rows', 'ai-woo-product-generator'));
            }
            
            // First row is headers
            $headers = array_map('strtolower', array_map('trim', $rows[0]));
            $data_rows = array_slice($rows, 1);
            
            return $this->normalize_rows($headers, $data_rows);
            
        } catch (Exception $e) {
            $this->logger->log('PhpSpreadsheet parse error', 'excel_parser', array('error' => $e->getMessage()), 'error');
            return new WP_Error('parse_error', __('Failed to parse Excel file: ', 'ai-woo-product-generator') . $e->getMessage());
        }
    }
    
    /**
     * Parse with SimpleXLSX
     */
    private function parse_with_simplexlsx($filepath) {
        try {
            $xlsx = SimpleXLSX::parse($filepath);
            
            if (!$xlsx) {
                return new WP_Error('parse_error', __('Failed to parse Excel file', 'ai-woo-product-generator'));
            }
            
            $rows = $xlsx->rows();
            
            if (empty($rows) || count($rows) < 2) {
                return new WP_Error('empty_file', __('Excel file is empty or has no data rows', 'ai-woo-product-generator'));
            }
            
            // First row is headers
            $headers = array_map('strtolower', array_map('trim', $rows[0]));
            $data_rows = array_slice($rows, 1);
            
            return $this->normalize_rows($headers, $data_rows);
            
        } catch (Exception $e) {
            $this->logger->log('SimpleXLSX parse error', 'excel_parser', array('error' => $e->getMessage()), 'error');
            return new WP_Error('parse_error', __('Failed to parse Excel file: ', 'ai-woo-product-generator') . $e->getMessage());
        }
    }
    
    /**
     * Parse CSV file
     * 
     * @param string $filepath Path to CSV file
     * @return array|WP_Error
     */
    private function parse_csv($filepath) {
        $handle = fopen($filepath, 'r');
        
        if (!$handle) {
            return new WP_Error('file_open_error', __('Failed to open CSV file', 'ai-woo-product-generator'));
        }
        
        // Detect delimiter
        $delimiter = $this->detect_csv_delimiter($filepath);
        
        // Read headers (first line)
        $headers = array_map('strtolower', array_map('trim', fgetcsv($handle, 0, $delimiter)));
        
        if (empty($headers)) {
            fclose($handle);
            return new WP_Error('empty_file', __('CSV file is empty', 'ai-woo-product-generator'));
        }
        
        // Read data rows
        $data_rows = array();
        while (($row = fgetcsv($handle, 0, $delimiter)) !== false) {
            if (!empty(array_filter($row))) { // Skip empty rows
                $data_rows[] = $row;
            }
        }
        
        fclose($handle);
        
        if (empty($data_rows)) {
            return new WP_Error('empty_file', __('CSV file has no data rows', 'ai-woo-product-generator'));
        }
        
        return $this->normalize_rows($headers, $data_rows);
    }
    
    /**
     * Detect CSV delimiter
     */
    private function detect_csv_delimiter($filepath) {
        $delimiters = array(',', ';', "\t", '|');
        $max_count = 0;
        $detected = ',';
        
        $handle = fopen($filepath, 'r');
        if ($handle) {
            $first_line = fgets($handle);
            fclose($handle);
            
            foreach ($delimiters as $delimiter) {
                $count = substr_count($first_line, $delimiter);
                if ($count > $max_count) {
                    $max_count = $count;
                    $detected = $delimiter;
                }
            }
        }
        
        return $detected;
    }
    
    /**
     * Normalize rows to standard format
     * 
     * @param array $headers Column headers
     * @param array $data_rows Data rows
     * @return array Normalized product data
     */
    private function normalize_rows($headers, $data_rows) {
        $normalized = array();
        
        // Map of possible column names to standard keys
        $column_map = array(
            // Product Name
            'product name' => 'name',
            'name' => 'name',
            'product' => 'name',
            'title' => 'name',
            'item name' => 'name',
            
            // Description
            'description' => 'description',
            'desc' => 'description',
            'product description' => 'description',
            
            // Base Price
            'base price' => 'baseprice',
            'price' => 'baseprice',
            'base_price' => 'baseprice',
            'regular price' => 'baseprice',
            'regular_price' => 'baseprice',
            
            // SKU
            'sku' => 'sku',
            'product sku' => 'sku',
            'product_sku' => 'sku',
            
            // Raw Category
            'raw category' => 'rawcategory',
            'category' => 'rawcategory',
            'raw_category' => 'rawcategory',
            'categories' => 'rawcategory',
            
            // Raw Tags
            'raw tags' => 'rawtags',
            'tags' => 'rawtags',
            'raw_tags' => 'rawtags',
            'product tags' => 'rawtags',
            
            // Notes
            'notes' => 'notes',
            'note' => 'notes',
            'remarks' => 'notes',
            'extra notes' => 'notes',
            
            // Additions (الإضافات)
            'additions' => 'additions',
            'addition' => 'additions',
            'add-ons' => 'additions',
            'addons' => 'additions',
            'الإضافات' => 'additions',
            'إضافات' => 'additions',
            
            // AI Module (موديول الذكاء الاصطناعي)
            'ai module' => 'ai_module',
            'ai_module' => 'ai_module',
            'module' => 'ai_module',
            'موديول' => 'ai_module',
            'موديول الذكاء الاصطناعي' => 'ai_module',
        );
        
        foreach ($data_rows as $row_index => $row) {
            // Create associative array from row data
            $row_data = array();
            foreach ($headers as $col_index => $header) {
                $value = isset($row[$col_index]) ? trim($row[$col_index]) : '';
                $header_lower = strtolower(trim($header));
                
                // Map to standard key
                if (isset($column_map[$header_lower])) {
                    $row_data[$column_map[$header_lower]] = $value;
                } else {
                    // Store unknown columns for reference
                    $row_data['_custom_' . $header_lower] = $value;
                }
            }
            
            // Validate required fields
            if (empty($row_data['name'])) {
                $this->logger->log(
                    'Row skipped: missing product name',
                    'excel_parser',
                    array('row' => $row_index + 2), // +2 because headers + 0-index
                    'warning'
                );
                continue;
            }
            
            // Set defaults
            $normalized[] = array(
                'name' => $row_data['name'] ?? '',
                'description' => $row_data['description'] ?? '',
                'baseprice' => $row_data['baseprice'] ?? '',
                'sku' => $row_data['sku'] ?? '',
                'rawcategory' => $row_data['rawcategory'] ?? '',
                'rawtags' => $row_data['rawtags'] ?? '',
                'notes' => $row_data['notes'] ?? '',
                'additions' => $row_data['additions'] ?? '',
                'ai_module' => $row_data['ai_module'] ?? '',
                '_row_index' => $row_index + 2, // Store original row number for error reporting
                '_raw_data' => $row_data, // Store all raw data for reference
            );
        }
        
        return $normalized;
    }
    
    /**
     * Normalize client-side parsed data (from SheetJS)
     * 
     * @param array $parsed_data Array of objects from SheetJS
     * @return array Normalized product data
     */
    public function normalize_client_parsed_data($parsed_data) {
        if (empty($parsed_data) || !is_array($parsed_data)) {
            return array();
        }
        
        $normalized = array();
        
        foreach ($parsed_data as $row_index => $row) {
            if (is_object($row)) {
                $row = (array) $row;
            }
            
            if (!is_array($row)) {
                continue;
            }
            
            // Map columns to standard format
            $row_data = array();
            
            // Map common column names
            foreach ($row as $key => $value) {
                $key_lower = strtolower(trim($key));
                
                // Map to standard keys
                if (in_array($key_lower, array('product name', 'name', 'product', 'title', 'item name'))) {
                    $row_data['name'] = trim($value);
                } elseif (in_array($key_lower, array('description', 'desc', 'product description'))) {
                    $row_data['description'] = trim($value);
                } elseif (in_array($key_lower, array('base price', 'price', 'base_price', 'regular price', 'regular_price'))) {
                    $row_data['baseprice'] = trim($value);
                } elseif (in_array($key_lower, array('sku', 'product sku', 'product_sku'))) {
                    $row_data['sku'] = trim($value);
                } elseif (in_array($key_lower, array('raw category', 'category', 'raw_category', 'categories'))) {
                    $row_data['rawcategory'] = trim($value);
                } elseif (in_array($key_lower, array('raw tags', 'tags', 'raw_tags', 'product tags'))) {
                    $row_data['rawtags'] = trim($value);
                } elseif (in_array($key_lower, array('notes', 'note', 'remarks', 'extra notes'))) {
                    $row_data['notes'] = trim($value);
                } elseif (in_array($key_lower, array('additions', 'addition', 'add-ons', 'addons', 'الإضافات', 'إضافات'))) {
                    $row_data['additions'] = trim($value);
                } elseif (in_array($key_lower, array('ai module', 'ai_module', 'module', 'موديول', 'موديول الذكاء الاصطناعي'))) {
                    $row_data['ai_module'] = trim($value);
                } else {
                    // Store unknown columns
                    $row_data['_custom_' . $key_lower] = trim($value);
                }
            }
            
            // Validate required fields
            if (empty($row_data['name'])) {
                $this->logger->log(
                    'Row skipped: missing product name',
                    'excel_parser',
                    array('row' => $row_index + 1),
                    'warning'
                );
                continue;
            }
            
            // Set defaults
            $normalized[] = array(
                'name' => $row_data['name'] ?? '',
                'description' => $row_data['description'] ?? '',
                'baseprice' => $row_data['baseprice'] ?? '',
                'sku' => $row_data['sku'] ?? '',
                'rawcategory' => $row_data['rawcategory'] ?? '',
                'rawtags' => $row_data['rawtags'] ?? '',
                'notes' => $row_data['notes'] ?? '',
                'additions' => $row_data['additions'] ?? '',
                'ai_module' => $row_data['ai_module'] ?? '',
                '_row_index' => $row_index + 1,
                '_raw_data' => $row_data,
            );
        }
        
        return $normalized;
    }
}





