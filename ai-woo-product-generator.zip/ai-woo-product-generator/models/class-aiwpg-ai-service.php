<?php
/**
 * AI Service Model
 * Handles AI-powered product classification and enrichment
 * Detects product type, category, kitchen assignment, and add-on groups
 */

if (!defined('ABSPATH')) {
    exit;
}

class AIWPG_AI_Service {
    
    /**
     * Gemini client
     */
    private $gemini_client;
    
    /**
     * Logger
     */
    private $logger;
    
    /**
     * Constructor
     */
    public function __construct() {
        $this->gemini_client = new AIWPG_Gemini_Client();
        $this->logger = AIWPG_Logger::get_instance();
    }
    
    /**
     * Enrich a single product row with AI classification
     * 
     * @param array $row Parsed row data with keys: name, description, baseprice, notes, etc.
     * @param string $ai_module Optional AI module to use (kitchen, food, beverages, mixed)
     * @return array|WP_Error Enriched data with type, category, kitchen, isaddon, addongroup
     */
    public function enrich_product_row($row, $ai_module = '') {
        // Use AI module from row if not provided
        if (empty($ai_module) && !empty($row['ai_module'])) {
            $ai_module = $row['ai_module'];
        }
        
        // Build prompt for AI classification
        $prompt = $this->build_classification_prompt($row, $ai_module);
        
        // Call AI API
        $response = $this->gemini_client->generate_text($prompt);
        
        if (is_wp_error($response)) {
            $this->logger->log(
                'AI enrichment failed',
                'ai_service',
                array(
                    'product_name' => $row['name'] ?? '',
                    'error' => $response->get_error_message()
                ),
                'error'
            );
            
            // Return fallback data instead of error
            return $this->get_fallback_classification($row);
        }
        
        // Parse AI response
        $enriched = $this->parse_classification_response($response, $row);
        
        return $enriched;
    }
    
    /**
     * Enrich multiple product rows (batch processing)
     * 
     * @param array $rows Array of parsed rows
     * @param int $batch_size Number of rows to process per batch (default: 10)
     * @param string $ai_module Optional AI module to use for all rows (overrides row-level module)
     * @return array Array of enriched rows with original data preserved
     */
    public function enrich_product_rows($rows, $batch_size = 10, $ai_module = '') {
        $enriched = array();
        $total = count($rows);
        $batches = array_chunk($rows, $batch_size);
        
        foreach ($batches as $batch_index => $batch) {
            $this->logger->log(
                'Processing AI enrichment batch',
                'ai_service',
                array(
                    'batch' => $batch_index + 1,
                    'total_batches' => count($batches),
                    'batch_size' => count($batch),
                    'ai_module' => $ai_module
                ),
                'info'
            );
            
            foreach ($batch as $row) {
                // Use global AI module if provided, otherwise use row-level module
                $row_ai_module = !empty($ai_module) ? $ai_module : ($row['ai_module'] ?? '');
                $enriched_row = $this->enrich_product_row($row, $row_ai_module);
                
                // Merge enriched data with original row
                $enriched[] = array_merge($row, $enriched_row);
            }
            
            // Small delay between batches to avoid rate limiting
            if ($batch_index < count($batches) - 1) {
                usleep(500000); // 0.5 second delay
            }
        }
        
        return $enriched;
    }
    
    /**
     * Build classification prompt for AI
     */
    private function build_classification_prompt($row, $ai_module = '') {
        $name = $row['name'] ?? '';
        $description = $row['description'] ?? '';
        $notes = $row['notes'] ?? '';
        $baseprice = $row['baseprice'] ?? '';
        $additions = $row['additions'] ?? '';
        
        // Use AI module from parameter or row data
        if (empty($ai_module) && !empty($row['ai_module'])) {
            $ai_module = $row['ai_module'];
        }
        
        // Get existing WooCommerce categories
        $existing_categories = $this->get_existing_categories();
        $categories_list = !empty($existing_categories) ? 
            "\nEXISTING CATEGORIES (prefer these if relevant): " . implode(', ', $existing_categories) : 
            "";
        
        // Get existing Woo Food add-on groups (if Woo Food is active)
        // Check if WooCommerce Food and Orders Jet plugins are active
        $addon_groups = array();
        if (function_exists('exwoofood_get_option')) {
            // Check if add-ons feature is enabled
            if (exwoofood_get_option('exfood_addon') === 'yes') {
                $addon_groups = $this->get_existing_addon_groups();
                
                // Log add-on groups found
                $this->logger->log(
                    'Found Woo Food add-on groups',
                    'ai_service',
                    array('addon_groups' => $addon_groups, 'count' => count($addon_groups)),
                    'info'
                );
            }
        } else {
            // Log that Woo Food is not active
            $this->logger->log(
                'WooCommerce Food plugin not active',
                'ai_service',
                array(),
                'info'
            );
        }
        
        $addon_groups_list = !empty($addon_groups) ? 
            "\nEXISTING ADD-ON GROUPS (prefer these if relevant): " . implode(', ', $addon_groups) : 
            "\nNOTE: No existing add-on groups found. You can create new ones like 'Pizza Extras', 'Burger Add-ons', etc.";
        
        // Build AI module instruction
        $ai_module_instruction = '';
        if (!empty($ai_module)) {
            $module_map = array(
                'kitchen' => '👨‍🍳 Kitchen - Focus on kitchen station assignment and food preparation',
                'food' => '🍕 Food - Focus on food items classification',
                'beverages' => '🥤 Beverages - Focus on drinks and beverages',
                'mixed' => '🍽 Mixed Only - Handle both food and beverages'
            );
            $module_text = isset($module_map[$ai_module]) ? $module_map[$ai_module] : $ai_module;
            $ai_module_instruction = "\n\nAI MODULE SELECTED: {$module_text}\nPlease use this module's focus when classifying the product.";
        }
        
        // Build additions instruction
        $additions_instruction = '';
        if (!empty($additions)) {
            $additions_instruction = "\n- Additions/Add-ons specified: {$additions}\nNOTE: This product may be related to or should be grouped with these additions.";
        }
        
        return "You are a classification engine for restaurant menu items. Analyze the following product information and classify it.

Product Information:
- Name: {$name}
- Description: {$description}
- Base Price: {$baseprice}
- Notes: {$notes}{$additions_instruction}{$categories_list}
{$addon_groups_list}{$ai_module_instruction}

Classify this product according to the following rules:

1. **Type**: Determine if this is \"Food\" or \"Beverage\"
   - If name/description contains: coffee, tea, latte, cappuccino, juice, drink, soda, beverage, smoothie, shake, water → Type = \"Beverage\"
   - Otherwise → Type = \"Food\"

2. **Category**: Assign appropriate WooCommerce category
   - Use existing categories if relevant, otherwise suggest a new appropriate category
   - For beverages: \"Hot Drinks\", \"Cold Drinks\", \"Coffee\", \"Tea\", etc.
   - For food: \"Main Dishes\", \"Appetizers\", \"Desserts\", \"Sides\", \"Pizza\", etc.

3. **Kitchen**: Assign kitchen station
   - For Beverages: \"Barista Station\" or \"Bar Station\"
   - For Food: \"Main Kitchen\", \"Dessert Station\", \"Pizza Station\", \"Grill Station\", etc.

4. **Tags**: Generate relevant tags (array of 2-4 tags)
   - Examples: [\"coffee\", \"hot drink\"], [\"pizza\", \"italian\"], [\"dessert\", \"sweet\"]

5. **Is Add-on**: Determine if this is an add-on/extra/side item - THIS IS VERY IMPORTANT
   - **CRITICAL INSTRUCTIONS**: You MUST carefully analyze the Notes field FIRST - it often contains explicit hints like \"extra\", \"add-on\", \"side\", \"إضافي\", \"إضافة\"
   - **Add-on detection keywords** (if ANY found in name/notes/description → isaddon = true):
     * English: \"extra\", \"add-on\", \"addon\", \"side\", \"topping\", \"sauce\", \"cheese\", \"additional\", \"supplement\", \"optional\", \"plus\", \"add\", \"with extra\", \"additional\"
     * Arabic: \"إضافي\", \"إضافة\", \"جانبي\", \"اضافي\", \"اضافة\", \"إضافات\"
   - **Examples of ADD-ONS** (always mark isaddon = true):
     * \"Extra Cheese\" → isaddon = true
     * \"Side Fries\" → isaddon = true
     * \"Add Onion\" → isaddon = true
     * \"Topping: Mushrooms\" → isaddon = true
     * Any product with \"extra\" or \"add-on\" in name/notes → isaddon = true
   - **Examples of NOT ADD-ONS** (always mark isaddon = false):
     * \"Pizza Margherita\" → isaddon = false (complete dish)
     * \"Caesar Salad\" → isaddon = false (complete dish)
     * \"Coffee Latte\" → isaddon = false (complete beverage)
   - **Decision logic**: If the product can be ordered as a standalone item → isaddon = false. If it's meant to be added to another product → isaddon = true

6. **Add-on Group**: If isaddon = true, you MUST provide an appropriate add-on group name
   - **REQUIRED**: When isaddon = true, ALWAYS provide a group name (NEVER return null or empty)
   - **Step 1**: Check EXISTING ADD-ON GROUPS listed above - if any match, use that EXACT name
   - **Step 2**: If no match, analyze product name and create logical group name:
     * Contains \"pizza\" → \"Pizza Extras\" or \"Pizza Toppings\"
     * Contains \"burger\" → \"Burger Add-ons\" or \"Burger Extras\"
     * Contains \"salad\" → \"Salad Toppings\" or \"Salad Add-ons\"
     * Contains \"coffee\", \"drink\", \"beverage\" → \"Drink Extras\" or \"Coffee Add-ons\"
     * General/unknown → \"Extras\" or \"Add-ons\"
   - **If isaddon = false**: Set addongroup to null
   - **CRITICAL RULE**: When isaddon = true, addongroup CANNOT be null or empty - always provide a group name

IMPORTANT: Return ONLY valid JSON with NO explanations, NO markdown formatting, NO code blocks.

Expected JSON structure:
{
  \"type\": \"Food\" or \"Beverage\",
  \"category\": \"Category Name\",
  \"tags\": [\"tag1\", \"tag2\", \"tag3\"],
  \"kitchen\": \"Kitchen Station Name\",
  \"isaddon\": true or false,
  \"addongroup\": \"Add-on Group Name\" or null
}";
    }
    
    /**
     * Parse AI classification response
     */
    private function parse_classification_response($response, $row) {
        // Clean JSON response
        $response = $this->clean_json_response($response);
        
        $data = json_decode($response, true);
        
        if (json_last_error() !== JSON_ERROR_NONE || !is_array($data)) {
            $this->logger->log(
                'Failed to parse AI classification response',
                'ai_service',
                array(
                    'product_name' => $row['name'] ?? '',
                    'response' => substr($response, 0, 500),
                    'json_error' => json_last_error_msg()
                ),
                'warning'
            );
            
            // Return fallback
            return $this->get_fallback_classification($row);
        }
        
        // Validate and set defaults
        $isaddon = false;
        if (isset($data['isaddon'])) {
            // Handle multiple formats
            if ($data['isaddon'] === true || $data['isaddon'] === 'true' || $data['isaddon'] === '1' || $data['isaddon'] === 1) {
                $isaddon = true;
            }
        }
        
        // Fallback: Check name/notes for add-on keywords if not explicitly set
        if (!$isaddon) {
            $search_text = strtolower(($row['name'] ?? '') . ' ' . ($row['notes'] ?? '') . ' ' . ($row['description'] ?? ''));
            if (preg_match('/\b(extra|add-on|addon|side|topping|sauce|cheese|additional|supplement|optional|plus|add|إضافي|إضافة)\b/i', $search_text)) {
                $isaddon = true;
                $this->logger->log(
                    'Detected add-on via keyword fallback',
                    'ai_service',
                    array('product_name' => $row['name'] ?? ''),
                    'info'
                );
            }
        }
        
        $addongroup = null;
        if ($isaddon) {
            if (!empty($data['addongroup'])) {
                $addongroup = sanitize_text_field($data['addongroup']);
            } else {
                // Suggest default group based on product name
                $name_lower = strtolower($row['name'] ?? '');
                if (strpos($name_lower, 'pizza') !== false) {
                    $addongroup = 'Pizza Extras';
                } elseif (strpos($name_lower, 'burger') !== false) {
                    $addongroup = 'Burger Add-ons';
                } elseif (strpos($name_lower, 'salad') !== false) {
                    $addongroup = 'Salad Toppings';
                } elseif (strpos($name_lower, 'coffee') !== false || strpos($name_lower, 'drink') !== false) {
                    $addongroup = 'Drink Extras';
                } else {
                    $addongroup = 'Extras';
                }
                
                $this->logger->log(
                    'Auto-suggested add-on group',
                    'ai_service',
                    array('product_name' => $row['name'] ?? '', 'addongroup' => $addongroup),
                    'info'
                );
            }
        }
        
        $enriched = array(
            'type' => isset($data['type']) && in_array($data['type'], array('Food', 'Beverage')) ? $data['type'] : 'Food',
            'category' => isset($data['category']) ? sanitize_text_field($data['category']) : 'Uncategorized',
            'tags' => isset($data['tags']) && is_array($data['tags']) ? array_map('sanitize_text_field', $data['tags']) : array(),
            'kitchen' => isset($data['kitchen']) ? sanitize_text_field($data['kitchen']) : 'Main Kitchen',
            'isaddon' => $isaddon,
            'addongroup' => $addongroup,
        );
        
        return $enriched;
    }
    
    /**
     * Get fallback classification when AI fails
     */
    private function get_fallback_classification($row) {
        $name = strtolower($row['name'] ?? '');
        $notes = strtolower($row['notes'] ?? '');
        $combined = $name . ' ' . $notes;
        
        // Simple keyword-based fallback
        $type = 'Food';
        $isaddon = false;
        
        // Detect beverage
        if (preg_match('/\b(coffee|tea|latte|cappuccino|juice|drink|soda|beverage|smoothie|shake|water)\b/i', $combined)) {
            $type = 'Beverage';
        }
        
        // Detect add-on - check more keywords
        $addon_keywords = array(
            'extra', 'add-on', 'addon', 'side', 'topping', 'sauce', 'cheese', 'additional',
            'supplement', 'optional', 'plus', 'add', 'إضافي', 'إضافة', 'جانبي', 'اضافي', 'اضافة'
        );
        
        foreach ($addon_keywords as $keyword) {
            if (stripos($combined, $keyword) !== false) {
                $isaddon = true;
                break;
            }
        }
        
        // Determine add-on group for fallback
        $addongroup = null;
        if ($isaddon) {
            $name_lower = strtolower($row['name'] ?? '');
            $notes_lower = strtolower($row['notes'] ?? '');
            $combined_lower = $name_lower . ' ' . $notes_lower;
            
            if (strpos($combined_lower, 'pizza') !== false) {
                $addongroup = 'Pizza Extras';
            } elseif (strpos($combined_lower, 'burger') !== false) {
                $addongroup = 'Burger Add-ons';
            } elseif (strpos($combined_lower, 'salad') !== false) {
                $addongroup = 'Salad Toppings';
            } elseif (strpos($combined_lower, 'coffee') !== false || strpos($combined_lower, 'drink') !== false || strpos($combined_lower, 'beverage') !== false) {
                $addongroup = 'Drink Extras';
            } else {
                $addongroup = 'Extras';
            }
        }
        
        return array(
            'type' => $type,
            'category' => $type === 'Beverage' ? 'Drinks' : 'Main Dishes',
            'tags' => array(),
            'kitchen' => $type === 'Beverage' ? 'Barista Station' : 'Main Kitchen',
            'isaddon' => $isaddon,
            'addongroup' => $addongroup,
        );
    }
    
    /**
     * Clean JSON response (remove markdown, code blocks)
     */
    private function clean_json_response($response) {
        // Remove markdown code blocks
        $response = preg_replace('/^```json\s*/i', '', $response);
        $response = preg_replace('/\s*```$/', '', $response);
        $response = preg_replace('/^```\s*/i', '', $response);
        $response = trim($response);
        
        // Try to extract JSON if there's extra text
        if (preg_match('/\{.*\}/s', $response, $matches)) {
            $response = $matches[0];
        }
        
        return $response;
    }
    
    /**
     * Get existing WooCommerce categories
     */
    private function get_existing_categories() {
        $categories = get_terms(array(
            'taxonomy' => 'product_cat',
            'hide_empty' => false,
            'number' => 50, // Limit to avoid huge prompts
        ));
        
        if (is_wp_error($categories) || empty($categories)) {
            return array();
        }
        
        return array_map(function($cat) {
            return $cat->name;
        }, $categories);
    }
    
    /**
     * Get existing Woo Food add-on groups (if plugin is active)
     * Also checks for Orders Jet Integration plugin
     */
    private function get_existing_addon_groups() {
        // Check if WooCommerce Food plugin is active
        if (!function_exists('exwoofood_get_option')) {
            $this->logger->log(
                'WooCommerce Food plugin not active - cannot fetch add-on groups',
                'ai_service',
                array(),
                'info'
            );
            return array();
        }
        
        // Check if Orders Jet Integration is active
        $orders_jet_active = class_exists('Orders_Jet_Integration') || defined('ORDERS_JET_PLUGIN_DIR');
        if ($orders_jet_active) {
            $this->logger->log(
                'Orders Jet Integration plugin detected',
                'ai_service',
                array(),
                'info'
            );
        }
        
        // Check if add-ons feature is enabled
        // First check if add-ons are disabled
        $all_options = get_option('exwoofood_options', array());
        $addons_disabled = isset($all_options['exwoofood_disable_exoptions']) && 
                          $all_options['exwoofood_disable_exoptions'] === 'yes';
        
        if ($addons_disabled) {
            $this->logger->log(
                'WooCommerce Food add-ons feature is disabled',
                'ai_service',
                array(),
                'info'
            );
            return array();
        }
        
        // Check if explicitly enabled
        $addon_enabled = isset($all_options['exfood_addon']) && $all_options['exfood_addon'] === 'yes';
        
        if (!$addon_enabled) {
            // Default: add-ons are enabled unless explicitly disabled
            // So we continue to fetch groups
        }
        
        global $wpdb;
        $addon_groups = array();
        
        // Query products with exwo_options meta (Woo Food add-on groups)
        // This is the main meta key used by Woo Food for add-on groups
        $results = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT post_id, meta_value 
                FROM {$wpdb->postmeta} 
                WHERE meta_key = %s
                LIMIT 100",
                'exwo_options'
            )
        );
        
        if ($results) {
            foreach ($results as $row) {
                $options = maybe_unserialize($row->meta_value);
                
                if (is_array($options)) {
                    foreach ($options as $option) {
                        if (isset($option['_name']) && !empty($option['_name'])) {
                            $group_name = trim(sanitize_text_field($option['_name']));
                            if (!empty($group_name) && !in_array($group_name, $addon_groups)) {
                                $addon_groups[] = $group_name;
                            }
                        }
                    }
                }
            }
        }
        
        // Also check _exwoofood_addition_data meta key (alternative structure)
        $results2 = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT post_id, meta_value 
                FROM {$wpdb->postmeta} 
                WHERE meta_key = %s
                LIMIT 100",
                '_exwoofood_addition_data'
            )
        );
        
        if ($results2) {
            foreach ($results2 as $row) {
                $addon_data = maybe_unserialize($row->meta_value);
                
                if (is_array($addon_data)) {
                    foreach ($addon_data as $group) {
                        if (isset($group['_name']) && !empty($group['_name'])) {
                            $group_name = trim(sanitize_text_field($group['_name']));
                            if (!empty($group_name) && !in_array($group_name, $addon_groups)) {
                                $addon_groups[] = $group_name;
                            }
                        }
                    }
                }
            }
        }
        
        $unique_groups = array_unique($addon_groups);
        
        $this->logger->log(
            'Retrieved Woo Food add-on groups',
            'ai_service',
            array(
                'groups' => $unique_groups,
                'count' => count($unique_groups),
                'orders_jet_active' => $orders_jet_active
            ),
            'info'
        );
        
        return $unique_groups;
    }
    
    /**
     * Generate add-on suggestions using AI
     * 
     * @param string $product_name Product name
     * @param string $product_description Product description
     * @param string $category_name Product category name
     * @param string $kitchen Kitchen name (optional)
     * @return array|WP_Error Array of suggested add-ons or error
     */
    public function generate_addon_suggestions($product_name, $product_description = '', $category_name = '', $kitchen = '') {
        // Build prompt for AI
        $prompt = "You are a product add-on suggestion expert for a restaurant/food business.\n\n";
        $prompt .= "Product Name: {$product_name}\n";
        
        if (!empty($product_description)) {
            $prompt .= "Product Description: {$product_description}\n";
        }
        
        if (!empty($category_name)) {
            $prompt .= "Category: {$category_name}\n";
        }
        
        if (!empty($kitchen)) {
            $prompt .= "Kitchen: {$kitchen}\n";
        }
        
        $prompt .= "\n";
        $prompt .= "Suggest 5-8 relevant add-ons for this product. For each add-on, provide:\n";
        $prompt .= "- name: The add-on name (e.g., 'Extra Cheese', 'Extra Olives')\n";
        $prompt .= "- group: A group name for organizing (e.g., 'Pizza Addons', 'Burger Extras')\n";
        $prompt .= "- price: Suggested price (number only, default 0.00)\n";
        $prompt .= "- price_type: 'flat_fee' or 'per_quantity'\n";
        $prompt .= "- selection_type: 'single_choice', 'multiple_choice', or 'checkbox'\n\n";
        $prompt .= "Return ONLY a valid JSON array of objects, no other text. Example format:\n";
        $prompt .= "[{\"name\":\"Extra Cheese\",\"group\":\"Pizza Addons\",\"price\":2.50,\"price_type\":\"flat_fee\",\"selection_type\":\"checkbox\"},...]\n";
        
        // Call AI API
        $response = $this->gemini_client->generate_text($prompt);
        
        if (is_wp_error($response)) {
            $this->logger->log(
                'AI add-on suggestions failed',
                'ai_service',
                array(
                    'product_name' => $product_name,
                    'error' => $response->get_error_message()
                ),
                'error'
            );
            return $response;
        }
        
        // Parse JSON response
        $suggestions = json_decode($response, true);
        
        if (json_last_error() !== JSON_ERROR_NONE || !is_array($suggestions)) {
            $this->logger->log(
                'Failed to parse AI add-on suggestions',
                'ai_service',
                array(
                    'product_name' => $product_name,
                    'response' => $response,
                    'json_error' => json_last_error_msg()
                ),
                'error'
            );
            
            // Return fallback suggestions
            return $this->get_fallback_addon_suggestions($product_name, $category_name);
        }
        
        // Validate and sanitize suggestions
        $valid_suggestions = array();
        foreach ($suggestions as $suggestion) {
            if (isset($suggestion['name']) && !empty($suggestion['name'])) {
                $valid_suggestions[] = array(
                    'name' => sanitize_text_field($suggestion['name']),
                    'group' => isset($suggestion['group']) ? sanitize_text_field($suggestion['group']) : 'Extras',
                    'price' => isset($suggestion['price']) ? floatval($suggestion['price']) : 0.00,
                    'price_type' => isset($suggestion['price_type']) && in_array($suggestion['price_type'], array('flat_fee', 'per_quantity')) 
                        ? $suggestion['price_type'] 
                        : 'flat_fee',
                    'selection_type' => isset($suggestion['selection_type']) && in_array($suggestion['selection_type'], array('single_choice', 'multiple_choice', 'checkbox'))
                        ? $suggestion['selection_type']
                        : 'multiple_choice',
                );
            }
        }
        
        return $valid_suggestions;
    }
    
    /**
     * Get fallback add-on suggestions when AI fails
     * 
     * @param string $product_name Product name
     * @param string $category_name Category name
     * @return array Fallback suggestions
     */
    private function get_fallback_addon_suggestions($product_name, $category_name = '') {
        $suggestions = array();
        
        // Basic fallback based on common add-ons
        $common_addons = array(
            array('name' => 'Extra Cheese', 'group' => 'Extras', 'price' => 2.00, 'price_type' => 'flat_fee', 'selection_type' => 'checkbox'),
            array('name' => 'Extra Sauce', 'group' => 'Extras', 'price' => 1.00, 'price_type' => 'flat_fee', 'selection_type' => 'checkbox'),
            array('name' => 'Extra Toppings', 'group' => 'Extras', 'price' => 1.50, 'price_type' => 'flat_fee', 'selection_type' => 'checkbox'),
        );
        
        // Category-specific suggestions
        $category_lower = strtolower($category_name);
        if (strpos($category_lower, 'pizza') !== false) {
            $suggestions[] = array('name' => 'Extra Cheese', 'group' => 'Pizza Addons', 'price' => 2.50, 'price_type' => 'flat_fee', 'selection_type' => 'checkbox');
            $suggestions[] = array('name' => 'Extra Olives', 'group' => 'Pizza Addons', 'price' => 1.50, 'price_type' => 'flat_fee', 'selection_type' => 'checkbox');
            $suggestions[] = array('name' => 'Extra Mushrooms', 'group' => 'Pizza Addons', 'price' => 2.00, 'price_type' => 'flat_fee', 'selection_type' => 'checkbox');
        } elseif (strpos($category_lower, 'burger') !== false) {
            $suggestions[] = array('name' => 'Extra Cheese', 'group' => 'Burger Extras', 'price' => 1.50, 'price_type' => 'flat_fee', 'selection_type' => 'checkbox');
            $suggestions[] = array('name' => 'Extra Bacon', 'group' => 'Burger Extras', 'price' => 3.00, 'price_type' => 'flat_fee', 'selection_type' => 'checkbox');
            $suggestions[] = array('name' => 'Extra Pickles', 'group' => 'Burger Extras', 'price' => 0.50, 'price_type' => 'flat_fee', 'selection_type' => 'checkbox');
        } else {
            $suggestions = $common_addons;
        }
        
        return $suggestions;
    }
}

