# Template and Quality Scoring Features Documentation

## نظرة عامة | Overview

تم إضافة ميزات جديدة لتحسين تجربة إنشاء المنتجات باستخدام الذكاء الاصطناعي:
1. **قوالب احترافية** - إدراج قوالب جاهزة مع المتغيرات
2. **تقييم جودة البرومبت** - قياس جودة الوصف بواسطة الذكاء الاصطناعي
3. **تحسين الوصف القصير** - إرجاع خيار واحد فقط محسّن

New features have been added to enhance the AI product generation experience:
1. **Professional Templates** - Insert ready-made templates with variables
2. **Prompt Quality Scoring** - AI-powered quality measurement
3. **Short Description Improvement** - Returns only one improved option

---

## ✨ الميزات الجديدة | New Features

### 1️⃣ زر "إدراج قالب" | Insert Template Button

#### الموقع | Location
- صفحة AI Product Generator → Single Product
- صفحة AI Product Generator → Multiple Products

#### الوظيفة | Functionality
- يضيف قالباً احترافياً في منطقة النص (textarea)
- يحتوي على متغيرات قابلة للتخصيص مثل:
  - `[اسم المنتج]`
  - `[السعر]`
  - `[الكمية]`
  - `[الوزن]`, `[الطول]`, `[العرض]`, `[الارتفاع]`
  - `[اللون]`, `[الحجم]`, `[المادة]`

#### أنواع القوالب | Template Types

**قالب المنتج البسيط (Simple Product):**
```
منتج [اسم المنتج] متوفر بسعر [السعر] وبكمية [الكمية] في المخزون.

المواصفات:
- النوع: منتج بسيط
- السعر: [السعر] (السعر الأساسي: [السعر الأساسي])
- الكمية المتوفرة: [الكمية]
- حالة المخزون: متوفر
- الوزن: [الوزن] كجم
- الأبعاد: [الطول] × [العرض] × [الارتفاع] سم

الميزات:
- [ميزة 1]
- [ميزة 2]
- [ميزة 3]

الوصف التفصيلي:
[اكتب وصفاً تفصيلياً للمنتج هنا]
```

**قالب المنتج المتغير (Variable Product):**
```
منتج [اسم المنتج] متوفر بأشكال وأحجام متعددة.

التنويعات المتاحة:
- النوع: منتج متغير
- السمات: [اللون، الحجم، المادة]
- نطاق السعر: من [السعر الأدنى] إلى [السعر الأقصى]

التنويعات:
1. [اللون: أحمر] - [الحجم: صغير] - السعر: [السعر] - الكمية: [الكمية]
2. [اللون: أزرق] - [الحجم: متوسط] - السعر: [السعر] - الكمية: [الكمية]
3. [اللون: أخضر] - [الحجم: كبير] - السعر: [السعر] - الكمية: [الكمية]

المواصفات العامة:
- الوزن: [الوزن] كجم
- الأبعاد: [الطول] × [العرض] × [الارتفاع] سم
- المادة: [المادة]

الوصف التفصيلي:
[اكتب وصفاً تفصيلياً للمنتج وتنويعاته هنا]
```

**قالب المنتجات المتعددة (Multiple Products):**
```
[اسم المنتج الأول] | [السعر] | [الكمية]
[اسم المنتج الثاني] | [السعر] | [الكمية]
[اسم المنتج الثالث] | [السعر] | [الكمية]
```

---

### 2️⃣ زر "قياس الجودة" | Score Quality Button

#### الموقع | Location
- صفحة AI Product Generator → Single Product
- صفحة AI Product Generator → Multiple Products

#### الوظيفة | Functionality
- يقيم جودة البرومبت المُدخل بواسطة الذكاء الاصطناعي
- يعطي درجة من 0 إلى 100
- يوفر ملاحظات تحسينية باللغة العربية
- يعرض النتيجة في شريط تقدم ملون

#### معايير التقييم | Scoring Criteria
- الوضوح والدقة
- اكتمال المعلومات (السعر، الكمية، الميزات)
- التنظيم والهيكلة
- استخدام المتغيرات والعناصر النائبة
- اللغة الاحترافية
- التفاصيل التي تساعد على توليد منتج جيد

#### ألوان الدرجات | Score Colors
- 🔴 **أحمر (0-49%)**: جودة منخفضة - يحتاج لتحسين كبير
- 🟡 **أصفر (50-79%)**: جودة متوسطة - يحتاج لبعض التحسينات
- 🟢 **أخضر (80-100%)**: جودة عالية - ممتاز!

#### واجهة العرض | Display Interface
```
┌─────────────────────────────────────────────┐
│  Prompt Quality Score:               85%   │
│  ████████████████████░░░░░░░░           │
│  ✓ البرومبت ممتاز وواضح ويحتوي على     │
│    تفاصيل كافية لإنتاج منتج عالي الجودة  │
└─────────────────────────────────────────────┘
```

---

### 3️⃣ تحسين زر "تحسين الوصف القصير" | Short Description Improvement

#### التحسينات | Improvements
- **قبل**: كان يرجع أحياناً عدة خيارات (Option 1, Option 2...)
- **بعد**: يرجع خياراً واحداً فقط محسّناً

#### كيف يعمل | How It Works
1. يرسل نصاً أكثر تحديداً للذكاء الاصطناعي
2. ينظف النتيجة من أي ترقيم أو خيارات متعددة
3. يزيل المقدمات مثل "Here is..." أو "Option 1:"
4. يعيد النص المحسّن مباشرةً

---

## 📁 الملفات المُعدّلة | Modified Files

### 1. Frontend (Views)
```
views/admin-ai-generator-page.php
```
- أضيف زر "Insert Template" بجانب "Improve Description"
- أضيف زر "Score Quality"
- أضيفت منطقة عرض النتيجة أسفل textarea

### 2. JavaScript Files
```
assets/js/generate_products/prompt-template.js (جديد | NEW)
assets/js/generate_products/init.js
```
- **prompt-template.js**: ملف جديد يحتوي على:
  - القوالب الاحترافية
  - منطق إدراج القوالب
  - منطق قياس الجودة
  - عرض النتائج

### 3. Backend (Controllers)
```
controllers/class-aiwpg-products-controller.php
```
- أضيفت دالة `score_prompt_quality()` لقياس الجودة
- أضيفت دالة `clean_single_option()` لتنظيف الخيار الواحد
- حُدّثت دالة `improve_field()` لضمان إرجاع خيار واحد فقط

### 4. Styles (CSS)
```
assets/css/aiwpg-admin.css
```
- أضيفت styles لـ `.quality-score-container`
- أضيفت styles لـ `.quality-progress-bar`
- أضيفت styles للألوان (low, medium, high)
- أضيف تأثير shimmer للشريط

### 5. Admin Controller
```
controllers/class-aiwpg-admin-controller.php
```
- تم تسجيل ملف `prompt-template.js` في نظام التحميل

---

## 🔌 AJAX Endpoints

### جديد | New Endpoint
```
Action: aiwpg_score_prompt_quality
Method: POST
Parameters:
  - nonce: string
  - prompt: string (textarea)
  
Response:
  - score: integer (0-100)
  - feedback: string (Arabic)
  - message: string
```

---

## 🎨 الأنماط المضافة | Added Styles

### Quality Score Container
- تصميم أنيق بظلال وألوان تدرجية
- شريط تقدم ديناميكي مع تأثير shimmer
- ألوان تتغير حسب الدرجة
- نص الملاحظات بالعربية مع محاذاة يمينية

### Progress Bar Colors
```css
.quality-progress-fill.low    /* أحمر - Red */
.quality-progress-fill.medium /* أصفر - Yellow */
.quality-progress-fill.high   /* أخضر - Green */
```

---

## 🚀 كيفية الاستخدام | How to Use

### استخدام القوالب | Using Templates
1. اذهب إلى AI Product Generator
2. اختر نوع المنتج (Simple أو Variable)
3. اضغط على "Insert Template"
4. استبدل المتغيرات بالقيم الفعلية
5. اضغط "Generate Product"

### قياس الجودة | Scoring Quality
1. اكتب أو أدرج وصف المنتج
2. اضغط على "Score Quality"
3. انتظر ثوانٍ قليلة
4. شاهد الدرجة والملاحظات
5. حسّن البرومبت حسب الملاحظات
6. أعد القياس للتأكد من التحسين

### تحسين الوصف القصير | Improving Short Description
1. اذهب إلى Products List
2. اضغط Edit على أي منتج
3. اذهب إلى تبويب General
4. املأ حقل Short Description
5. اضغط على أيقونة الأدوات بجانب الحقل
6. سيتم إرجاع نص واحد محسّن فقط

---

## 🧪 الاختبار | Testing

### اختبار القوالب
✅ اختبر إدراج القالب البسيط
✅ اختبر إدراج القالب المتغير
✅ اختبر إدراج قالب المنتجات المتعددة
✅ اختبر الاستبدال vs الإلحاق

### اختبار قياس الجودة
✅ اختبر مع برومبت ضعيف (يجب أن يعطي < 50%)
✅ اختبر مع برومبت متوسط (يجب أن يعطي 50-79%)
✅ اختبر مع برومبت ممتاز (يجب أن يعطي >= 80%)
✅ اختبر عرض الملاحظات بالعربية

### اختبار تحسين الوصف القصير
✅ اختبر مع نص بسيط
✅ تأكد من إرجاع خيار واحد فقط
✅ تأكد من عدم وجود ترقيم أو "Option 1"
✅ تأكد من جودة النص المُحسّن

---

## 📊 الإحصائيات التقنية | Technical Stats

- **الملفات الجديدة**: 1 (prompt-template.js)
- **الملفات المُعدّلة**: 5
- **دوال PHP الجديدة**: 2
- **AJAX Endpoints الجديدة**: 1
- **CSS Classes الجديدة**: 8
- **أسطر الكود المضافة**: ~400+

---

## 🔮 تحسينات مستقبلية | Future Enhancements

### محتملة | Potential
- [ ] إضافة قوالب أكثر تنوعاً
- [ ] حفظ القوالب المخصصة من المستخدم
- [ ] مكتبة قوالب جاهزة حسب الفئات
- [ ] تقييم تفصيلي بمعايير منفصلة
- [ ] مقارنة بين نسختين من البرومبت
- [ ] اقتراحات تحسين تلقائية
- [ ] تصدير واستيراد القوالب

---

## 🛠️ المتطلبات التقنية | Technical Requirements

- WordPress 5.0+
- WooCommerce 3.0+
- PHP 7.4+
- jQuery 3.0+
- Google Gemini API Key

---

## 📝 ملاحظات المطور | Developer Notes

### هيكلة الكود | Code Structure
- الكود منظم ومعياري (Modular)
- استخدام namespace `window.AIWPG`
- فصل المنطق عن العرض
- استخدام AJAX لجميع الطلبات
- التعامل مع الأخطاء بشكل صحيح

### الأمان | Security
- استخدام nonce للتحقق
- فحص الصلاحيات (manage_woocommerce)
- تنظيف البيانات (sanitize)
- escape النصوص قبل العرض

### الأداء | Performance
- تحميل ذكي للملفات حسب الصفحة
- cache busting للتطوير
- استخدام CSS transitions بدلاً من JS animations
- تقليل عدد طلبات AJAX

---

## 🎯 الخلاصة | Summary

تم تنفيذ جميع الميزات المطلوبة بنجاح:
1. ✅ زر إدراج القالب مع قوالب احترافية
2. ✅ زر قياس الجودة مع واجهة عرض جميلة
3. ✅ تحسين زر الوصف القصير ليعطي خياراً واحداً فقط

All requested features have been successfully implemented:
1. ✅ Insert Template button with professional templates
2. ✅ Score Quality button with beautiful display interface
3. ✅ Improved Short Description button to return only one option

---

**تاريخ التطوير | Development Date**: 2025-11-25
**الإصدار | Version**: 1.0.0
**المطور | Developer**: AI Assistant with Cursor IDE

